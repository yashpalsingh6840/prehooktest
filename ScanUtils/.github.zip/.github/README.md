# soap-parity - SOAP service (repo1) vs repo2 parity check for GitHub Copilot

Answers, per SOAP operation: **does repo2 implement it fully, partially, or not at all?** It compares the request and response contract, DB access (including the SQL inside procedures and triggers), outbound HTTP/SOAP calls with their request/response fields, messaging, validations and business rules. The result is **one plain-language document**, `parity_out/<ServiceName>/parity_report.md`. It holds:

- the decisions to make;
- per operation, **what callers must change** when they move from the SOAP call to the REST endpoint. The move itself is planned, so where a field is now sent (URL path, query string, header or body) counts as a match, not a gap;
- per operation, the old and new call flows with a two-line explanation of every important method;
- links to the exact lines on GitHub or Azure DevOps.

## Why a script + a prompt (and not just a prompt)

Asking Copilot to "read both repos and compare" fails in a token-limited client environment. It runs out of context, skips files, and invents evidence. Here the work is split in two:

| Step | Who | Cost |
|---|---|---|
| Parse WSDL/XSD (imports, extensions, choices, restrictions), index both repos, trace each operation's call path, match fields/tables/procs/hosts/queues/constants | `soap_parity.py` (deterministic, local, Python stdlib only) | 0 tokens |
| Read one compact summary (`parity_summary.md`) and the logic packs, verify a capped review queue with ±15-line reads, write `review/<Op>.notes.json` (2 lines per method), `review/<Op>.md` (verdict, differences) and `review/_overall.md` (bottom line, decisions) | Copilot | small and bounded |
| Merge both into `parity_report.md` with call flows, external calls, DB objects and code links | `soap_parity.py --phase report` | 0 tokens |

## Layout

```
.github/
  README.md                            -> this file
  prompts/soap-parity-extract.prompt.md -> step 1: /soap-parity-extract (call flows, DB object list, SQL export script)
  prompts/soap-parity.prompt.md        -> step 2: /soap-parity (compare, review, final report)
  instructions/soap-parity.instructions.md -> workspace rule: SOAP parity requests always run the script (no hand-made analysis)
  skills/soap-parity-extract/SKILL.md  -> step 1 as an Agent Skill (/soap-parity-extract where prompt files are not read)
  skills/soap-parity/SKILL.md          -> step 2 procedure + report format (Agent Skill /soap-parity)
  skills/soap-parity/soap_parity.py    -> the extractor (single file, no pip install)
  skills/soap-parity/synonyms.example.json
samples/                               -> test fixtures next to .github (not needed on the client; self-test commands run from the folder holding both)
```

## Setup (client machine)

1. Copy the `.github` folder into the workspace you open in VS Code. That is usually a parent folder containing both repos, or repo2.
2. Check that Python 3.8+ is available: `python --version` (or `py -3 --version`). Nothing else is needed.
3. In Copilot Chat (Agent mode) run the two steps (details in "Two-step flow" below). Each takes the service (the `.svc` file path from repo1, or a WSDL URL or file), the repo2 path, optionally repo1 (defaults to the `.sln` folder above the `.svc`), optionally an operation, and optionally the web URLs of both repos for code links:
   1. `/soap-parity-extract`. You get `call_graph.md`, `db_objects.md` and `export_db_schema.sql`. Run that script in SSMS and save its output in the service folder's `db_schema\` sub-folder.
   2. `/soap-parity`. The SQL in `db_schema\` is read automatically. You get `parity_out/<ServiceName>/parity_report.md`.

   No SQL objects to review? Skip step 1 and run `/soap-parity` directly.
   - Both commands exist twice: as prompt files (`.github/prompts`) and as Agent Skills (`.github/skills/soap-parity-extract`, `.github/skills/soap-parity`). Some Copilot setups (Copilot CLI, VS Code with prompt files turned off) only register skills; the skills give the same two commands there.
   - If neither shows up, attach the step's `SKILL.md` to the chat and say "follow this skill".
   - **Check that the script really ran.** Copilot's reply starts with `Run id: <id> | folder: ...`. The same id is on the `run` line of `parity_out\diag.txt`. If the reply has no id, or a different one, Copilot did its own analysis instead of running the script. Discard that result and run again (a stronger model helps). Files in the folder that the script did not write (for example a hand-made `INDEX.md`) show up as `W-FOREIGN` on the card and are never used.
   - Older VS Code versions use `mode: 'agent'` instead of `agent: 'agent'` in the prompt front matter.

You can also run the script yourself and give Copilot only the summary. For large repos this is recommended: run it once in a terminal, then tell Copilot "already run" so it skips straight to reading the summary.

Using the `.svc` file from repo1. The contract is read from the WCF code, and repo1 defaults to the folder holding the `.sln`:

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl "D:\src\legacy\Quote.Web\QuoteService.svc" --repo2 "D:\src\new\Quotes.Api" -o GetQuote
```

Using a WSDL URL or a saved file:

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl "https://host/QuoteService.svc" --repo1 "D:\src\legacy" --repo2 "D:\src\new"
```

### Which input to use

| You have | Pass | Notes |
|---|---|---|
| The `.svc` file in repo1 | `--wsdl X.svc` | Works offline with no auth. The contract comes from `[ServiceContract]/[OperationContract]/[DataContract]/[DataMember(Name, IsRequired)]`, plus DataAnnotations (`[StringLength]`, `[Range]`, `[RegularExpression]`) and enums. Types that live only in a referenced DLL or NuGet package show as `UNRESOLVED` (`W-SVC`). |
| A reachable service URL | `--wsdl https://.../X.svc` | Tries `?singleWsdl`, then `?wsdl`. Brings XSD facets such as pattern, length and enumeration. |
| Both | `--wsdl <url or file> --svc X.svc` | WSDL contract plus the entry point pinned to the `.svc` class. This is the most accurate option. |

The repo2 path can be the sub-folder you think holds the match. It is faster and makes false endpoint matches less likely. If the match turns out to be elsewhere, the summary and `run.log` list the candidates.

Outputs: **one root folder `parity_out/`, with one sub-folder per service** (`parity_out/<ServiceName>/`, named after the `.svc`/WSDL file).
- Runs for single operations (`-o`) add to the same sub-folder. Its `diag.txt` and documents cover every operation analysed there.
- `parity_out/diag.txt` is always the card of the latest run.
- If the service, repo1 or repo2 path changes, the earlier results are moved to `_old_<time>/` inside the folder, so nothing is deleted. `--fresh` does the same on request.
- `--out <folder>` still works if you want a different place.

```
parity_out/
  diag.txt                      <- latest DIAG card (share this)
  FundTransferService/
    diag.txt, run.log           <- this service: one card for all its operations
    parity_report.md            <- THE final document
    call_graph.md, db_objects.md, export_db_schema.sql, extract_next_steps.md   (step 1)
    parity_summary.md, logic_<op>.md                                             (for Copilot)
    repo2_map.json              <- repo2 endpoints pinned by Copilot (re-used automatically)
    db_schema/                  <- save the SSMS export here (read automatically)
    review/                     <- Copilot's files: _overall.md, <Op>.md, <Op>.notes.json
    data/                       <- parity.json, contract.json, repo*_index.json, run_info.json, wsdl_cache/
```

| File | For | Contents |
|---|---|---|
| `diag.txt` | **sharing / troubleshooting** | The DIAG card (also printed at the end of every run) |
| `run.log` | troubleshooting | Full timestamped log: phases, every warning, skipped, slow and failed files, repo2 candidates with scores, crash traceback |
| `parity_summary.md` | the LLM (not for people - read `parity_report.md`) | Compact per-operation comparison and review queue (operations of the current run) |
| `parity_report.md` | you | The final report: reviewer text + call flows + external calls + DB objects + code links |
| `data/` | deep dives / re-runs | Full detail |

## Logs: what to share when something needs fixing

Every run, including failed runs and crashes, ends with a card like this in the terminal, in `parity_out/<ServiceName>/diag.txt` and in `parity_out/diag.txt`:

```
============================ SOAP-PARITY DIAG v1.5.16 full ============================
run    id 3f9a1c | 2026-11-19 21:44 | py 3.12.10 | Windows 11 | exit=0 | 0s | mem 43MB | jobs 8
folder parity_out/QuoteService  | this run all | folder 1 op(s)
input  mode=svc-code | contract=svc:QuoteService.svc | ops=1
       repo1=repo1 (auto from .svc) | repo2=repo2 | svcClass=QuoteService
phase  index-repo1 0.0s | contract-from-svc 0.0s | index-repo2 0.0s | analyze 0.0s | write 0.0s
repo1  seen 3 code 2 conf 0 xml 0 orm 0 | skip test 0+0d gen 0 big 0 fail 0 walkErr 0
       classes 7 methods 3 hits 4 tables 0 procs 0
repo2  seen 3 code 3 conf 0 xml 0 orm 0 | skip test 0+0d gen 0 big 0 fail 0 walkErr 0
       classes 9 methods 6 hits 4 tables 0 procs 0
--------------------------------------------------------------------------------------------
OPERATION / VERDICT / score   (2 lines per operation)
GetQuote                     PARTIAL          0.89  review 3
   r1 QuoteService.svc.cs:15 2files/3m | r2 QuoteController.cs:19 0.61 2files
   req 2/1/0/0  resp 5/0/0 unset 17  int 0/0  rules 1/1
legend: req/resp match/fuzzy/missing/unresolved | int match/missing | rules matched/total
summary parity_summary.md 4 KB ~ 1k tokens for Copilot
--------------------------------------------------------------------------------------------
WARNINGS none
links  r1 github @ 3f9c2a1b7e (commit) | r2 azure @ develop (arg)
docs   call_graph.md, db_objects.md, export_db_schema.sql (3 objects)
files  diag.txt run.log parity_summary.md logic_*.md call_graph.md
============================================================================================
```

Per operation: line 1 is the verdict, score and review-queue size. Line 2 shows the repo1 entry (files/methods on its call path, `CAP` if the 400-method limit was hit) and the chosen repo2 endpoint (score, files, `FORCED` if set with `--repo2-entry`). Line 3 has the counts. `unset` = response fields the legacy code never assigns (not counted as gaps).

- **Share a screenshot of this card, or paste `diag.txt`.** It is usually enough to diagnose the run. When I need more, I'll ask for specific lines from `run.log`, for example `findstr /C:"candidate" parity_out\<ServiceName>\run.log`.
- Absolute repo paths are replaced with `<repo1>`, `<repo2>` and `<home>` (use `--no-redact` to turn this off). Relative file paths, class and operation names do appear, so check them before sharing outside the client.
- On a crash (exit 3) the card shows the phase, the file or operation being processed, and the last code frames (`soap_parity.py:<line> in <function>`).

How to read the card:

| Symptom on the card | Likely cause / fix |
|---|---|
| `r1 NOT FOUND`, or `1files` | The entry method was not found, or DI/reflection hides the call path. Pass the `.svc` (`--svc`), or check `--repo1`. |
| `r2 NONE`, a low score, or the wrong endpoint | Re-run with `-o <op> --repo2-entry Class.Method` (or `path/File.cs:line`). The candidates and their scores are in `run.log` (`candidate` lines). |
| `r1 ... 98files/400m CAP` / `W-ENTRY ... over-broad` | The repo1 call path fans out through shared base classes or interfaces. Lower `--max-fanout` (default 6). The `slice file X <- Class.Method` lines in `run.log` show where it fans out. |
| Many `u` in `REQ m/f/x/u`, or `W-SVC ... not found in repo1 source` | DTOs are in a NuGet package or a DLL. Use the WSDL URL or file instead of the `.svc`. |
| `W-LIMIT ... skipped N file(s) over 1464 KB` | Huge generated files were skipped. Use `--max-file-kb 4000`. Big `*.designer.cs` files are always scanned for table and proc mappings. |
| `walkErr > 0` | Folders could not be listed (permissions, or paths longer than 260 chars). |
| `W-LINK ... not on the remote` / `links ... local files` | The links point to the branch, because the checked-out commit is not pushed. Or no web URL is known. Pass `--repoN-url` and/or `--repoN-ref <branch\|commit>`. |
| `W-SVC ... exist in several namespaces` | With a `.svc`, contract types are resolved like the compiler does: namespace-qualified name, then the file's own namespace and `using`s. If a name is still ambiguous (for example, the same class in a generated `Reference.cs` proxy), a hand-written `[DataContract]` class wins and the choice is in `run.log` (`ambiguous`). For a contract with no guesswork, pass the WSDL: `--wsdl <saved ?singleWsdl file> --svc <.svc>`. |
| `W-FOREIGN ... not written by soap_parity.py` | Files in the service folder that the script did not write, usually hand-made by an assistant that skipped the script. They are never used. Delete them, and make sure the reply starts with the card's run id. |
| `docs parity_report.md \| reviews 1/3 op(s)` / `W-REPORT` | Some `review/<Op>.md` files are missing, or `_overall.md` is missing. A review older than the latest analysis of its operation is kept, with a "may be out of date" note. A review file matching no operation is shown under "Other reviewer notes". Run `/soap-parity` again for the missing operations. |
| `method notes 3/40 used` | The keys in `review/<Op>.notes.json` don't match the `### old:Class.Method` headings in the logic packs. Copy them exactly. |
| `W-REPORT ... earlier results moved to _old_...` | The service, repo1 or repo2 path changed, so the folder started over. Earlier files are in `_old_<time>/`. |
| `fail > 0` (`W-INDEX-FAIL`) | A file could not be parsed. The traceback is in `run.log`. |
| A phase takes many minutes | Narrow `--repo2` and `--repo1`, and use `-o`. Check `slowest:` on the card. |

## Checklist after each step 1 run (before step 2)

Run these from the folder that holds `parity_out` and `.github`. Replace `<Service>` with the folder name, for example `FundTransferService`. Nothing below changes any file.

**1. Right version, script really ran, nothing foreign.** The card shows the version, the run id and any `W-FOREIGN`:
```powershell
Get-Content parity_out\<Service>\diag.txt -TotalCount 3
Select-String -Path parity_out\<Service>\diag.txt -Pattern "W-FOREIGN","^map"
```
Expected: the current version on line 1, the same `run id` as the first line of Copilot's reply, no `W-FOREIGN`, and a `map` line with `failed 0`.

**2. repo2 mapping done.** The `map` line should show `unmatched 0`, or only operations Copilot searched for and reported as `no repo2 counterpart found (searched: ...)`. Full repo2 paths for every mapped operation, and low-score matches marked CONFIRM:
```powershell
Select-String -Path parity_out\<Service>\extract_next_steps.md -Pattern "^- \*\*"
```

**3. Contract types resolved to the right classes.** With a `.svc`, the script reads the request/response classes from code. When several classes share a name (generated proxies, nested types), it logs the one it picked:
```powershell
Select-String -Path parity_out\<Service>\run.log -Pattern "svc type","ambiguous"
```
Each line reads `svc type <Name> -> <namespace>.<Name> in <file> (<n> same-named types)`. In Visual Studio, use Go To Definition on the operation's parameter and return types in the service interface. The namespace and file must match. If they don't, share these lines (type names and paths only, no source code). The certain alternative is the WSDL: open `https://<test host>/<Service>.svc?singleWsdl` in a browser, save it as a `.wsdl` file, and run with `--wsdl <file> --svc <.svc path>`.

**4. Signs of a wrong contract on the card.** To see the request/response field types the script read (type names only, no source code):
```powershell
python -c "import json;[print(o['name'],'| request:',[(f['name'],f['type']) for f in o['request']][:6],'| response:',[(f['name'],f['type']) for f in o['response']][:6]) for o in json.load(open(r'parity_out\<Service>\data\contract.json'))]"
```
These are worth step 3 above:
- `resp 0/0/1` where the old operation clearly returns an object (the response collapsed to one value). If the type above is `string`, `DataSet` or `XmlElement`, the old service returns serialized text or a DataSet: there are no fields to compare, and step 2 must compare how the content is built instead;
- request or response fields named `...Field` or starting with `_` (private fields of a generated class);
- a large jump in field counts between two runs with no code change.

**5. Skipped big file.** If the card shows `W-LIMIT`, see which file was skipped:
```powershell
Select-String -Path parity_out\<Service>\run.log -Pattern "skipped big file","big designer file"
```
A big LINQ to SQL `*.designer.cs` is still read for its table and proc mappings (`big designer file indexed for mappings only`). If the skipped file is ordinary code on a call path, add `--max-file-kb 4000` to the run.

**6. Old call flow cut short.** `r1 unresolved: ..._xxxService.Method` with only about 3 files means the old code hands over to an object the script can't find (often a client of another service):
```powershell
Select-String -Path parity_out\<Service>\run.log -Pattern "unresolved" | Select-Object -First 10
```

**7. Before step 2:** save the output of `parity_out\<Service>\export_db_schema.sql` (SSMS, read-only) as `parity_out\<Service>\db_schema\<database>.sql`.

What to share when something looks wrong: `parity_out\<Service>\diag.txt`, Copilot's reply, and the output of the commands above. None of it contains source code.

**All of the above, automatically.** Every run (step 1, step 2, report) refreshes **`parity_out\share_all.txt`**, so you normally run nothing extra: just share that file. To rebuild it by hand, run this from the folder that holds `parity_out` and `.github`:
```powershell
python .github/skills/soap-parity/soap_parity.py --collect
```
It writes **`parity_out\share_all.txt`** for all service folders at once: every DIAG card, the operations and their repo2 mappings (with CONFIRM marks), the request/response field types (with `!` on suspicious ones: private-field names, unresolved types, a response that is a single value), the `run.log` lines on type resolution, skipped files and unresolved calls, and which `db_schema\` and `review\` files exist. It only reads, and contains no source code. Share that one file plus Copilot's replies. Use `py -3` if `python` is not found.

## Token / credit efficiency in Copilot

What keeps Copilot's usage small:

| Measure | Effect |
|---|---|
| All extraction is done by the local script | Copilot never reads the repos broadly; the script costs 0 tokens |
| `--quiet` (used by the prompt) | Copilot's terminal output is only the DIAG card (about 25 lines), with no progress or warning spam |
| `parity_summary.md` is capped | `--max-rows 40`, `--max-rules 30`, `--max-review 25`. Operations with no repo2 match get a compact form of about 10 lines |
| `NOT_SET_IN_REPO1` | Response fields the legacy code never fills (often most of a big SOAP response) collapse to one line instead of one row each |
| Review queue ±15 lines per item | No whole-file reads |
| `--repo2-entry` re-run instead of manual reading | If Copilot finds the counterpart, it re-runs the script (cheap) instead of reading the code |
| The card shows `summary ... ~Nk tokens` | You can see the cost before Copilot reads the summary |

Tips: run per operation (`-o`); run the script yourself for big repos and tell Copilot "already run"; put confirmed renames in a synonyms file so the next summary is smaller.

## Large enterprise repos

- Source files are parsed in parallel (`--jobs`, default min(8, CPUs)). Measured on this machine: about 6,000 + 3,000 C# files, 42k classes and 100k methods took **81 s** with `--jobs 8` (261 s single-process). Peak memory was about 0.5 GB in the main process.
- Skipped automatically: `bin`, `obj`, `packages`, `node_modules`, `.vs`, test projects and test files (unless `--include-tests`), `*.g.cs`, `AssemblyInfo.cs`, `Resources/Settings.Designer.cs`, and source files over `--max-file-kb`.
- UTF-16 files (common in old Visual Studio projects) are decoded correctly.
- Bundled JavaScript libraries (`*.min.js`, jquery, angular, bootstrap, ...) and `bower_components` are skipped (`vendorJs` on the card).
- **Index cache:** the parsed index of each repo is saved under `%LOCALAPPDATA%\soap_parity_cache` and reused while no source/config file changed (the card shows `CACHED`). Re-runs per operation or with `--repo2-entry` then skip the re-parse. Use `--no-cache` to force a fresh parse; delete the folder to reclaim disk (roughly 10-15 KB per source file).
- **Same class names in different namespaces** (e.g. `QuoteService` in WebServices, ApplicationServices and Infrastructure): the call path follows only the class the calling file can see (`using`/`namespace`, Java `import`/`package`), and the `.svc` `Service="Full.Name"` pins the exact class.
- **Two classes with the same name calling each other** (a WCF `QuoteService` calling an ApplicationServices `QuoteService` through `Application.QuoteService _svc` or `using AppQuotes = ...QuoteService;`): namespace-qualified types and `using` aliases are resolved, and a field whose type has the caller's own name is never resolved back to the caller.
- If the repo1 call path still stops early, the card shows `r1 unresolved: Method._field.Call()` and `run.log` lists every call near the entry that could not be resolved.
- **WCF wrapper elements** (`GetQuoteResponse/GetQuoteResult/...`, `GetQuotes/requests/QuoteRequest[]`) are looked through automatically when matching repo2 DTOs; the summary notes `compared below SOAP wrapper element(s)`.
- Batch operations (SOAP request is a list) prefer repo2 endpoints that take a collection.
- Generated data contexts (LINQ to SQL / EF `DataContext`/`DbContext`, `*.designer.cs`): calling one method on them does not count every `Table<T>`/`DbSet<T>` they declare as used; only tables and procs used inside the reached methods count.
- Recommended for very large repos: run once per operation (`-o`), point `--repo1` at the service's solution folder, and point `--repo2` at the likely project folder.

## Two-step flow and the final report

The two steps exist because the tools in the client environment cannot connect to SQL Server, while you can.

**Step 1: `/soap-parity-extract`** (`--phase extract`, needs no database). The script writes these files to `parity_out/<ServiceName>/`:

| File | For | Content |
|---|---|---|
| `call_graph.md` | you | A preview, per operation: the old and new call flows (one line per method, with what the tool read from the code), external calls with request and response fields, DB objects, code links |
| `db_objects.md` | you | Every table, proc, view, function and trigger on the call paths: who uses it (old/new, read/write/exec), and whether its SQL definition has been seen |
| `export_db_schema.sql` | you, in SSMS | Read-only T-SQL with the object names filled in (details below) |
| `extract_next_steps.md` | Copilot | Operations without a repo2 endpoint. Copilot searches for each one, writes `repo2_map.json` and runs step 1 again (fast, the index is cached) |

`export_db_schema.sql` returns the CREATE scripts of the listed objects, plus up to three levels of what they depend on (procs called by procs, functions, views, tables) and the triggers on those tables:
- It only reads the catalog views and `OBJECT_DEFINITION`. It makes no temp tables and uses no dynamic SQL.
- It works on SQL Server 2008 or later and Azure SQL, with any collation, including case-sensitive.

To export:
1. Open it in SSMS, connect to the application database and press F5.
2. With **Results to Grid**, click a cell, press Ctrl+A, then Ctrl+C.
3. Paste into Notepad and save as UTF-8 in the service folder's `db_schema\` sub-folder, for example `parity_out\FundTransferService\db_schema\<database>.sql`. It is read automatically in step 2.
4. Check that the last line is `-- END OF EXPORT (...)`.

If the two repos use different databases, run the script in each one and save one file per database in `db_schema\`. Instead of SSMS you can also use sqlcmd:

```bash
sqlcmd -S <server> -d <database> -E -i parity_out\FundTransferService\export_db_schema.sql -o parity_out\FundTransferService\db_schema\<database>.sql -y 0 -f 65001
```

The script ends in rows that start with `--`:
- `-- NOT FOUND`: the object is in another database, or doesn't exist.
- `-- NO ACCESS`: the object is encrypted, or you lack `VIEW DEFINITION` permission.

**Step 2: `/soap-parity`** (`--phase full`, then `--phase report`; the SQL in `db_schema\` is read automatically):
1. The script does the full analysis. A `repo2_map.json` from step 1 is reused when the service, repos and operations are the same.
2. Copilot verifies the review queue and reads the logic packs, which hold the method code next to the script's `Facts:` and the SQL of the procs and triggers.
3. Copilot writes two small files:
   - `review/<Op>.notes.json`: two plain sentences per method;
   - `review/<Op>.md`: per operation, the verdict, what differs, the business-logic comparison and the gaps;
   - `review/_overall.md`: bottom line, decisions and glossary across all operations.
4. `--phase report` builds **`parity_report.md`**, the one document to read and share:
   - bottom line and decisions;
   - **suggested changes (all operations)**: one table, highest risk first, of the fixes Copilot proposes for every PARTIAL/DIFFERENT/MISSING finding. Each operation's chapter has the details: why, what to change, a short code sketch using names from the real code, and a "done when" check. A non-FULL review without suggestions gives `W-REPORT`;
   - an overview table;
   - per operation: the review; **What callers must change** (the consumer notice: new REST call, inputs that moved to the URL path / query string / header, renamed fields, type changes, and the inputs or data the new endpoint does not take or return); both call flows with Copilot's notes, external calls with request and response fields, and DB objects;
   - a DB appendix.

   References written as `old:path:line` / `new:path:line` become links. Every service has its own folder, and the folder starts over when its inputs change, so a report never mixes up two services. A review written before the latest analysis of its operation is shown with a "may be out of date" note.

**Code links.** Each repo needs a web URL and a ref:
- **Web URL:** taken from `--repo1-url` / `--repo2-url` (GitHub, GitHub Enterprise, Azure DevOps, GitLab or Bitbucket; a pasted `.../tree/<branch>/<folder>` URL is fine). Otherwise it is read from the repo's own git settings in `.git`, without running git. User names and tokens in the remote URL are never copied.
- **Ref:** taken from `--repoN-ref`. Otherwise it is the checked-out commit when that commit is on the remote, so links show exactly the code that was analysed. Otherwise it is the branch, with a `W-LINK` warning.
- **No web URL:** links are relative to the service folder, which opens the files in VS Code.

**What the call flows show.** Each line is **Class.Method**, then what it does, then a link. The "what it does" part combines:
- Copilot's two-line note;
- facts the tool reads from the code: `Rejects when <condition> -> <error>` (only when that `if` directly guards the `throw`), `Checks <condition>` (with constant values resolved), rounding, procs run and tables read or written, external calls, messages, caches and transactions;
- the developer's `/// <summary>` comment.

Interface calls with no implementation in the repo are marked as such. Constructors, logging helpers and one-line pass-throughs are folded into "+N small helper(s)". External calls show the HTTP verb and route, or the config key for the base URL, plus the request and response types with their fields. Concrete types of generic helpers such as `Get<List<OrderDto>>` are read from the calling line. Generated WCF clients (`ClientBase<T>`) show as SOAP calls with their operation, request and response.

## Database objects and deep business-logic review

**DB objects.** For every operation, the summary lists each table, view, stored procedure, function and trigger on either side's call path. Each one is marked `read`/`write`/`exec`, with `via proc X` or `via trigger on T` when it is reached through SQL. The status is `BOTH`, `ONLY_REPO1`, `ONLY_REPO2` or `BOTH_DIFFERENT_USE`. Objects used only by repo1 also go into the review queue.

To include **procedure logic and table columns**, give the SQL definitions in one of these ways:

| Way | How |
|---|---|
| SQL already in the repos | `.sql` files in the repos (for example an SSDT database project) are read automatically |
| Exported scripts (recommended) | Run `export_db_schema.sql` (step 1) in SSMS and save the output in the service folder's `db_schema\` (read automatically). Or use SSMS > Tasks > Generate Scripts for the objects in `data/db_objects_to_export.txt`. Scripts in other folders: `--db-scripts <folder>` |
| Pull from the database | `--db-server <server> --db-name <db>` runs `sqlcmd`, which must be installed, with **Windows authentication** (`-E`). It sends only read-only catalog queries (`sys.objects`, `sys.columns`, `OBJECT_DEFINITION`, `sys.sql_expression_dependencies`) and fetches only the objects the operations use, plus their dependencies (procs they call, tables they touch, triggers on written tables). The results are saved to `<service folder>/db_scripts/`. For a SQL login, add `--db-user <login>` and set the password yourself in the `SQLCMDPASSWORD` environment variable, never on the command line or in chat. It needs `VIEW DEFINITION` permission; encrypted procs are reported as not readable. |

The parser follows `EXEC` chains, lists the tables each procedure reads and writes, notes transactions and `RAISERROR`/`THROW`, collects logic lines (`CASE`, `IF`, `ROUND`, `DATEADD`, literal values), and reads table columns (type, nullable, default, identity, primary key).

**Deep review (on by default).** For each operation, `logic_<operation>.md` (in the service folder) puts the code a reviewer needs side by side:
- the repo1 entry method, then the methods on its call path with the most conditions, calculations, validations and data access, in call order;
- the same for repo2;
- the stored procedure, function and trigger bodies on the path;
- the columns of the tables involved.

The pack is capped by `--deep-lines` (default 600, about 8-10k tokens per operation). Copilot reads it once and fills the report's "Business logic comparison" table rule by rule: old behaviour, new behaviour, same?, risk, what to do. Use `--no-deep` (or `depth=quick` in the prompt) to save tokens.

**Pinning repo2 methods for many operations.** Use `--repo2-entry Operation=Class.Method` (repeatable), or a JSON map:

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl FundTransferService.wsdl --svc "...\FundTransferService.svc" --repo2 "C:\Projs\n600-FundTransferAPI" --repo2-map repo2_map.json --quiet
```

`repo2_map.json`: `{"SubmitISRFundTransferOrder": "src/FundTransfer.Api/Endpoints/FundTransfer.cs:73", "CalculateRRSPWithdrawalDetails": "FundTransferController.CalculateRrsp"}`

Value forms, most precise first:
- `path/File.cs:line`: the method, or the `MapPost(...)` line of a minimal-API endpoint (a lambda is selected exactly). The path may be partial (`Endpoints/FundTransfer.cs:73`).
- `Class.Method`: matched exactly first, then tolerantly. Class may be the file name (`ForeignExchange` → `ForeignExchange.cs`) or the class name without a `Controller`/`Endpoints`/`Module`/`Handler`/`Api`/`Service` suffix. For a minimal-API lambda, Method may be a word of its route.

A value that matches nothing gives `W-ENTRY ... repo2 pin X matched no method ...; closest: ...`, and the operation is listed under PIN FAILED in `extract_next_steps.md` with the closest endpoints, so it can be corrected.

## What it detects

| Area | .NET | Java / others |
|---|---|---|
| SOAP entry (repo1) | WCF `[ServiceContract]/[OperationContract]` (interface → implementation), ASMX `[WebMethod]`, `OperationContract(Name/Action)`, `*Async` suffix | JAX-WS `@WebMethod`, Spring-WS `@PayloadRoot` |
| repo2 entry | ASP.NET Core controllers (`[Route("api/[controller]")]`, `[HttpPost]`), Minimal APIs (`MapPost`), WCF/CoreWCF, MediatR `Send` → `IRequestHandler.Handle` | Spring MVC, JAX-RS, Express, FastAPI/Flask, Go `HandleFunc` |
| Contract | DTO properties, records, `[DataMember(Name)]`, `[JsonPropertyName]`, `[XmlElement]` wire names, enums, collections, list wrappers (`ArrayOfX`) | fields, records, `@JsonProperty`, `@XmlElement` |
| DB | **LINQ to SQL** (`.dbml`, `*.designer.cs` `[Table]/[Function]`, `Table<T>`, query syntax, `SubmitChanges`, `ExecuteQuery`), EF Core / EF6 (`DbSet`, `ToTable`, `[Table]`, `.edmx`), Dapper, ADO.NET (`SqlCommand`, `CommandType.StoredProcedure`) | JDBC, `SimpleJdbcCall`, JPA/JPQL (entity → table), MyBatis mappers |
| Outbound | `HttpClient` (incl. typed clients registered with `AddHttpClient<>` + config), RestSharp, WCF client proxies (`ClientBase<>`) | RestTemplate, WebClient, Feign, JAX-WS ports, OkHttp |
| Messaging | Service Bus, MassTransit, RabbitMQ, MSMQ | JMS, Kafka, Rabbit |
| Config | `web.config` appSettings/connectionStrings/endpoints, `appsettings*.json`, `IConfiguration["A:B"]`, `GetSection`, `GetConnectionString` | `.properties`, `.yml`, `${...}` / `@Value` |
| Validation | DataAnnotations, FluentValidation (`RuleFor` chains mapped onto DTO fields), guard clauses, `required` modifier, nullable reference types (`<Nullable>enable`) | Bean Validation, guards |
| Business rules | conditions/calculations on the call path; constants are resolved (`TaxRate` → 0.08) and compared by value with the repo2 path | same |

## Review notes: what makes this kind of comparison go wrong, and how this setup avoids it

1. **The SOAP URL alone is not enough.** The WSDL only describes the contract. DB calls, outbound integrations, validations and rules live in repo1's source, so always pass `--repo1`. Without it, only contract comparison is possible.
2. **The WSDL is often unreachable from the client machine.** WCF with Windows/NTLM auth, VPN or proxies are common causes. The script fails fast with exit code 2 and a hint. The fix is to save `…svc?singleWsdl` from a browser (a single file with all schemas inlined) and pass `--wsdl file`, or omit `--wsdl` so the script uses the WSDL inside repo1. Imports that fail to load fall back to local `.xsd` copies in repo1 or `--schema-dir`, matched by file name or namespace.
3. **Name drift between repos** (`customerId` vs `custId`, `items/item` vs `LineItems`): the script uses token, abbreviation and containment matching plus wire-name attributes, and reports these as `FUZZY` for confirmation. Confirmed pairs go into a synonyms file so the next run is cleaner.
4. **Comparing whole repos gives false matches.** A table used elsewhere in repo2 does not prove this operation uses it. The script traces the call path from each entry point, covering DI interface → implementation, constructors and `@PostConstruct`, and MediatR handlers. It then compares only what is reachable and reports `FOUND_ELSEWHERE` separately.
5. **Generated code hides the data layer.** LINQ to SQL and EF6 put mappings in `*.designer.cs`, `.dbml` and `.edmx`. Those files are indexed, not skipped.
6. **A facade can look like a full implementation.** If repo2 just calls the legacy SOAP service, the DTOs match 100%. The summary has a `CHECK` section when repo2 references the legacy service address or contains SOAP client code.
7. **Type drift is silent.** Examples are `xs:decimal` → `double` for money, `dateTime` → `DateOnly`, and a repeating element mapped to a single value. These are flagged as `WARN`/`MISMATCH`.
8. **LLM hallucination and token overrun:** the prompt allows reading only the summary plus ±15 lines per review item, caps the queue at 25 items per operation, requires `file:line` for every claim, and has a "Not verified" section in the report.
9. **Big services:** run with `-o <Operation>` per operation (or in batches) to keep each summary small.

## Limitations (heuristic tool)

- Parsing is regex-based, not compiler-based. Reflection, dynamic dispatch, DI registrations by convention, and code generated at build time can break the call path. When the slice looks too small, the review queue says so and Copilot should search.
- Business-rule matching compares literals/constants. Equivalent logic written differently (`* 0.9` vs `- 10%`) shows as `NOT_FOUND`/`REVIEW` and needs the LLM or a human to judge.
- Stored procedures, functions and triggers are analysed only when their SQL is provided (see "Database objects"). The analysis is regex-based: dynamic SQL (`EXEC(@sql)`, `sp_executesql`) is not followed.
- Request/response shapes of external calls come from declared types, not from captured traffic. A payload built field by field, for example an anonymous object or a dictionary, shows as "not detected".
- Method facts are conservative. A condition is reported as "Rejects when ..." only when the `if` directly guards the `throw`; otherwise the line just says "Throws ...".
- WSDL 1.1 is fully supported. WSDL 2.0 support is basic. EDMX parsing is best effort.

## Flags

`--wsdl` (WSDL URL/file or `.svc` file/URL), `--svc`, `--repo1`, `--repo2`, `-o/--operation` (repeatable), `--out`, `--list-ops`, `--schema-dir`, `--synonyms`, `--insecure`, `--timeout`, `--include-tests`, `--max-depth` (call-path depth, default 8), `--min-score` (repo2 endpoint match threshold, default 0.35), `--max-rows` (40), `--max-rules` (30), `--max-review` (25), `--all-rows`, `--jobs` (parallel parsing, default min(8, CPUs)), `--max-file-kb` (default 1464), `--repo2-entry` (force the repo2 method), `--max-fanout` (default 6), `--quiet`, `--no-cache`, `--no-redact`, `--repo2-map`, `--no-deep`, `--deep-lines` (600), `--db-scripts`, `--db-server`, `--db-name`, `--db-user`, `--db-trust-cert`, `--phase extract|full|report` (default full), `--fresh`, `--repo1-url`, `--repo2-url`, `--repo1-ref`, `--repo2-ref`, `--graph-nodes` (150), `--graph-depth` (6), `--collect [folder]` (write `share_all.txt` and exit).
Credentials: env vars `SOAP_PARITY_USER`/`SOAP_PARITY_PASSWORD` (Basic) or `SOAP_PARITY_HEADER="Authorization: Bearer …"`. Never put them on the command line.

## Self-test

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl samples/wsdl/quote.wsdl --repo1 samples/dotnet/repo1_l2s --repo2 samples/dotnet/repo2 --out parity_test
```

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl samples/dotnet/repo1/Legacy.Quote/QuoteService.svc --repo2 samples/dotnet/repo2 --out parity_test_svc
```

Expected (both commands): `GetQuote` is **PARTIAL**. Missing: `country`, `discountAmount`, `channel` and `taxAmount`; `totalPrice` decimal→double is flagged, and the 8% tax rule is `NOT_FOUND`. `CancelOrder` is **NOT_IMPLEMENTED**, with the proc (`USP_CANCELORDER` in the LINQ to SQL sample, `PKG_ORDER.CANCEL_ORDER` in the `.svc` sample), the `ORDERS` table and the `audit-queue` missing.

Enterprise-pattern case, `samples/dotnet/route_case`, mirrors a real WCF → REST migration:
- repo2 uses `GET v1/quote/{market}/{symbol}` returning `IActionResult` through a service, plus a batch endpoint `POST v1/quote/symbols`.
- The legacy response has 22 fields, but only 5 are ever set.
- A WCF wrapped WSDL is included.
- Four classes named `QuoteService` sit in different namespaces; one is an unrelated Reports class. The WCF class reaches the Application one through a namespace-qualified field (GetQuote) and a `using` alias (GetQuotes).

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl samples/dotnet/route_case/QuoteService.wsdl --svc samples/dotnet/route_case/repo1/Quotes.Wcf/QuoteService.svc --repo1 samples/dotnet/route_case/repo1 --repo2 samples/dotnet/route_case/repo2 --quiet --out parity_test_rc
```

Expected:
- `GetQuote` is PARTIAL, using `QuoteController.Get` (score about 0.80), with `resp 5/0/0 unset 17` and `LastPrice`/`PrevDayClose` flagged as decimal→double.
- `GetQuotes` is PARTIAL, using the batch endpoint `QuotesBatch.cs`, with `resp 5/0/0 unset 17`.
- The repo1 call path covers 5 files (WCF → Application → Infrastructure → generated DataContext); the Reports `QuoteService` and its `REPORT_AUDIT` table are not on it.
- The integrations are the MOD `/v2/delayed` call and the mutual-fund stored procedure `USP_GETMUTUALFUNDQUOTE`, both MISSING in repo2.
- None of the 60 tables declared on the generated `QuoteDataContext` (`Quotes.Data/QuoteData.designer.cs`) are listed: declaring a table is not using it.

Two-step flow sample, `samples/dotnet/wcf_patterns`: a WCF service vs an ASP.NET Core API. The API has an HTTP partner call, a generated WCF client, a generic HTTP helper, EF and a message publisher.

```bash
python .github/skills/soap-parity/soap_parity.py --phase extract --wsdl samples/dotnet/wcf_patterns/repo1/Svc.Web/FundTransferService.svc --repo2 samples/dotnet/wcf_patterns/repo2 --quiet --out parity_wcf
```

```bash
python .github/skills/soap-parity/soap_parity.py --phase report --wsdl samples/dotnet/wcf_patterns/repo1/Svc.Web/FundTransferService.svc --repo2 samples/dotnet/wcf_patterns/repo2 --quiet --out parity_wcf
```

Expected in `parity_wcf/call_graph.md`:
- SubmitOrder old: `Rejects when request.Amount > DailyLimit (DailyLimit = 25000)` and `Runs stored procedure USP_SUBMITTRANSFER`.
- SubmitOrder new: `Rejects when request.Amount > MaxAmount (MaxAmount = 50000)`, `Writes table TRANSFER_QUEUE`, plus three external calls:
  - `POST {Partner:BaseUrl}/v2/transfers` with `PartnerTransferRequest {...}` → `PartnerTransferResponse {...}`;
  - SOAP `FxRateServiceClient.GetRate`;
  - a published `TransferCreated` message.
- `IMessagePublisher.Publish` is marked "Interface only".
- GetOrders new: `GET /v1/orders/ (from caller)` returning `[ OrderDto {...} ]`.

The second command writes `parity_wcf/parity_report.md`. It warns `W-REPORT ... built without reviewer text`, because no `review/` files were written.
