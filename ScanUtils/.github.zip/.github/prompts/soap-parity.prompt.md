---
description: 'SOAP parity STEP 2: compare a legacy SOAP/WCF operation (repo1) with repo2 - contract, DB objects and their SQL, outbound calls, messaging, validations and a deep business-logic review - and produce ONE plain-language report (parity_out/<Service>/parity_report.md) with call flows and code links. Run /soap-parity-extract first when the DB schema is needed.'
agent: 'agent'
argument-hint: 'service=<.svc file | WSDL url/file> repo2=<path> [repo1=<path>] [operation=<name>] [repo2entry=<Class.Method>] [dbscripts=<folder>] [repo1url=<web URL>] [repo2url=<web URL>] [depth=quick]'
---

# SOAP parity - step 2: compare and report (token-budgeted)

Inputs (ask once for a missing required one, do not guess; optional ones may stay empty). Use the SAME service/repo inputs as step 1:
- Service: ${input:service:Path to the .svc file in repo1, OR WSDL URL / .wsdl file}
- repo2 (prefer the solution root so dependent projects are included): ${input:repo2:Path to repo2}
- repo1 (optional with a .svc - defaults to the .sln folder): ${input:repo1:Path to repo1 or leave empty}
- Operation (optional - empty = all operations in one run): ${input:operation:Operation name or leave empty for all}
- repo2 entry (optional): ${input:repo2entry:Class.Method or leave empty}
- Extra SQL scripts folder (optional; `FOLDER/db_schema` is read automatically): ${input:dbscripts:Folder or leave empty}
- Code links (optional): ${input:repo1url:repo1 web URL or leave empty} / ${input:repo2url:repo2 web URL or leave empty}
- Depth: ${input:depth:deep (default) or quick}

**Output folder:** ONE folder per service, `parity_out/<ServiceName>` (DIAG card line `folder`; FOLDER below). Never pass
`--out`, never create other folders. A run with `-o` adds that operation to FOLDER; the report and `diag.txt` always
cover every operation in FOLDER. `FOLDER/repo2_map.json` from step 1 is re-used automatically.

**HARD RULES (non-negotiable - a run that breaks one is invalid):**
1. Your FIRST action is running the command in step 1 in the terminal. Do not open, search or read any repo1/repo2 file before it has finished successfully.
2. Never do the analysis yourself and never write documents by hand (`INDEX.md`, `diag.txt`, `parity_report.md`, summaries). They come ONLY from the script. The only files you may write are `FOLDER/repo2_map.json` and the files under `FOLDER/review/`.
3. If the script cannot run (python not found, error, exit code not 0): STOP, show the error and the DIAG card, ask the user to share `parity_out/diag.txt`. Never fall back to analysing the code yourself.
4. Proof: the first line of your reply is `Run id: <id> | folder: <folder line>` copied exactly from the last DIAG card (the report run). No id = you did not run the script.
5. `W-FOREIGN` on the card = files in FOLDER the script did not write. Name them and ask the user to delete them; never use them.

Follow `.github/skills/soap-parity/SKILL.md`. Budget rules: two script runs (analysis + report; a third only for the repo2 map), read only `FOLDER/parity_summary.md` (it covers the operations of THIS run) and - in deep mode - `FOLDER/logic_<operation>.md`, at most 25 review items per operation, ±15 lines per extra read, no whole-file reads, no browsing of the repos. Never put a password or connection string on the command line or in chat.

1. **Analyse**:
   ```
   python .github/skills/soap-parity/soap_parity.py --wsdl "<service>" --repo2 "<repo2>" [--repo1 "<repo1>"] [-o <operation>] [--repo2-entry <Class.Method>] [--db-scripts "<dbscripts>"] [--repo1-url "<repo1url>"] [--repo2-url "<repo2url>"] [--no-deep if depth=quick] --quiet
   ```
   Use `py -3` if `python` is missing. Quote paths. Omit empty options. Wait for it to finish; never start it twice.
2. Exit code 2/3: show the ERROR/HINT and the DIAG card, ask the user to share `parity_out/diag.txt`, stop.
3. Read only `FOLDER/parity_summary.md`. Report DIAG warnings (`W-FOREIGN`, `W-SVC`, `W-ENTRY`, `W-LIMIT`, `W-DB`, `W-LINK`, `W-REPORT`, `W-INDEX-FAIL`, `W-XSD-*`) first.
4. If an operation says **"No repo2 endpoint matched"**: do its single search, add the counterparts to `FOLDER/repo2_map.json` as `{"Operation": "path/File.cs:line"}` - copy a listed candidate (`path:line`) when it is the counterpart, else the file and line of the method or `MapPost(...)` line you found; never guess class names. Fix entries marked PIN FAILED using the "Closest" list (all such operations at once, keep the other entries) and re-run step 1 of this prompt once. Do not compare code by reading it yourself.
5. Verify only the "LLM review queue" items (max 25 per operation: the field table rows plus the numbered items; full paths are in its "Files:" line), one ±15-line read per reference. `NOT_SET_IN_REPO1` fields are not gaps.
6. **Deep review** (default; skip if depth=quick): read `FOLDER/logic_<operation>.md` once per operation and compare the business logic rule by rule (SKILL.md section 4). repo2 is a planned REST replacement: compare information and behaviour, not transport. SOAP vs REST, route/verb, where an input is sent (URL path, query, header, body - the same field in any place is SAME), name casing and SOAP fault vs HTTP status are NOT differences and carry no risk (the script lists them for consumers under "What callers must change"); never ask whether a SOAP facade is needed. Differences are: inputs not taken at all, data not returned, changed meaning/precision/rules/validation/error conditions/data source/side effects (SKILL.md "REST migration rules").
7. For EACH operation of this run write (SKILL.md 4a/4b; `<Op>` = operation name, characters other than letters, digits, `.`, `-`, `_` replaced by `_`):
   - `FOLDER/review/<Op>.notes.json` - two plain sentences per method of its logic pack, keys exactly as the `### old:...` / `### new:...` headings;
   - `FOLDER/review/<Op>.md` - the verdict line and the review of that operation, ending with **Suggested changes in repo2**: a table row plus a block (why, change, short code sketch using only names seen in the code, done-when check) for EVERY DIFFERENT/MISSING/PARTIAL finding of risk HIGH or MEDIUM (SKILL.md 4b). A PARTIAL verdict without suggested changes is incomplete.
   Then write or update `FOLDER/review/_overall.md` (bottom line, decisions, glossary - across ALL operations in FOLDER). Do not touch other operations' files.
8. **Build the report**: run the command from step 1 again with `--phase report` added and WITHOUT `-o`. It writes `FOLDER/parity_report.md` for all operations in FOLDER. Check the card line `docs ... reviews N/M op(s) | method notes X/Y used`; fix file names/keys if needed and run `--phase report` again. Do not read the report back.
9. Reply: first line `Run id: <id> | folder: <folder line>` from the last card; then the bottom line, the overview (operation - verdict - one line), the suggested changes (operation - # - change - risk - effort, one line each), the decisions needed, and the last line `Read: FOLDER/parity_report.md (parity_summary.md and logic_*.md are working files for Copilot, not for people).`
