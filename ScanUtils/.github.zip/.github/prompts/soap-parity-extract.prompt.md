---
description: 'SOAP parity STEP 1 (no database access needed): map each SOAP/WCF operation to its repo2 endpoint, draw the old and new call flows, list the DB objects (procs, tables) and create a read-only SSMS script the user runs to export their SQL. Step 2 is /soap-parity.'
agent: 'agent'
argument-hint: 'service=<.svc file | WSDL url/file> repo2=<path> [repo1=<path>] [operation=<name>] [repo2entry=<Class.Method>] [repo1url=<web URL>] [repo2url=<web URL>]'
---

# SOAP parity - step 1: extract (token-budgeted)

Inputs (ask once for a missing required one, do not guess; optional ones may stay empty):
- Service: ${input:service:Path to the .svc file in repo1, OR WSDL URL / .wsdl file}
- repo2 (prefer the solution root so dependent projects are included): ${input:repo2:Path to repo2}
- repo1 (optional with a .svc - defaults to the .sln folder): ${input:repo1:Path to repo1 or leave empty}
- Operation (optional - leave empty to do all operations in one run): ${input:operation:Operation name or leave empty for all}
- repo2 entry (optional): ${input:repo2entry:Class.Method or leave empty}
- Code links (optional, e.g. https://github.com/org/repo): ${input:repo1url:repo1 web URL or leave empty} / ${input:repo2url:repo2 web URL or leave empty}

**Output folder:** the script always uses ONE folder per service, `parity_out/<ServiceName>` (shown on the DIAG card's
`folder` line; called FOLDER below). Never pass `--out` and never create other `parity_out_*` folders. Runs for single
operations add to the same FOLDER; one `diag.txt` covers all of them.

**HARD RULES (non-negotiable - a run that breaks one is invalid):**
1. Your FIRST action is running the command in step 1 in the terminal. Do not open, search or read any repo1/repo2 file before it has finished successfully.
2. Never do the analysis yourself and never write documents by hand (`INDEX.md`, `diag.txt`, call flows, DB lists, summaries). They come ONLY from the script. The only file you may write is `FOLDER/repo2_map.json`.
3. If the script cannot run (python not found, error, exit code not 0): STOP, show the error and the DIAG card, ask the user to share it. Never fall back to analysing the code yourself.
4. Proof: the first line of your reply is `Run id: <id> | folder: <folder line>` copied exactly from the last DIAG card. No id = you did not run the script.
5. Step 1 gives NO verdicts: never call an operation NOT_IMPLEMENTED, MISSING, PARTIAL or done. An operation with `0files` or `r2 NONE` on the card is UNMAPPED (repo2 not followed yet), not "not implemented"; the card's verdict words are provisional.
6. You may not reply before step 3 is done for every operation listed in `extract_next_steps.md`. A summary of the first script run alone is invalid.

Budget: you read ONE small file (`FOLDER/extract_next_steps.md`) plus the repo2 searches of step 3 (±15 lines per hit). Never open `call_graph.md`, `db_objects.md` or the SQL script - they are for the user. No other browsing of the repos.

1. **Run**:
   ```
   python .github/skills/soap-parity/soap_parity.py --phase extract --wsdl "<service>" --repo2 "<repo2>" [--repo1 "<repo1>"] [-o <operation>] [--repo2-entry <Class.Method>] [--repo1-url "<repo1url>"] [--repo2-url "<repo2url>"] --quiet
   ```
   Use `py -3` if `python` is missing. Quote paths. Omit empty options. Wait for it to finish; never start it twice.
2. Exit code 2/3: show the ERROR/HINT and the DIAG card, ask the user to share `parity_out/diag.txt`, stop.
3. **Map repo2 (MANDATORY - step 1 is not finished without it).** Read `FOLDER/extract_next_steps.md`. For EVERY operation under **"For Copilot: operations without a repo2 endpoint"** (also PIN FAILED ones): (a) use a listed candidate (`path:line`) if it is the counterpart; (b) otherwise search repo2 (the listed nouns/fields and REST-style names), at most ±15 lines per hit to confirm. Batch-style operations (`Process...`, `Run...`, `Recover...`, `...Queued...`, `...Postdated...`) are usually background jobs in repo2, not HTTP endpoints: also search for `BackgroundService`, `IHostedService`, `IJob` (Quartz), `RecurringJob`/`BackgroundJob` (Hangfire), `[Function]`/`TimerTrigger`/`ServiceBusTrigger` (Azure Functions), queue consumers (`IConsumer<`, `ProcessMessageAsync`), and pin the job's `Execute`/`Run`/`ExecuteAsync` method with `path:line`. If repo2 has no job project, say so: the job may live in another repo.; (c) write each counterpart you are reasonably sure of to `FOLDER/repo2_map.json` as `{"Operation": "path/File.cs:line"}` - never guess class names; keep the other entries, replace PIN FAILED ones. (d) under "Operations already mapped to repo2", check each match marked CONFIRM - auto or pinned, also re-used pins (±15 lines; say what the method does); pin the right one if it is wrong. Re-run the SAME command once if you changed `repo2_map.json` (the map is picked up automatically) and check the card's `map` line (`failed 0`; `unmatched` only for operations you searched and did not find). Do not compare code yourself.
4. Reply in at most ~15 lines:
   - line 1: `Run id: <id> | folder: <folder line>` from the LAST card;
   - line 2: the card's `map` line, copied exactly;
   - per operation: `mapped -> <full path:line from extract_next_steps.md> (auto / pinned; sure / likely)` or `no repo2 counterpart found (searched: <terms>)`;
   - DIAG warnings (codes + one line each), if any;
   - for the user: open `FOLDER/call_graph.md` and `FOLDER/db_objects.md`; run `FOLDER/export_db_schema.sql` in SSMS (read-only; Results to Grid, Ctrl+A, Ctrl+C) and save the result as `FOLDER/db_schema/<database>.sql` - it is picked up automatically;
   - next step: `/soap-parity` with the same inputs;
   - last line: `To share the results: parity_out/share_all.txt (updated by every run).`
