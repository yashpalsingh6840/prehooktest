---
name: soap-parity
description: SOAP parity STEP 2 - runs the bundled script soap_parity.py (never analyse the code by hand). Compare a legacy SOAP service (repo1, WSDL URL, file or .svc) with another codebase (repo2) and report whether each operation is fully, partially or not implemented - request/response contract, DB objects and their SQL, outbound HTTP/SOAP calls with request/response shapes, messaging, validations and business rules - as one plain-language report with call flows and code links. Use when asked to check SOAP-to-REST/.NET/Java migration parity or "does repo2 cover this SOAP service".
---

# SOAP parity skill

The script `soap_parity.py` (this folder, Python 3.8+, standard library only) does all extraction deterministically.
**Your job is only to run it, read its compact summary, verify the short review queue, and write two small files
(method notes + your review); the script then builds the one final document.**
Never read the repositories broadly - that wastes tokens and is less accurate than the script.

## HARD RULES (non-negotiable - a run that breaks one is invalid)
1. **Your FIRST action is running the script (section 1) in the terminal.** Do not open, search or read any file of
   repo1/repo2 before it has finished successfully. Later reads are only the ±15-line checks of the review queue.
2. **Never do the analysis or write documents yourself.** Summaries, call flows, DB object lists, logic packs and
   `parity_report.md` come ONLY from the script. Never write `INDEX.md`, `diag.txt`, `parity_report.md` or any other
   document by hand. The only files you may write are `FOLDER/repo2_map.json` and the files under `FOLDER/review/`
   (`<Op>.notes.json`, `<Op>.md`, `_overall.md`); the script turns them into the report.
3. **If the script cannot run** (python not found, error, exit code not 0), STOP: show the error and the DIAG card (if
   any) and ask the user to share `parity_out/diag.txt`. Do NOT fall back to reading the code and comparing it yourself.
4. **Proof:** the first line of your reply is `Run id: <id> | folder: <folder line>` copied exactly from the LAST card
   (the `--phase report` run). `parity_summary.md` shows the run id of the analysis run. If you do not have an id, you
   did not run the script - go back to rule 1.
5. A `W-FOREIGN` warning means files in FOLDER were not written by the script (often by an earlier assistant). Name
   them in your reply and ask the user to delete them; never use their content.

**One folder per service.** Without `--out` (never pass it) everything goes to `parity_out/<ServiceName>` (FOLDER;
the DIAG card's `folder` line). Runs with `-o` for single operations ADD to FOLDER: the documents and the one
`diag.txt` cover every operation analysed there; `parity_summary.md` and `logic_*.md` are rewritten for the operations
of the current run. `parity_out/diag.txt` is always the latest card. If the service/repo1/repo2 change, earlier results
are moved to `FOLDER/_old_<time>/` (nothing is deleted); `--fresh` does the same on request.
Layout: `diag.txt`, `run.log`, `parity_report.md`, `call_graph.md`, `db_objects.md`, `export_db_schema.sql`,
`extract_next_steps.md`, `parity_summary.md`, `logic_<op>.md`, `repo2_map.json`, `db_schema/` (user's SQL export,
read automatically), `review/` (your files), `data/` (json for tools).

Two-step flow (`--phase`):
| Step | Command | Script writes | You do |
|---|---|---|---|
| 1 `extract` (no DB needed) | `/soap-parity-extract` | `extract_next_steps.md` (for you), `call_graph.md`, `db_objects.md`, `export_db_schema.sql` (for the user) | map unmatched operations (`repo2_map.json`), tell the user to run the SQL export and save it in `FOLDER/db_schema/` |
| 2 `full` (default) | `/soap-parity` | `parity_summary.md`, `logic_<op>.md` | verify queue, deep review, write `review/<Op>.notes.json`, `review/<Op>.md`, `review/_overall.md` |
| 2b `report` | `/soap-parity` (last step, no `-o`) | `parity_report.md` = the ONE document for the human | nothing - do not read it back |
Step 1 is its own skill, `.github/skills/soap-parity-extract/SKILL.md` (`/soap-parity-extract`; it runs this folder's
script). If the user invokes `/soap-parity` but asks for step 1 / "extract" only, follow that file instead of the steps below.
`repo2_map.json` in FOLDER is re-used automatically. A review file older than the latest analysis of its operation is
still shown, with a "may be out of date" note.

## 1. Run

```
python .github/skills/soap-parity/soap_parity.py --wsdl "<.svc file | wsdl url | wsdl file>" --repo2 "<repo2>" [--repo1 "<repo1>"] [-o <op>] [--repo2-entry <Class.Method>] --quiet
```

What `--wsdl` accepts:
| Input | What happens |
|---|---|
| `...\MyService.svc` (file in repo1) | Reads `Service="..."` from the .svc, finds that class and its `[ServiceContract]` interface in repo1, and builds the contract from `[OperationContract]` + `[DataContract]/[DataMember]` code. repo1 defaults to the folder with the `.sln` above the .svc. The repo1 entry point is pinned to that class. |
| `https://host/MyService.svc` | Fetches `?singleWsdl`, then `?wsdl` |
| `service.wsdl` / `?wsdl` URL | Parses the WSDL + imported XSDs (the XSD facets give richer validation checks) |
| (omitted) | The largest `*.wsdl` in repo1, else the only `*.svc` in repo1 |
Use `--wsdl <wsdl> --svc <file.svc>` together to get the WSDL contract and the pinned entry class.

Options to use when relevant:
| Situation | Add |
|---|---|
| Many operations (> 5) or a big summary | `-o <OperationName>` (repeatable) - one run per operation or group; all go into the same FOLDER (never use another `--out`) |
| Only want the operation list | `--list-ops` |
| Large repos | narrow `--repo2` to the sub-folder that likely holds the match; set `--repo1` to the service's solution folder instead of a monorepo root; `-o` per operation |
| WSDL URL unreachable / needs Windows auth / VPN | pass the `.svc` file instead, or save `<url>?singleWsdl` from a browser and pass `--wsdl <file>` |
| Imported XSDs are in another folder | `--schema-dir <folder>` |
| Self-signed TLS on the WSDL host | `--insecure` |
| Known renames between repos (custId vs customerId) | `--synonyms synonyms.json` (see `synonyms.example.json`) |
| Test code should count | `--include-tests` |
| Process creation blocked / low memory | `--jobs 1` |
| Repos changed but results look stale / want a clean parse | `--no-cache` (the index is otherwise reused while no file changed) |
| Stored-procedure / table definitions are not in the repos | `--db-scripts <folder>` (SSMS Generate Scripts output), or `--db-server <server> --db-name <db>` (sqlcmd, Windows auth, read-only catalog queries; SQL login: `--db-user` + env `SQLCMDPASSWORD`) |
| Save tokens: skip the deep business-logic review | `--no-deep` (deep is on by default; logic pack about 600 lines per operation) |
| Huge generated source files skipped (`W-LIMIT`) | `--max-file-kb 4000` |
| You know (or found) the repo2 method that implements the operation | `-o <op> --repo2-entry Class.Method` (or `path/File.cs:line`) |
| repo1 call path is huge (card `r1 ... 98files`, `W-ENTRY ... over-broad`) | lower `--max-fanout` (default 6) or `--max-depth` (default 8) |
| Copilot is running it | always add `--quiet` (console = DIAG card only) |
| Code links in the documents (GitHub, GitHub Enterprise, Azure DevOps, GitLab, Bitbucket) | `--repo1-url <web URL> --repo2-url <web URL>` (default: the git remote of the checkout; credentials are never copied). Pin with `--repo1-ref/--repo2-ref <branch|commit>` (default: the checked-out commit when it is pushed, else the branch) |
| Call flows too long / too deep in the documents | `--graph-nodes 150` / `--graph-depth 6` (defaults) |

Credentials for the WSDL URL go in env vars `SOAP_PARITY_USER` / `SOAP_PARITY_PASSWORD` or `SOAP_PARITY_HEADER` - never on the command line, never in chat.

Exit code 2 = bad input (missing file/folder, unknown operation, no operations found), 3 = script crash. Show the ERROR/HINT lines and the DIAG card, ask the user to share `parity_out/diag.txt` (always the latest card), and stop. Do not try to parse the WSDL or the repos yourself.

### Diagnostics (every run)
- Console + `FOLDER/diag.txt` (copy: `parity_out/diag.txt`): the **SOAP-PARITY DIAG card**, one per service folder, covering all its operations (about 25 lines; repo paths are redacted to `<repo1>`/`<repo2>`). It is the thing to share when something looks wrong.
- `FOLDER/run.log`: the full timestamped log (every warning, slow and skipped files, candidate endpoints with scores, crash tracebacks).
- Warning codes on the card: `W-SVC` (.svc class/contract problem), `W-ENTRY` (repo1 entry or repo2 endpoint not found, or tiny call path), `W-WSDL-LOAD`, `W-XSD-UNRESOLVED`, `W-XSD-NS`, `W-INDEX-FAIL` (file could not be parsed), `W-LIMIT` (big files skipped, unreadable folders, parallel fallback), `W-DB`, `W-LINK` (code links: no git info / commit not pushed / bad URL), `W-REPORT` (review files missing / older than the analysis / matching no operation; earlier results moved after an input change), `W-FOREIGN` (files in the folder the script did not write - e.g. hand-written by an assistant; never used), `E-INPUT`, `E-CRASH`.
- Card lines `links` (where code links point), `docs` (documents written; in the report step: `llm review yes/MISSING`, `method notes used/given`), `map` (repo2_map.json re-used).

## 2. Read

Read only `FOLDER/parity_summary.md` (operations of this run). Meaning of statuses:
- Contract: `MATCH` same normalized name; `FUZZY` similar name (confirm); `MISSING`; `MISSING(parent)`; `UNRESOLVED` (type not found in repo2); `NOT_SET_IN_REPO1` (response field the legacy code never assigns - not a gap, do not report); `/WARN` or `/MISMATCH` type issues (e.g. xsd decimal -> double).
- Integrations: `MATCH`; `FOUND_ELSEWHERE` (exists in repo2 but not reachable from the matched endpoint - may be dead code or a different flow); `MISSING`; `EXTRA_IN_REPO2`.
- Validation: `GAP`; `CHECK_IMPERATIVE` (a code check mentions the field); `IMPLICIT_NRT` (C# non-nullable reference type - only enforced if `[ApiController]` + nullable context; confirm).
- Business rules: `LITERALS_IN_REPO2_SLICE` (same constants found on the repo2 path), `LITERALS_ELSEWHERE_IN_REPO2`, `PARTIAL`, `NOT_FOUND`, `REVIEW` (no literal to compare - needs reading).
- Auto verdicts are heuristics: `FULL (verify)`, `PARTIAL`, `MOSTLY_MISSING`, `NOT_IMPLEMENTED`, `PARTIAL (DTOs exist, no endpoint found)`.

If an "Extraction warnings" section exists (or the DIAG card shows warnings), report it to the user first. If a "CHECK: repo2 has SOAP-client calls..." section exists, check whether repo2 is only a facade over the legacy service (that changes the verdict).

## 3. Verify (token budget)

For each operation, work only through its "LLM review queue" (stop after 25 items; say how many were skipped). It is grouped:
a field table (rows with "name differs" = the `CONFIRM name mapping` check, rows with a type note = the `TYPE` check), then numbered
lists for tables/procedures/external systems (`INTEGRATION`), database objects (`DB`), business rules (`RULE`) and input checks
(`VALIDATION`). Short file names are expanded in the "Files:" line under the queue - open that full path:
- Open only the referenced line range ±15 lines. One read per reference. No full files.
- `RULE ...` items: understand the repo1 rule, then search for the equivalent concept (identifier, constant, keyword) only inside that operation's "repo2 reachable files". Classify: `SAME`, `DIFFERENT` (state the difference: formula, rounding, threshold, order), `MISSING`.
- `CONFIRM name mapping`: confirm the fields carry the same data (check wire names, e.g. `[JsonPropertyName]`, `[DataMember(Name)]`).
- `INTEGRATION ... MISSING/FOUND_ELSEWHERE`: one search in repo2 for the table/proc/host/queue name; check it is not reached via config, a different repository class, or a message handler.
- `VALIDATION`: check repo2 for the equivalent rule (DataAnnotations, FluentValidation, guard clauses, model binding).
- `TYPE`: decide if the drift is harmful (money in double = harmful; DateTime vs DateTimeOffset = check time zone semantics).
Do NOT re-check rows already marked MATCH, and do not hunt for new problems outside the queue unless the user asks.

**No repo2 endpoint matched** (compact section in the summary): do the one search it asks for, for every such operation. Collect the counterparts in `FOLDER/repo2_map.json` as `{"Operation": "path/File.cs:line"}` - copy a listed candidate (`path:line`) when it is the counterpart, else the file and line of the method or `MapPost(...)` line you found; never guess class names. Fix entries marked PIN FAILED using the "Closest" list (keep the other entries) and re-run the same command ONCE (the map is picked up automatically) instead of comparing the code by reading it - the re-run costs a few hundred tokens, manual reading costs tens of thousands and misses DB/rule/validation checks. The index cache makes the re-run fast.

## 4. Review and write your two files (the script builds the report)

The reader of the final report is a person deciding whether repo2 can replace the SOAP service. They may not know either
codebase. You write only judgement and plain-language explanations; the script adds the call flows, external calls with
request/response fields, DB objects, the overview table and all code links. Never write those parts yourself.

### Deep review (from `FOLDER/logic_<operation>.md`)
Compare behaviour, rule by rule: conditions/branches, calculations (formula, rounding, precision), thresholds and limits,
defaults, input normalisation (trim/upper-case), error cases and messages, data source and freshness (real-time/delayed,
cache), ordering/filtering of lists, side effects (logging, audit rows, messages sent), and SQL logic inside procedures,
functions and triggers (the pack includes their code when SQL definitions were provided).
`ROUND(x, 4)` in a proc vs no rounding in repo2 is DIFFERENT; the same check written differently is SAME. If the repo2
counterpart of a rule is not in the pack, write UNVERIFIED (not MISSING) unless the review queue confirmed it.
Each method in the pack has a `Facts:` line (checks, DB use, external calls the script found) - build on it, do not repeat it.

### REST migration rules (repo2 is a planned REST replacement - consumers WILL change their calls)
Compare **information and behaviour, not transport**. These are NOT differences and never carry risk; the script already
lists them for consumers under "What callers must change" in the report - do not repeat them:
- SOAP vs REST, SOAP envelope vs JSON, URL / route / HTTP verb, SOAPAction, WSDL vs OpenAPI.
- An old input that the new endpoint takes from the URL path, query string, header, form or body (statuses MATCH with
  "Consumer change" notes). Where a field is sent does not matter; that the same information arrives does.
- Field-name casing, wrapper/envelope elements, list wrappers, a renamed field that carries the same data (after you confirm it).
- SOAP fault vs HTTP status code, when the same error conditions are still rejected (only different conditions or a lost
  error case is a difference).
- An old input that the new endpoint takes from the login token / claims / configuration instead of the request (say so: SAME).
Never ask "is a SOAP facade needed?" or "callers must change their call" - that is the plan, not a finding.
What IS a difference: an old input no longer accepted at all (the new code cannot behave as before); old response data not
returned; changed meaning, precision (decimal -> double for money), rounding, defaults, limits; different validation or
error conditions; different data source/freshness; missing side effects (audit, DB writes, messages).
In the `Request` row: SAME if every old input reaches the new code somehow (any of the places above); otherwise list only the
inputs that are not taken.

### 4a. `FOLDER/review/<Op>.notes.json` (one per operation)
```json
{
  "old:FundTransferBusiness.Submit": "Checks that the amount is not above the daily limit of 25,000 and then saves the transfer through the stored procedure usp_SubmitTransfer. Returns a confirmation number with status QUEUED.",
  "new:TransferService.Create": "..."
}
```
- `<Op>` = operation name with characters other than letters, digits, `.`, `-`, `_` replaced by `_`.
- One entry per method heading in that operation's logic pack (`### old:Class.Method` / `### new:Class.Method`), key copied exactly.
  Skip one-line pass-through methods. At most ~40 entries per operation.
- Exactly two short plain sentences: (1) what the method does for the business, (2) the rule, data or external system
  that matters (limits, rounding, which table/proc/API). No code names except the ones a reader would search for.
- Facts only from the code you read. Never guess intent; if unclear, say what it does mechanically.

### 4b. `FOLDER/review/<Op>.md` (one per operation) and `FOLDER/review/_overall.md`
Write evidence as `old:<path>:<line>` or `new:<path>:<line>` with the paths exactly as in the summary - the script
turns them into links (references to files or lines that do not exist are marked "unverified"). Use `##` headings.

`review/<Op>.md`:
```
**Verdict:** FULL | PARTIAL | NOT_IMPLEMENTED - one sentence why. Confidence H/M/L.

One sentence: what this operation does for its callers.

## What is different
| Area | Same? | Risk | What is different - in plain words | Evidence |
|---|---|---|---|---|
(Areas: Request, Response, Errors, Validations, Data read, Data written, Calls to other systems, Messaging,
Business rules, Caching, Transactions, Security. Same?: SAME / DIFFERENT / MISSING / EXTRA / UNVERIFIED.
Risk: HIGH (callers get wrong/missing data, money/limits differ, security hole), MEDIUM (behaviour change some callers
notice), LOW (cosmetic/internal), - (SAME). Note = **Old vs new**, **So what** (who is affected, concrete example),
**Do** (fix or question). One short sentence for SAME rows.)

## Business logic comparison
| # | Rule, in plain words | Old behaviour | New behaviour | Same? | Risk | What to do |
(one row per rule from the logic pack, evidence `old:...` / `new:...` in the behaviour cells)

## Database objects
Plain-language meaning of each ONLY-old object and each stored procedure/trigger rule ("the old proc also writes an audit
row on every transfer; repo2 does not - is the audit still required?"). Objects without SQL definition: "logic not reviewed".

## Suggested changes in repo2
| # | Change (plain words) | Where (new) | Risk | Effort | Type |
|---|---|---|---|---|---|
(One row for EVERY row above that is DIFFERENT, MISSING or PARTIAL with risk HIGH or MEDIUM, and for every rule marked
DIFFERENT/MISSING - nothing else; at most 10, highest risk first. Where = `new:<path>:<line>` of the method or class to
change (from the summary, the logic pack or a ±15-line read). Effort: S (< 1 day), M (1-3 days), L (more).
Type: Code | Config | Decision (the code cannot say which side is right -> also put the question in _overall.md
"Decisions needed" and write the code change for the most likely answer). If there is nothing to change: one line
"No changes needed." and no table.)

Then one block per row, same number:
**1. <Change title>** - fixes: <Area or rule # from above>
- **Why:** old vs new in one sentence, with evidence `old:...` / `new:...`.
- **Change:** what to do in repo2, concretely (which class/method/property, which value, which check).
- **Sketch** (only for Type Code, at most 12 lines, in the language and style of the new code, using ONLY names you saw in
  the code you read - write `/* TODO: ... */` where a name is unknown; never invent APIs, tables or config keys):
  ```csharp
  ...
  ```
- **Done when:** one test or check that proves it (input -> expected output, e.g. "GetQuote for CA/RY returns
  LastPrice 101.2345 with 4 decimals").

## Not verified
Bullets: what was not checked and why it matters.
```

`review/_overall.md` (across ALL operations in FOLDER; update it after each run, keep it short):
```
# Bottom line
2-4 plain sentences: can repo2 replace the SOAP service today? What must happen first?

# Decisions needed
Numbered questions the code cannot answer, each with options and consequence, e.g.
1. Which daily limit is correct? - 25,000 (old): repo2 must change MaxAmount. - 50,000 (new): no code change; inform operations.

# Glossary
Only terms you used ("Facade = the new service just calls the old one").
```
Writing rules:
- Plain words first, code names second. No unexplained jargon (slice, xref, DTO, cardinality).
- Say the consequence for callers, not only the code difference ("decimal vs double" -> "amounts are stored as floating
  point; 0.1 + 0.2 may become 0.30000000000000004 - wrong for money").
- Every factual claim has evidence from the summary, the logic pack or a ±15-line read; never invent evidence.
- `NOT_SET_IN_REPO1` fields are not gaps; mention them once ("the old service declares 56 response fields but fills 5").
- FULL only if: no MISSING/MISMATCH contract rows, no MISSING integrations, no DIFFERENT/MISSING rules after verification.
- Keep each operation under ~1.5 pages. Do not copy call flows, field lists or tables the script already prints.

Then run the same command with `--phase report` and without `-o`. The DIAG card shows `docs parity_report.md | reviews
N/M op(s) | method notes X/Y used`. If N < M, `_overall.md` is missing, or X is much lower than Y, fix the file names /
keys and run `--phase report` again (cheap). Do not read the report back. End your reply with the line
`Read: FOLDER/parity_report.md (parity_summary.md and logic_*.md are working files for Copilot, not for people).`

## 5. Re-run tips
- Many FUZZY confirmations -> put them in a synonyms JSON and re-run so the next summary is smaller.
- Wrong repo2 endpoint chosen -> look at "repo2 candidates"; re-run with `--min-score` higher, or tell the user which endpoint was used.
- Output too large -> run per operation with `-o`, or lower `--max-rows`.
- Card shows `R1 ENTRY NOT FOUND` or `(1)` slice file -> pass the `.svc` with `--svc` (pins the class), or check `--repo1` contains the implementation.
- Card shows `r2 NONE` (or the wrong endpoint) but the method is known -> `--repo2-entry Class.Method`. Candidate scores are in `run.log` (`candidate` lines).
