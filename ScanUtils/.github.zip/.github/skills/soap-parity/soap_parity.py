#!/usr/bin/env python3
"""
soap_parity.py - Deterministic SOAP (repo1) vs codebase (repo2) parity extractor.

Python 3.8+, standard library only (no pip install needed).

It does the heavy lifting OUTSIDE the LLM so Copilot only has to read a small
summary and verify a short list of file:line evidence:

  1. Reads the WSDL (URL or file), follows wsdl:import / xsd:import / xsd:include,
     flattens request/response/fault payloads into field paths with types,
     cardinality and XSD restrictions.
  2. Indexes repo1 and repo2 source code (Java/Kotlin/C#/TS/JS/Python/Go):
     classes, DTO fields + validation annotations, methods, endpoints,
     outbound HTTP/SOAP calls, DB access (SQL tables, stored procs, repositories),
     messaging, validations, error handling, config URLs.
  3. Per SOAP operation, finds the entry method in repo1 and the best candidate
     endpoint in repo2, slices the reachable code (method-level call graph,
     best effort), and compares contract, integrations, validations and
     business-rule literals.
  4. Writes out/parity_summary.md (small, for the LLM) + out/parity.json (full).

Usage:
  python soap_parity.py --wsdl "https://host/Service?wsdl" --repo1 C:\\src\\legacy --repo2 C:\\src\\new
  python soap_parity.py --wsdl path\\to\\service.wsdl --repo2 C:\\src\\new --operation GetQuote
  python soap_parity.py --wsdl ... --list-ops

Auth for WSDL URLs (never pass secrets on the command line):
  set SOAP_PARITY_USER / SOAP_PARITY_PASSWORD   -> HTTP Basic
  set SOAP_PARITY_HEADER="Authorization: Bearer xyz" -> any single header
  HTTPS_PROXY / HTTP_PROXY are honoured.
"""
import argparse
import base64
import binascii
import difflib
import io
import json
import os
import platform
import re
import ssl
import sys
import time
import traceback
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict, deque

VERSION = "1.5.16"
XSD = "http://www.w3.org/2001/XMLSchema"
WSDL11 = "http://schemas.xmlsoap.org/wsdl/"
WSDL20 = "http://www.w3.org/ns/wsdl"
SOAP_NS = ("http://schemas.xmlsoap.org/wsdl/soap/", "http://schemas.xmlsoap.org/wsdl/soap12/")

WARNINGS = []

# Warning codes: shown in the diagnostic card (diag.txt) so a screenshot is enough to diagnose a run.
WARN_CODES = [
    ("W-LINK", r"^link:"),
    ("W-REPORT", r"^report:"),
    ("W-FOREIGN", r"^foreign:"),
    ("W-SVC", r"^svc:"),
    ("W-ENTRY", r"^entry:"),
    ("W-LIMIT", r"^limit:"),
    ("W-DB", r"^db:"),
    ("W-WSDL-LOAD", r"could not load|could not parse|not a WSDL"),
    ("W-XSD-UNRESOLVED", r"unresolved|not found for|element .* not found"),
    ("W-XSD-NS", r"imported without schemaLocation|unknown prefix|resolved by local name"),
    ("W-INDEX-FAIL", r"failed to index"),
]


def warn_code(msg):
    for code, rx in WARN_CODES:
        if re.search(rx, msg):
            return code
    return "W-OTHER"


CRED_URL_RE = re.compile(r"(\b[a-z][a-z0-9+.\-]*://)[^/@\s]+@", re.I)


class RunLog:
    """run.log (full, timestamped) + diag.txt (crisp card, screenshot-friendly). Absolute roots are redacted."""

    def __init__(self):
        self.t0 = time.time()
        self.fh = None
        self.phases = []          # (name, seconds)
        self.cur_phase = "startup"
        self.cur_t = self.t0
        self.cur_file = None      # file being indexed (shown on crash)
        self.redact = []          # (abs path, token)
        self.info = {}
        self.events = []          # (level, code, msg)
        self.out_dir = None
        # run id: random per run, printed on the card and at the top of every file the LLM reads. The LLM must quote it -
        # a reply without the id of the latest card means the script was not run (the LLM improvised).
        self.run_id = binascii.hexlify(os.urandom(3)).decode("ascii")

    def open(self, out_dir):
        self.out_dir = out_dir
        try:
            self.fh = open(os.path.join(out_dir, "run.log"), "w", encoding="utf-8")
        except OSError:
            self.fh = None
        self.write("soap_parity %s  run id %s  python %s  %s" % (VERSION, self.run_id, sys.version.split()[0], platform.platform()))

    def add_redaction(self, path, token):
        if path:
            ap = os.path.abspath(path)
            self.redact.append((ap, token))
            self.redact.append((ap.replace("\\", "/"), token))
            self.redact.sort(key=lambda x: -len(x[0]))

    def r(self, s):
        s = CRED_URL_RE.sub(r"\1***@", str(s))
        for p, tok in self.redact:
            if p and p in s:
                s = s.replace(p, tok)
        return s

    def write(self, msg, echo=False):
        line = "%7.1fs [%s] %s" % (time.time() - self.t0, self.cur_phase, self.r(msg))
        if self.fh:
            try:
                self.fh.write(line + "\n")
                self.fh.flush()
            except OSError:
                pass
        if echo:
            print(self.r(msg), flush=True)

    def phase(self, name):
        now = time.time()
        if self.cur_phase != "startup":
            self.phases.append((self.cur_phase, now - self.cur_t))
        self.write("phase end: %s (%.1fs)" % (self.cur_phase, now - self.cur_t))
        self.cur_phase, self.cur_t = name, now
        say("[%s] %s ..." % (time.strftime("%H:%M:%S"), name))

    def event(self, level, code, msg):
        self.events.append((level, code, self.r(msg)))
        self.write("%s %s %s" % (level, code, msg))


LOG = RunLog()
LOG.quiet = False


def say(msg):
    if not LOG.quiet:
        print(msg, flush=True)


def warn(msg):
    if msg not in WARNINGS:
        WARNINGS.append(msg)
        LOG.event("WARN", warn_code(msg), msg)
        if LOG.quiet:
            pass
        elif len(WARNINGS) <= 25:
            print("WARN: " + LOG.r(msg), file=sys.stderr)
        elif len(WARNINGS) == 26:
            print("WARN: (more warnings - see run.log)", file=sys.stderr)


def q(ns, tag):
    return "{%s}%s" % (ns, tag)


def local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


# --------------------------------------------------------------------------- names

def norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def tokens(s):
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", s or "")
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", s)
    return [t for t in re.split(r"[^A-Za-z0-9]+", s.lower()) if t]


VERBS = {"get", "create", "add", "update", "delete", "remove", "find", "fetch", "retrieve", "process",
         "do", "handle", "submit", "post", "put", "patch", "save", "search", "list", "query", "request",
         "response", "api", "v1", "v2", "v3", "v4", "by", "for", "and", "the", "async", "op", "operation"}


def stem(t):
    return t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t


def nouns(*names):
    out = set()
    for n in names:
        for t in tokens(n):
            if t not in VERBS and not t.isdigit():
                out.add(stem(t))
    return out


class Names:
    def __init__(self, synonyms):
        self.syn = {}
        for canon, aliases in (synonyms or {}).items():
            c = norm(canon)
            self.syn[c] = c
            for a in aliases if isinstance(aliases, list) else [aliases]:
                self.syn[norm(a)] = c

    def sim(self, a, b):
        na, nb = norm(a), norm(b)
        if not na or not nb:
            return 0.0
        if na == nb:
            return 1.0
        if self.syn.get(na) and self.syn.get(na) == self.syn.get(nb):
            return 0.95
        ta, tb = tokens(a), tokens(b)
        if ta and len(ta) == len(tb) and all(
                (x == y) or (min(len(x), len(y)) >= 2 and (x.startswith(y) or y.startswith(x))) for x, y in zip(ta, tb)):
            return 0.85
        if min(len(na), len(nb)) >= 4 and (na.endswith(nb) or nb.endswith(na) or na.startswith(nb) or nb.startswith(na)):
            return 0.8
        return round(difflib.SequenceMatcher(None, na, nb).ratio() * 0.9, 3)


# --------------------------------------------------------------------------- WSDL / XSD loading

def is_url(s):
    return bool(re.match(r"^https?://", s or "", re.I))


def join_loc(base, rel):
    if re.match(r"^[a-z][a-z0-9+.-]*://", rel, re.I):
        return rel
    if is_url(base):
        return urllib.parse.urljoin(base, rel)
    return os.path.normpath(os.path.join(os.path.dirname(base), rel))


def parse_xml(data):
    """Parse XML keeping in-scope namespace prefixes for every element."""
    if b"<!ENTITY" in data[:20000]:
        raise ValueError("document declares XML entities; refused for safety")
    stack, pending, nsmaps, root = [{}], {}, {}, None
    for ev, obj in ET.iterparse(io.BytesIO(data), events=("start-ns", "start", "end")):
        if ev == "start-ns":
            pending[obj[0] or ""] = obj[1]
        elif ev == "start":
            m = dict(stack[-1])
            m.update(pending)
            pending = {}
            nsmaps[obj] = m
            stack.append(m)
            if root is None:
                root = obj
        else:
            stack.pop()
    return root, nsmaps


class Loader:
    def __init__(self, insecure=False, timeout=30, cache_dir=None, local_dirs=()):
        self.insecure, self.timeout, self.cache_dir = insecure, timeout, cache_dir
        self.manifest = {}
        self.by_ns, self.by_base = defaultdict(list), defaultdict(list)
        for d in local_dirs:
            self._index_local(d)

    def _index_local(self, d):
        if not d or not os.path.isdir(d):
            return
        for root, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS and not is_out_dir(root, x)]
            for f in files:
                if f.lower().endswith((".xsd", ".wsdl")):
                    p = os.path.join(root, f)
                    self.by_base[f.lower()].append(p)
                    try:
                        with open(p, "rb") as fh:
                            head = fh.read(8000).decode("utf-8", "replace")
                        m = re.search(r'targetNamespace\s*=\s*["\']([^"\']+)', head)
                        if m:
                            self.by_ns[m.group(1)].append(p)
                    except OSError:
                        pass

    def fetch(self, loc):
        if is_url(loc):
            req = urllib.request.Request(loc, headers={"User-Agent": "soap-parity/" + VERSION})
            user = os.environ.get("SOAP_PARITY_USER")
            if user:
                tok = base64.b64encode(("%s:%s" % (user, os.environ.get("SOAP_PARITY_PASSWORD", ""))).encode()).decode()
                req.add_header("Authorization", "Basic " + tok)
            hdr = os.environ.get("SOAP_PARITY_HEADER", "")
            if ":" in hdr:
                k, v = hdr.split(":", 1)
                req.add_header(k.strip(), v.strip())
            ctx = ssl._create_unverified_context() if self.insecure else None
            with urllib.request.urlopen(req, timeout=self.timeout, context=ctx) as r:
                data = r.read()
        else:
            p = loc
            if loc.lower().startswith("file:"):
                p = urllib.request.url2pathname(urllib.parse.urlparse(loc).path)
            with open(p, "rb") as fh:
                data = fh.read()
        self._save(loc, data)
        return data

    def _save(self, loc, data):
        if not self.cache_dir:
            return
        os.makedirs(self.cache_dir, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9._-]+", "_", loc)[-80:]
        fn = "%03d_%s" % (len(self.manifest) + 1, name)
        if not fn.lower().endswith((".xsd", ".wsdl", ".xml")):
            fn += ".xml"
        with open(os.path.join(self.cache_dir, fn), "wb") as fh:
            fh.write(data)
        self.manifest[loc] = fn
        with open(os.path.join(self.cache_dir, "manifest.json"), "w", encoding="utf-8") as fh:
            json.dump(self.manifest, fh, indent=1)

    def fallback(self, loc, namespace=None):
        base = os.path.basename(urllib.parse.urlparse(loc).path if is_url(loc) else loc).lower() if loc else ""
        for p in self.by_base.get(base, []):
            return p
        if namespace:
            for p in self.by_ns.get(namespace, []):
                return p
        return None


class Contract:
    def __init__(self, loader):
        self.loader = loader
        self.nsmap = {}
        self.owner_tns = {}
        self.elements, self.types, self.groups, self.attr_groups, self.attributes = {}, {}, {}, {}, {}
        self.messages, self.port_types, self.bindings, self.services = {}, {}, {}, {}
        self.wsdl2_ops = []
        self.loaded = set()
        self.loaded_ns = set()
        self.pending_ns = set()

    # ---- loading
    def load(self, loc, override_tns=None, namespace=None):
        key = (loc, override_tns)
        if key in self.loaded:
            return
        self.loaded.add(key)
        try:
            data = self.loader.fetch(loc)
        except Exception as e:  # noqa
            fb = self.loader.fallback(loc, namespace)
            if fb and (fb, override_tns) not in self.loaded:
                warn("could not load %s (%s); using local copy %s" % (loc, e, fb))
                return self.load(fb, override_tns)
            warn("could not load %s: %s" % (loc, e))
            return
        try:
            root, nsm = parse_xml(data)
        except Exception as e:  # noqa
            if is_url(loc) and "wsdl" not in loc.lower():
                self.loaded.discard(key)
                return self.load(loc + ("&" if "?" in loc else "?") + "wsdl", override_tns, namespace)
            warn("could not parse %s: %s" % (loc, e))
            return
        self.nsmap.update(nsm)
        tag = root.tag
        if tag == q(WSDL11, "definitions"):
            self._wsdl11(root, loc)
        elif tag == q(WSDL20, "description"):
            self._wsdl20(root, loc)
        elif tag == q(XSD, "schema"):
            self._schema(root, loc, override_tns)
        elif is_url(loc) and "wsdl" not in loc.lower():
            self.loaded.discard(key)
            self.load(loc + ("&" if "?" in loc else "?") + "wsdl", override_tns, namespace)
        else:
            warn("%s is not a WSDL/XSD document (root=%s)" % (loc, local(tag)))

    def _schema(self, s, loc, override_tns=None):
        tns = s.get("targetNamespace") or override_tns or ""
        self.loaded_ns.add(tns)
        for ch in s:
            t = local(ch.tag)
            if t in ("import", "include", "redefine", "override"):
                sl = ch.get("schemaLocation")
                ns = ch.get("namespace")
                if sl:
                    self.load(join_loc(loc, sl), tns if t != "import" else None, ns)
                elif ns:
                    self.pending_ns.add(ns)
                if t in ("redefine", "override"):
                    self._register(ch, tns)
            self._register_one(ch, t, tns)

    def _register(self, parent, tns):
        for ch in parent:
            self._register_one(ch, local(ch.tag), tns)

    def _register_one(self, ch, t, tns):
        name = ch.get("name")
        if not name:
            return
        reg = {"element": self.elements, "complexType": self.types, "simpleType": self.types,
               "group": self.groups, "attributeGroup": self.attr_groups, "attribute": self.attributes}.get(t)
        if reg is not None:
            reg[(tns, name)] = ch
            self.owner_tns[ch] = tns

    def _wsdl11(self, root, loc):
        tns = root.get("targetNamespace", "")
        for imp in root.findall(q(WSDL11, "import")):
            if imp.get("location"):
                self.load(join_loc(loc, imp.get("location")), namespace=imp.get("namespace"))
        types = root.find(q(WSDL11, "types"))
        if types is not None:
            for s in types.findall(q(XSD, "schema")):
                self._schema(s, loc)
        for m in root.findall(q(WSDL11, "message")):
            self.messages[(tns, m.get("name"))] = m
        for pt in root.findall(q(WSDL11, "portType")):
            self.port_types[(tns, pt.get("name"))] = pt
        for b in root.findall(q(WSDL11, "binding")):
            self.bindings[(tns, b.get("name"))] = b
        for sv in root.findall(q(WSDL11, "service")):
            for port in sv.findall(q(WSDL11, "port")):
                addr = None
                for ch in port:
                    if local(ch.tag) == "address":
                        addr = ch.get("location")
                self.services[self.resolve(port, port.get("binding"), tns)] = {
                    "service": sv.get("name"), "port": port.get("name"), "address": addr}

    def _wsdl20(self, root, loc):
        tns = root.get("targetNamespace", "")
        types = root.find(q(WSDL20, "types"))
        if types is not None:
            for s in types.findall(q(XSD, "schema")):
                self._schema(s, loc)
        for itf in root.findall(q(WSDL20, "interface")):
            for op in itf.findall(q(WSDL20, "operation")):
                rec = {"name": op.get("name"), "portType": itf.get("name"), "parts": {}}
                for d in ("input", "output"):
                    el = op.find(q(WSDL20, d))
                    if el is not None and el.get("element"):
                        rec["parts"][d] = [("element", self.resolve(el, el.get("element"), tns), "body", el)]
                rec["parts"]["faults"] = []
                self.wsdl2_ops.append(rec)

    def resolve_pending(self):
        for ns in list(self.pending_ns):
            if ns in self.loaded_ns or ns == XSD:
                continue
            p = self.loader.fallback(None, ns)
            if p:
                warn("namespace %s imported without schemaLocation; using local %s" % (ns, p))
                self.load(p)
            else:
                warn("namespace %s imported without schemaLocation and no local copy found" % ns)

    # ---- qname helpers
    def resolve(self, el, qn, ctx_tns=""):
        if not qn:
            return ("", "")
        if ":" in qn:
            p, n = qn.split(":", 1)
            ns = self.nsmap.get(el, {}).get(p)
            if ns is None:
                warn("unknown prefix '%s' in %s" % (p, qn))
                ns = ""
            return (ns, n)
        return (self.nsmap.get(el, {}).get("", ctx_tns), qn)

    def lookup(self, reg, key, what):
        if key in reg:
            return reg[key]
        cands = [v for (ns, n), v in reg.items() if n == key[1]]
        if len(cands) == 1:
            warn("%s {%s}%s resolved by local name only" % (what, key[0], key[1]))
            return cands[0]
        return None

    # ---- operations
    def operations(self):
        ops = []
        if self.wsdl2_ops:
            for r in self.wsdl2_ops:
                ops.append(self._op_payloads(r["name"], r["portType"], r["parts"], {}, None))
        bind_info = {}
        for bkey, b in self.bindings.items():
            ptkey = self.resolve(b, b.get("type"), bkey[0])
            style = "document"
            for ch in b:
                if local(ch.tag) == "binding" and ch.get("style"):
                    style = ch.get("style")
            for op in b.findall(q(WSDL11, "operation")):
                info = {"style": style, "soapAction": None, "binding": bkey[1],
                        "address": (self.services.get(bkey) or {}).get("address")}
                for ch in op:
                    if local(ch.tag) == "operation":
                        info["soapAction"] = ch.get("soapAction") or info["soapAction"]
                        info["style"] = ch.get("style") or info["style"]
                bind_info.setdefault((ptkey, op.get("name")), info)
        seen = set()
        for ptkey, pt in self.port_types.items():
            for op in pt.findall(q(WSDL11, "operation")):
                name = op.get("name")
                parts = {"input": [], "output": [], "faults": []}
                for d in ("input", "output", "fault"):
                    for io_el in op.findall(q(WSDL11, d)):
                        mkey = self.resolve(io_el, io_el.get("message"), ptkey[0])
                        msg = self.lookup(self.messages, mkey, "message")
                        if msg is None:
                            warn("message %s not found for %s" % (mkey[1], name))
                            continue
                        for part in msg.findall(q(WSDL11, "part")):
                            if part.get("element"):
                                pk = ("element", self.resolve(part, part.get("element"), mkey[0]), part.get("name"), part)
                            else:
                                pk = ("type", self.resolve(part, part.get("type"), mkey[0]), part.get("name"), part)
                            parts["faults" if d == "fault" else d].append(pk)
                uniq = name if name not in seen else "%s.%s" % (ptkey[1], name)
                seen.add(name)
                ops.append(self._op_payloads(uniq, ptkey[1], parts, bind_info.get((ptkey, name), {}), name))
        return ops

    def _op_payloads(self, name, pt, parts, info, wsdl_name):
        rec = {"name": name, "wsdlName": wsdl_name or name, "portType": pt,
               "soapAction": info.get("soapAction"), "style": info.get("style"),
               "address": info.get("address"), "request": [], "response": [], "faults": []}
        for d, target in (("input", "request"), ("output", "response"), ("faults", "faults")):
            for kind, key, pname, el in parts.get(d, []):
                fl = Flattener(self)
                if kind == "element":
                    g = self.lookup(self.elements, key, "element")
                    if g is None:
                        warn("element %s not found (op %s)" % (key[1], name))
                        continue
                    fl.elem(g, "", self.owner_tns.get(g, key[0]), [])
                else:
                    prefix = rec["wsdlName"] if target != "faults" else ""
                    fl.typed(pname, key, prefix, el, [])
                rec[target].extend(fl.fields)
        return rec


class Flattener:
    MAX_DEPTH = 25

    def __init__(self, c):
        self.c = c
        self.fields = []

    @staticmethod
    def _occ(v, default):
        if v is None:
            return default
        return "unbounded" if v == "unbounded" else int(v)

    def _add(self, **kw):
        kw.setdefault("restr", {})
        self.fields.append(kw)

    def elem(self, e, prefix, tns, stack, choice=False, mn=None, mx=None):
        if len(stack) > self.MAX_DEPTH:
            return
        mn = mn if mn is not None else e.get("minOccurs")
        mx = mx if mx is not None else e.get("maxOccurs")
        ref = e.get("ref")
        if ref:
            key = self.c.resolve(e, ref, tns)
            g = self.c.lookup(self.c.elements, key, "element")
            if g is None:
                warn("element ref %s unresolved" % key[1])
                self._add(path=(prefix + "/" if prefix else "") + key[1], name=key[1], type="UNRESOLVED",
                          min=self._occ(mn, 1), max=self._occ(mx, 1), complex=False, attr=False, choice=choice)
                return
            return self.elem(g, prefix, self.c.owner_tns.get(g, key[0]), stack, choice, mn, mx)
        name = e.get("name")
        mn_i, mx_i = self._occ(mn, 1), self._occ(mx, 1)
        is_list = mx_i == "unbounded" or (isinstance(mx_i, int) and mx_i > 1)
        path = (prefix + "/" if prefix else "") + name + ("[]" if is_list else "")
        base = dict(path=path, name=name, min=mn_i, max=mx_i, attr=False, choice=choice,
                    nillable=e.get("nillable") == "true", list=is_list)
        ct = e.find(q(XSD, "complexType"))
        st = e.find(q(XSD, "simpleType"))
        if ct is not None:
            self._add(type="(anonymous)", complex=True, **base)
            self.complex(ct, path, tns, stack)
        elif st is not None:
            b, r = self.simple(st, tns, 0)
            self._add(type=b, complex=False, restr=r, **base)
        elif e.get("type"):
            self._typed_into(base, self.c.resolve(e, e.get("type"), tns), stack)
        else:
            self._add(type="anyType", complex=False, **base)

    def typed(self, name, key, prefix, el, stack):
        path = (prefix + "/" if prefix else "") + name
        self._typed_into(dict(path=path, name=name, min=1, max=1, attr=False, choice=False, nillable=False, list=False),
                         key, stack)

    def _typed_into(self, base, key, stack):
        if key[0] == XSD:
            self._add(type=key[1], complex=False, **base)
            return
        if key[0] == WCF_SER_NS and key[1] in WCF_SER_TYPES:
            self._add(type=WCF_SER_TYPES[key[1]], complex=False, typeName=key[1], **base)
            return
        t = self.c.lookup(self.c.types, key, "type")
        if t is None:
            warn("type %s unresolved (field %s)" % (key[1], base["path"]))
            self._add(type="UNRESOLVED:" + key[1], complex=False, **base)
        elif local(t.tag) == "simpleType":
            b, r = self.simple(t, self.c.owner_tns.get(t, key[0]), 0)
            self._add(type=b, complex=False, restr=r, typeName=key[1], **base)
        elif key in stack:
            self._add(type="RECURSIVE:" + key[1], complex=True, **base)
        else:
            self._add(type=key[1], complex=True, **base)
            self.complex(t, base["path"], self.c.owner_tns.get(t, key[0]), stack + [key])

    def simple(self, st, tns, depth):
        restr = {}
        if depth > 10:
            return "string", restr
        for ch in st:
            t = local(ch.tag)
            if t == "restriction":
                b = "string"
                inner = ch.find(q(XSD, "simpleType"))
                if ch.get("base"):
                    key = self.c.resolve(ch, ch.get("base"), tns)
                    if key[0] == XSD:
                        b = key[1]
                    else:
                        bt = self.c.lookup(self.c.types, key, "type")
                        if bt is not None and local(bt.tag) == "simpleType":
                            b, restr = self.simple(bt, self.c.owner_tns.get(bt, key[0]), depth + 1)
                            restr = dict(restr)
                elif inner is not None:
                    b, restr = self.simple(inner, tns, depth + 1)
                for f in ch:
                    fn = local(f.tag)
                    if fn == "enumeration":
                        restr.setdefault("enumeration", []).append(f.get("value"))
                    elif fn in ("pattern", "length", "minLength", "maxLength", "minInclusive", "maxInclusive",
                                "minExclusive", "maxExclusive", "totalDigits", "fractionDigits"):
                        restr[fn] = f.get("value")
                return b, restr
            if t == "list":
                return "list", restr
            if t == "union":
                return "union", restr
        return "string", restr

    def complex(self, ct, path, tns, stack, choice=False):
        for ch in ct:
            t = local(ch.tag)
            if t in ("sequence", "all"):
                self.particles(ch, path, tns, stack, choice)
            elif t == "choice":
                self.particles(ch, path, tns, stack, True)
            elif t == "group":
                self._group(ch, path, tns, stack, choice)
            elif t == "complexContent":
                for d in ch:
                    if local(d.tag) == "extension" and d.get("base"):
                        key = self.c.resolve(d, d.get("base"), tns)
                        if key[0] != XSD:
                            bt = self.c.lookup(self.c.types, key, "type")
                            if bt is None:
                                warn("base type %s unresolved (at %s)" % (key[1], path))
                            elif key in stack:
                                warn("recursive base type %s" % key[1])
                            else:
                                self.complex(bt, path, self.c.owner_tns.get(bt, key[0]), stack + [key], choice)
                    if local(d.tag) in ("extension", "restriction"):
                        self.complex(d, path, tns, stack, choice)
            elif t == "simpleContent":
                for d in ch:
                    if local(d.tag) in ("extension", "restriction"):
                        key = self.c.resolve(d, d.get("base"), tns)
                        self._add(path=path + "/#value", name="#value", type=key[1] if key[0] == XSD else "string",
                                  min=1, max=1, complex=False, attr=False, choice=False)
                        self.complex(d, path, tns, stack, choice)
            elif t == "attribute":
                self._attr(ch, path, tns)
            elif t == "attributeGroup" and ch.get("ref"):
                key = self.c.resolve(ch, ch.get("ref"), tns)
                ag = self.c.lookup(self.c.attr_groups, key, "attributeGroup")
                if ag is not None:
                    self.complex(ag, path, self.c.owner_tns.get(ag, key[0]), stack, choice)

    def particles(self, node, path, tns, stack, choice):
        for ch in node:
            t = local(ch.tag)
            if t == "element":
                self.elem(ch, path, tns, stack, choice)
            elif t in ("sequence", "all"):
                self.particles(ch, path, tns, stack, choice)
            elif t == "choice":
                self.particles(ch, path, tns, stack, True)
            elif t == "group":
                self._group(ch, path, tns, stack, choice)
            elif t == "any":
                self._add(path=path + "/*any*", name="*any*", type="any", min=0, max=1, complex=False,
                          attr=False, choice=choice)

    def _group(self, ch, path, tns, stack, choice):
        if not ch.get("ref"):
            return
        key = self.c.resolve(ch, ch.get("ref"), tns)
        g = self.c.lookup(self.c.groups, key, "group")
        if g is None:
            warn("group %s unresolved" % key[1])
        elif ("group",) + key not in stack:
            self.complex(g, path, self.c.owner_tns.get(g, key[0]), stack + [("group",) + key], choice)

    def _attr(self, a, path, tns):
        if a.get("ref"):
            key = self.c.resolve(a, a.get("ref"), tns)
            g = self.c.lookup(self.c.attributes, key, "attribute")
            name, typ, restr = key[1], "string", {}
            if g is not None and g.get("type"):
                tk = self.c.resolve(g, g.get("type"), tns)
                typ = tk[1]
        else:
            name, typ, restr = a.get("name"), "string", {}
            st = a.find(q(XSD, "simpleType"))
            if st is not None:
                typ, restr = self.simple(st, tns, 0)
            elif a.get("type"):
                tk = self.c.resolve(a, a.get("type"), tns)
                if tk[0] == XSD:
                    typ = tk[1]
                else:
                    t = self.c.lookup(self.c.types, tk, "type")
                    if t is not None and local(t.tag) == "simpleType":
                        typ, restr = self.simple(t, self.c.owner_tns.get(t, tk[0]), 0)
        self._add(path=path + "/@" + name, name=name, type=typ, restr=restr,
                  min=1 if a.get("use") == "required" else 0, max=1, complex=False, attr=True, choice=False)


# --------------------------------------------------------------------------- code scanning

SKIP_DIRS = {"bower_components", "jspm_packages", ".git", ".svn", ".hg", "node_modules", "target", "build", "bin", "obj", "dist", "out", ".idea", ".vs",
             ".vscode", ".gradle", "__pycache__", "vendor", "packages", ".mvn", "coverage", ".next", "venv", ".venv",
             "site-packages", "TestResults", "logs"}
# this tool's own output folders: never indexed as repo code, even when parity_out lies inside repo1/repo2
OUT_DIR_PREFIX = "parity_out"
OUT_ABS = set()          # normcase'd absolute paths of --out and the parity_out root of this run


def is_out_dir(parent, name):
    if name.lower().startswith(OUT_DIR_PREFIX):
        return True
    return bool(OUT_ABS) and os.path.normcase(os.path.abspath(os.path.join(parent, name))) in OUT_ABS
TEST_DIR_RE = re.compile(r"(^|[\\/])([\w\-]*[.\-_])?(test|tests|__tests__|spec|specs|it|integration-?tests?|testing|unit-?tests?|"
                         r"functionaltests?|acceptancetests?|benchmarks?)([\\/]|$)", re.I)
# NOTE: *.designer.cs is NOT skipped - LINQ to SQL DataContext/entities and EF6 code live there.
GENERATED_FILE_RE = re.compile(r"(\.g\.cs|\.g\.i\.cs|AssemblyInfo\.cs|\.AssemblyAttributes\.cs|GlobalUsings\.g\.cs|Resources\.Designer\.cs|Settings\.Designer\.cs)$", re.I)
CODE_EXT = {".java": "java", ".kt": "kotlin", ".kts": "kotlin", ".scala": "scala", ".groovy": "groovy", ".cs": "cs",
            ".vb": "vb", ".ts": "ts", ".tsx": "ts", ".js": "js", ".jsx": "js", ".mjs": "js", ".py": "py", ".go": "go"}
CONF_EXT = {".properties", ".yml", ".yaml", ".config", ".json", ".env", ".ini", ".toml"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "tsconfig.json", "package.json", "angular.json",
              "pom.xml", "launchsettings.json", "composer.lock"}
MAX_FILE = 1_500_000
VENDOR_JS_RE = re.compile(r"(\.min\.js$|\.bundle\.js$|^(jquery|angular|bootstrap|knockout|kendo|modernizr|lodash|underscore|moment|backbone|"
                          r"require|respond|d3|highcharts|chart|select2|toastr|signalr|globalize|datatables|handlebars|mustache|"
                          r"sammy|q|es5-shim|json2|webgrease|microsoftajax|microsoftmvc)[\w.\-]*\.js$)")

KEYWORDS = {"if", "for", "while", "switch", "catch", "return", "new", "else", "throw", "throws", "try", "do", "synchronized",
            "using", "lock", "foreach", "when", "sizeof", "typeof", "nameof", "await", "yield", "super", "this", "assert",
            "case", "in", "is", "as", "function", "def", "fun", "func", "class", "elif", "with", "except", "lambda",
            "print", "default", "base", "select", "from", "where", "var", "val", "let", "const"}
MODS = ("public|private|protected|internal|static|final|abstract|synchronized|async|override|virtual|sealed|default|"
        "open|suspend|inline|operator|native|transient|extern|unsafe|partial|fun|readonly|export")
METHOD_RE = re.compile(r"^\s*(?P<mods>(?:(?:%s)\s+)*)(?:<[^>()]*>\s*)?(?P<ret>[\w.\[\]?]+(?:\s*<[^()=;]*>)?(?:\[\])*\??\s+)?"
                       r"(?P<name>[A-Za-z_]\w*)\s*(?:<[^>()]*>\s*)?\(" % MODS)
PY_DEF_RE = re.compile(r"^(\s*)(?:async\s+)?def\s+(\w+)\s*\(")
GO_FUNC_RE = re.compile(r"^\s*func\s+(?:\(\s*\w*\s*\*?(\w+)[^)]*\)\s*)?(\w+)\s*\(")
JS_FUNC_RE = re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function\s*\*?\s*(\w+)\s*\(|"
                        r"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*(?::\s*[\w<>\[\]]+\s*)?=>|\w+\s*=>))")
CLASS_RE = re.compile(r"\b(class|interface|enum|record|struct|object|trait)\s+([A-Za-z_]\w*)([^{;]*)")
LEAD_ANN_RE = re.compile(r"^\s*(?:(?:@[\w.]+(?:\([^()]*(?:\([^()]*\)[^()]*)*\))?|\[[^\]]*\])\s*)+")
JAVA_FIELD_RE = re.compile(r"^\s*(?:(?:private|protected|public|internal)\s+)?(?:(?:final|volatile|transient|readonly|required|lateinit)\s+)*"
                           r"(?P<type>[A-Z][\w.]*(?:\s*<[^;=()]*>)?(?:\[\])?|int|long|short|byte|double|float|boolean|char|bool|string|decimal|object)\??\s+"
                           r"(?P<name>[A-Za-z_]\w*)\s*(?:=[^;]*)?;")
CS_PROP_RE = re.compile(r"^\s*public\s+(?:virtual\s+|required\s+|override\s+|new\s+)*(?P<type>[\w.]+(?:\s*<[^;=()]*>)?(?:\[\])?\??)\s+"
                        r"(?P<name>[A-Za-z_]\w*)\s*\{\s*(?:get|init|set)")
KT_PROP_RE = re.compile(r"(?:val|var)\s+(?P<name>\w+)\s*:\s*(?P<type>[\w.]+(?:<[^>]*>)?\??)")
TS_PROP_RE = re.compile(r"^\s*(?:(?:public|private|protected|readonly)\s+)*(?P<name>[A-Za-z_]\w*)\??\s*[:!]\s*(?P<type>[\w.]+(?:<[^>]*>)?(?:\[\])?)\s*[;,=]?\s*$")
PY_PROP_RE = re.compile(r"^\s+(?P<name>[a-z_]\w*)\s*:\s*(?P<type>[\w.\[\], ]+?)\s*(?:=.*)?$")
VAR_RE = re.compile(r"\b([A-Z]\w*)(?:\s*<[^;()=]*>)?(?:\[\])?\s+([a-z_]\w*)\s*(?=[;=,):])")
VAR2_RE = re.compile(r"\b([a-z_]\w*)\s*:\s*([A-Z]\w*)")
VAR3_RE = re.compile(r"\bvar\s+(\w+)\s*=\s*new\s+([A-Z]\w*)")
# var mgr = ServiceLocator.Current.GetInstance<IFundTransferManager>();  var x = container.Resolve<IFoo>(...)
VAR4_RE = re.compile(r"\b(?:var|[A-Z]\w*)\s+(\w+)\s*=\s*(?:await\s+)?[\w.]*?\w+\s*<\s*([A-Z]\w*)\s*>\s*\(")
# properties / fields with an upper-case name: protected IFundTransferBusiness Business { get; set; }  private IFoo Manager;
PROP_DECL_RE = re.compile(r"^\s*(?:(?:public|private|protected|internal|static|readonly|virtual|override|new|abstract|sealed)\s+)+"
                          r"([A-Z]\w*)(?:\s*<[^;()=]*>)?\s+([A-Za-z_]\w*)\s*(?:[;={]|=>)")
# chained locator / factory call: ServiceLocator.Resolve<IFoo>().Bar(  Factory.Create<IFoo>(x).Bar(
GENERIC_CHAIN_RE = re.compile(r"<\s*([A-Z]\w*)\s*>\s*\(\s*[^()]*\)\s*\.\s*(\w+)\s*\(")
CALL_RECV_RE = re.compile(r"\b([A-Za-z_]\w*)\s*(?:\?\.|\.|->|::)\s*([A-Za-z_]\w*)\s*(?:<(?:[^<>()]|<(?:[^<>()]|<[^<>()]*>)*>)*>)?\(")
CALL_RE = re.compile(r"(?<![\w.$])([A-Za-z_]\w*)\s*\(")
METHREF_RE = re.compile(r"\b([A-Za-z_]\w*)::([A-Za-z_]\w*)")
NEW_RE = re.compile(r"\bnew\s+([A-Z]\w*)")
TYPE_TOKEN_RE = re.compile(r"\b([A-Z][A-Za-z0-9_]+)\b")
STR_RE = re.compile(r'"((?:\\.|[^"\\])*)"|\'((?:\\.|[^\'\\])*)\'')

# (category, subtype, regex)
HIT_PATTERNS = [
    ("endpoint", "soap", r"@WebService\b|@WebMethod\b|@Endpoint\b|@PayloadRoot\b|@SoapAction\b|\[OperationContract|\[ServiceContract|@ResponsePayload|\[WebMethod\b|\[WebService\b|\[SoapDocumentMethod"),
    ("endpoint", "rest", r"@(Get|Post|Put|Delete|Patch|Request)Mapping\b|@(GET|POST|PUT|DELETE|PATCH)\b|@Path\s*\(|\[Http(Get|Post|Put|Delete|Patch)\b|\[Route\s*\(|\bMap(Get|Post|Put|Delete)\s*\("),
    ("endpoint", "js-py-go", r"\b(app|router|server)\.(get|post|put|delete|patch)\s*\(|@(app|router|api)\.(route|get|post|put|delete|patch)\b|\bHandleFunc\s*\("),
    ("endpoint", "listener", r"@(JmsListener|KafkaListener|RabbitListener|SqsListener|StreamListener)\b"),
    ("outbound", "rest-template", r"\.(getForObject|getForEntity|postForObject|postForEntity|patchForObject)\s*\(|\b\w*[Tt]emplate\s*\.\s*(exchange|put|delete)\s*\(|\bnew\s+RestTemplate\b"),
    ("outbound", "webclient", r"\bWebClient\b|\bRestClient\b|\.retrieve\s*\(\)|\.bodyToMono\s*\(|\.uri\s*\("),
    ("outbound", "feign", r"@FeignClient\b|@HttpExchange\b|@(Get|Post)Exchange\b"),
    ("outbound", "http-client", r"\bHttpClients?\b|new\s+Http(Get|Post|Put|Delete)\b|\bOkHttpClient\b|new\s+URL\s*\(|HttpURLConnection|HttpRequest\.newBuilder|ClientBuilder\.|\.(GetAsync|PostAsync|PutAsync|PatchAsync|SendAsync|DeleteAsync|GetStringAsync|GetStreamAsync|GetByteArrayAsync|GetFromJsonAsync|PostAsJsonAsync|PutAsJsonAsync|PatchAsJsonAsync|DeleteFromJsonAsync)\s*(?:<[^>()]*>)?\s*\(|\.(Get|Post|Put|Delete)Json(Async)?\s*<|\bRestSharp\b|new\s+RestRequest|\baxios\b|\bfetch\s*\(|\brequests\.(get|post|put|delete|request)\s*\(|\bhttpx\.|\bhttp\.(Get|Post|NewRequest)\b"),
    ("outbound", "soap-client", r"WebServiceTemplate|marshalSendAndReceive|\.getPort\s*\(|JaxWsProxyFactoryBean|SOAPConnection|ChannelFactory<|\bSoapClient\b|zeep\.Client|ClientBase<|\bSoapHttpClientProtocol\b|new\s+\w+(Soap|Service|Ws)Client\s*\("),
    ("outbound", "grpc", r"ManagedChannelBuilder|GrpcChannel\.|grpc\.Dial"),
    ("messaging", "publish", r"jmsTemplate\.|convertAndSend|kafkaTemplate\.send|rabbitTemplate\.|CreateSender\s*\(|SendMessageAsync\s*\(|BasicPublish|SendMessageRequest|PublishRequest|\.[Pp]ublish(Async)?\s*\(|IPublishEndpoint|\.Produce(Async)?\s*\(|MessageQueue\s*\(|\.Send\s*\(\s*new\s+Message\b"),
    ("db", "jdbc", r"\bJdbcTemplate\b|NamedParameterJdbcTemplate|jdbcTemplate\.|\.query(ForObject|ForList|ForMap|ForRowSet)?\s*\(\s*\"|\.batchUpdate\s*\(|PreparedStatement|\.executeQuery\s*\(|\.executeUpdate\s*\("),
    ("db", "stored-proc", r"SimpleJdbcCall|withProcedureName|withFunctionName|@Procedure\b|StoredProcedureQuery|createStoredProcedureQuery|prepareCall|CommandType\.StoredProcedure|callproc\s*\("),
    ("db", "linq2sql", r"\bDataContext\b|\bGetTable\s*<|\bExecuteQuery\s*<|\bExecuteCommand\s*\(|\bSubmitChanges\s*\(|\b(Insert|Delete|InsertAll|DeleteAll)OnSubmit\s*\(|CompiledQuery\.Compile|\bExecuteMethodCall\s*\("),
    ("db", "linq-query", r"\bfrom\s+\w+\s+in\s+(?:this\.)?_?\w+\.\w+"),
    ("db", "orm", r"@Query\b|\bEntityManager\b|\.createQuery\s*\(|\.createNativeQuery\s*\(|extends\s+\w*(Jpa|Crud|PagingAndSorting|Mongo|Reactive\w*)Repository|@Select\b|@Insert\b|@Update\b|@Delete\b|SqlSession|\bDbSet<|FromSqlRaw|FromSqlInterpolated|ExecuteSqlRaw|\.SaveChanges(Async)?\s*\(|\bSqlCommand\b|OracleCommand|NpgsqlCommand|\.Query(Async|First\w*|Single\w*)?<|MongoTemplate|session\.query\s*\(|\.objects\.(filter|get|create)\s*\("),
    ("db", "sql", r"[\"'`]\s*(SELECT\s|INSERT\s+INTO\s|UPDATE\s+\w|DELETE\s+FROM\s|MERGE\s+INTO\s|CALL\s|EXEC(UTE)?\s|\{\s*call\s)"),
    ("cache", "cache", r"@Cacheable\b|@CacheEvict\b|RedisTemplate|IDistributedCache|IMemoryCache|\bJedis\b"),
    ("validation", "annotation", r"@(NotNull|NotBlank|NotEmpty|Size|Pattern|Min|Max|DecimalMin|DecimalMax|Positive|PositiveOrZero|Negative|Email|Past|Future|PastOrPresent|FutureOrPresent|Valid|Validated|Digits|Length|Range)\b|\[(Required|StringLength|MaxLength|MinLength|Range|RegularExpression|EmailAddress)\b"),
    ("validation", "imperative", r"throw\s+new\s+\w*(Validation|Invalid|IllegalArgument|BadRequest|Business|Constraint|Argument\w*)\w*|Objects\.requireNonNull|\bAssert\.\w+\s*\(|Preconditions\.check|\bValidate\.\w+\s*\(|StringUtils\.(isBlank|isEmpty|hasText|isNotBlank|isNotEmpty)|\bRuleFor\s*\(|ArgumentNullException|ValidationResult|BindingResult|\bvalidator\.validate\s*\(|raise\s+\w*(Validation|Value)Error"),
    ("error", "fault", r"@WebFault\b|SOAPFaultException|SoapFault\w*|FaultException|@ExceptionHandler\b|@ControllerAdvice\b|ResponseStatusException|@ResponseStatus\b|throw\s+new\s+\w+Exception|raise\s+\w+(Error|Exception)"),
    ("transaction", "tx", r"@Transactional\b|TransactionScope|BeginTransaction|\.commit\s*\(\s*\)|\.rollback\s*\(\s*\)"),
    ("security", "authz", r"@PreAuthorize\b|@Secured\b|@RolesAllowed\b|\[Authorize\b|@login_required"),
    ("mapping", "mapper", r"@Mapper\b|ModelMapper|ObjectMapper|\bMapStruct\b|IMapper\b|\.Map<"),
]
IMPORT_LINE_RE = re.compile(r"^\s*(?:import\s|package\s|namespace\s|from\s+\S+\s+import\b|(?:global\s+)?using\s+(?:static\s+)?[\w.]+(?:\s*=\s*[\w.<>,\s]+)?\s*;)")
HIT_RES = [(c, s, re.compile(r, re.I if s == "sql" else 0)) for c, s, r in HIT_PATTERNS]
SQL_TABLE_RE =re.compile(r"\b(?:FROM|JOIN|INTO|UPDATE|MERGE\s+INTO|DELETE\s+FROM)\s+([A-Za-z_][\w$#]*(?:\.[A-Za-z_][\w$#]*)?)", re.I)
SQL_NOT_TABLE = {"SELECT", "WHERE", "SET", "VALUES", "DUAL", "TABLE", "THE", "A", "AN", "AND", "OR", "ON", "AS", "TO", "OF",
                 "EACH", "ANY", "ALL", "LATERAL", "UNNEST", "JSON_TABLE"}
PROC_RES = [re.compile(p, re.I) for p in (
    r"with(?:Procedure|Function)Name\s*\(\s*\"([^\"]+)\"",
    r"@Procedure\s*\(\s*(?:\w+\s*=\s*)?\"([^\"]+)\"",
    r"createStoredProcedureQuery\s*\(\s*\"([^\"]+)\"",
    r"\{\s*\??=?\s*call\s+([\w.$#]+)",
    r"[\"'`]\s*(?:CALL|EXEC(?:UTE)?)\s+([\w.$#\[\]]+)",
    r"callproc\s*\(\s*[\"']([^\"']+)")]
PATH_LIT_RE = re.compile(r"[\"'`]((?:https?://[^\"'`\s]*)|(?:\$\{[^}]+\})?/[A-Za-z0-9_\-./{}$:]*)[\"'`]")
REL_PATH_RE = re.compile(r"\$?[\"'`]([A-Za-z][\w\-]*(?:/[\w\-{}.]*)+)[\"'`]")
HOST_RE = re.compile(r"https?://([A-Za-z0-9.\-]+)(?::\d+)?")
JDBC_RE = re.compile(r"jdbc:[\w:]+(?://|@)?([A-Za-z0-9.\-]+)")
PLACEHOLDER_RE = re.compile(r"\$\{([\w.\-]+)(?::[^}]*)?\}")
CS_CONFIG_RE = re.compile(r"(?:Configuration|_config\w*|config\w*|AppSettings|_settings)\s*\[\s*\"([^\"]+)\"\s*\]|GetValue<[^>]*>\s*\(\s*\"([^\"]+)\""
                          r"|GetConnectionString\s*\(\s*\"([^\"]+)\"|ConnectionStrings\s*\[\s*\"([^\"]+)\"\s*\]|GetSection\s*\(\s*\"([^\"]+)\"")
RULE_LINE_RE = re.compile(r"\b(if|elif|switch|case|when|while)\b|\?[^:;?.]+:|\.equals(IgnoreCase)?\s*\(|==|!=|>=|<=|[*/+\-]=|"
                          r"\b(multiply|add|subtract|divide|setScale|compareTo|max|min|round|floor|ceil|Round|Floor|Ceiling|Max|Min|Abs|Multiply|Divide)\s*\(|"
                          r"[*/]\s*\(?\s*\d|\d\s*[*/]|\bBigDecimal\s*\(\s*\"")
LOG_LINE_RE = re.compile(r"\b(log|logger|LOG|LOGGER|_logger|console|System\.out|print|Debug|Trace)\s*[.(]")
NUM_RE = re.compile(r"(?<![\w.])(\d+\.\d+|\d{2,})[mMdDfFlLuU]?(?![\w.])")
MEDIA_TYPE_RE = re.compile(r"^(application|text|image|audio|video|multipart|font)/", re.I)
CONST_RE = re.compile(r"\b(?:const|static\s+final|static\s+readonly|final\s+static|readonly\s+static)\s+[\w.<>?\[\]]+\s+([A-Za-z_]\w*)\s*=\s*([^;]+);"
                      r"|^\s*(?:private\s+|public\s+)?(?:const\s+)?(?:val\s+)?([A-Z][A-Z0-9_]{2,})\s*(?::\s*\w+)?\s*=\s*([^;\n]+)")
HANDLER_IFACE_RE = re.compile(r"\b(?:IRequestHandler|INotificationHandler|ICommandHandler|IQueryHandler|IConsumer|IHandleMessages|IEventHandler|RequestHandler)\s*<\s*([A-Za-z_]\w*)")
VALIDATOR_RE = re.compile(r"\bAbstractValidator\s*<\s*([A-Za-z_]\w*)")
FLUENT_MAP = [(re.compile(r"^(NotEmpty|NotNull)$"), "Required(fluent)"),
              (re.compile(r"^(Matches|EmailAddress|IsInEnum|IsEnumName|Must)$"), "Pattern(fluent)"),
              (re.compile(r"^(Length|MaximumLength|MinimumLength)$"), "Length(fluent)"),
              (re.compile(r"^(GreaterThan|GreaterThanOrEqualTo|LessThan|LessThanOrEqualTo|InclusiveBetween|ExclusiveBetween|PrecisionScale)$"), "Range(fluent)")]
ALIAS_RE = re.compile(r"(?:DataMember|MessageBodyMember|XmlElement|XmlAttribute|XmlArray|XmlArrayItem)\s*\([^)]*?\bName\s*=\s*\"([^\"]+)\""
                      r"|(?:XmlElement|XmlAttribute|XmlArray|JsonPropertyName|JsonProperty|SerializedName|JsonAlias|XmlElementAttribute)\s*\(\s*\"([^\"]+)\""
                      r"|@(?:JsonProperty|XmlElement|XmlAttribute|SerializedName)\s*\(\s*(?:value\s*=\s*|name\s*=\s*)?\"([^\"]+)\"")
IGNORED_FIELDS = {"extensiondata", "propertychanged", "serialversionuid"}
WCF_SER_NS = "http://schemas.microsoft.com/2003/10/Serialization/"
WCF_SER_TYPES = {"guid": "string", "char": "int", "duration": "duration", "anyURI": "string"}


def proc_key(name):
    """Normalize stored-procedure names: strip brackets and default schema (dbo.)."""
    n = name.replace("[", "").replace("]", "").upper().strip()
    return n[4:] if n.startswith("DBO.") else n


def value_hosts(v):
    """hosts referenced by a config value: URLs, JDBC urls, ADO.NET connection strings."""
    out = {h.lower() for h in HOST_RE.findall(v) + JDBC_RE.findall(v)}
    m = re.search(r"(?:Server|Data Source|Host|Addr|Address)\s*=\s*(?:tcp:)?([^;,\\]+)", v, re.I)
    if m and "=" in v and ";" in v:
        out.add("db:" + m.group(1).strip().lower())
    return out


def clean_lines(lines, lang):
    """Strip comments (keep strings). Returns list of same length."""
    out, in_block = [], False
    for s in lines:
        res, i, n, inq = [], 0, len(s), None
        while i < n:
            c = s[i]
            if in_block:
                if s.startswith("*/", i):
                    in_block = False
                    i += 2
                else:
                    i += 1
                continue
            if inq:
                res.append(c)
                if c == "\\" and i + 1 < n:
                    res.append(s[i + 1])
                    i += 2
                    continue
                if c == inq:
                    inq = None
                i += 1
                continue
            if lang == "py" and c == "#":
                break
            if lang != "py" and s.startswith("//", i):
                break
            if lang != "py" and s.startswith("/*", i):
                in_block = True
                i += 2
                continue
            if c in "\"`" or (c == "'" and lang in ("py", "js", "ts")):
                inq = c
            res.append(c)
            i += 1
        out.append("".join(res))
    return out


def blank_strings(s):
    return STR_RE.sub('""', s)


def block_end(blank, start, lang, raw=None):
    if lang == "py":
        ind = len(raw[start]) - len(raw[start].lstrip())
        end = start
        for i in range(start + 1, len(raw)):
            t = raw[i]
            if not t.strip():
                continue
            if len(t) - len(t.lstrip()) <= ind:
                break
            end = i
        return end
    depth, seen = 0, False
    for i in range(start, min(len(blank), start + 20000)):
        for ch in blank[i]:
            if ch == "{":
                depth += 1
                seen = True
            elif ch == "}":
                depth -= 1
                if seen and depth <= 0:
                    return i
            elif ch == ";" and not seen and depth == 0:
                return i
            elif ch == "(":
                depth += 0  # parentheses ignored
        if not seen and i - start > 12:
            return start
    return len(blank) - 1


def ann_start(clean, i):
    """Walk back over annotations/attributes stacked above line i."""
    j = i
    while j - 1 >= 0 and i - (j - 1) <= 10:
        t = clean[j - 1].strip()
        if not t or t.endswith((";", "{", "}")) or t.startswith(("//", "*", "/*")):
            break
        if t.startswith(("@", "[")) or not re.match(r"^(public|private|protected|internal|static|class|def|fun|func)\b", t):
            j -= 1
            continue
        break
    return j


def parse_annotations(txt):
    """Java @Ann(args) and C# [Ann(args), Other] -> ['Ann(args)', 'Other'] (Attribute suffix removed)."""
    out = []
    for n, args in re.findall(r"@(\w+)(\([^)]*\))?", txt):
        out.append(n + (args or ""))
    for block in re.findall(r"\[([A-Za-z][^\[\]]*)\]", txt):
        for part in RepoIndex._split_params(block):
            # [System.Serializable], [global::System.Data.Linq.Mapping.Table(...)] -> Serializable, Table(...)
            m = re.match(r"\s*(?:\w+\s*:\s*)?(?:global::)?(?:\w+\.)*(\w+)\s*(\(.*\))?\s*$", part)
            if m:
                out.append(re.sub(r"Attribute$", "", m.group(1)) + (m.group(2) or ""))
    return out


def strip_generics(t):
    prev = None
    while prev != t:
        prev = t
        t = re.sub(r"<[^<>]*>", "", t)
    return t


def generic_args(t):
    m = re.search(r"<(.*)>", t or "")
    if not m:
        return []
    return [x for x in re.findall(r"[A-Za-z_]\w*", m.group(1))]


class RepoIndex:
    def __init__(self, root, include_tests=False, label="repo"):
        self.root = os.path.abspath(root)
        self.label = label
        self.files = []          # dicts
        self.classes = defaultdict(list)   # name -> [class rec]
        self.children = defaultdict(set)   # parent simple name -> child class names
        self.hits = []
        self.config = {}         # key -> (value, file, line)
        self.config_hosts = defaultdict(list)
        self.mapper_stmts = defaultdict(list)  # MyBatis id -> [(file, line, text)]
        self.entity_table = {}
        self.sql_files = []
        self.include_tests = include_tests
        self.nullable_enabled = False
        self.handlers = defaultdict(set)    # request/message type -> handler class names (MediatR etc.)
        self.dbsets = {}                    # DbSet property name -> entity class
        self.constants = defaultdict(set)   # CONST_NAME -> literal values
        self.typed_client_cfg = defaultdict(set)  # .NET typed HttpClient class -> config keys / hosts
        self.db_funcs = {}                  # LINQ to SQL / EF function wrapper method -> stored proc name
        self.orm_models = []                # .dbml / .edmx files found
        self._scan()
        self._post()

    def _post(self):
        """Cross-file facts: EF table mappings, DbSet props, FluentValidation rules, handlers, constants."""
        for f in self.files:
            if f["lang"] not in ("cs", "java", "kotlin", "ts", "js", "py", "vb"):
                continue
            text = "\n".join(f["clean"])
            for m in re.finditer(r"Entity<\s*(\w+)\s*>\s*\(\s*\)[\s\S]{0,300}?\.ToTable\s*\(\s*\"([^\"]+)\"", text):
                self.entity_table[m.group(1)] = m.group(2).split(".")[-1]
            m = re.search(r"IEntityTypeConfiguration<\s*(\w+)\s*>", text)
            if m:
                t = re.search(r"\.ToTable\s*\(\s*\"([^\"]+)\"", text)
                if t:
                    self.entity_table[m.group(1)] = t.group(1).split(".")[-1]
            for m in re.finditer(r"AddHttpClient\s*<\s*(?:\w+\s*,\s*)?(\w+)\s*>\s*\(([\s\S]{0,400}?)\)\s*;", text):
                for cm in CS_CONFIG_RE.finditer(m.group(2)):
                    self.typed_client_cfg[m.group(1)].add(next(g for g in cm.groups() if g).replace(":", "."))
                for h in HOST_RE.findall(m.group(2)):
                    self.typed_client_cfg[m.group(1)].add("host:" + h.lower())
            # EF DbSet<T> Prop, LINQ to SQL Table<T> Prop  -> entity set property
            for m in re.finditer(r"\b(?:DbSet|IDbSet|Table|ITable)\s*<\s*(\w+)\s*>\s+(\w+)\s*(?:\{|=>|;)", text):
                self.dbsets[m.group(2)] = m.group(1)
                self.entity_table.setdefault(m.group(1), m.group(2))
            # LINQ to SQL stored procedure wrappers: [Function(Name="dbo.usp_X")] public int usp_X(...)
            for m in re.finditer(r"\[(?:[\w:.]*\.)?Function(?:Attribute)?\s*\(\s*Name\s*=\s*\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                                 r"(?:public|internal|private|protected)\s+[\w.<>\[\], ]+?\s+(\w+)\s*\(", text):
                self.db_funcs[m.group(2)] = m.group(1).replace("[", "").replace("]", "")
            for i, line in enumerate(f["clean"]):
                cm = CONST_RE.search(line)
                if cm:
                    name = cm.group(1) or cm.group(3)
                    for v in literal_set([cm.group(2) or cm.group(4)]):
                        self.constants[name].add(v)
            for c in f["classes"]:
                for hm in HANDLER_IFACE_RE.finditer(c.get("rest", "")):
                    self.handlers[hm.group(1)].add(c["name"])
                vm = VALIDATOR_RE.search(c.get("rest", ""))
                if vm:
                    body = "\n".join(f["clean"][c["start"]:c["end"] + 1])
                    for rm in re.finditer(r"RuleFor(?:Each)?\s*\(\s*\w+\s*=>\s*\w+\.(\w+)\s*\)([^;]*)", body):
                        prop, chain = rm.group(1), rm.group(2)
                        anns = []
                        for call in re.findall(r"\.(\w+)\s*[(<]", chain):
                            for rx, label in FLUENT_MAP:
                                if rx.match(call):
                                    anns.append(label + ":" + call)
                        for tc in self.classes.get(vm.group(1), []):
                            for fd in tc["fields"]:
                                if fd["name"] == prop:
                                    fd.setdefault("annotations", []).extend(anns)
                                    fd["validatedBy"] = "%s:%d" % (f["path"], c["start"] + 1)
        for c_list in self.classes.values():
            for c in c_list:
                if c["table"]:
                    self.entity_table[c["name"]] = c["table"]
        upper_entities = {k.upper(): v for k, v in self.entity_table.items()}
        for h in self.hits:
            new = []
            for k in h["keys"]:
                if k[0] == "proc-const":
                    for kind, v in self.constants.get(k[1], ()):
                        if kind == "str":
                            new.append(("proc", proc_key(v)))
                    continue
                if k[0] == "table":
                    t = k[1]
                    jvm = self.files[h["fidx"]]["lang"] in ("java", "kotlin", "scala", "groovy")
                    if jvm and t in upper_entities:  # JPQL / HQL entity name -> mapped table
                        t = upper_entities[t].upper()
                    elif jvm and t.endswith("ENTITY") and len(t) > 6:
                        t = t[:-6]
                    new.append(("table", t))
                    continue
                new.append(k)
            h["keys"] = sorted(set(new))

    # ---- walk
    def _scan(self):
        st = self.stats = defaultdict(int)
        self.slow_files = []      # (seconds, rel)
        self.big_files = []       # rel paths over MAX_FILE
        code_jobs = []            # source files are parsed after the walk (in parallel when there are many)
        t_last = time.time()

        def walk_err(e):
            st["walkErrors"] += 1
            LOG.write("%s: cannot list %s: %s" % (self.label, getattr(e, "filename", "?"), e))

        for root, dirs, files in os.walk(self.root, onerror=walk_err):
            n0 = len(dirs)
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".") and not is_out_dir(root, d)]
            st["dirsSkipped"] += n0 - len(dirs)
            rel_root = os.path.relpath(root, self.root)
            if not self.include_tests and TEST_DIR_RE.search(rel_root):
                st["testDirsSkipped"] += 1
                dirs[:] = []
                continue
            for f in files:
                st["seen"] += 1
                if time.time() - t_last > 10:
                    t_last = time.time()
                    say("  %s: %d files seen, %d indexed (%.0fs)" % (self.label, st["seen"], st["indexed"], time.time() - LOG.cur_t))
                p = os.path.join(root, f)
                ext = os.path.splitext(f)[1].lower()
                fl = f.lower()
                if fl in SKIP_FILES or GENERATED_FILE_RE.search(f):
                    st["generatedSkipped"] += 1
                    continue
                if ext == ".csproj":
                    try:
                        if re.search(r"<Nullable>\s*enable", self._read(p), re.I):
                            self.nullable_enabled = True
                    except OSError:
                        pass
                    continue
                if ext not in CODE_EXT and ext not in CONF_EXT and ext not in (".xml", ".sql", ".dbml", ".edmx") \
                        and not fl.endswith(".config"):
                    continue
                if ext in (".js", ".mjs") and VENDOR_JS_RE.search(fl):
                    st["vendorSkipped"] += 1        # bundled 3rd-party libraries (jquery, angular, ...): slow and irrelevant
                    continue
                rel = os.path.relpath(p, self.root).replace("\\", "/")
                try:
                    size = os.path.getsize(p)
                except OSError:
                    st["unreadable"] += 1
                    continue
                is_proxy = fl in ("reference.cs", "reference.vb") and re.search(r"(service|connected)[ _]?(references?|services)", rel.lower())
                if size > MAX_FILE and ext not in (".dbml", ".edmx") and not (is_proxy and size <= 4 * MAX_FILE):
                    if ext in (".cs", ".vb") and fl.endswith((".designer.cs", ".designer.vb")) and size < 40 * MAX_FILE:
                        try:
                            self._light_orm(self._read(p), rel)   # big LINQ to SQL / EF6 designer: mappings only
                            st["bigDesignerLight"] += 1
                        except Exception as e:  # noqa
                            warn("%s: failed to index %s: %s" % (self.label, rel, e))
                        continue
                    st["bigSkipped"] += 1
                    self.big_files.append(rel)
                    LOG.write("%s: skipped big file (%d KB) %s" % (self.label, size // 1024, rel))
                    continue
                if not self.include_tests and re.search(r"(Tests?|Spec|IT)\.(java|kt|cs|ts|js|py|go)$|_test\.(py|go)$|\.(spec|test)\.(ts|js)$", f):
                    st["testFilesSkipped"] += 1
                    continue
                if ext in CODE_EXT:
                    code_jobs.append((p, rel, CODE_EXT[ext]))
                    continue
                LOG.cur_file = "%s/%s" % (self.label, rel)
                t1 = time.time()
                try:
                    if ext in CONF_EXT or fl.endswith((".config",)):
                        self._conf(p, rel, ext)
                        st["config"] += 1
                    elif ext == ".xml":
                        self._xml(p, rel)
                        st["xml"] += 1
                    elif ext == ".sql":
                        self.sql_files.append(rel)
                        st["sql"] += 1
                    elif ext in (".dbml", ".edmx"):
                        self._orm_model(p, rel, ext)
                        st["ormModel"] += 1
                    st["indexed"] += 1
                except Exception as e:  # noqa
                    st["failed"] += 1
                    warn("%s: failed to index %s: %s" % (self.label, rel, e))
                    LOG.write(traceback.format_exc(limit=3))
                dt = time.time() - t1
                if dt > 1.0:
                    self.slow_files.append((round(dt, 1), rel))
                    LOG.write("%s: slow file %.1fs %s" % (self.label, dt, rel))
        LOG.cur_file = None
        self._index_code(code_jobs)
        glob_imports = set()
        for f in self.files:
            glob_imports |= f.get("globalImports", set())
        if glob_imports:   # C# 'global using' applies to every file of the project (approximation: whole repo)
            for f in self.files:
                if "imports" in f and f["lang"] == "cs":
                    f["imports"] |= glob_imports
        for c_list in self.classes.values():
            for c in c_list:
                for par in c["parents"]:
                    self.children[par].add(c["name"])
                if c["table"]:
                    self.entity_table[c["name"]] = c["table"]
        self.slow_files.sort(reverse=True)
        if st["bigSkipped"]:
            warn("limit: %s skipped %d file(s) over %d KB (see run.log); raise with --max-file-kb" % (self.label, st["bigSkipped"], MAX_FILE // 1024))
        if st["walkErrors"]:
            warn("limit: %s: %d folder(s) could not be listed (permissions / path > 260 chars?) - see run.log" % (self.label, st["walkErrors"]))
        if st["seen"] and not st["code"]:
            warn("%s: no source files indexed under %s - wrong folder?" % (self.label, self.root))

    def _merge(self, files, hits, outcomes):
        remap = {}
        for f in files:
            old = f["idx"]
            f["idx"] = remap[old] = len(self.files)
            self.files.append(f)
            for c in f["classes"]:
                c["fidx"] = f["idx"]
                self.classes[c["name"]].append(c)
        for h in hits:
            h["fidx"] = remap[h["fidx"]]
            self.hits.append(h)
        st = self.stats
        for rel, dt, err in outcomes:
            if err:
                st["failed"] += 1
                warn("%s: failed to index %s: %s" % (self.label, rel, err.splitlines()[0] if err else err))
                LOG.write(err)
            else:
                st["code"] += 1
                st["indexed"] += 1
            if dt > 1.0:
                self.slow_files.append((round(dt, 1), rel))
                LOG.write("%s: slow file %.1fs %s" % (self.label, dt, rel))

    def _index_code(self, jobs):
        jobs.sort(key=lambda j: j[1])
        n = len(jobs)
        workers = min(JOBS, max(1, n // 150))
        LOG.write("%s: parsing %d source files with %d process(es)" % (self.label, n, workers))
        if workers > 1:
            try:
                from concurrent.futures import ProcessPoolExecutor
                size = max(20, min(400, n // (workers * 4) or 1))
                chunks = [jobs[i:i + size] for i in range(0, n, size)]
                done, t_last = 0, time.time()
                with ProcessPoolExecutor(max_workers=workers) as ex:
                    for files, hits, outcomes in ex.map(_index_worker, chunks):
                        self._merge(files, hits, outcomes)
                        done += len(outcomes)
                        if time.time() - t_last > 10:
                            t_last = time.time()
                            say("  %s: %d/%d source files parsed (%.0fs)" % (self.label, done, n, time.time() - LOG.cur_t))
                return
            except Exception as e:  # noqa - e.g. process creation blocked by policy: fall back to one process
                warn("limit: %s: parallel indexing failed (%s: %s) - falling back to 1 process (use --jobs 1 to skip)" % (
                    self.label, type(e).__name__, e))
                self.files, self.hits, self.classes = [], [], defaultdict(list)
                self.stats["code"] = self.stats["failed"] = 0
                self.slow_files = []
        t_last = time.time()
        for i in range(0, n, 200):
            files, hits, outcomes = _index_worker(jobs[i:i + 200], self.label)
            self._merge(files, hits, outcomes)
            if time.time() - t_last > 10:
                t_last = time.time()
                say("  %s: %d/%d source files parsed (%.0fs)" % (self.label, min(n, i + 200), n, time.time() - LOG.cur_t))

    def _light_orm(self, text, rel):
        """Mappings only, for designer files too big for full indexing."""
        for m in re.finditer(r"\[(?:[\w:.]*\.)?Table(?:Attribute)?\s*\(\s*(?:Name\s*=\s*)?\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                             r"(?:public|internal)?\s*(?:partial\s+)?class\s+(\w+)", text):
            self.entity_table[m.group(2)] = m.group(1).replace("[", "").replace("]", "").split(".")[-1]
        for m in re.finditer(r"\[(?:[\w:.]*\.)?Function(?:Attribute)?\s*\(\s*Name\s*=\s*\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                             r"(?:public|internal|private|protected)\s+[\w.<>\[\], ]+?\s+(\w+)\s*\(", text):
            self.db_funcs[m.group(2)] = m.group(1).replace("[", "").replace("]", "")
        for m in re.finditer(r"\b(?:DbSet|IDbSet|Table|ITable)\s*<\s*(\w+)\s*>\s+(\w+)\s*(?:\{|=>|;)", text):
            self.dbsets[m.group(2)] = m.group(1)
            self.entity_table.setdefault(m.group(1), m.group(2))
        LOG.write("%s: big designer file indexed for mappings only: %s" % (self.label, rel))

    @staticmethod
    def _read(p):
        with open(p, "rb") as fh:
            data = fh.read()
        if data[:2] in (b"\xff\xfe", b"\xfe\xff"):          # UTF-16 with BOM (common for old VS / designer files)
            return data.decode("utf-16", "replace")
        if len(data) > 3 and data[1:2] == b"\x00" and data[3:4] == b"\x00":   # UTF-16LE without BOM
            return data.decode("utf-16-le", "replace")
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                return data.decode(enc)
            except UnicodeDecodeError:
                continue
        return data.decode("utf-8", "replace")

    # ---- code files
    def _code(self, p, rel, lang):
        raw = self._read(p).splitlines()
        clean = clean_lines(raw, lang)
        blank = [blank_strings(x) for x in clean]
        f = {"path": rel, "lang": lang, "raw": raw, "clean": clean, "classes": [], "methods": [],
             "vars": defaultdict(set), "placeholders": set(), "idx": len(self.files)}
        self.files.append(f)
        # classes
        for i, line in enumerate(clean):
            for m in CLASS_RE.finditer(blank[i]):
                kind, name, rest = m.group(1), m.group(2), m.group(3)
                if kind == "object" and lang not in ("kotlin", "scala"):
                    continue
                if name in KEYWORDS:
                    continue
                end = block_end(blank, i, lang, raw)
                rest_ng = strip_generics(rest)
                params = ""
                if "(" in rest_ng and kind in ("record", "class", "struct") and lang not in ("py",):
                    pm = re.match(r"\s*\((.*?)\)(.*)", rest_ng)
                    if pm:
                        params, rest_ng = pm.group(1), pm.group(2)
                if lang == "py":
                    parents = re.findall(r"[A-Za-z_][\w.]*", rest_ng.split(":")[0])
                else:
                    parents = [x for x in re.findall(r"[A-Z][\w]*", rest_ng) if x not in ("Extends", "Implements")]
                astart = ann_start(clean, i)
                ann_txt = " ".join(clean[astart:i + 1])
                tm = re.search(r"@Table\s*\(\s*(?:name\s*=\s*)?\"([^\"]+)\"|\[(?:[\w:.]*\.)?Table(?:Attribute)?\s*\(\s*(?:Name\s*=\s*)?\"([^\"]+)\"|__tablename__\s*=\s*['\"](\w+)",
                               ann_txt + " " + " ".join(clean[i:min(end + 1, i + 6)]))
                is_entity = bool(re.search(r"@Entity\b|\[(?:[\w:.]*\.)?Table(?:Attribute)?\b|__tablename__", ann_txt + " ".join(clean[i:min(end + 1, i + 6)])))
                table = next(g for g in tm.groups() if g).replace("[", "").replace("]", "").split(".")[-1] if tm else (name if is_entity else None)
                c = {"name": name, "kind": kind, "file": rel, "fidx": f["idx"], "start": i, "end": end,
                     "parents": [x.split(".")[-1] for x in parents], "fields": [], "lang": lang,
                     "is_enum": kind == "enum", "table": table, "annotations": parse_annotations(ann_txt),
                     "rest": rest + " " + " ".join(clean[i + 1:min(i + 3, end + 1)]).split("{")[0] if "{" not in rest else rest}
                if params:
                    for pp in self._split_params(params):
                        fd = self._param_field(pp, lang)
                        if fd:
                            fd["line"] = i + 1
                            c["fields"].append(fd)
                f["classes"].append(c)
                self.classes[name].append(c)
        # namespaces / imports (used to tell apart classes with the same simple name)
        if lang in ("cs", "vb", "java", "kotlin", "scala", "groovy"):
            ns_marks, imports = [], set()
            for i, line in enumerate(clean):
                s = line.lstrip()
                if not s[:1] or s[0] not in "nNpuUiI":
                    continue
                m = NS_DECL_RE.match(line)
                if m:
                    ns_marks.append((i, m.group(1)))
                    continue
                m = USING_RE.match(line)
                if m:
                    imp = m.group(1)
                    imports.add(imp)
                    if s.startswith("global "):
                        f.setdefault("globalImports", set()).add(imp)
                    if lang not in ("cs", "vb") and "." in imp:
                        imports.add(imp.rsplit(".", 1)[0])     # java: import a.b.C -> package a.b
            f["imports"], f["nsList"] = imports, [n for _, n in ns_marks]
            for c in f["classes"]:
                c["ns"] = next((n for i, n in reversed(ns_marks) if i <= c["start"]), "")
        # methods
        for i, line in enumerate(clean):
            name, cls_hint = self._method_decl(line, blank[i], lang, raw, i)
            if not name:
                continue
            end = block_end(blank, i, lang, raw)
            astart = ann_start(clean, i) if lang != "py" else i
            if lang == "py":
                j = i
                while j - 1 >= 0 and clean[j - 1].strip().startswith("@"):
                    j -= 1
                astart = j
            cls = self._enclosing_class(f, i)
            sig = " ".join(clean[i:min(i + 6, end + 1)])
            sig = sig.split("{")[0] if lang != "py" else sig.split(":")[0]
            f["methods"].append({"name": name, "start": astart, "decl": i, "end": end, "cls": cls_hint or (cls["name"] if cls else None),
                                 "sig": sig[:400]})
        # fields (DTO properties)
        for c in f["classes"]:
            inner_methods = [m for m in f["methods"] if c["start"] < m["decl"] <= c["end"]]
            for i in range(c["start"] + 1, c["end"] + 1):
                if any(m["start"] <= i <= m["end"] for m in inner_methods):
                    continue
                own = self._enclosing_class(f, i)
                if own is not c:
                    continue
                fd = self._field_decl(clean[i], lang)
                if fd and norm(fd["name"]) not in IGNORED_FIELDS:
                    a = ann_start(clean, i)
                    ann_txt = " ".join(clean[a:i + 1])
                    fd["annotations"] = parse_annotations(ann_txt)
                    al = ALIAS_RE.search(ann_txt)
                    if al:
                        fd["alias"] = next(g for g in al.groups() if g)
                    if lang == "cs" and re.search(r"\brequired\s", LEAD_ANN_RE.sub("", clean[i])):
                        fd["annotations"].append("Required(modifier)")
                    if re.search(r"IsRequired\s*=\s*true", ann_txt):
                        fd["annotations"].append("Required(DataMember)")
                    fd["line"] = i + 1
                    c["fields"].append(fd)
            if c["is_enum"]:
                body = " ".join(clean[c["start"] + 1:c["end"] + 1]).split(";")[0]
                c["enum_values"] = re.findall(r"\b([A-Z][A-Z0-9_]+)\b", body)[:50]
        # qualified variable types (Ns.Sub.QuoteService _svc) and using-aliases (using X = Ns.QuoteService;)
        if lang in ("cs", "vb", "java", "kotlin"):
            qv, al = {}, {}
            for line in clean:
                if "." not in line and "=" not in line:
                    continue
                am = ALIAS_USING_RE.match(line)
                if am:
                    al[am.group(1)] = am.group(2).replace("global::", "")
                    continue
                for qm in QUAL_VAR_RE.finditer(line):
                    full = (qm.group(1) + qm.group(2)).replace("global::", "")
                    if full.split(".")[0] not in ("this", "base", "System", "Microsoft", "java", "javax"):
                        qv[qm.group(3)] = full
            if qv:
                f["qualvars"] = qv
            if al:
                f["aliases"] = al
        # variables / placeholders
        for i, line in enumerate(clean):
            for m in VAR_RE.finditer(line):
                f["vars"][m.group(2)].add(m.group(1))
            for m in VAR2_RE.finditer(line):
                f["vars"][m.group(1)].add(m.group(2))
            for m in VAR3_RE.finditer(line):
                f["vars"][m.group(1)].add(m.group(2))
            for m in VAR4_RE.finditer(line):
                f["vars"][m.group(1)].add(m.group(2))
            m = PROP_DECL_RE.match(line)
            if m and m.group(1) not in KEYWORDS and m.group(2) not in KEYWORDS:
                f["vars"][m.group(2)].add(m.group(1))
            for m in PLACEHOLDER_RE.finditer(line):
                f["placeholders"].add(m.group(1))
            for m in CS_CONFIG_RE.finditer(line):
                f["placeholders"].add(next(g for g in m.groups() if g).replace(":", "."))
            for m in re.finditer(r"(?:getenv|environ(?:\.get)?|process\.env)\s*[\[(.]\s*['\"]?([A-Z_][A-Z0-9_]*)", line):
                f["placeholders"].add(m.group(1))
        # hits
        for i, line in enumerate(clean):
            if not line.strip() or IMPORT_LINE_RE.match(line):
                continue
            decl_only = "(" not in line and self._field_decl(line, lang) is not None
            for cat, sub, rx in HIT_RES:
                if rx.search(line):
                    if decl_only and cat in ("db", "outbound", "messaging", "cache"):
                        continue
                    self._hit(f, i, cat, sub)

    @staticmethod
    def _split_params(s):
        out, depth, cur = [], 0, ""
        for ch in s:
            if ch in "<([":
                depth += 1
            elif ch in ">)]":
                depth -= 1
            if ch == "," and depth == 0:
                out.append(cur)
                cur = ""
            else:
                cur += ch
        if cur.strip():
            out.append(cur)
        return out

    @staticmethod
    def _param_field(pp, lang):
        anns = parse_annotations(pp)
        al = ALIAS_RE.search(pp)
        pp2 = re.sub(r"@\w+(\([^)]*\))?\s*|\[[^\]]*\]\s*", "", pp).strip()
        pp2 = pp2.split("=")[0].strip()
        rec = None
        m = re.match(r"(?:val|var)?\s*(\w+)\s*:\s*([\w.<>\[\]?, ]+)", pp2) if lang in ("kotlin", "scala", "ts", "py") else None
        if m:
            rec = {"name": m.group(1), "type": m.group(2).strip(), "annotations": anns}
        else:
            m = re.match(r"(?:final\s+)?([\w.<>\[\]?, ]+?)\s+(\w+)$", pp2)
            if m:
                rec = {"name": m.group(2), "type": m.group(1).strip(), "annotations": anns}
        if rec and al:
            rec["alias"] = next(g for g in al.groups() if g)
        return rec

    def _field_decl(self, line, lang):
        s = LEAD_ANN_RE.sub("", line)
        if re.search(r"\bstatic\b|\bconst\b", s) and not re.search(r"\bdata\b", s):
            return None
        rx = {"cs": CS_PROP_RE, "kotlin": KT_PROP_RE, "scala": KT_PROP_RE, "ts": TS_PROP_RE, "js": None, "py": PY_PROP_RE}.get(lang, JAVA_FIELD_RE)
        if rx is None:
            return None
        m = rx.search(s) if rx in (KT_PROP_RE,) else rx.match(s)
        if not m and lang == "cs":
            m = JAVA_FIELD_RE.match(s)
        if not m:
            return None
        name, typ = m.group("name"), m.group("type").strip()
        if name in KEYWORDS or typ in ("return", "new", "throw", "else", "package", "import"):
            return None
        acc = re.search(r"\b(public|private|protected|internal)\b", s)
        return {"name": name, "type": typ, "access": acc.group(1) if acc else "",
                "prop": bool(re.search(r"\{\s*(?:get|set|init)\b|=>", s))}

    def _method_decl(self, line, blank, lang, raw, i):
        if lang == "py":
            m = PY_DEF_RE.match(line)
            return (m.group(2), None) if m else (None, None)
        if lang == "go":
            m = GO_FUNC_RE.match(line)
            return (m.group(2), m.group(1)) if m else (None, None)
        if lang in ("js", "ts"):
            m = JS_FUNC_RE.match(line)
            if m:
                return (m.group(1) or m.group(2), None)
        s = LEAD_ANN_RE.sub("", blank)
        m = METHOD_RE.match(s)
        if not m:
            return None, None
        name = m.group("name")
        ret = (m.group("ret") or "").strip()
        mods = (m.group("mods") or "").strip()
        if name in KEYWORDS or ret.split("<")[0] in KEYWORDS or ret.endswith("."):
            return None, None
        if not mods and not ret:
            if lang in ("js", "ts") and re.search(r"\)\s*(?::\s*[^={;]+)?\{\s*$", s) and line.startswith((" ", "\t")):
                return name, None
            return None, None
        if "=" in s.split("(")[0]:
            return None, None
        return name, None

    @staticmethod
    def _enclosing_class(f, i):
        best = None
        for c in f["classes"]:
            if c["start"] <= i <= c["end"] and (best is None or c["start"] >= best["start"]):
                best = c
        return best

    def _enclosing_method(self, f, i):
        best = None
        for m in f["methods"]:
            if m["start"] <= i <= m["end"] and (best is None or m["start"] >= best["start"]):
                best = m
        return best

    def _hit(self, f, i, cat, sub):
        line = f["clean"][i]
        ctx = " ".join(f["clean"][i:i + 4])
        keys = []
        if cat == "db":
            sql_ctx = (ctx if sub in ("sql", "orm", "jdbc", "linq2sql") else line).replace("[", "").replace("]", "")
            for t in SQL_TABLE_RE.findall(sql_ctx) if sub != "linq-query" else []:
                tn = t.upper()
                if tn.split(".")[-1] not in SQL_NOT_TABLE and not tn.isdigit():
                    keys.append(("table", tn.split(".")[-1]))
            for rx in PROC_RES:
                for pn in rx.findall(ctx):
                    keys.append(("proc", proc_key(pn)))
            if sub == "stored-proc" and re.search(r"StoredProcedure", line):
                win = " ".join(f["clean"][max(0, i - 6):i + 3])
                for pn in re.findall(r"(?:SqlCommand|OracleCommand|NpgsqlCommand|DbCommand|Query\w*|Execute\w*|CommandText\s*=)\s*(?:<[^>]*>)?\s*\(?\s*\$?\"([\w.\[\]$#]+)\"", win):
                    keys.append(("proc", proc_key(pn)))
            if sub == "stored-proc" and not any(k[0] == "proc" for k in keys):
                for ident in re.findall(r"with(?:Procedure|Function)Name\s*\(\s*([A-Za-z_]\w*)\s*\)|StoredProcedureQuery\s*\(\s*([A-Za-z_]\w*)", ctx):
                    keys.append(("proc-const", next(x for x in ident if x)))
        if cat in ("outbound", "endpoint"):
            for lit in PATH_LIT_RE.findall(ctx) + [x for x in REL_PATH_RE.findall(ctx) if not MEDIA_TYPE_RE.match(x)]:
                k = self.path_key(lit)
                if k:
                    keys.append(("path", k))
        if cat in ("outbound", "messaging"):
            for ph in PLACEHOLDER_RE.findall(ctx):
                keys.append(("config", ph))
        if cat == "messaging":
            for s in re.findall(r"(?:CreateSender|CreateReceiver|convertAndSend|[Ss]end|Produce|BasicPublish|GetQueue\w*|QueueClient|TopicClient|"
                                r"Destination|Topic|Queue|routingKey|exchange)\w*\s*\(\s*\"([\w.\-/:]{3,80})\"", line):
                keys.append(("queue", s.upper()))
        meth = self._enclosing_method(f, i)
        self.hits.append({"cat": cat, "sub": sub, "file": f["path"], "fidx": f["idx"], "line": i + 1,
                          "method": meth["name"] if meth else None,
                          "text": f["raw"][i].strip()[:180], "keys": sorted(set(keys))})

    @staticmethod
    def path_key(lit):
        p = lit
        if is_url(p):
            p = urllib.parse.urlparse(p).path
        p = PLACEHOLDER_RE.sub("", p)
        segs = [s for s in p.split("/") if s and not s.startswith("{") and not s.startswith(":") and s not in (".", "..")]
        segs = [s for s in segs if re.match(r"^[A-Za-z0-9_\-.]+$", s)]
        if not segs:
            return None
        if len(segs) == 1 and "." in segs[0]:
            return None  # file name, not an API path
        return "/" + "/".join(s.lower() for s in segs)

    # ---- config
    def _conf(self, p, rel, ext):
        txt = self._read(p)
        entries = []
        if ext in (".yml", ".yaml"):
            stack = []
            for ln, line in enumerate(txt.splitlines(), 1):
                if not line.strip() or line.lstrip().startswith(("#", "-")):
                    continue
                m = re.match(r"^(\s*)([\w.\-\[\]\"']+)\s*:\s*(.*)$", line)
                if not m:
                    continue
                ind = len(m.group(1))
                while stack and stack[-1][0] >= ind:
                    stack.pop()
                key = m.group(2).strip("\"'")
                val = m.group(3).strip().strip("\"'")
                full = ".".join([s[1] for s in stack] + [key])
                if val and not val.startswith("#"):
                    entries.append((full, val, ln))
                else:
                    stack.append((ind, key))
        elif ext == ".json":
            try:
                obj = json.loads(txt)
            except ValueError:
                return

            def walk(o, pre):
                if isinstance(o, dict):
                    for k, v in o.items():
                        walk(v, pre + [str(k)])
                elif isinstance(o, (str, int, float, bool)):
                    entries.append((".".join(pre), str(o), 0))
            walk(obj, [])
        elif ext == ".config" or rel.lower().endswith(".config"):
            for ln, line in enumerate(txt.splitlines(), 1):
                for m in re.finditer(r"<add\s+(?:key|name)=\"([^\"]+)\"[^>]*?(?:value|connectionString)=\"([^\"]+)\"", line):
                    entries.append((m.group(1), m.group(2), ln))
                for m in re.finditer(r"address=\"([^\"]+)\"", line):
                    entries.append(("endpoint.address", m.group(1), ln))
        else:
            for ln, line in enumerate(txt.splitlines(), 1):
                m = re.match(r"^\s*([\w.\-\[\]]+)\s*[=:]\s*(.*)$", line)
                if m and not line.lstrip().startswith(("#", "!", ";")):
                    entries.append((m.group(1), m.group(2).strip(), ln))
        for k, v, ln in entries:
            self.config[k] = (v, rel, ln)
            for h in value_hosts(v):
                self.config_hosts[h].append((k, rel, ln))

    def _orm_model(self, p, rel, ext):
        """LINQ to SQL .dbml / EF6 .edmx: entity-set property -> table, method -> stored procedure."""
        txt = self._read(p)
        self.orm_models.append(rel)
        if ext == ".dbml":
            def attr(tag, name):
                a = re.search(r"\b%s=\"([^\"]+)\"" % name, tag)
                return a.group(1) if a else None
            for m in re.finditer(r"<Table\s+([^>]*)>\s*<Type\s+([^>]*)>", txt):
                tname, member, typ = attr(m.group(1), "Name"), attr(m.group(1), "Member"), attr(m.group(2), "Name")
                if tname and typ:
                    self.entity_table[typ] = tname.replace("[", "").replace("]", "").split(".")[-1]
                    if member:
                        self.dbsets[member] = typ
            for m in re.finditer(r"<Function\s+([^>]*)>", txt):
                fname, meth = attr(m.group(1), "Name"), attr(m.group(1), "Method")
                if fname:
                    self.db_funcs[meth or fname.split(".")[-1]] = fname.replace("[", "").replace("]", "")
        else:  # edmx: EntitySetMapping / FunctionImportMapping (best effort)
            for m in re.finditer(r"<EntitySetMapping\s+Name=\"(\w+)\"[\s\S]{0,400}?TypeName=\"[\w.()]*?\.?(\w+)\)?\"[\s\S]{0,300}?StoreEntitySet=\"(\w+)\"", txt):
                self.dbsets[m.group(1)] = m.group(2)
                self.entity_table[m.group(2)] = m.group(3)
            for m in re.finditer(r"<FunctionImportMapping\s+FunctionImportName=\"(\w+)\"\s+FunctionName=\"[\w.]*?\.?(\w+)\"", txt):
                self.db_funcs[m.group(1)] = m.group(2)

    def _xml(self, p, rel):
        txt = self._read(p)
        if "<mapper" in txt[:3000]:
            lines = txt.splitlines()
            for i, line in enumerate(lines):
                m = re.search(r"<(select|insert|update|delete)\s+[^>]*id=\"(\w+)\"", line)
                if m:
                    body = " ".join(lines[i:i + 15])
                    self.mapper_stmts[m.group(2)].append((rel, i + 1, body))
        elif re.search(r"<(beans|configuration|jaxws|cxf|spring)", txt[:3000]) or rel.lower().endswith(".config"):
            self._conf(p, rel, ".config")
            for ln, line in enumerate(txt.splitlines(), 1):
                for h in HOST_RE.findall(line):
                    self.config_hosts[h.lower()].append(("xml", rel, ln))

    def resolve_hosts(self, placeholder):
        """config key (or section) -> hosts. Matches exact key, section prefix, or suffix (ConnectionStrings.X)."""
        out = set()

        def kn(s):
            return s.lower().replace("-", "").replace("_", ".").replace(":", ".")
        c = kn(placeholder)
        for k, (v, rel, ln) in self.config.items():
            k2 = kn(k)
            if k2 == c or k2.startswith(c + ".") or k2.endswith("." + c):
                out |= value_hosts(v)
        return out

    # ---- lookup helpers
    def class_recs(self, name):
        return self.classes.get(name, [])

    def methods_in(self, c, mname):
        f = self.files[c["fidx"]]
        return [(f, m) for m in f["methods"] if m["name"] == mname and c["start"] <= m["decl"] <= c["end"]]

    @staticmethod
    def sees(ns, f):
        """Can code in file f refer to a type declared in namespace/package ns without qualification?"""
        if not ns or "imports" not in f:
            return True
        if ns in f["imports"]:
            return True
        return any(x == ns or x.startswith(ns + ".") for x in f.get("nsList", ()))

    def visible_recs(self, name, f):
        recs = self.class_recs(name)
        if len(recs) <= 1:
            return recs
        if "imports" not in f:
            return recs
        # C#/Java precedence: own (or enclosing) namespace first, then imported namespaces
        own = [c for c in recs if c.get("ns") and any(x == c["ns"] or x.startswith(c["ns"] + ".") for x in f.get("nsList", ()))]
        if own:
            deepest = max(len(c["ns"]) for c in own)
            return [c for c in own if len(c["ns"]) == deepest]
        vis = [c for c in recs if self.sees(c.get("ns"), f)]
        return vis or recs

    def methods_named(self, cls_name, mname):
        out = []
        for c in self.class_recs(cls_name):
            f = self.files[c["fidx"]]
            for m in f["methods"]:
                if m["name"] == mname and c["start"] <= m["decl"] <= c["end"]:
                    out.append((f, m))
        return out

    def subclasses(self, name, depth=0):
        out = set()
        if depth > 6:
            return out
        for ch in self.children.get(name, ()):
            out.add(ch)
            out |= self.subclasses(ch, depth + 1)
        return out

    def superclasses(self, name, depth=0):
        out = set()
        if depth > 6:
            return out
        for c in self.class_recs(name):
            for p in c["parents"]:
                if p in self.classes:
                    out.add(p)
                    out |= self.superclasses(p, depth + 1)
        return out

    def summary(self):
        return {"root": self.root, "files": len(self.files), "classes": sum(len(v) for v in self.classes.values()),
                "methods": sum(len(f["methods"]) for f in self.files), "hits": len(self.hits),
                "sqlFiles": self.sql_files[:50]}


ALIAS_USING_RE = re.compile(r"^\s*(?:global\s+)?using\s+(\w+)\s*=\s*((?:global::)?[\w.]+)\s*;")
QUAL_VAR_RE = re.compile(r"(?<![\w.])((?:global::)?(?:[A-Za-z_]\w*\.)+)([A-Z]\w*)(?:\s*<[^;()=]*>)?(?:\[\])?\s+([A-Za-z_]\w*)\s*(?=[;=,)])")
NS_DECL_RE = re.compile(r"^\s*(?:namespace|Namespace|package)\s+([\w.]+)")
USING_RE = re.compile(r"^\s*(?:global\s+)?(?:using|Imports|import)\s+(?:static\s+)?(?:\w+\s*=\s*)?([\w.]+?)(?:\.\*)?\s*;?\s*$")
# method names too generic to resolve against "any class this file uses" when the receiver type is unknown
COMMON_METHODS = {"Get", "Set", "Add", "Remove", "Contains", "Where", "Select", "First", "FirstOrDefault", "Any", "All", "Count",
                  "ToList", "ToArray", "ToString", "Equals", "GetHashCode", "Dispose", "Close", "Open", "Clear", "Find", "Load",
                  "Save", "Update", "Delete", "Insert", "Execute", "Run", "Send", "Read", "Write", "Map", "Parse", "Format",
                  "Validate", "Create", "Build", "Init", "Initialize", "Process", "Handle", "Invoke", "Log", "Info", "Error",
                  "Debug", "Warn", "Trace", "get", "set", "add", "put", "remove", "size", "isEmpty", "stream", "map", "filter",
                  "collect", "of", "toString", "equals", "length", "push", "then", "catch", "forEach", "Join", "Split",
                  "Trim", "Replace", "Substring", "IndexOf", "StartsWith", "EndsWith", "ToUpper", "ToLower",
                  "ToUpperInvariant", "ToLowerInvariant", "Append", "AppendLine", "ConfigureAwait", "Result", "Wait",
                  "GetType", "GetValue", "SetValue", "GetProperty", "GetProperties", "GetMethod", "Serialize", "Deserialize",
                  "WriteLine", "Flush", "Dispose", "AddWithValue", "ToBase64String", "GetBytes", "GetString", "Encode",
                  "Decode", "Now", "Today", "Format", "Concat", "IsNullOrEmpty", "IsNullOrWhiteSpace", "TryParse",
                  "ContainsKey", "TryGetValue", "OrderBy", "OrderByDescending", "GroupBy", "Sum", "Max", "Min", "Single",
                  "SingleOrDefault", "Last", "LastOrDefault", "Skip", "Take", "Distinct", "Cast", "OfType", "AsQueryable",
                  "ToDictionary", "Aggregate", "Zip", "Reverse"}
JOBS = 1   # set from --jobs
MAX_FANOUT = 6   # set from --max-fanout
INDEX_EXT = set(CODE_EXT) | CONF_EXT | {".xml", ".sql", ".dbml", ".edmx", ".csproj"}


def _repo_signature(root, include_tests):
    """Cheap fingerprint of every indexable file (path, size, mtime) - any change invalidates the cache."""
    import hashlib
    h = hashlib.sha1(("%s|%s|%s|%s" % (VERSION, MAX_FILE, include_tests, os.path.abspath(root))).encode("utf-8"))
    n = 0
    for r, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith(".") and not is_out_dir(r, d))
        for fn in sorted(files):
            if os.path.splitext(fn)[1].lower() in INDEX_EXT or fn.lower().endswith(".config"):
                try:
                    st = os.stat(os.path.join(r, fn))
                except OSError:
                    continue
                h.update(("%s|%d|%d\n" % (os.path.join(r, fn), st.st_size, int(st.st_mtime))).encode("utf-8", "replace"))
                n += 1
    return h.hexdigest(), n


def load_index(root, include_tests, label, use_cache=True):
    """RepoIndex, re-used from a local cache when no indexable file changed since the last run."""
    if not use_cache:
        return RepoIndex(root, include_tests, label)
    import hashlib
    import pickle
    import tempfile
    cache_dir = os.path.join(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir(), "soap_parity_cache")
    key = hashlib.sha1(("%s|%s|%s" % (os.path.abspath(root).lower(), label, include_tests)).encode("utf-8")).hexdigest()[:16]
    path = os.path.join(cache_dir, key + ".pkl")
    t0 = time.time()
    sig, n = _repo_signature(root, include_tests)
    LOG.write("%s: signature of %d files computed in %.1fs" % (label, n, time.time() - t0))
    try:
        with open(path, "rb") as fh:
            data = pickle.load(fh)
        if data.get("sig") == sig:
            idx = data["index"]
            idx.from_cache = True
            for w in getattr(idx, "scan_warnings", []):
                warn(w)
            say("  %s: unchanged since last run - using cached index (%s)" % (label, path))
            LOG.write("%s: loaded cached index %s" % (label, path))
            return idx
    except (OSError, EOFError, pickle.UnpicklingError, AttributeError, KeyError, ValueError, TypeError):
        pass
    w0 = len(WARNINGS)
    idx = RepoIndex(root, include_tests, label)
    idx.scan_warnings = WARNINGS[w0:]
    try:
        os.makedirs(cache_dir, exist_ok=True)
        tmp = "%s.%d.tmp" % (path, os.getpid())     # parallel runs on the same repo must not share a temp file
        with open(tmp, "wb") as fh:
            pickle.dump({"sig": sig, "index": idx}, fh, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp, path)
        LOG.write("%s: index cached at %s" % (label, path))
    except Exception as e:  # noqa - caching is best effort
        LOG.write("%s: could not cache index: %s" % (label, e))
    return idx


def _index_worker(batch, label="repo"):
    """Parse a batch of source files in isolation (runs in a worker process). Returns (files, hits, outcomes)."""
    w = RepoIndex.__new__(RepoIndex)
    w.files, w.hits, w.classes, w.label = [], [], defaultdict(list), label
    outcomes = []
    for p, rel, lang in batch:
        t1 = time.time()
        n_files, n_hits = len(w.files), len(w.hits)
        try:
            w._code(p, rel, lang)
            outcomes.append((rel, time.time() - t1, None))
        except Exception as e:  # noqa
            del w.files[n_files:]
            del w.hits[n_hits:]
            outcomes.append((rel, time.time() - t1, "%s: %s\n%s" % (type(e).__name__, e, traceback.format_exc(limit=3))))
    return w.files, w.hits, outcomes


# --------------------------------------------------------------------------- slicing

class Slice:
    """Best-effort method-level reachability from entry methods."""

    def __init__(self, repo, entries, max_depth=8, max_methods=400):
        self.repo = repo
        self.lines = defaultdict(set)       # fidx -> set(line index)
        self.methods = []                   # (file, method)
        self.types = set()
        self.visited = set()
        self.visited_classes = set()
        self.method_lines = defaultdict(set)  # only lines inside visited method bodies
        self.fanout = {}                      # (type, method) -> implementations NOT followed
        self.via = {}                         # fidx -> first (from file, method) that pulled it in (diagnostics)
        self.unresolved = []                  # calls near the entry whose target class could not be resolved (call order)
        self.node = {}                        # (fidx, decl) -> (file, method)   for the call graph
        self.edges = defaultdict(list)        # (fidx, decl) -> [(fidx, decl)] callees, first-seen order
        self._edge_set = set()
        self.entries = [(f["idx"], m["decl"]) for f, m in entries]
        for f, m in entries:
            self.node[(f["idx"], m["decl"])] = (f, m)
        q_ = deque((f, m, 0) for f, m in entries)
        while q_ and len(self.visited) < max_methods:
            f, m, d = q_.popleft()
            key = (f["idx"], m["decl"])
            if key in self.visited:
                continue
            self.visited.add(key)
            self.methods.append((f, m))
            for i in range(m["start"], m["end"] + 1):
                self.lines[f["idx"]].add(i)
                self.method_lines[f["idx"]].add(i)
            cls = self.repo._enclosing_class(f, m["decl"])
            if cls and (f["idx"], cls["start"]) not in self.visited_classes:
                self.visited_classes.add((f["idx"], cls["start"]))
                # lifecycle code runs for every call: constructors, @PostConstruct, afterPropertiesSet
                for x in f["methods"]:
                    if cls["start"] <= x["decl"] <= cls["end"] and (
                            x["name"] == cls["name"] or x["name"] in ("afterPropertiesSet", "__init__") or
                            re.search(r"@PostConstruct", " ".join(f["clean"][x["start"]:x["decl"] + 1]))):
                        q_.append((f, x, d))
                        self._edge(key, f, x)
            if cls and not self._data_context(f, cls):  # class-level lines (fields/constants/annotations) are shared context
                inner = [x for x in f["methods"] if cls["start"] <= x["decl"] <= cls["end"]]
                for i in range(cls["start"], cls["end"] + 1):
                    if not any(x["start"] <= i <= x["end"] for x in inner):
                        self.lines[f["idx"]].add(i)
            if d >= max_depth:
                continue
            for nf, nm in self._callees(f, m, cls):
                self._edge(key, nf, nm)
                if nf["idx"] not in self.via and nf["idx"] != f["idx"]:
                    self.via[nf["idx"]] = "%s.%s" % (os.path.basename(f["path"]), m["name"])
                q_.append((nf, nm, d + 1))
        self.capped = len(self.visited) >= max_methods

    def _edge(self, key, nf, nm):
        ck = (nf["idx"], nm["decl"])
        if ck == key or (key, ck) in self._edge_set:
            return
        self._edge_set.add((key, ck))
        self.edges[key].append(ck)
        self.node.setdefault(ck, (nf, nm))

    def stats(self):
        return {"methods": len(self.visited), "files": len(self.lines), "capped": self.capped,
                "fanoutSkipped": sorted(("%s.%s x%d" % (t, mm, n) for (t, mm), n in self.fanout.items()))[:10],
                "unresolved": self.unresolved[:15]}

    def _callees(self, f, m, cls):
        repo = self.repo
        body = "\n".join(f["clean"][m["decl"]:m["end"] + 1])
        own = cls["name"] if cls else None
        # superclasses of THIS class record (not of every class sharing its simple name)
        own_supers = set()
        if cls:
            for p in cls["parents"]:
                own_supers.add(p)
                own_supers |= repo.superclasses(p)
        out = []
        targets = []  # (class name, method name[, namespace qualifier | "!self"])
        inherited = {}
        for sup in own_supers:
            for c in repo.class_recs(sup):
                for k, v in repo.files[c["fidx"]]["vars"].items():
                    inherited.setdefault(k, set()).update(v)
        calls = []
        qualvars, aliases = f.get("qualvars", {}), f.get("aliases", {})
        early = len(self.visited) <= 15
        for recv, meth in CALL_RECV_RE.findall(body) + METHREF_RE.findall(body):
            types = set()
            n0 = len(targets)
            if recv in ("this", "self", "base", "super"):
                types.add(own)
                if recv in ("super", "base") and own:
                    types |= own_supers
            elif recv in qualvars:                       # Ns.Sub.QuoteService _svc  -> exact namespace
                q = qualvars[recv]
                targets.append((q.rsplit(".", 1)[-1], meth, q.rsplit(".", 1)[0]))
            elif recv in repo.classes:
                types.add(recv)
            calls.append((recv, meth))
            for t in (f["vars"].get(recv) or inherited.get(recv) or ()):
                if t in aliases:                         # using AppQuotes = Ns.QuoteService;  AppQuotes _svc
                    q = aliases[t]
                    targets.append((q.rsplit(".", 1)[-1], meth, q.rsplit(".", 1)[0] if "." in q else None))
                elif recv not in qualvars:
                    types.add(t)
            for t in types:
                if t:
                    # a field/variable whose type has the SAME simple name as the calling class is another class
                    # (C# would need a qualifier or alias) -> never resolve it back to the caller itself
                    self_clash = t == own and recv not in ("this", "self", "base", "super")
                    targets.append((t, meth, "!self") if self_clash else (t, meth))
            if not types and len(targets) == n0 and recv[:1].islower() and meth not in COMMON_METHODS:
                # unknown receiver: try classes referenced by this file that define the method
                for t in self._file_types(f):
                    targets.append((t, meth))

        for t, meth in GENERIC_CHAIN_RE.findall(body):
            targets.append((t, meth))
            calls.append((t, meth))
        for name in CALL_RE.findall(body):
            if name in KEYWORDS:
                continue
            if own:
                targets.append((own, name))
                for sup in own_supers:
                    targets.append((sup, name))
            if name in repo.classes:  # constructor
                targets.append((name, name))
        for t in NEW_RE.findall(body):
            targets.append((t, t))
        # interface / abstract method -> implementations of the same method
        if own:
            # only classes that really derive from THIS class/interface (by name chain + namespace visibility)
            sub_names = repo.subclasses(own)
            impl = []
            for s in sub_names:
                for c in repo.class_recs(s):
                    if set(c["parents"]) & (sub_names | {own}) and repo.sees(cls.get("ns"), repo.files[c["fidx"]]):
                        impl.append(c)
            if len(impl) > MAX_FANOUT:
                impl = [c for c in impl if repo.methods_in(c, m["name"])]
                if len(impl) > MAX_FANOUT:
                    self.fanout[(own, m["name"])] = len(impl)
                    impl = []
            for c in impl:
                out.extend(repo.methods_in(c, m["name"]))
        for t in TYPE_TOKEN_RE.findall(body):
            if t in repo.classes:
                self.types.add(t)
            # mediator / bus dispatch: Send(new XCommand()) -> XCommandHandler.Handle
            for h in repo.handlers.get(t, ()):
                for hm in ("Handle", "HandleAsync", "Consume", "Execute", "ExecuteAsync", "handle", "Process"):
                    targets.append((h, hm))
        # MyBatis mapper statements
        for name in set(CALL_RE.findall(body)) | {mm for _, mm in CALL_RECV_RE.findall(body)}:
            for rel, ln, text in repo.mapper_stmts.get(name, []):
                self.types.add("mapper:" + name)
        seen, resolved = set(), set()
        for tgt in targets:
            t, meth = tgt[0], tgt[1]
            qual = tgt[2] if len(tgt) > 2 else None
            if not t:
                continue
            # which class(es) named t does THIS file mean? (big repos have several QuoteService / Mapper / Helper classes)
            if qual == "!self":
                others = [c for c in repo.class_recs(t) if c is not cls and c.get("ns") != (cls or {}).get("ns")]
                t_recs = [c for c in others if repo.sees(c.get("ns"), f)] or others
                if len(t_recs) > MAX_FANOUT:
                    self.fanout[(t, meth)] = len(t_recs)
                    t_recs = []
            elif qual:
                cands = repo.class_recs(t)
                t_recs = [c for c in cands if (c.get("ns") or "") == qual or (c.get("ns") or "").endswith("." + qual)] \
                    or repo.visible_recs(t, f)
            elif t == own and cls is not None:
                t_recs = [c for c in repo.class_recs(own) if c.get("ns") == cls.get("ns")] or [cls]
            else:
                t_recs = repo.visible_recs(t, f)
            t_ns = {c.get("ns") or "" for c in t_recs}
            sub_recs = []
            sub_names = repo.subclasses(t)
            for s in sub_names:
                for c in repo.class_recs(s):
                    if not (set(c["parents"]) & (sub_names | {t})):
                        continue            # same simple name, but this class does not derive from t
                    sf = repo.files[c["fidx"]]
                    if "" in t_ns or any(repo.sees(ns, sf) for ns in t_ns):
                        sub_recs.append(c)
            if len(sub_recs) > MAX_FANOUT:
                # base class / widely implemented interface: following every implementation explodes the slice
                impls = [c for c in sub_recs if repo.methods_in(c, meth)]
                if len(impls) > MAX_FANOUT:
                    self.fanout[(t, meth)] = len(impls)
                    sub_recs = []
            for c in t_recs + sub_recs:
                key = (c["fidx"], c["start"], meth)
                if key in seen:
                    continue
                seen.add(key)
                found = repo.methods_in(c, meth)
                if found:
                    resolved.add(meth)
                out.extend(found)
                self.types.add(c["name"])
        if early:
            for recv, meth in calls:
                if meth in resolved or meth in COMMON_METHODS or recv in ("this", "self", "base", "super", "obj", "o", "e", "ex",
                                                                          "x", "item", "value", "sender", "args", "request", "response"):
                    continue
                known_var = recv in f["vars"] or recv in inherited or recv in qualvars
                if recv[:1].isupper() and not known_var and recv not in repo.classes:
                    continue        # static framework class (Console, Math, JsonConvert, ...)
                tset = f["vars"].get(recv) or inherited.get(recv) or set()
                if tset and not any(t in repo.classes for t in tset) and not any(re.match(r"I[A-Z]", t) for t in tset):
                    continue        # concrete framework/library class (SqlCommand, HttpClient, ...): not part of the app's logic
                if tset and any(any(p_ not in repo.classes for p_ in c_["parents"]) and c_["kind"] != "interface"
                                for t in tset for c_ in repo.class_recs(t)):
                    continue        # repo class with a framework base class (DbContext.SaveChanges, ClientBase.Close): inherited
                typ = ",".join(sorted(tset)) or "?"
                u = "%s.%s.%s() [type %s]" % (m["name"], recv, meth, typ)
                if u not in self.unresolved:
                    self.unresolved.append(u)
        return out

    def _file_types(self, f):
        ts = set()
        for v in f["vars"].values():
            ts |= {t for t in v if t in self.repo.classes}
        return ts

    @staticmethod
    def _data_context(f, cls):
        """Generated data classes (LINQ to SQL / EF DataContext, *.designer.cs, very large classes): their class-level
        lines declare EVERY table (Table<T>/DbSet<T> properties). Using one method must not mark all tables as used."""
        if f["path"].lower().endswith((".designer.cs", ".designer.vb")) or cls["end"] - cls["start"] > 600:
            return True
        return any(re.search(r"DataContext|DbContext|ObjectContext", p) for p in cls["parents"])

    def contains(self, hit):
        i = hit["line"] - 1
        if hit.get("cat") == "db" and re.search(r"\b(?:I?Table|I?DbSet|ObjectSet)\s*<", hit.get("text", "")):
            return i in self.method_lines.get(hit["fidx"], ())   # a table property declaration is not a use
        return i in self.lines.get(hit["fidx"], ())

    def files(self):
        return sorted({self.repo.files[i]["path"] for i in self.lines})


# --------------------------------------------------------------------------- comparison helpers

XSD_FAMILY = {}
for _t in ("string", "normalizedString", "token", "anyURI", "ID", "IDREF", "NCName", "Name", "language", "QName",
           "NMTOKEN", "ENTITY", "union", "list"):
    XSD_FAMILY[_t] = "string"
for _t in ("int", "integer", "long", "short", "byte", "unsignedInt", "unsignedLong", "unsignedShort", "unsignedByte",
           "positiveInteger", "negativeInteger", "nonNegativeInteger", "nonPositiveInteger"):
    XSD_FAMILY[_t] = "int"
XSD_FAMILY.update({"decimal": "decimal", "double": "float", "float": "float", "boolean": "bool", "dateTime": "datetime",
                   "date": "date", "time": "time", "base64Binary": "binary", "hexBinary": "binary", "duration": "duration",
                   "anyType": "any", "anySimpleType": "any", "any": "any", "gYear": "int"})

CODE_FAMILY = {
    "string": "string", "str": "string", "charsequence": "string", "uuid": "string", "guid": "string", "char[]": "string",
    "int": "int", "integer": "int", "long": "int", "short": "int", "byte": "int", "biginteger": "int", "int32": "int",
    "int64": "int", "int16": "int", "uint": "int", "ulong": "int", "atomicinteger": "int", "atomiclong": "int",
    "bigdecimal": "decimal", "decimal": "decimal", "double": "float", "float": "float", "single": "float",
    "number": "number", "boolean": "bool", "bool": "bool",
    "localdatetime": "datetime", "offsetdatetime": "datetime", "zoneddatetime": "datetime", "instant": "datetime",
    "datetime": "datetime", "datetimeoffset": "datetime", "xmlgregoriancalendar": "datetime", "calendar": "datetime",
    "timestamp": "datetime", "date": "date|datetime", "localdate": "date", "dateonly": "date", "localtime": "time",
    "timeonly": "time", "timespan": "duration", "duration": "duration", "byte[]": "binary", "bytes": "binary",
    "object": "any", "jsonnode": "any", "any": "any", "dynamic": "any",
}
COLLECTION_RE = re.compile(r"^(List|ArrayList|Set|HashSet|Collection|Iterable|IEnumerable|IList|ICollection|IReadOnlyList|"
                           r"Array|Seq|MutableList|Sequence|list|set|tuple|Flux)\b|\[\]$")


def code_type_info(t):
    t = (t or "").strip().rstrip("?")
    t = re.sub(r"^(Optional|Nullable|Mono|Task|ResponseEntity|ActionResult|Maybe)\s*<(.*)>$", r"\2", t)
    is_list = bool(COLLECTION_RE.search(t)) or t.endswith("[]") and t.lower() not in ("byte[]", "char[]")
    elem = t
    if is_list:
        ga = generic_args(t)
        elem = ga[-1] if ga else t[:-2] if t.endswith("[]") else t
    base = strip_generics(elem).split(".")[-1].strip()
    fam = CODE_FAMILY.get(base.lower()) or CODE_FAMILY.get(t.lower())
    return {"base": base, "list": is_list, "family": fam}


def type_compat(xsd_type, code_t, repo):
    xf = XSD_FAMILY.get(xsd_type)
    info = code_type_info(code_t)
    cf = info["family"]
    if xf is None or xf == "any":
        return "OK", ""
    if cf is None:
        cls = repo.class_recs(info["base"])
        if cls and cls[0]["is_enum"] and xf == "string":
            return "OK", "enum"
        return "WARN", "code type %s vs xsd %s" % (info["base"], xsd_type)
    if cf == "any":
        return "OK", ""
    if xf == cf or (xf in ("date", "datetime") and "date" in cf and cf != "date") or (xf == "datetime" and cf == "date|datetime") or (xf == "date" and cf == "date|datetime"):
        return "OK", ""
    if xf == "decimal" and cf == "float":
        return "WARN", "precision drift: xsd decimal -> floating point %s" % info["base"]
    if xf == "datetime" and cf == "date":
        return "WARN", "time part lost: xsd dateTime -> %s" % info["base"]
    if cf == "number" and xf in ("int", "decimal", "float"):
        return "OK", ""
    if xf in ("int",) and cf in ("decimal", "float"):
        return "WARN", "int -> %s" % info["base"]
    if xf in ("decimal", "float") and cf == "int":
        return "WARN", "fraction lost: xsd %s -> %s" % (xsd_type, info["base"])
    return "MISMATCH", "xsd %s vs code %s" % (xsd_type, info["base"])


REQ_ANN = re.compile(r"^(NotNull|NotBlank|NotEmpty|Required|NonNull|Nonnull|JsonProperty\(.*required\s*=\s*true)", re.I)
PAT_ANN = re.compile(r"^(Pattern|RegularExpression|Email|EmailAddress)", re.I)
LEN_ANN = re.compile(r"^(Size|Length|MaxLength|StringLength|MinLength)", re.I)
RANGE_ANN = re.compile(r"^(Min|Max|DecimalMin|DecimalMax|Positive|PositiveOrZero|Negative|Range|Digits)", re.I)


def validation_gaps(sf, fd, repo, imperative_fields):
    gaps = []
    anns = fd.get("annotations", []) if fd else []
    typ = fd.get("type", "") if fd else ""
    nm = norm(sf["name"])
    imp = nm in imperative_fields
    r = sf.get("restr", {})
    required = isinstance(sf.get("min"), int) and sf["min"] >= 1 and not sf.get("choice") and not sf.get("nillable")
    value_type = re.match(r"^(int|long|double|boolean|bool|short|float|decimal|byte|char|DateTime|DateTimeOffset|DateOnly|TimeOnly|Guid|TimeSpan)$", typ)
    implicit_nrt = repo.nullable_enabled and typ and not typ.endswith("?") and re.match(r"^(string|[A-Z]\w*)$", typ) and not typ.startswith(("List", "IList", "IEnumerable"))
    if required and not any(REQ_ANN.match(a) for a in anns) and not value_type:
        gaps.append(("required", "minOccurs=1", "IMPLICIT_NRT" if implicit_nrt and not imp else imp))
    if "pattern" in r and not any(PAT_ANN.match(a) for a in anns):
        gaps.append(("pattern", r["pattern"], imp))
    if any(k in r for k in ("length", "maxLength", "minLength")) and not any(LEN_ANN.match(a) for a in anns):
        gaps.append(("length", ",".join("%s=%s" % (k, r[k]) for k in ("length", "minLength", "maxLength") if k in r), imp))
    if any(k in r for k in ("minInclusive", "maxInclusive", "minExclusive", "maxExclusive", "totalDigits")) and not any(RANGE_ANN.match(a) for a in anns):
        gaps.append(("range", ",".join("%s=%s" % (k, r[k]) for k in ("minInclusive", "maxInclusive", "minExclusive", "maxExclusive", "totalDigits") if k in r), imp))
    if "enumeration" in r:
        info = code_type_info(typ)
        cls = repo.class_recs(info["base"])
        if not (cls and cls[0]["is_enum"]) and not any(PAT_ANN.match(a) for a in anns):
            gaps.append(("enumeration", "|".join(r["enumeration"][:10]), imp))
        elif cls and cls[0]["is_enum"]:
            missing = [v for v in r["enumeration"] if norm(v) not in {norm(x) for x in cls[0].get("enum_values", [])}]
            if missing:
                gaps.append(("enumeration", "enum %s lacks %s" % (info["base"], ",".join(missing[:10])), imp))
    return gaps


class ContractMatcher:
    def __init__(self, fields, repo, names):
        self.fields = fields
        self.repo = repo
        self.names = names
        self.by_parent = defaultdict(list)
        for f in fields:
            parent = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
            self.by_parent[parent].append(f)
        self.rows = []

    def children(self, path):
        return self.by_parent.get(path, [])

    def class_score(self, path, cls):
        kids = self.children(path)
        if not kids or not cls["fields"]:
            return 0.0, {}
        mapping, used = {}, set()
        for k in kids:
            best, bf = 0.0, None
            for fd in cls["fields"]:
                if fd["name"] in used:
                    continue
                s = self.names.sim(k["name"], fd["name"])
                if fd.get("alias"):
                    s = max(s, self.names.sim(k["name"], fd["alias"]))
                if s > best:
                    best, bf = s, fd
            if bf and best >= 0.8:
                mapping[k["path"]] = (bf, best)
                used.add(bf["name"])
        score = sum(s for _, s in mapping.values()) / len(kids)
        return round(score, 3), mapping

    def best_class(self, path, candidates=None, top=3):
        pool = []
        names = candidates if candidates is not None else list(self.repo.classes.keys())
        for n in names:
            for c in self.repo.class_recs(n):
                if c["is_enum"]:
                    continue
                s, _ = self.class_score(path, c)
                if s > 0:
                    pool.append((s, c))
        pool.sort(key=lambda x: (-x[0], len(x[1]["fields"])))
        return pool[:top]

    def compare(self, root_path, cls, depth=0, out=None):
        out = out if out is not None else []
        score, mapping = self.class_score(root_path, cls)
        used = set()
        for k in self.children(root_path):
            m = mapping.get(k["path"])
            row = {"path": k["path"], "xsdType": k["type"], "min": k["min"], "max": k["max"],
                   "restr": k.get("restr", {}), "choice": k.get("choice"), "attr": k.get("attr"),
                   "repoClass": cls["name"], "repoFile": cls["file"]}
            if not m:
                row.update(status="MISSING", repoField=None)
                out.append(row)
                if k["complex"]:
                    for d in self._descendants(k["path"]):
                        out.append({"path": d["path"], "xsdType": d["type"], "min": d["min"], "max": d["max"],
                                    "restr": d.get("restr", {}), "status": "MISSING(parent)", "repoField": None,
                                    "repoClass": None, "repoFile": None})
                continue
            fd, sim = m
            used.add(fd["name"])
            row.update(repoField=fd["name"] + ((" (wire: %s)" % fd["alias"]) if fd.get("alias") else ""),
                       repoFieldName=fd["name"], repoType=fd["type"], repoLine=fd.get("line"), sim=sim,
                       annotations=fd.get("annotations", []), validatedBy=fd.get("validatedBy"),
                       status="MATCH" if sim >= 0.95 else "FUZZY")
            info = code_type_info(fd["type"])
            notes = []
            if k.get("list") and not info["list"]:
                notes.append("xsd repeating, code single")
            if not k.get("list") and info["list"] and not k["complex"]:
                notes.append("code collection, xsd single")
            if not k["complex"]:
                st, msg = type_compat(k["type"], fd["type"], self.repo)
                row["typeCheck"] = st
                if msg:
                    notes.append(msg)
            row["notes"] = "; ".join(notes)
            out.append(row)
            if k["complex"] and depth < 12 and not k["type"].startswith("RECURSIVE"):
                child_path = k["path"]
                kids = self.children(child_path)
                # wrapper collapse: <items><item[]/></items>  <->  List<LineItem> items  (also WCF ArrayOfX)
                if len(kids) == 1 and kids[0].get("list") and info["list"]:
                    row_w = {"path": kids[0]["path"], "xsdType": kids[0]["type"], "min": kids[0]["min"],
                             "max": kids[0]["max"], "restr": kids[0].get("restr", {}), "status": "MATCH",
                             "repoField": fd["name"] + "[]", "repoType": info["base"],
                             "repoClass": cls["name"], "repoFile": cls["file"], "repoLine": fd.get("line"),
                             "notes": "wrapper collapsed"}
                    out.append(row_w)
                    if not kids[0]["complex"]:
                        st, msg = type_compat(kids[0]["type"], info["base"], self.repo)
                        row_w["typeCheck"] = st
                        if msg:
                            row_w["notes"] += "; " + msg
                        continue
                    child_path = kids[0]["path"]
                target = [c for c in self.repo.class_recs(info["base"]) if not c["is_enum"]]
                if not target:
                    for ga in generic_args(fd["type"]):
                        target = [c for c in self.repo.class_recs(ga) if not c["is_enum"]]
                        if target:
                            break
                if target:
                    self.compare(child_path, target[0], depth + 1, out)
                else:
                    bc = self.best_class(child_path, top=1)
                    if bc and bc[0][0] >= 0.5:
                        self.compare(child_path, bc[0][1], depth + 1, out)
                    else:
                        for d in self._descendants(child_path):
                            out.append({"path": d["path"], "xsdType": d["type"], "min": d["min"], "max": d["max"],
                                        "restr": d.get("restr", {}), "status": "UNRESOLVED", "repoField": None,
                                        "repoClass": None, "repoFile": None,
                                        "notes": "code type %s not found in repo" % info["base"]})
        for fd in cls["fields"]:
            if fd["name"] not in used:
                out.append({"path": root_path + "/(" + fd["name"] + ")", "xsdType": None, "status": "EXTRA_IN_REPO",
                            "repoField": fd["name"], "repoType": fd["type"], "repoClass": cls["name"],
                            "repoFile": cls["file"], "repoLine": fd.get("line")})
        return out

    def _descendants(self, path):
        return [f for f in self.fields if f["path"].startswith(path + "/")]


def method_sig_types(repo, f, m):
    toks = set(TYPE_TOKEN_RE.findall(m["sig"]))
    ret = set()
    pre = m["sig"].split("(")[0]
    for t in TYPE_TOKEN_RE.findall(pre):
        ret.add(t)
    params = set(TYPE_TOKEN_RE.findall(m["sig"][len(pre):]))
    return {t for t in params if t in repo.classes}, {t for t in ret if t in repo.classes}, toks


def literal_set(lines):
    out = set()
    for line in lines:
        if LOG_LINE_RE.search(line):
            continue
        for s1, s2 in STR_RE.findall(line):
            s = s1 or s2
            if 1 <= len(s) <= 40 and not re.search(r"\s(FROM|WHERE|SELECT)\s", s, re.I) and not s.startswith(("http", "/", "$")):
                try:
                    out.add(("num", "%g" % float(s)))
                except ValueError:
                    out.add(("str", s.lower()))
        for n in NUM_RE.findall(STR_RE.sub("", line)):
            try:
                out.add(("num", "%g" % float(n)))
            except ValueError:
                pass
    return out


# --------------------------------------------------------------------------- per-operation analysis

SOAP_MARK_RE = re.compile(r"@WebService|@WebMethod|@Endpoint\b|@PayloadRoot|@SoapAction|OperationContract|ServiceContract|@ResponsePayload|"
                          r"WebServiceGatewaySupport|\[WebMethod|\[WebService|\[SoapDocumentMethod|System\.Web\.Services")
ENDPOINT_ANN_RE = re.compile(r"@(Get|Post|Put|Delete|Patch|Request)Mapping|@(GET|POST|PUT|DELETE|PATCH)\b|@Path\b|\[Http(Get|Post|Put|Delete|Patch)|"
                             r"@WebMethod|@PayloadRoot|@SoapAction|\bOperationContract\b|\[WebMethod|@(app|router|api)\.(route|get|post|put|delete|patch)|"
                             r"\bMap(Get|Post|Put|Delete)\s*\(|@(JmsListener|KafkaListener|RabbitListener)")


def base_name(n):
    return re.sub(r"(Async|_async)$", "", n or "")


def find_repo1_entries(repo, op, names):
    cands = []
    opn = op["wsdlName"]
    req_root = op["request"][0]["name"] if op["request"] else None
    impl = op.get("implClass")
    if impl:   # .svc given: the implementing class is known -> pin the entry to it
        want = {norm(op.get("codeMethod") or ""), norm(opn)} - {""}
        pinned = []
        recs = repo.class_recs(impl)
        if op.get("implNs"):     # several classes share the simple name: keep the one named in the .svc
            recs = [c for c in recs if c.get("ns") == op["implNs"]] or recs
        for c in recs:
            f = repo.files[c["fidx"]]
            for m in f["methods"]:
                if c["start"] < m["decl"] <= c["end"] and (norm(m["name"]) in want or norm(base_name(m["name"])) in want):
                    pinned.append((f, m))
        if pinned:
            return pinned[:4]
        warn("entry: %s.%s not found in implementing class - falling back to name search" % (impl, op.get("codeMethod") or opn))
    for f in repo.files:
        file_soap = any(SOAP_MARK_RE.search(x) for x in f["clean"][:400])
        for m in f["methods"]:
            ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
            s = names.sim(base_name(m["name"]), opn)
            strong = bool(re.search(r"operationName\s*=\s*\"%s\"|localPart\s*=\s*\"(%s|%s)\"|SoapAction\([^)]*%s|"
                                    r"OperationContract\s*\([^)]*Name\s*=\s*\"%s\"|Action\s*=\s*\"[^\"]*[/:]%s\"|MessageName\s*=\s*\"%s\"" % (
                re.escape(opn), re.escape(opn), re.escape(req_root or opn), re.escape(opn), re.escape(opn), re.escape(opn), re.escape(opn)), ann))
            if req_root and re.search(r"\b%s\b" % re.escape(req_root), m["sig"]) and file_soap:
                strong = True
            if strong:
                score = 3.0
            elif s >= 0.95:
                score = 2.0 + (0.5 if file_soap or SOAP_MARK_RE.search(ann) else 0)
            else:
                continue
            cands.append((score, f, m))
    cands.sort(key=lambda x: -x[0])
    if not cands:
        return []
    top = cands[0][0]
    return [(f, m) for s, f, m in cands if s >= top - 0.5][:4]


def repo2_endpoints(repo):
    eps = []
    for f in repo.files:
        class_route = {}
        for c in f["classes"]:
            a = ann_start(f["clean"], c["start"])
            txt = " ".join(f["clean"][a:c["start"] + 1])
            m = re.search(r"@RequestMapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?\"([^\"]*)\"|\[Route\(\s*\"([^\"]*)\"|@Path\(\s*\"([^\"]*)\"", txt)
            if m:
                class_route[c["name"]] = m.group(1) or m.group(2) or m.group(3)
        for m in f["methods"]:
            ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
            if not ENDPOINT_ANN_RE.search(ann):
                continue
            rm = re.search(r"Mapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?\"([^\"]*)\"|\[Http\w+\(\s*\"([^\"]*)\"|\[Route\(\s*\"([^\"]*)\"|@Path\(\s*\"([^\"]*)\"|\.(?:route|get|post|put|delete|patch)\(\s*['\"]([^'\"]*)|Map\w+\(\s*\"([^\"]*)\"", ann)
            route = next((g for g in (rm.groups() if rm else ()) if g), "")
            verb = re.search(r"@(Get|Post|Put|Delete|Patch)Mapping|\[Http(Get|Post|Put|Delete|Patch)|@(GET|POST|PUT|DELETE)|\.(get|post|put|delete|patch)\(", ann)
            verb = next((g for g in (verb.groups() if verb else ()) if g), "SOAP" if re.search(r"WebMethod|PayloadRoot|SoapAction|OperationContract", ann) else "")
            croute = class_route.get(m["cls"], "")
            full = (croute + "/" + route).replace("//", "/") if route or croute else ""
            full = full.replace("[controller]", re.sub(r"Controller$", "", m["cls"] or "").lower()).replace("[action]", m["name"].lower())
            eps.append({"file": f["path"], "fidx": f["idx"], "line": m["decl"] + 1, "method": m["name"], "cls": m["cls"],
                        "route": full, "verb": verb.upper(), "f": f, "m": m})
        # ASP.NET Core minimal API: app.MapPost("/x", handler | lambda)
        for i, line in enumerate(f["clean"]):
            mm = re.search(r"\.Map(Get|Post|Put|Delete|Patch)\s*\(\s*\"([^\"]+)\"\s*,\s*(.*)", line)
            if not mm:
                continue
            rest = mm.group(3)
            hm = re.match(r"\s*(?:\w+\.)*(\w+)\s*\)", rest)
            found = False
            if hm and "=>" not in rest:
                for f2 in repo.files:
                    for m2 in f2["methods"]:
                        if m2["name"] == hm.group(1):
                            eps.append({"file": f2["path"], "fidx": f2["idx"], "line": m2["decl"] + 1, "method": m2["name"],
                                        "cls": m2["cls"], "route": mm.group(2), "verb": mm.group(1).upper(), "f": f2, "m": m2})
                            found = True
            if not found:
                end = block_end([blank_strings(x) for x in f["clean"]], i, f["lang"], f["raw"])
                pseudo = {"name": "lambda@%d" % (i + 1), "start": i, "decl": i, "end": max(end, i), "cls": None,
                          "sig": " ".join(f["clean"][i:min(end + 1, i + 3)])[:400]}
                eps.append({"file": f["path"], "fidx": f["idx"], "line": i + 1, "method": pseudo["name"], "cls": None,
                            "route": mm.group(2), "verb": mm.group(1).upper(), "f": f, "m": pseudo})
        # JS/Express style: router.post('/x', handler)
        for i, line in enumerate(f["clean"]):
            mm = re.search(r"\b(app|router|server)\.(get|post|put|delete|patch)\s*\(\s*['\"`]([^'\"`]+)['\"`]\s*,\s*(?:[\w.]+\s*,\s*)*([\w.]+)\s*\)", line)
            if mm:
                handler = mm.group(4).split(".")[-1]
                for f2 in repo.files:
                    for m2 in f2["methods"]:
                        if m2["name"] == handler:
                            eps.append({"file": f2["path"], "fidx": f2["idx"], "line": m2["decl"] + 1, "method": handler,
                                        "cls": m2["cls"], "route": mm.group(3), "verb": mm.group(2).upper(), "f": f2, "m": m2})
    return eps


def repo2_entry_for(args, op):
    """--repo2-entry / --repo2-map -> spec for this operation (per-operation mapping wins over a global one)."""
    per, glob = {}, None
    for e in getattr(args, "repo2_entry", None) or []:
        if "=" in e and not re.match(r"^[A-Za-z]:[\\/]", e):
            k, v = e.split("=", 1)
            per[norm(k)] = v.strip()
        else:
            glob = e
    per.update({norm(k): v for k, v in (getattr(args, "_repo2_map", None) or {}).items()})
    return per.get(norm(op["name"])) or per.get(norm(op.get("wsdlName") or "")) or glob


PIN_CLS_SUFFIX_RE = re.compile(r"(Controller|Endpoints?|Module|Handlers?|Api|Service|Routes?|Group)$", re.I)


def _route_words(route):
    return {norm(x) for x in re.split(r"[^A-Za-z0-9]+", route or "") if x}


def forced_repo2_eps(spec, eps, repo):
    """--repo2-entry / repo2_map.json value -> endpoint records (any method, not only HTTP endpoints).
    Forms: 'path/File.cs:line' (most precise - also selects a minimal-API lambda), 'Class.Method', 'Method'.
    Class.Method is matched strictly first, then tolerantly: Class may be the file name (ForeignExchange -> ForeignExchange.cs)
    or the class name without a Controller/Endpoints/Module/... suffix; Method may also be a route word of a lambda endpoint."""
    spec = spec.strip().strip("`").strip()
    fm = re.match(r"^(.+?):(\d+)$", spec)
    if fm:
        want = fm.group(1).replace("\\", "/").lower().lstrip("./")
        line = int(fm.group(2))

        def file_ok(path):
            pl = path.lower()
            return pl == want or pl.endswith("/" + want) or (("/" not in want) and os.path.basename(pl) == want)
        # an endpoint (incl. minimal-API lambdas) declared at / spanning that line wins over the enclosing method
        hits = [e for e in eps if file_ok(e["file"]) and e["m"]["start"] + 1 <= line <= e["m"]["end"] + 1]
        if hits:
            return sorted(hits, key=lambda e: (e["m"]["end"] - e["m"]["start"], abs(e["line"] - line)))[:1]
        out = [(f, m) for f in repo.files if file_ok(f["path"]) for m in f["methods"] if m["start"] + 1 <= line <= m["end"] + 1]
        out = sorted(out, key=lambda x: x[1]["end"] - x[1]["start"])[:1]   # innermost method
    else:
        cls, _, meth = spec.rpartition(".")
        nm = norm(base_name(meth))
        ncls = norm(cls)
        ncls_s = norm(PIN_CLS_SUFFIX_RE.sub("", cls)) if cls else ""

        def stem(f):
            return norm(os.path.splitext(os.path.basename(f["path"]))[0])

        def name_ok(m):
            return norm(m["name"]) == nm or norm(base_name(m["name"])) == nm
        out = [(f, m) for f in repo.files for m in f["methods"] if name_ok(m) and (not cls or (m["cls"] or "") == cls)]
        if not out and cls:          # tolerant: file name, or class name without a Controller/Endpoints/... suffix
            out = [(f, m) for f in repo.files for m in f["methods"] if name_ok(m) and (
                stem(f) in (ncls, ncls_s) or (m["cls"] and norm(PIN_CLS_SUFFIX_RE.sub("", m["cls"])) in (ncls, ncls_s)))]
        if not out:                  # minimal-API lambda: file/class + a route word equal to Method
            lam = [e for e in eps if e.get("route") and nm in _route_words(e["route"]) and (
                not cls or stem(e["f"]) in (ncls, ncls_s) or norm(PIN_CLS_SUFFIX_RE.sub("", e.get("cls") or "")) in (ncls, ncls_s))]
            if lam:
                return lam[:4]
        if len(out) > 1:             # prefer real endpoints, then the shortest file path (deterministic)
            out.sort(key=lambda x: (not any(e["fidx"] == x[0]["idx"] and e["m"] is x[1] for e in eps), x[0]["path"], x[1]["decl"]))
    res = []
    for f, m in out[:4]:
        known = next((e for e in eps if e["fidx"] == f["idx"] and e["m"] is m), None)
        res.append(known or {"file": f["path"], "fidx": f["idx"], "line": m["decl"] + 1, "method": m["name"], "cls": m["cls"],
                             "route": "(forced)", "verb": "", "f": f, "m": m})
    return res


def pin_suggestions(spec, eps, n=3):
    """Closest repo2 endpoints to a pin that matched nothing - shown in the warning so the map can be corrected."""
    key = norm(spec.split(":")[0])
    scored = []
    for e in eps:
        label = "%s %s %s %s" % (os.path.splitext(os.path.basename(e["file"]))[0], e.get("cls") or "", e["method"], e.get("route") or "")
        scored.append((difflib.SequenceMatcher(None, key, norm(label)).ratio(), e["file"], e["line"], e))
    scored.sort(key=lambda x: (-x[0], x[1], x[2]))
    return ["%s:%d (%s%s)" % (e["file"], e["line"], ((e.get("cls") + ".") if e.get("cls") else "") + e["method"],
                              (" " + (e.get("verb") or "") + " " + e["route"]) if e.get("route") and e["route"] != "(forced)" else "")
            for _, _, _, e in scored[:n]]


def rank_repo2(op, eps, repo2, names):
    req_chain, res_chain = root_chain(op["request"]), root_chain(op["response"])
    req_root = req_chain[-1] if req_chain else None
    req_is_list = bool(req_root) and req_root.endswith("[]")
    res_root = res_chain[-1] if res_chain else None
    cm_req = ContractMatcher(op["request"], repo2, names)
    cm_res = ContractMatcher(op["response"], repo2, names)
    op_nouns = nouns(op["wsdlName"])
    req_leaf = {norm(f["name"]) for f in op["request"][1:] if not f.get("complex")} if op["request"] else set()
    req_top = [f for f in op["request"] if req_root and f["path"].startswith(req_root + "/") and "/" not in f["path"][len(req_root) + 1:]]
    ranked = []

    def res_score(types):
        best_s, best_c = 0.0, None
        for t in sorted(types):         # sorted: ties resolve the same way on every run
            for c in repo2.class_recs(t):
                s = max((cm_res.class_score(rp, c)[0] for rp in res_chain), default=0)
                if s > best_s:
                    best_s, best_c = s, c
        return best_s, best_c

    for ep in eps:
        params, rets, _ = method_sig_types(repo2, ep["f"], ep["m"])
        name_s = names.sim(base_name(ep["method"]), op["wsdlName"])
        ep_nouns = nouns(ep["method"], ep["route"] or "")
        noun_s = len(op_nouns & ep_nouns) / max(1, len(op_nouns)) if op_nouns else 0
        req_s, req_cls = 0.0, None
        for t in sorted(params):
            for c in repo2.class_recs(t):
                s = max((cm_req.class_score(rp, c)[0] for rp in req_chain), default=0)
                if s > req_s:
                    req_s, req_cls = s, c
        # route / query / primitive parameters: GetQuote(string market, string symbol) vs request fields market, symbol
        pnames = route_param_names(ep)
        if pnames and req_leaf:
            hit = sum(1 for p in pnames if any(names.sim(p, q) >= 0.8 for q in req_leaf))
            if hit:
                denom = max(1, min(len(req_top) or len(req_leaf), len(pnames) + 2))
                req_s = max(req_s, 0.9 * min(1.0, hit / denom))
        # batch vs single: a SOAP request that is a list (GetQuotes -> QuoteRequest[]) needs an endpoint taking a collection
        ptxt = ep["m"]["sig"].split("(", 1)[1] if "(" in ep["m"]["sig"] else ""
        takes_list = bool(re.search(r"\b(?:I?List|IEnumerable|I?Collection|IReadOnlyList|IReadOnlyCollection|Set|HashSet)\s*<|\[\]\s+\w", ptxt))
        if req_is_list:
            req_s = min(1.0, req_s + 0.25) if takes_list else req_s * 0.5
        elif takes_list:
            req_s *= 0.7
        res_s, res_cls = res_score(rets | set(generic_args(ep["m"]["sig"].split("(")[0])))
        total = 0.25 * max(name_s if name_s >= 0.8 else 0, noun_s) + 0.5 * req_s + 0.25 * res_s
        if name_s >= 0.95:
            total = max(total, 0.6)
        ranked.append({"score": round(total, 3), "ep": ep, "req_cls": req_cls, "res_cls": res_cls,
                       "req_s": req_s, "res_s": res_s, "name_s": max(name_s, noun_s), "_n": max(name_s if name_s >= 0.8 else 0, noun_s)})
    ranked.sort(key=lambda x: -x["score"])
    # second pass for the best few: response type hidden behind IActionResult / Task<IActionResult> / service calls
    for r in ranked[:12]:
        if r["res_cls"] is not None or not res_root:
            continue
        s, c = res_score(body_response_types(repo2, r["ep"]))
        if c is not None and s > 0:
            r["res_s"], r["res_cls"] = s, c
            r["score"] = round(max(r["score"], 0.25 * r["_n"] + 0.5 * r["req_s"] + 0.25 * s), 3)
    ranked.sort(key=lambda x: (-x["score"], -x["res_s"]))
    return ranked


PRIM_PARAM_RE = re.compile(r"(?:\[\w+(?:\([^)]*\))?\]\s*|@\w+(?:\([^)]*\))?\s*)*(?:string|int|long|short|decimal|double|bool|Guid|"
                           r"DateTime|DateTimeOffset|String|Integer|Long|Boolean|UUID|LocalDate)\??\s+(\w+)")


PARAM_SKIP_TYPES = ("CancellationToken", "HttpContext", "HttpRequest", "HttpResponse", "ClaimsPrincipal", "ILogger",
                    "IServiceProvider", "HttpServletRequest", "HttpServletResponse", "Principal", "Authentication")


def endpoint_inputs(ep, repo=None):
    """Inputs of a REST endpoint and where each comes from: [{'name','source','type','wire'}].
    source: route | query | header | body | form. ASP.NET Core rules: [From*] wins; a simple parameter named in the route
    template is route, other simple ones are query; a complex one is body ([ApiController]) - for [FromQuery] complex types
    the public fields become query inputs. Java: @PathVariable/@RequestParam/@RequestHeader/@RequestBody."""
    sig = ep["m"]["sig"]
    if "(" not in sig:
        return []
    route_names = {x.lower() for x in re.findall(r"\{\*?(\w+)(?::[^}]*)?\??\}", ep.get("route") or "")}
    out = []
    for raw in RepoIndex._split_params(sig.split("(", 1)[1].rsplit(")", 1)[0]):
        ptxt = raw.strip()
        if not ptxt:
            continue
        attrs = re.findall(r"\[\s*(?:\w+\.)*(\w+?)(?:Attribute)?\s*(?:\(([^)]*)\))?\s*\]", ptxt) + \
            re.findall(r"@(\w+)(?:\(([^)]*)\))?", ptxt)
        an = {a.lower(): v for a, v in attrs}
        body = re.sub(r"\[[^\]]*\]\s*|@\w+(?:\([^)]*\))?\s*", "", ptxt)
        body = re.sub(r"\b(this|ref|out|in|params|final)\s+", "", body).split("=")[0].strip()
        m = re.match(r"^(.+?)\s+(\w+)$", body)
        if not m:
            continue
        typ, name = m.group(1).strip(), m.group(2)
        if typ.split("<")[0].split(".")[-1] in PARAM_SKIP_TYPES or "fromservices" in an or "autowired" in an:
            continue
        wire = None
        for k_ in ("fromquery", "fromheader", "fromroute", "fromform", "requestparam", "requestheader", "pathvariable"):
            if k_ in an and an[k_]:
                w = re.search(r"(?:Name|value|name)\s*=\s*\"([^\"]+)\"|^\s*\"([^\"]+)\"", an[k_])
                if w:
                    wire = w.group(1) or w.group(2)
        simple = bool(PRIM_PARAM_RE.search(typ + " " + name)) or typ.rstrip("?") in ("char", "float", "byte", "uint", "ulong")
        if "fromroute" in an or "pathvariable" in an:
            src = "route"
        elif "fromquery" in an or "requestparam" in an:
            src = "query"
        elif "fromheader" in an or "requestheader" in an:
            src = "header"
        elif "frombody" in an or "requestbody" in an:
            src = "body"
        elif "fromform" in an:
            src = "form"
        elif name.lower() in route_names:
            src = "route"
        elif simple:
            src = "query"
        else:
            src = "body"
        if src in ("query", "form") and not simple and repo is not None:
            recs = repo.class_recs(typ.split("<")[0].split(".")[-1].rstrip("?"))
            if recs:
                for fd in recs[0].get("fields", []):
                    out.append({"name": fd["name"], "source": src, "type": fd.get("type", ""), "wire": None,
                                "via": "%s.%s" % (recs[0]["name"], fd["name"])})
                continue
        out.append({"name": name, "source": src, "type": typ, "wire": wire, "complex": not simple})
    return out


def match_request_inputs(rows, flds, root_path, ep, repo, names):
    """REST inputs sent outside the body class (route/query/header) cover request fields the class compare left MISSING;
    with no body class, the request fields are compared with these inputs only - never with an unrelated DTO."""
    inputs = [x for x in endpoint_inputs(ep, repo) if not (x["source"] == "body" and x.get("complex"))]
    if not inputs:
        return rows
    by_path = {r_["path"]: r_ for r_ in rows}
    kids = [f for f in flds if f["path"].startswith(root_path + "/") and "/" not in f["path"][len(root_path) + 1:]]
    used = set()
    for k in kids:
        r_ = by_path.get(k["path"])
        if r_ is not None and r_["status"] not in ("MISSING",):
            continue
        best, bs = None, 0.0
        for x in inputs:
            if id(x) in used:
                continue
            sc = max(names.sim(x["name"], k["name"]), names.sim(x.get("wire") or "", k["name"]) if x.get("wire") else 0)
            if sc > bs:
                best, bs = x, sc
        if not best or bs < 0.8:
            continue
        used.add(id(best))
        label = {"route": "URL path {%s}", "query": "query string ?%s=", "header": "HTTP header %s", "form": "form field %s",
                 "body": "body %s"}[best["source"]] % (best.get("wire") or best["name"])
        row = r_ if r_ is not None else {"path": k["path"], "xsdType": k["type"], "min": k["min"], "max": k["max"],
                                         "restr": k.get("restr", {})}
        row.update(status="MATCH" if bs >= 0.95 else "FUZZY", repoField="%s (%s)" % (best.get("via") or best["name"], label),
                   repoFieldName=best["name"], repoType=best["type"], repoClass="(endpoint input)", repoFile=ep["file"],
                   repoLine=ep["line"], sim=bs, inputSource=best["source"])
        # same data, different place: not a gap, but callers must be told where to send it now
        notes = ["Consumer change: send it as %s%s" % (label, "" if bs >= 0.95 else " (name differs - confirm)")]
        if not k.get("complex"):
            st, msg = type_compat(k["type"], best["type"], repo)
            row["typeCheck"] = st
            if msg:
                notes.append(msg)
        row["notes"] = "; ".join(notes)
        if r_ is None:
            rows.append(row)
    return rows


def route_param_names(ep):
    sig = ep["m"]["sig"]
    names_ = set()
    if "(" in sig:
        for p in RepoIndex._split_params(sig.split("(", 1)[1].rsplit(")", 1)[0]):
            m = PRIM_PARAM_RE.search(p.strip())
            if m:
                names_.add(m.group(1))
    names_ |= set(re.findall(r"\{(\w+)(?::[^}]*)?\}", ep.get("route") or ""))
    return {n for n in names_ if n.lower() not in ("cancellationtoken", "ct", "token")}


def body_response_types(repo, ep):
    """Types an endpoint most likely returns when the signature does not say (IActionResult etc.)."""
    f, m = ep["f"], ep["m"]
    ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
    out = set(re.findall(r"ProducesResponseType\s*\(\s*typeof\s*\(\s*(?:\w+\.)*(\w+)", ann))
    out |= set(re.findall(r"ProducesResponseType\s*<\s*(\w+)", ann))
    try:
        sl = Slice(repo, [(f, m)], max_depth=3, max_methods=40)
    except Exception:  # noqa
        return out
    for f2, m2 in sl.methods:
        body = "\n".join(f2["clean"][m2["decl"]:m2["end"] + 1])
        out |= set(re.findall(r"\bnew\s+(\w+)\s*[({]", body))
        _, rets, _ = method_sig_types(repo, f2, m2)
        out |= rets | set(generic_args(m2["sig"].split("(")[0]))
    return {t for t in out if t in repo.classes}


def hit_ref(h):
    return "%s:%d" % (h["file"], h["line"])


def integration_keys(hits, repo):
    keys = defaultdict(list)
    for h in hits:
        if h["cat"] not in ("db", "outbound", "messaging", "cache"):
            continue
        for k in h["keys"]:
            if k[0] == "config":
                for host in repo.resolve_hosts(k[1]):
                    keys[("host", host)].append(h)
                continue
            keys[k].append(h)
        f = repo.files[h["fidx"]]
        if h["cat"] == "outbound":
            phs = set(f["placeholders"])
            for c in f["classes"]:
                phs |= repo.typed_client_cfg.get(c["name"], set())
            for ph in phs:
                hosts = {ph[5:]} if ph.startswith("host:") else repo.resolve_hosts(ph)
                for host in hosts:
                    keys[("host", host)].append(h)
    return keys


def entity_keys(slice_, repo):
    out = defaultdict(list)
    for fidx, ls in slice_.method_lines.items():
        f = repo.files[fidx]
        for i in ls:
            m_ = repo._enclosing_method(f, i)
            if m_ and m_["decl"] == i and re.search(r"\{\s*get\b", f["clean"][i]):
                continue  # property declaration of the context class, not a usage
            line = STR_RE.sub('""', f["clean"][i])
            # EF DbSet / LINQ to SQL Table<T> usage: _db.Customers.Where(..), from c in db.Customers, db.Orders.InsertOnSubmit(..)
            for prop in set(re.findall(r"\.\s*(\w+)\b(?!\s*\()", line)):
                ent = repo.dbsets.get(prop)
                if ent:
                    out[("table", repo.entity_table.get(ent, prop).split(".")[-1].upper())].append(
                        {"file": f["path"], "line": i + 1, "text": "entity set %s: %s" % (prop, f["clean"][i].strip()[:150])})
            for ent in re.findall(r"\b(?:Set|GetTable)\s*<\s*(\w+)\s*>\s*\(", line):
                if ent in repo.entity_table:
                    out[("table", repo.entity_table[ent].split(".")[-1].upper())].append({"file": f["path"], "line": i + 1, "text": "Set<%s>" % ent})
            # stored-procedure wrapper methods (LINQ to SQL [Function], EF6 function imports)
            for fn in set(re.findall(r"\.\s*(\w+)\s*\(", line)):
                if fn in repo.db_funcs:
                    out[("proc", proc_key(repo.db_funcs[fn]))].append({"file": f["path"], "line": i + 1, "text": "proc wrapper " + fn})
    for t in slice_.types:
        tbl = repo.entity_table.get(t)
        if tbl:
            c = repo.class_recs(t)[0]
            out[("table", tbl.upper())].append({"file": c["file"], "line": c["start"] + 1, "text": "entity " + t})
    for f, m in slice_.methods:
        cls = repo._enclosing_class(f, m["decl"])
        if cls and any(re.search(r"Repository|Dao|DAO|Mapper|DbContext|CrudRepository", p) for p in cls["parents"] + [cls["name"]]):
            for ga in generic_args(" ".join(f["clean"][cls["start"]:cls["start"] + 2])):
                tbl = repo.entity_table.get(ga)
                if tbl:
                    out[("table", tbl.upper())].append({"file": f["path"], "line": m["decl"] + 1, "text": "repository " + cls["name"] + "." + m["name"]})
    return out


AUTO_MAP_RE = re.compile(r"\bMapper\.Map|_?mapper\.Map\b|\.Map<|\bAdapt<|JsonConvert\.DeserializeObject|JsonSerializer\.Deserialize|"
                         r"ReadAsAsync|ReadFromJsonAsync|XmlSerializer|DataContractSerializer|copyProperties|ModelMapper|"
                         r"objectMapper\.(?:read|convert)|\.Translate<|ExecuteQuery<|SqlQuery<|FromSql", re.I)
ASSIGN_RE = re.compile(r"(?:^|[.\s{,(])([A-Za-z_]\w*)\s*=(?![=>])")
SETTER_RE = re.compile(r"\bset([A-Z]\w*)\s*\(")


def root_chain(fields):
    """[root, child, grandchild...]: follow single complex children (WCF/doc-literal wrappers:
    GetQuoteResponse -> GetQuoteResult -> fields, GetQuotes -> requests -> QuoteRequest[] -> fields)."""
    if not fields:
        return []
    kids = defaultdict(list)
    for f in fields:
        if "/" in f["path"]:
            kids[f["path"].rsplit("/", 1)[0]].append(f)
    chain = [fields[0]["path"]]
    for _ in range(4):
        k = kids.get(chain[-1], [])
        if len(k) == 1 and k[0].get("complex") and kids.get(k[0]["path"]):
            chain.append(k[0]["path"])
        else:
            break
    return chain


def unset_response_paths(s1, repo1, op):
    """Response fields never assigned on the repo1 call path (legacy contracts often declare far more than they fill).
    Returns an empty set when auto-mapping / deserialisation could fill fields without visible assignments."""
    resp = op.get("response") or []
    if not resp:
        return set()
    lines = []
    helper = re.compile(r"(?i)log|trace|audit|serializ|diagnos|telemetry|eventsource|crosscutting|instrument")
    for fidx, idxs in s1.method_lines.items():
        f = repo1.files[fidx]
        if helper.search(f["path"]):
            continue                    # logging / tracing helpers serialise objects - not response mapping
        for i in idxs:
            if i < len(f["clean"]):
                mm = repo1._enclosing_method(f, i)
                if mm and helper.search(mm["name"]):
                    continue
                lines.append(f["clean"][i])
    text = "\n".join(lines)
    if AUTO_MAP_RE.search(text):
        LOG.write("unset-check %s: skipped (auto-mapping/deserialisation on repo1 path)" % op["name"])
        return set()
    chain = root_chain(resp)
    root = chain[-1]
    root_types = {x for p in chain for f in resp if f["path"] == p for x in (f.get("type"), f.get("name")) if x}
    for t in root_types:   # response object materialised generically (Query<Resp>, Get<Resp>) -> cannot tell
        if t not in ("(anonymous)", "(wrapper)") and re.search(
                r"(?<!new )\b(?!(?:I?List|IEnumerable|I?Collection|IReadOnlyList|Task|ValueTask|ActionResult|Func|Action|"
                r"Nullable|HashSet|Dictionary|Array)\b)\w+\s*<\s*%s\s*>\s*\(" % re.escape(t), text):
            LOG.write("unset-check %s: skipped (response type %s created generically)" % (op["name"], t))
            return set()
    assigned = set()
    for line in lines:
        for m in ASSIGN_RE.finditer(line):
            assigned.add(norm(m.group(1)))
        for m in SETTER_RE.finditer(line):
            assigned.add(norm(m.group(1)))
    body = [f for f in resp if f["path"].startswith(root + "/")]
    names_of = {f["path"]: {norm(f["name"]), norm(f.get("codeName") or "")} - {""} for f in body}
    is_set = {p: bool(n & assigned) for p, n in names_of.items()}
    if len(body) < 6 or not any(is_set.values()):
        return set()        # too small, or nothing recognisable assigned -> evidence too weak
    out = set()
    for p, v in is_set.items():
        if not v and not any(is_set[q] for q in is_set if q.startswith(p + "/")):
            out.add(p)
    LOG.write("unset-check %s: %d of %d response fields never assigned on repo1 path" % (op["name"], len(out), len(body)))
    return out


# --------------------------------------------------------------------------- DB objects: SQL scripts, schema, sqlcmd extract

SQL_OBJ_RE = re.compile(r"\b(?:CREATE\s+OR\s+ALTER|CREATE|ALTER)\s+(PROC(?:EDURE)?|FUNCTION|VIEW|TABLE|TRIGGER)\s+"
                        r"((?:\[?[\w$#]+\]?\s*\.\s*)?\[?[\w$#]+\]?)", re.I)
SQL_GO_RE = re.compile(r"^\s*GO\s*;?\s*$", re.I | re.M)
SQL_READ_RE = re.compile(r"(?<![@#\w])(?:FROM|JOIN)\s+((?:\[?\w+\]?\s*\.\s*)?\[?[#@]?\w+\]?)", re.I)
SQL_WRITE_RE = re.compile(r"(?<![@#\w])(?:INSERT\s+(?:INTO\s+)?|UPDATE\s+|DELETE\s+(?:FROM\s+)?|MERGE\s+(?:INTO\s+)?|TRUNCATE\s+TABLE\s+)"
                          r"((?:\[?\w+\]?\s*\.\s*)?\[?[#@]?\w+\]?)", re.I)
SQL_EXEC_RE = re.compile(r"(?<![@#\w])EXEC(?:UTE)?\s+(?:@\w+\s*=\s*)?((?:\[?\w+\]?\s*\.\s*)?\[?\w+\]?)", re.I)
SQL_SIGNAL_RE = re.compile(r"\b(CASE|WHEN|IF|ELSE|ROUND|DATEADD|DATEDIFF|GETDATE|GETUTCDATE|SYSDATETIME|RAISERROR|THROW|"
                           r"BEGIN\s+TRAN|COMMIT|ROLLBACK|TOP|ISNULL|COALESCE|NULLIF|CAST|CONVERT|ROW_NUMBER|RANK|SUM|AVG|MIN|MAX|"
                           r"HAVING|EXISTS|@@ROWCOUNT|@@ERROR|SCOPE_IDENTITY|NEWID|LOCK|UPDLOCK|NOLOCK)\b|\b\d+\.\d+\b|'[^']{1,30}'",
                           re.I)
SQL_NOT_OBJ = {"SELECT", "WHERE", "SET", "VALUES", "AS", "ON", "DUAL", "INSERTED", "DELETED", "OUTPUT", "TOP", "WITH", "THE",
               # SQL type names (never tables; protects against odd text such as "@p FROM varchar")
               "VARCHAR", "NVARCHAR", "CHAR", "NCHAR", "INT", "BIGINT", "SMALLINT", "TINYINT", "DECIMAL", "NUMERIC", "MONEY",
               "FLOAT", "REAL", "BIT", "DATE", "DATETIME", "DATETIME2", "TIME", "UNIQUEIDENTIFIER", "XML", "VARBINARY", "TEXT",
               "NTEXT", "STATISTICS", "OPENJSON", "OPENXML", "STRING_SPLIT"}
DB_WRITE_TXT_RE = re.compile(r"\b(INSERT|UPDATE|DELETE|MERGE|TRUNCATE)\b|SubmitChanges|(Insert|Delete|InsertAll|DeleteAll)OnSubmit|"
                             r"SaveChanges|ExecuteNonQuery|ExecuteCommand|\.Add(Range)?\(|\.Remove(Range)?\(|\.Update\(|batchUpdate|"
                             r"executeUpdate|\.save(All|AndFlush)?\(|\.delete\w*\(|persist\(|merge\(", re.I)


def sql_key(name):
    n = re.sub(r"\s+", "", name.replace("[", "").replace("]", "")).upper().strip()
    return n[4:] if n.startswith("DBO.") else n


def strip_sql_comments(t):
    t = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), t, flags=re.S)
    return re.sub(r"--[^\n]*", "", t)


class SqlCatalog:
    """Parses CREATE/ALTER PROCEDURE|FUNCTION|VIEW|TABLE|TRIGGER from .sql files (repo database projects,
    SSMS 'Generate Scripts' output, or --db-extract). Keys are normalised names without 'dbo.'."""

    def __init__(self):
        self.objects = {}       # key -> object dict
        self.triggers_on = defaultdict(list)   # table key -> trigger keys
        self.files = 0

    def add_paths(self, paths):
        for p in paths:
            if os.path.isdir(p):
                for root, dirs, files in os.walk(p):
                    dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
                    for fn in files:
                        if fn.lower().endswith(".sql"):
                            self.add_file(os.path.join(root, fn), p)
            elif os.path.isfile(p):
                self.add_file(p, os.path.dirname(p))

    def add_file(self, path, base):
        try:
            if os.path.getsize(path) > 20 * 1024 * 1024:
                return
            raw = RepoIndex._read(path)
        except OSError:
            return
        self.files += 1
        rel = os.path.relpath(path, base).replace("\\", "/") if base else path
        text = strip_sql_comments(raw)
        ms = list(SQL_OBJ_RE.finditer(text))
        gos = [m.start() for m in SQL_GO_RE.finditer(text)]
        for i, m in enumerate(ms):
            start = m.start()
            end = ms[i + 1].start() if i + 1 < len(ms) else len(text)
            nxt_go = next((g for g in gos if g > start), None)
            if nxt_go is not None and nxt_go < end:
                end = nxt_go
            body = text[start:end]
            kind = m.group(1).upper()
            kind = "PROC" if kind.startswith("PROC") else kind
            key = sql_key(m.group(2))
            line = text.count("\n", 0, start) + 1
            obj = {"key": key, "kind": kind, "file": rel, "line": line, "body": body.strip()}
            if kind == "TABLE":
                obj["columns"], obj["pk"] = self._table_columns(body)
            else:
                obj.update(self._analyse_code(body, kind))
            if kind == "TRIGGER":
                tm = re.search(r"\bON\s+((?:\[?\w+\]?\s*\.\s*)?\[?\w+\]?)", body, re.I)
                if tm:
                    obj["onTable"] = sql_key(tm.group(1))
                    self.triggers_on[obj["onTable"]].append(key)
            # keep the richest definition (CREATE over ALTER fragments)
            if key not in self.objects or len(body) > len(self.objects[key]["body"]):
                self.objects[key] = obj

    @staticmethod
    def _names(rx, body, own):
        out = set()
        for n in rx.findall(body):
            k = sql_key(n)
            if not k or k.startswith(("@", "#")) or k.split(".")[-1] in SQL_NOT_OBJ or k == own or k.isdigit():
                continue
            out.add(k)
        return out

    def _analyse_code(self, body, kind):
        head = body.split("\n", 1)[0]
        own = sql_key(SQL_OBJ_RE.match(body).group(2)) if SQL_OBJ_RE.match(body) else ""
        am = re.search(r"\bAS\b|\bBEGIN\b|\bRETURNS\b", body, re.I)
        sig = body[:am.start()] if am else head
        params = ["@%s %s" % (p, t) for p, t in re.findall(r"@(\w+)\s+([\w]+(?:\s*\([^)]*\))?)", sig)][:30]
        writes = self._names(SQL_WRITE_RE, body, own)
        reads = self._names(SQL_READ_RE, body, own) - writes
        execs = self._names(SQL_EXEC_RE, body, own)
        signals = []
        for ln, line in enumerate(body.split("\n")):
            s = line.strip()
            if s and SQL_SIGNAL_RE.search(s) and len(signals) < 40:
                signals.append((ln, s[:160]))
        return {"params": params, "reads": sorted(reads), "writes": sorted(writes), "execs": sorted(execs),
                "transaction": bool(re.search(r"\bBEGIN\s+TRAN|\bCOMMIT\b|\bROLLBACK\b", body, re.I)),
                "errors": bool(re.search(r"\bRAISERROR\b|\bTHROW\b|\bTRY\b", body, re.I)), "signals": signals,
                "lines": body.count("\n") + 1}

    @staticmethod
    def _table_columns(body):
        i = body.find("(")
        if i < 0:
            return [], []
        depth, j = 0, i
        for j in range(i, len(body)):
            if body[j] == "(":
                depth += 1
            elif body[j] == ")":
                depth -= 1
                if depth == 0:
                    break
        inner = body[i + 1:j]
        cols, pk = [], []
        for part in RepoIndex._split_params(inner):
            p = " ".join(part.split())
            up = p.upper()
            if up.startswith(("CONSTRAINT", "PRIMARY", "FOREIGN", "UNIQUE", "INDEX", "CHECK", "PERIOD")):
                pm = re.search(r"PRIMARY\s+KEY[^(]*\(([^)]*)\)", p, re.I)
                if pm:
                    pk += [c.replace("[", "").replace("]", "").split()[0] for c in pm.group(1).split(",") if c.strip()]
                continue
            m = re.match(r"\[?(\w+)\]?\s+\[?(\w+)\]?\s*(\([^)]*\))?(.*)$", p)
            if not m:
                continue
            rest = m.group(4) or ""
            dm = re.search(r"\bDEFAULT\s*(\(+.*?\)+|'[^']*'|\S+)", rest, re.I)
            cols.append({"name": m.group(1), "type": (m.group(2) + (m.group(3) or "")).lower(),
                         "null": not re.search(r"\bNOT\s+NULL\b", rest, re.I) and not re.search(r"PRIMARY\s+KEY", rest, re.I),
                         "default": dm.group(1) if dm else None, "identity": bool(re.search(r"\bIDENTITY\b", rest, re.I))})
            if re.search(r"PRIMARY\s+KEY", rest, re.I):
                pk.append(m.group(1))
        return cols[:300], pk

    def get(self, key):
        k = sql_key(key)
        if k in self.objects:
            return self.objects[k]
        short = k.split(".")[-1]
        cands = [o for kk, o in self.objects.items() if kk.split(".")[-1] == short]
        return cands[0] if len(cands) == 1 else None

    def expand(self, keys, depth=4):
        """Follow EXEC chains, tables written/read by procs, and triggers on written tables.
        Returns {key: via} for every reachable object (via = '' for the starting keys)."""
        seen = {k: "" for k in keys}
        frontier = list(keys)
        for _ in range(depth):
            nxt = []
            for k in frontier:
                o = self.get(k)
                if not o:
                    continue
                for e in o.get("execs", []) + o.get("reads", []) + o.get("writes", []):
                    if e not in seen:
                        seen[e] = "%s %s" % (o["kind"].lower(), k)
                        nxt.append(e)
                for w in o.get("writes", []):
                    for tr in self.triggers_on.get(w, []):
                        if tr not in seen:
                            seen[tr] = "trigger on %s" % w
                            nxt.append(tr)
            frontier = nxt
        return seen


CATALOG = SqlCatalog()
SLICES = {}     # operation -> (op, repo1 slice, repo2 slice) for the logic pack
DBKEYS = {}     # operation -> (repo1 db refs, repo2 db refs) for re-computing after --db-extract


def _db_mode(texts):
    if any(DB_WRITE_TXT_RE.search(t or "") for t in texts):
        return "write"
    return "read"


def db_refs(keys):
    """{('table'|'proc', NAME): [hit-like dicts]} -> {NAME: {'kind','mode','refs'}} (tables and procs only)."""
    out = {}
    for (kind, name), hs in keys.items():
        if kind not in ("table", "proc"):
            continue
        k = sql_key(name)
        mode = "exec" if kind == "proc" else _db_mode([h.get("text", "") for h in hs])
        out[k] = {"kind": "proc" if kind == "proc" else "table", "mode": mode,
                  "refs": sorted({"%s:%s" % (h["file"], h["line"]) for h in hs})[:4]}
    return out


def db_inventory(r1, r2):
    """Rows for the DB-objects table: every object used (directly or via procs) on either call path."""
    def expand(refs):
        if not CATALOG.objects:
            return {k: ("", v) for k, v in refs.items()}
        ex = CATALOG.expand(list(refs))
        out = {}
        for k, via in ex.items():
            if k in refs:
                out[k] = ("", refs[k])
            else:
                o = CATALOG.get(k)
                src = via.split(" ", 1)[1] if " " in via else via
                parent = CATALOG.get(src)
                mode = "fires" if (o and o["kind"] == "TRIGGER") else "exec" if (o and o["kind"] in ("PROC", "FUNCTION")) else \
                    ("write" if parent and k in parent.get("writes", []) else "read")
                out[k] = (via, {"kind": (o["kind"].lower() if o else "table"), "mode": mode, "refs": []})
        return out
    e1, e2 = expand(r1), expand(r2)
    rows = []
    for k in sorted(set(e1) | set(e2)):
        via1, a = e1.get(k, ("", None))
        via2, b = e2.get(k, ("", None))
        o = CATALOG.get(k)
        st = "BOTH" if a and b else ("ONLY_REPO1" if a else "ONLY_REPO2")
        if a and b and a["mode"] != b["mode"] and "exec" not in (a["mode"], b["mode"]):
            st = "BOTH_DIFFERENT_USE"
        det = ""
        if o:
            if o["kind"] == "TABLE":
                det = "%d columns, PK %s" % (len(o.get("columns", [])), ",".join(o.get("pk", [])) or "-")
            else:
                det = "; ".join(x for x in (
                    ("reads " + ",".join(o["reads"][:5])) if o.get("reads") else "",
                    ("writes " + ",".join(o["writes"][:5])) if o.get("writes") else "",
                    ("calls " + ",".join(o["execs"][:4])) if o.get("execs") else "",
                    "transaction" if o.get("transaction") else "", "raises errors" if o.get("errors") else "",
                    ("%d logic lines" % len(o.get("signals", []))) if o.get("signals") else "") if x)
        rows.append({"object": k, "kind": (o["kind"].lower() if o else (a or b)["kind"]), "status": st,
                     "repo1": ("%s%s" % (a["mode"], (" via " + via1) if via1 else "")) if a else "-",
                     "repo1At": (a or {}).get("refs", []), "repo2": ("%s%s" % (b["mode"], (" via " + via2) if via2 else "")) if b else "-",
                     "repo2At": (b or {}).get("refs", []), "definition": ("%s:%d" % (o["file"], o["line"])) if o else None,
                     "details": det})
    return rows


def db_missing_definitions(results):
    out = []
    for r in results:
        for x in r.get("dbObjects", []):
            if not x["definition"] and x["object"] not in out:
                out.append(x["object"])
    return out


def run_sqlcmd(args, query, timeout=60):
    """Read-only catalog query through sqlcmd. Windows auth (-E) unless --db-user (password: env SQLCMDPASSWORD)."""
    import subprocess
    exe = os.environ.get("SOAP_PARITY_SQLCMD") or "sqlcmd"
    cmd = [exe, "-S", args.db_server, "-d", args.db_name, "-b", "-h", "-1", "-y", "0", "-W", "-s", "|", "-l", "30"]
    cmd += ["-U", args.db_user] if args.db_user else ["-E"]
    if args.db_trust_cert:
        cmd.append("-C")
    cmd += ["-Q", "SET NOCOUNT ON; " + query]
    if exe.lower().endswith(".py"):
        cmd = [sys.executable] + cmd
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout or "sqlcmd failed").strip().splitlines()[-1][:200])
    return p.stdout


def db_extract(args, names, out_dir, max_objects=200):
    """Fetch definitions (procs/functions/views/triggers) and column lists (tables) for the given objects plus what
    they depend on. Only SELECTs on catalog views / OBJECT_DEFINITION - nothing is modified."""
    os.makedirs(out_dir, exist_ok=True)
    todo, done, written, failed = list(names), set(), 0, []
    q = lambda s: s.replace("'", "''")
    while todo and len(done) < max_objects:
        n = todo.pop(0)
        if n in done:
            continue
        done.add(n)
        cand = n if "." in n else "dbo." + n
        try:
            info = run_sqlcmd(args, "SELECT TOP 1 o.type, SCHEMA_NAME(o.schema_id) + '.' + o.name FROM sys.objects o "
                                    "WHERE o.object_id = COALESCE(OBJECT_ID(N'%s'), OBJECT_ID(N'%s'))" % (q(cand), q(n))).strip()
        except Exception as e:  # noqa
            failed.append("%s (%s)" % (n, e))
            if len(failed) >= 3 and not written:
                break           # server unreachable / no permission: stop early
            continue
        if not info:
            failed.append("%s (not found)" % n)
            continue
        typ, full = [x.strip() for x in info.split("|", 1)]
        fn = os.path.join(out_dir, re.sub(r"[^\w.]+", "_", full) + ".sql")
        if typ == "U":
            rows = run_sqlcmd(args, (
                "SELECT c.name, t.name, c.max_length, c.precision, c.scale, c.is_nullable, c.is_identity, "
                "ISNULL(dc.definition,''), CASE WHEN EXISTS (SELECT 1 FROM sys.index_columns ic JOIN sys.indexes i "
                "ON i.object_id = ic.object_id AND i.index_id = ic.index_id WHERE i.is_primary_key = 1 AND "
                "ic.object_id = c.object_id AND ic.column_id = c.column_id) THEN 1 ELSE 0 END "
                "FROM sys.columns c JOIN sys.types t ON t.user_type_id = c.user_type_id "
                "LEFT JOIN sys.default_constraints dc ON dc.object_id = c.default_object_id "
                "WHERE c.object_id = OBJECT_ID(N'%s') ORDER BY c.column_id") % q(full))
            cols, pk = [], []
            for line in rows.splitlines():
                p = line.split("|")
                if len(p) < 9:
                    continue
                name, typ_, ml, prec, scale, nullable, ident, dflt, ispk = [x.strip() for x in p[:9]]
                t = typ_
                if typ_ in ("varchar", "char", "varbinary", "binary"):
                    t += "(%s)" % ("max" if ml == "-1" else ml)
                elif typ_ in ("nvarchar", "nchar"):
                    t += "(%s)" % ("max" if ml == "-1" else int(ml) // 2)
                elif typ_ in ("decimal", "numeric"):
                    t += "(%s,%s)" % (prec, scale)
                cols.append("    [%s] %s%s %s%s" % (name, t, " IDENTITY" if ident == "1" else "",
                                                     "NULL" if nullable == "1" else "NOT NULL", (" DEFAULT " + dflt) if dflt else ""))
                if ispk == "1":
                    pk.append("[%s]" % name)
            if pk:
                cols.append("    PRIMARY KEY (%s)" % ", ".join(pk))
            body = "CREATE TABLE %s (\n%s\n)\n" % (full, ",\n".join(cols))
            for tr in run_sqlcmd(args, "SELECT OBJECT_SCHEMA_NAME(object_id) + '.' + name FROM sys.triggers WHERE parent_id = OBJECT_ID(N'%s')" % q(full)).splitlines():
                if tr.strip():
                    todo.append(tr.strip())
        else:
            body = run_sqlcmd(args, "SELECT OBJECT_DEFINITION(OBJECT_ID(N'%s'))" % q(full), timeout=120)
            if not body.strip() or body.strip() == "NULL":
                failed.append("%s (definition hidden: WITH ENCRYPTION or no VIEW DEFINITION permission)" % full)
                continue
            for dep in run_sqlcmd(args, "SELECT DISTINCT ISNULL(referenced_schema_name, 'dbo') + '.' + referenced_entity_name "
                                        "FROM sys.sql_expression_dependencies WHERE referencing_id = OBJECT_ID(N'%s') "
                                        "AND referenced_database_name IS NULL AND referenced_entity_name IS NOT NULL" % q(full)).splitlines():
                if dep.strip() and dep.strip() not in done:
                    todo.append(dep.strip())
        with open(fn, "w", encoding="utf-8") as fh:
            fh.write("-- extracted by soap_parity.py %s from %s/%s (read-only catalog query)\n" % (VERSION, args.db_server, args.db_name))
            fh.write(body)
        written += 1
    return written, failed


# --------------------------------------------------------------------------- deep mode: logic pack for the LLM

LOGIC_LINE_RE = re.compile(r"\b(if|else|switch|case|when|return|throw|catch|while|for|foreach)\b|[<>]=?|==|!=|&&|\|\||\?\?|[*/%+-]\s*\d|"
                           r"\b\d+(\.\d+)?m?\b|Math\.|Round|decimal|Validate|IsNullOrEmpty|IsNullOrWhiteSpace|Cache|Realtime|Delayed",
                           re.I)


def _method_block(f, m, max_lines):
    """Readable source of one method (comments/blank lines removed), with original line numbers."""
    out = []
    for i in range(m["start"], min(m["end"] + 1, len(f["raw"]))):
        c = f["clean"][i].rstrip()
        if not c.strip():
            continue
        out.append("%5d  %s" % (i + 1, f["raw"][i].rstrip()[:160]))
    if len(out) > max_lines:
        out = out[:max_lines - 1] + ["  ...  (%d more lines)" % (len(out) - max_lines + 1)]
    return out


def _rank_methods(repo, sl, entry_keys):
    """Entry first, then methods with the most logic/validation/data-access lines; trivial ones dropped."""
    hits_by = defaultdict(int)
    for h in repo.hits:
        if sl.contains(h) and h["cat"] in ("db", "outbound", "messaging", "validation", "error", "transaction", "cache", "security"):
            hits_by[(h["fidx"], h["method"])] += 2
    ranked = []
    for order, (f, m) in enumerate(sl.methods):
        body = f["clean"][m["decl"]:m["end"] + 1]
        n = sum(1 for x in body if x.strip())
        if n <= 2 and (f["idx"], m["decl"]) not in entry_keys:
            continue                    # getters, one-line delegations
        logic = sum(1 for x in body if LOGIC_LINE_RE.search(x))
        score = logic + hits_by.get((f["idx"], m["name"]), 0) + (1000 if (f["idx"], m["decl"]) in entry_keys else 0)
        if score <= 1 and (f["idx"], m["decl"]) not in entry_keys:
            continue
        ranked.append((score, order, f, m))
    ranked.sort(key=lambda x: (-x[0], x[1]))
    return ranked


def write_logic_pack(path, op, res, repo1, s1, repo2, s2, budget, ctx=None):
    """<folder>/logic_<op>.md: the code an LLM needs to compare business logic, side by side, size-capped."""
    L = ["# Logic pack: %s" % op["name"],
         "",
         "Purpose: compare BUSINESS LOGIC between repo1 (legacy SOAP) and repo2. Contents were selected by soap_parity.py from each side's",
         "call path (entry method first, then the methods with the most conditions, calculations, validations and data access).",
         "Line numbers are real (`file:line`). Read only this file for the deep review; do not open the repos broadly.",
         "Each method heading is its key for `review/<Op>.notes.json` (e.g. `old:Class.Method`); `Facts:` = what the tool already read from the code.",
         ""]
    per_side = max(100, budget // 2)
    for label, repo, sl, pack in (("repo1 (legacy)", repo1, s1, (ctx or {}).get("pack1")), ("repo2 (new)", repo2, s2, (ctx or {}).get("pack2"))):
        L.append("## %s" % label)
        if not sl:
            L.append("_no call path (entry/endpoint not found)_\n")
            continue
        entry = {(f["idx"], m["decl"]) for f, m in sl.methods[:1]}
        used, picked = 0, []
        ranked = _rank_methods(repo, sl, entry)
        for score, order, f, m in ranked:          # pick by importance ...
            blk = _method_block(f, m, 60)
            if used + len(blk) > per_side and picked:
                continue
            picked.append((order, f, m, blk))
            used += len(blk)
        for order, f, m, blk in sorted(picked, key=lambda x: x[0]):   # ... show in call order
            cls = repo._enclosing_class(f, m["decl"])
            if pack:
                L.append("\n### `%s`  (%s:%d)\n" % (pack.note_key(f, m), f["path"], m["decl"] + 1))
                try:
                    fx = pack.facts(f, m)
                except Exception as e:  # noqa
                    fx = []
                    LOG.write("facts for %s failed: %s" % (m["name"], e))
                if fx:
                    L.append("Facts: " + "; ".join(fx) + "\n")
            else:
                L.append("\n### `%s.%s`  (%s:%d)\n" % (cls["name"] if cls else "?", m["name"], f["path"], m["decl"] + 1))
            L.append("```")
            L.extend(blk)
            L.append("```")
        if len(picked) < len(ranked):
            L.append("\n_... line budget reached; %d more relevant method(s) on the path not shown (raise --deep-lines)_" % (len(ranked) - len(picked)))
        L.append("")
    # SQL logic on either side
    sql_rows = [x for x in res.get("dbObjects", []) if x["definition"] and x["kind"] in ("proc", "function", "view", "trigger")]
    if sql_rows:
        L.append("## Database logic (stored procedures / functions / views / triggers on the call paths)")
        used = 0
        for x in sql_rows:
            o = CATALOG.get(x["object"])
            if not o:
                continue
            lines = [l for l in o["body"].split("\n") if l.strip()]
            if len(lines) > 80:
                lines = lines[:80] + ["... (%d more lines; logic lines below)" % (len(lines) - 80)] + \
                        ["%s" % s for _, s in o.get("signals", [])[:20]]
            if used + len(lines) > budget // 2:
                L.append("\n_... SQL budget reached_")
                break
            L.append("\n### %s `%s` (%s) - used by: repo1 %s | repo2 %s\n" % (o["kind"].lower(), x["object"], x["definition"], x["repo1"], x["repo2"]))
            L.append("```sql")
            L.extend(lines)
            L.append("```")
            used += len(lines)
    tables = [x for x in res.get("dbObjects", []) if x["definition"] and x["kind"] == "table"]
    if tables:
        L.append("\n## Tables on the call paths (columns)\n")
        for x in tables[:25]:
            o = CATALOG.get(x["object"])
            cols = ", ".join("%s %s%s%s" % (c["name"], c["type"], "" if c["null"] else " NOT NULL",
                                          (" =" + c["default"]) if c.get("default") else "") for c in o.get("columns", [])[:40])
            L.append("- `%s` (%s; repo1 %s, repo2 %s): %s" % (x["object"], x["definition"], x["repo1"], x["repo2"], cols))
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    return os.path.getsize(path)


# --------------------------------------------------------------------------- human review pack: code links, call graph, DB export

SHA_RE = re.compile(r"^[0-9a-f]{40}$")


def _read_small(path, limit=1 << 20):
    try:
        if os.path.getsize(path) > limit:
            return None
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    except OSError:
        return None


def remote_to_web(url):
    """git remote URL -> web base URL (credentials always removed). None when it cannot be derived safely."""
    u = (url or "").strip()
    if not u:
        return None
    u = u.rstrip("/")
    if u.lower().endswith(".git"):
        u = u[:-4]
    m = re.match(r"^(?:ssh://)?[\w.\-]+@ssh\.dev\.azure\.com(?::\d+)?[:/]v3/([^/]+)/([^/]+)/([^/]+)$", u, re.I)
    if m:
        return "https://dev.azure.com/%s/%s/_git/%s" % m.groups()
    m = re.match(r"^(?:ssh://)?[\w.\-]+@vs-ssh\.visualstudio\.com(?::\d+)?[:/]v3/([^/]+)/([^/]+)/([^/]+)$", u, re.I)
    if m:
        return "https://%s.visualstudio.com/%s/_git/%s" % m.groups()
    if re.match(r"^https?://", u, re.I):
        p = urllib.parse.urlsplit(u)
        host = p.netloc.rsplit("@", 1)[-1]          # drop user:password@ / PAT@
        if not host:
            return None
        return urllib.parse.urlunsplit((p.scheme.lower(), host, p.path.rstrip("/"), "", ""))
    m = re.match(r"^ssh://(?:[\w.\-]+@)?([\w\-]+(?:\.[\w\-]+)+)(?::(\d+))?/(.+)$", u) or \
        re.match(r"^(?:[\w.\-]+@)?([\w\-]+(?:\.[\w\-]+)+)():(?!\d+/)(.+)$", u)      # scp-like host:path (needs the colon)
    if m:
        host, port, path = m.groups()
        if port and port != "22":
            return None             # custom SSH port (e.g. Bitbucket Server): web URL differs - pass --repoN-url
        return "https://%s/%s" % (host, path.strip("/"))
    return None                     # local path remote, unknown form


def link_style(base):
    b = (base or "").lower()
    if "/projects/" in b and "/repos/" in b:
        return "bbserver"
    if "dev.azure.com" in b or "visualstudio.com" in b or "/_git/" in b:
        return "azure"
    if "gitlab" in b:
        return "gitlab"
    if "bitbucket.org" in b:
        return "bitbucket"
    return "github"


def split_repo_url(url):
    """User-pasted base URL -> (base, ref or None, path prefix). Accepts .../tree/<ref>/<sub/folder>, .../blob/...,
    GitLab .../-/tree/..., Bitbucket .../src/<ref>/..., Azure DevOps ...?path=/x&version=GBmain."""
    u = (url or "").strip()
    if not u:
        return None, None, ""
    p = urllib.parse.urlsplit(u)
    if not p.scheme or not p.netloc:
        return None, None, ""
    host = p.netloc.rsplit("@", 1)[-1]
    path = p.path.rstrip("/")
    if path.lower().endswith(".git"):
        path = path[:-4]
    ref, prefix = None, ""
    if link_style(u) == "azure":
        qs = urllib.parse.parse_qs(p.query)
        v = (qs.get("version") or [""])[0]
        if v[:2] in ("GB", "GC", "GT") and len(v) > 2:
            ref = v[2:]
        pp = (qs.get("path") or [""])[0].strip("/")
        if pp:
            prefix = pp
    else:
        m = re.match(r"^(.*?/repos/[^/]+)/browse(?:/(.*))?$", path)
        if m:                                           # Bitbucket Server: .../projects/P/repos/R/browse/<folder>?at=<ref>
            at = (urllib.parse.parse_qs(p.query).get("at") or [""])[0]
            return (urllib.parse.urlunsplit((p.scheme.lower(), host, m.group(1), "", "")),
                    re.sub(r"^refs/(heads|tags)/", "", at) or None, urllib.parse.unquote(m.group(2) or "").strip("/"))
        m = re.match(r"^(.*?)/(?:-/)?(?:tree|blob|src)/([^/]+)(?:/(.*))?$", path)
        if m:
            path, ref, prefix = m.group(1), urllib.parse.unquote(m.group(2)), urllib.parse.unquote(m.group(3) or "").strip("/")
    return urllib.parse.urlunsplit((p.scheme.lower(), host, path, "", "")), ref, prefix


def git_info(root):
    """Reads .git directly (git may not be installed): repo root, path prefix, remote web URL, branch, commit, and whether
    the commit is on a remote-tracking branch. Never runs git, never reads credentials. None if not a git checkout."""
    try:
        d = os.path.abspath(root)
        g = None
        for _ in range(40):
            if os.path.exists(os.path.join(d, ".git")):
                g = os.path.join(d, ".git")
                break
            nd = os.path.dirname(d)
            if nd == d:
                break
            d = nd
        if not g:
            return None
        gitdir = g
        if os.path.isfile(g):                       # worktree / submodule: "gitdir: <path>"
            txt = (_read_small(g) or "").strip()
            if not txt.startswith("gitdir:"):
                return None
            gitdir = txt[7:].strip()
            if not os.path.isabs(gitdir):
                gitdir = os.path.normpath(os.path.join(d, gitdir))
        common = gitdir
        cd = _read_small(os.path.join(gitdir, "commondir"))
        if cd and cd.strip():
            common = os.path.normpath(os.path.join(gitdir, cd.strip()))
        prefix = os.path.relpath(os.path.abspath(root), d).replace("\\", "/")
        info = {"root": d, "prefix": "" if prefix == "." else prefix, "branch": None, "sha": None, "remote": None,
                "pushed": False, "refs": set()}
        packed = {}
        for line in (_read_small(os.path.join(common, "packed-refs"), 64 << 20) or "").splitlines():
            parts = line.strip().split(" ", 1)
            if len(parts) == 2 and SHA_RE.match(parts[0]):
                packed[parts[1].strip()] = parts[0]

        for k in packed:
            for pre in ("refs/heads/", "refs/tags/", "refs/remotes/origin/"):
                if k.startswith(pre):
                    info["refs"].add(k[len(pre):])
        for sub, pre in (("heads", ""), ("tags", ""), (os.path.join("remotes", "origin"), "")):
            base_ = os.path.join(common, "refs", sub)
            for r_, _d, fs in os.walk(base_):
                for fn in fs:
                    info["refs"].add(os.path.relpath(os.path.join(r_, fn), base_).replace("\\", "/"))

        def ref_sha(ref):
            for base in (gitdir, common):
                v = _read_small(os.path.join(base, *ref.split("/")))
                if v and SHA_RE.match(v.strip()):
                    return v.strip()
            return packed.get(ref)
        head = (_read_small(os.path.join(gitdir, "HEAD")) or "").strip()
        if head.startswith("ref:"):
            ref = head[4:].strip()
            if ref.startswith("refs/heads/"):
                info["branch"] = ref[len("refs/heads/"):]
            info["sha"] = ref_sha(ref)
        elif SHA_RE.match(head):
            info["sha"] = head
        # remote: [remote "origin"] url = ...  (first remote if there is no origin)
        cfg = _read_small(os.path.join(gitdir, "config")) or _read_small(os.path.join(common, "config")) or ""
        remotes, cur = {}, None
        for line in cfg.splitlines():
            s = line.strip()
            m = re.match(r'^\[remote\s+"([^"]+)"\]$', s)
            if m:
                cur = m.group(1)
                continue
            if s.startswith("["):
                cur = None
                continue
            m = re.match(r"^url\s*=\s*(.+)$", s)
            if cur and m and cur not in remotes:
                remotes[cur] = m.group(1).strip()
        url = remotes.get("origin") or (next(iter(remotes.values())) if remotes else None)
        info["remoteName"] = "origin" if "origin" in remotes else (next(iter(remotes)) if remotes else None)
        info["remote"] = remote_to_web(url) if url else None
        if info["sha"]:
            rr = os.path.join(common, "refs", "remotes")
            shas = {v for k, v in packed.items() if k.startswith("refs/remotes/")}
            for base_, dirs, files in os.walk(rr):
                for fn in files:
                    v = _read_small(os.path.join(base_, fn))
                    if v and SHA_RE.match(v.strip()):
                        shas.add(v.strip())
            info["pushed"] = info["sha"] in shas
        return info
    except Exception as e:  # noqa - links are a convenience; never fail the run for them
        LOG.write("git info for %s failed: %s" % (root, e))
        return None


class CodeLinks:
    """file:line -> link. Web link when a base URL is known (--repoN-url, or the git remote); otherwise a relative link
    from the output folder (opens in VS Code); otherwise plain text."""

    def __init__(self, root, out_dir, url=None, ref=None, label="repo1"):
        self.root = os.path.abspath(root)
        self.out_dir = os.path.abspath(out_dir)
        self.label = label
        self.git = git_info(self.root)
        base, url_ref, url_prefix = split_repo_url(url) if url else (None, None, "")
        if url and not base:
            warn("link: --%s-url is not a valid http(s) URL - using local links" % label)
        self.source = "arg" if base else None
        if not base and self.git and self.git.get("remote"):
            base, self.source = self.git["remote"], "git-remote"
        self.base = base.rstrip("/") if base else None
        self.style = link_style(self.base) if self.base else "local"
        # path prefix of the given repo folder inside the git repository
        if url and base:
            # explicit URL: its own path is the folder; the git checkout may be a different (outer) repository
            if url_ref and ref and (url_ref + "/" + url_prefix + "/").startswith(ref.strip("/") + "/"):
                # --repoN-ref release/1.2 + pasted .../tree/release/1.2/src/Svc -> folder src/Svc
                url_prefix = (url_ref + "/" + url_prefix)[len(ref.strip("/")):].strip("/")
            elif url_ref and url_prefix and self.git and self.git.get("refs") and not ref:
                parts = (url_ref + "/" + url_prefix).split("/")
                for i in range(len(parts), 0, -1):            # longest known branch/tag: release/1.2 + src/Svc
                    if "/".join(parts[:i]) in self.git["refs"]:
                        url_ref, url_prefix = "/".join(parts[:i]), "/".join(parts[i:])
                        break
            same_repo = bool(self.git and self.git.get("remote") and
                             self.git["remote"].rstrip("/").lower() == self.base.lower())
            if url_prefix:
                self.prefix = url_prefix            # the pasted URL names the folder: trust it
            elif same_repo:
                self.prefix = self.git["prefix"]    # base URL of the same repository: the folder's place in it
            else:
                self.prefix = ""
                if self.git and self.git.get("prefix"):
                    warn("link: %s folder is inside another git repository (%s); links assume the folder is the root of %s - "
                         "if not, paste the URL of the folder (.../tree/<branch>/<folder>)" % (label, self.git.get("remote") or "?", self.base))
            LOG.write("link: %s url base=%s ref=%s prefix=%s" % (label, self.base, url_ref, self.prefix or "-"))
        else:
            same_repo = bool(self.git)
            self.prefix = self.git["prefix"] if self.git else url_prefix
            if self.git and self.prefix and self.base:
                LOG.write("link: %s folder is the sub-folder '%s' of the git repository %s (pass --%s-url if that is wrong)"
                          % (label, self.prefix, self.base, label))
        git_ref = self.git if same_repo else None      # never take the commit of an unrelated outer checkout
        # ref: explicit > from the pasted URL > checked-out commit (if on the remote) > branch > HEAD (= default branch)
        self.ref, self.ref_src = None, None
        if ref:
            self.ref, self.ref_src = ref.strip(), "arg"
        elif url_ref:
            self.ref, self.ref_src = url_ref, "url"
        elif git_ref and git_ref.get("sha") and git_ref.get("pushed"):
            self.ref, self.ref_src = self.git["sha"], "commit"
        elif git_ref and git_ref.get("branch"):
            self.ref, self.ref_src = self.git["branch"], "branch"
            if self.git.get("sha") and self.base:
                warn("link: %s commit %s is not on the remote - links point to branch '%s' (line numbers may differ)"
                     % (label, self.git["sha"][:8], self.git["branch"]))
        else:
            self.ref, self.ref_src = "HEAD", "default"
            if self.base:
                warn("link: %s has no git info - links use the default branch; pass --%s-ref <branch|commit> to pin them" % (label, label))

    def describe(self):
        if not self.base:
            return "local files (no web URL)"
        ref = self.ref[:10] if self.ref and SHA_RE.match(self.ref) else self.ref
        return "%s @ %s (%s)%s" % (self.style, ref, self.ref_src, (" in /%s" % self.prefix[-40:]) if self.prefix else "")

    def url(self, rel, a, b=None):
        a = max(1, int(a or 1))
        b = int(b) if b else None
        path = ((self.prefix.strip("/") + "/") if self.prefix else "") + rel.lstrip("/")
        if self.base:
            qp = urllib.parse.quote(path, safe="/")
            ref = urllib.parse.quote(self.ref or "HEAD", safe="/")
            if self.style == "azure":
                q = "path=/%s" % qp
                if self.ref and self.ref != "HEAD":
                    q += "&version=%s%s" % ("GC" if SHA_RE.match(self.ref) else "GB", urllib.parse.quote(self.ref, safe=""))
                q += "&line=%d&lineEnd=%d&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents" % (a, b or a)
                return "%s?%s" % (self.base, q)
            if self.style == "gitlab":
                return "%s/-/blob/%s/%s#L%d%s" % (self.base, ref, qp, a, ("-%d" % b) if b and b > a else "")
            if self.style == "bbserver":
                return "%s/browse/%s?at=%s#%d%s" % (self.base, qp, urllib.parse.quote(self.ref or "HEAD", safe=""), a,
                                                    ("-%d" % b) if b and b > a else "")
            if self.style == "bitbucket":
                return "%s/src/%s/%s#lines-%d%s" % (self.base, ref, qp, a, (":%d" % b) if b and b > a else "")
            return "%s/blob/%s/%s#L%d%s" % (self.base, ref, qp, a, ("-L%d" % b) if b and b > a else "")
        try:
            r = os.path.relpath(os.path.join(self.root, rel), self.out_dir).replace("\\", "/")
        except ValueError:
            return None             # different drive: no relative link (never write absolute paths into shared docs)
        return "%s#L%d" % (urllib.parse.quote(r, safe="/._-"), a)

    def md(self, rel, a, b=None, text=None):
        text = text or "%s:%d" % (os.path.basename(rel), a)
        u = self.url(rel, a, b)
        text = text.replace("[", "(").replace("]", ")")
        return "[%s](%s)" % (text, u) if u else "`%s`" % text


def md_cell(s, n=None):
    s = re.sub(r"\s+", " ", str(s if s is not None else "")).strip()
    if n and len(s) > n:
        s = s[:n - 3].rstrip() + "..."
    return s.replace("|", "\\|").replace("<", "&lt;").replace(">", "&gt;")


def md_code(s, n=None, table=False):
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    if n and len(s) > n:
        s = s[:n - 3].rstrip() + "..."
    if table:
        s = s.replace("|", "\\|")
    return ("`` %s ``" % s) if "`" in s else "`%s`" % s


def doc_comment(f, m):
    """/// <summary> (C#) or /** ... */ (Java) right above the method; first sentence."""
    raw = f["raw"]
    i = m["start"] - 1
    buf = []
    while i >= 0 and len(buf) < 30:
        s = raw[i].strip()
        if s.startswith("///"):
            buf.insert(0, s[3:])
        elif s.startswith(("*", "/**", "*/")) and buf is not None:
            buf.insert(0, s.lstrip("/*").rstrip("*/"))
            if s.startswith("/**"):
                break
        elif s.startswith("[") or s.startswith("@") or not s:
            if buf:
                break
        else:
            break
        i -= 1
    txt = " ".join(buf)
    sm = re.search(r"<summary>(.*?)</summary>", txt, re.S | re.I)
    if sm:
        txt = sm.group(1)
    elif "<" in txt and re.search(r"<(param|returns|remarks)\b", txt, re.I):
        txt = re.split(r"<(?:param|returns|remarks)\b", txt, flags=re.I)[0]
    txt = re.sub(r"<see\s+cref=\"(?:\w:)?([^\"]+)\"\s*/>", r"\1", txt)
    txt = re.sub(r"<[^>]+>", " ", txt)
    txt = re.sub(r"@\w+.*$", "", txt)
    txt = re.sub(r"\s+", " ", txt).strip()
    if not txt or len(txt) < 8:
        return None
    first = re.split(r"(?<=[.!?])\s", txt)[0]
    return first[:160]


def _call_text(line, start_rx):
    """`Math.Round(a * b, 2)` out of a longer line (balanced parentheses)."""
    m = re.search(start_rx, line)
    if not m:
        return None
    depth, j = 0, m.end() - 1
    for j in range(m.end() - 1, len(line)):
        if line[j] == "(":
            depth += 1
        elif line[j] == ")":
            depth -= 1
            if depth == 0:
                return line[m.start():j + 1]
    return None


PROXY_PLUMBING = {"ConfigureEndpoint", "GetBindingForEndpoint", "GetEndpointAddress", "GetDefaultBinding",
                  "GetDefaultEndpointAddress", "OpenAsync", "CloseAsync", "Open", "Close", "Abort", "Dispose"}
THROW_RE = re.compile(r"\bthrow\s+new\s+([\w.]+)\s*(?:<[^;()]*>)?\s*\(([^;]*)|\bthrow\s+([\w.]+)\s*(?:<[^;()]*>)?\s*\(|"
                      r"\braise\s+(\w+)\s*\(([^)]*)")
IF_COND_RE = re.compile(r"\bif\s*\(")
HTTP_VERB_RES = [
    (re.compile(r"\.(Get|Post|Put|Patch|Delete)(?:AsJson|FromJson|String|Stream|ByteArray)?Async\b"), None),
    (re.compile(r"\bHttpMethod\.(Get|Post|Put|Patch|Delete)\b", re.I), None),
    (re.compile(r"\bMethod\.(GET|POST|PUT|PATCH|DELETE)\b", re.I), None),
    (re.compile(r"\bnew\s+Http(Get|Post|Put|Patch|Delete)\b"), None),
    (re.compile(r"\b(get|post|put|patch|delete)For(?:Object|Entity)\b"), None),
    (re.compile(r"\brequests\.(get|post|put|patch|delete)\b"), None),
    (re.compile(r"\bUploadString|UploadData|UploadValues"), "POST"),
    (re.compile(r"\bDownloadString|DownloadData|OpenRead"), "GET"),
]
REQ_BODY_RES = [
    re.compile(r"\b(?:SerializeObject|Serialize|AddJsonBody|AddBody|AddXmlBody|bodyValue|writeValueAsString|toJson)\s*(?:<[^>()]*>)?\s*\(\s*(?:new\s+([A-Z]\w*)|([A-Za-z_]\w*))"),
    re.compile(r"\b(?:Post|Put|Patch)AsJsonAsync\s*(?:<[^>()]*>)?\s*\([^,()]+(?:\([^()]*\))?,\s*(?:new\s+([A-Z]\w*)|([A-Za-z_]\w*))"),
    re.compile(r"\bJsonContent\.Create\s*(?:<[^>()]*>)?\s*\(\s*(?:new\s+([A-Z]\w*)|([A-Za-z_]\w*))"),
    re.compile(r"\b(?:postForObject|postForEntity|put|exchange)\s*\([^,()]+,\s*(?:new\s+([A-Z]\w*)|([A-Za-z_]\w*))"),
]
RESP_TYPE_RE = re.compile(r"\b(?:ReadAsAsync|ReadFromJsonAsync|DeserializeObject|Deserialize|GetFromJsonAsync|Execute(?:Async|Get|Post)?|"
                          r"(?:Get|Post|Put)(?:Async)?|readValue|retrieve\(\)\.bodyToMono|Content\.ReadAs\w*)\s*<\s*([\w.]+(?:<[\w.,\s]+>)?)\s*>"
                          r"|\b(?:getForObject|postForObject|getForEntity|postForEntity|bodyToMono|bodyToFlux|readValue)\s*\([^;]*?,\s*([A-Z]\w*)\.class")
GENERIC_PARAM_RE = re.compile(r"^T(?:[A-Z]\w*)?$")


def _type_of_var(repo, f, m, name):
    """Declared type of a variable/parameter/field name in file f (best effort)."""
    for t in sorted(f["vars"].get(name, ())):
        base = strip_generics(t)
        if base in repo.classes or GENERIC_PARAM_RE.match(base):
            return t
    pm = re.search(r"([\w.]+(?:<[^()]*?>)?(?:\[\])?)\s+%s\b" % re.escape(name), m.get("sig", ""))
    if pm:
        return pm.group(1)
    return None


def type_shape(repo, t, depth=0, max_fields=20, seen=None):
    """'{ amount: decimal, from: { ... } }' from the class fields (own + base classes). Unknown types -> name only."""
    seen = set(seen or ())
    t = (t or "").strip().rstrip("?")
    if not t:
        return "?"
    inner = generic_args(t)
    base = strip_generics(t).split(".")[-1].rstrip("[]")
    if t.endswith("[]") or re.match(r"^(List|IList|IEnumerable|ICollection|IReadOnlyList|Collection|Set|HashSet|Array|ArrayList)\b", strip_generics(t)):
        el = inner[-1] if inner else base
        return "[ %s ]" % type_shape(repo, el, depth, max_fields, seen)
    recs = repo.class_recs(base)
    if not recs or depth > 1 or base in seen:
        return base
    seen.add(base)
    c = recs[0]
    fields = list(c["fields"])
    for p in c["parents"]:
        for pc in repo.class_recs(p)[:1]:
            fields += [x for x in pc["fields"] if x["name"] not in {y["name"] for y in fields}]
    if c.get("is_enum"):
        return "%s (one of: %s)" % (base, ", ".join(c.get("enum_values", [])[:8]) or "?")
    out = []
    for fd in fields[:max_fields]:
        ft = fd.get("type") or "?"
        fb = strip_generics(ft).split(".")[-1].rstrip("[]?")
        sub = type_shape(repo, ft, depth + 1, 8, seen) if (fb in repo.classes and fb != base) else ft
        out.append("%s: %s" % (fd["name"], sub))
    more = " ..+%d" % (len(fields) - max_fields) if len(fields) > max_fields else ""
    return "%s { %s%s }" % (base, ", ".join(out), more) if out else base


class ReviewPack:
    """Per-operation call graph + method one-liners + outbound calls, for humans (call_graph.md)."""

    LOGGY_RE = re.compile(r"(?i)(^|[._])(log|logger|logging|trace|tracing|telemetry|eventsource|diagnostic|instrument|metric)")

    def __init__(self, repo, links, side, max_nodes=150, max_depth=6, notes=None):
        self.repo, self.links, self.side, self.max_nodes, self.max_depth = repo, links, side, max_nodes, max_depth
        self.notes = notes or {}            # {"old:Class.Method": "two plain sentences"} written by the LLM
        self.used_notes = set()
        self.hits_by_file = defaultdict(list)
        for h in repo.hits:
            self.hits_by_file[h["fidx"]].append(h)
        self._facts = {}

    # ---- per method
    def cls_of(self, f, m):
        return self.repo._enclosing_class(f, m["decl"])

    def qname(self, f, m):
        c = self.cls_of(f, m)
        return "%s.%s" % (c["name"] if c else os.path.splitext(os.path.basename(f["path"]))[0], m["name"])

    def method_hits(self, f, m):
        return [h for h in self.hits_by_file.get(f["idx"], ()) if m["start"] + 1 <= h["line"] <= m["end"] + 1
                and self.repo._enclosing_method(f, h["line"] - 1) is m]

    def db_uses(self, f, m):
        """[(kind, name, mode)] for this method: SQL text, procs, LINQ to SQL / EF entity sets, proc wrappers."""
        repo, out = self.repo, []
        for h in self.method_hits(f, m):
            if h["cat"] != "db":
                continue
            for k in h["keys"]:
                if k[0] in ("table", "proc"):
                    out.append((k[0], k[1], "exec" if k[0] == "proc" else _db_mode([h["text"]])))
        nested = [(x["start"], x["end"]) for x in f["methods"]
                  if x is not m and m["start"] <= x["start"] and x["end"] <= m["end"] and x["decl"] > m["decl"]]
        for i in range(m["decl"], min(m["end"] + 1, len(f["clean"]))):
            if nested and any(a <= i <= b for a, b in nested):
                continue                # line of a nested/local method - belongs to that method
            line = STR_RE.sub('""', f["clean"][i])
            for prop in set(re.findall(r"\.\s*(\w+)\b(?!\s*\()", line)):
                ent = repo.dbsets.get(prop)
                if ent:
                    out.append(("table", repo.entity_table.get(ent, prop).split(".")[-1].upper(), _db_mode([line])))
            for fn in set(re.findall(r"\.\s*(\w+)\s*\(", line)):
                if fn in repo.db_funcs:
                    out.append(("proc", proc_key(repo.db_funcs[fn]), "exec"))
        if re.search(r"\b(?:SaveChanges(?:Async)?|SubmitChanges)\s*\(", " ".join(f["clean"][m["decl"]:m["end"] + 1])):
            out = [(a, b, "read+save" if (a == "table" and c != "write") else c) for a, b, c in out]
        seen, res = set(), []
        for k in out:
            if (k[0], k[1]) in seen:
                if k[2] == "write":
                    res = [(a, b, "write") if (a, b) == (k[0], k[1]) else (a, b, c) for a, b, c in res]
                continue
            seen.add((k[0], k[1]))
            res.append(k)
        return res

    def _cond_before(self, f, i, m, guard=False):
        """Condition of the nearest `if (...)` on lines i-2..i (same method).
        guard=True (line i is a `throw`): only when that `if` DIRECTLY guards the throw - nothing but `{` between the
        condition and `throw`. Otherwise None, so a throw after an early-return `if` is never reported with the
        (inverted) condition of that `if`."""
        for j in (range(i, max(m["decl"], i - 3) - 1, -1) if guard else [i]):
            line = f["clean"][j]
            if not IF_COND_RE.search(line):
                continue
            if guard:
                txt = " ".join(f["clean"][j:i + 1])
            else:                       # the `if` line itself; its condition may continue on the next lines
                txt = " ".join(f["clean"][j:min(i + 4, m["end"] + 1, len(f["clean"]))])
            mm = IF_COND_RE.search(txt)
            if guard:
                tp = txt.rfind("throw")
                if tp < 0:
                    return None
                cands = [x for x in IF_COND_RE.finditer(txt) if x.start() < tp]
                if not cands:
                    return None
                mm = cands[-1]
            k = mm.end()
            depth, out, close = 1, [], None
            for pos in range(k, len(txt)):
                ch = txt[pos]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        close = pos
                        break
                out.append(ch)
            cond = "".join(out).strip()
            if not cond or close is None:
                return None
            if guard:
                between = txt[close + 1:txt.rfind("throw")].strip()
                if between not in ("", "{"):
                    return None
            return cond
        return None

    def _const_note(self, text):
        notes = []
        for ident in re.findall(r"\b([A-Za-z_]\w*)\b", STR_RE.sub("", text)):
            vals = self.repo.constants.get(ident)
            if vals and len(vals) == 1 and len(notes) < 2:
                v = next(iter(vals))[1]
                if "%s = %s" % (ident, v) not in notes:
                    notes.append("%s = %s" % (ident, v))
        return (" (%s)" % ", ".join(notes)) if notes else ""

    def facts(self, f, m):
        key = (f["idx"], m["decl"])
        if key in self._facts:
            return self._facts[key]
        F = []
        doc = doc_comment(f, m)
        if doc:
            F.append("%s _(code comment)_" % md_cell(doc, 160))
        used_conds = set()
        px = self.soap_proxy(f, m)
        if px:
            F.append("Calls external SOAP service operation **%s** (generated client)" % px["target"])
        # validations / errors
        n_throw = 0
        for i in range(m["decl"], min(m["end"] + 1, len(f["clean"]))):
            line = f["clean"][i]
            tm = THROW_RE.search(line)
            if tm and n_throw < 2:
                exc = (tm.group(1) or tm.group(3) or tm.group(4) or "error").split(".")[-1]
                msg = ""
                raw_i = f["raw"][i] if i < len(f["raw"]) else ""
                tpos = max(raw_i.find("throw"), raw_i.find("raise"), 0)
                sm = STR_RE.search(raw_i[tpos:])          # the message of the exception, not a string in the if-condition
                if sm:
                    msg = ' "%s"' % (sm.group(1) or sm.group(2) or "")[:60]
                cond = self._cond_before(f, i, m, guard=True)
                if cond:
                    used_conds.add(cond)
                    F.append("Rejects when %s%s -> %s%s" % (md_code(cond, 90), self._const_note(cond), exc, msg))
                else:
                    F.append("Throws %s%s" % (exc, msg))
                n_throw += 1
        # DB
        own_cls = self.cls_of(f, m)
        if m["name"] in self.repo.db_funcs and own_cls and Slice._data_context(f, own_cls):
            F.append("Generated wrapper that runs stored procedure **%s**" % proc_key(self.repo.db_funcs[m["name"]]))
        uses = self.db_uses(f, m)
        procs = [n for k, n, _ in uses if k == "proc"]
        writes = [n for k, n, md in uses if k == "table" and md == "write"]
        reads = [n for k, n, md in uses if k == "table" and md == "read"]
        saves = [n for k, n, md in uses if k == "table" and md == "read+save"]
        if procs:
            F.append("Runs stored procedure %s" % ", ".join("**%s**" % x for x in procs[:3]) + (" +%d" % (len(procs) - 3) if len(procs) > 3 else ""))
        if writes:
            F.append("Writes table %s" % ", ".join("**%s**" % x for x in writes[:3]) + (" +%d" % (len(writes) - 3) if len(writes) > 3 else ""))
        if reads:
            F.append("Reads table %s" % ", ".join("**%s**" % x for x in reads[:3]) + (" +%d" % (len(reads) - 3) if len(reads) > 3 else ""))
        if saves:
            F.append("Loads %s and saves changes (SaveChanges) - may update it" % ", ".join("**%s**" % x for x in saves[:3]))
        hs = self.method_hits(f, m)
        outs = [h for h in hs if h["cat"] == "outbound"]
        if outs:
            d = self.outbound_detail(f, m, outs[0])
            F.append("Calls external %s %s" % (d["kind"], md_code(("%s %s" % (d["verb"] or "", d["target"] or "")).strip() or "(see outbound table)", 80)))
        msgs = [h for h in hs if h["cat"] == "messaging"]
        if msgs:
            q = sorted({k[1] for h in msgs for k in h["keys"] if k[0] == "queue"})
            F.append("Publishes a message" + ((" to " + ", ".join(q[:2])) if q else ""))
        if any(h["cat"] == "cache" for h in hs):
            F.append("Uses a cache")
        body = f["clean"][m["decl"]:m["end"] + 1]
        if any(re.search(r"\bTransactionScope\b|BeginTransaction|@Transactional|\.Commit\s*\(", x) for x in body):
            F.append("Uses a transaction")
        # rules with literals / constants (max 2)
        n_rule = 0
        for i in range(m["decl"], min(m["end"] + 1, len(f["clean"]))):
            if n_rule >= 2:
                break
            line = f["clean"][i]
            if THROW_RE.search(line) or LOG_LINE_RE.search(line):
                continue
            mm = IF_COND_RE.search(line) or re.search(r"\b(?:else\s+if|while)\s*\(", line)
            if mm:
                cond = self._cond_before(f, i, m)
                if cond in used_conds:
                    continue
                if cond and (NUM_RE.search(STR_RE.sub("", cond)) or STR_RE.search(cond) or
                             any(x in self.repo.constants for x in re.findall(r"\b([A-Za-z_]\w*)\b", cond))) \
                        and not re.search(r"(?i)\b(log|debug|trace)", cond):
                    F.append("Checks %s%s" % (md_code(cond, 80), self._const_note(cond)))
                    used_conds.add(cond)
                    n_rule += 1
            elif re.search(r"\bMath\.Round\s*\(|\bdecimal\.Round\s*\(|setScale\s*\(|RoundingMode\.", line):
                F.append("Rounds: %s" % md_code(_call_text(line, r"\b(?:Math|decimal)\.Round\s*\(|setScale\s*\(") or line.strip(), 80))
                n_rule += 1
        rm = None
        for x in reversed(body):
            rm = re.search(r"\breturn\s+new\s+([A-Z]\w*)", x)
            if rm:
                break
        if rm and len(F) < 5:
            F.append("Builds the %s it returns" % rm.group(1))
        self._facts[key] = F
        return F

    PROXY_BASE_RE = re.compile(r"^(ClientBase|DuplexClientBase|SoapHttpClientProtocol|HttpWebClientProtocol|WebServicesClientProtocol)$")

    def soap_proxy(self, f, m):
        """Method of a generated SOAP/WCF client (Reference.cs: class X : ClientBase<IX>) -> outbound detail."""
        c = self.cls_of(f, m)
        if not c or not any(self.PROXY_BASE_RE.match(p_) for p_ in c["parents"]) or m["name"] == c["name"]:
            return None
        sig = m.get("sig", "")
        if re.search(r"\b(static|partial)\b", sig.split("(")[0]) or m["name"] in PROXY_PLUMBING:
            return None             # generated plumbing (ConfigureEndpoint, GetBindingForEndpoint, Open/CloseAsync)
        body = " ".join(f["clean"][m["decl"]:m["end"] + 1])
        if not re.search(r"\bChannel\s*\.|\.Invoke(?:Async)?\s*\(|\bInvoke(?:Async)?\s*\(|BeginInvoke|EndInvoke", body):
            return None             # not a remote call
        pre = strip_generics(sig.split("(")[0]).split()
        ret = pre[-2] if len(pre) >= 2 else None
        ret = None if ret in (None, "void", "Task") or ret in MODS.split("|") else ret
        tm = re.search(r"Task\s*<\s*([\w.]+(?:<[^<>()]*>)?)\s*>", sig.split("(")[0])
        if tm:
            ret = tm.group(1)
        args_ = sig.split("(", 1)[1] if "(" in sig else ""
        pt = re.match(r"\s*(?:ref\s+|out\s+)?([\w.]+(?:<[^()]*?>)?)\s+\w+", args_)
        req = pt.group(1) if pt else None
        return {"kind": "SOAP", "verb": None, "target": "%s.%s" % (c["name"], m["name"]), "config": [],
                "request": req, "response": ret, "at": (f["path"], m["decl"] + 1), "method": self.qname(f, m),
                "requestShape": type_shape(self.repo, req) if req else None,
                "responseShape": type_shape(self.repo, ret) if ret else None,
                "note": "address in config (system.serviceModel/client)"}

    def note_key(self, f, m):
        return "%s:%s" % (self.side, self.qname(f, m))

    def note(self, f, m):
        n = self.notes.get(self.note_key(f, m))
        if not n:
            return None
        self.used_notes.add(self.note_key(f, m))
        return md_cell(n, 400)

    def outbound_detail(self, f, m, h):
        """kind, verb, target (route/URL/config key), request and response type with field shapes."""
        repo = self.repo
        i = h["line"] - 1
        lo, hi = m["decl"], min(m["end"] + 1, len(f["clean"]))
        body = "\n".join(f["clean"][lo:hi])
        near = " ".join(f["clean"][max(lo, i - 2):min(hi, i + 4)])
        kind = {"soap-client": "SOAP", "grpc": "gRPC"}.get(h["sub"], "HTTP")
        verb = None
        for rx, fixed in HTTP_VERB_RES:
            mm = rx.search(near) or rx.search(body)
            if mm:
                verb = fixed or mm.group(1).upper()
                break
        paths = [k[1] for k in h["keys"] if k[0] == "path"]
        lits = []
        for x in PATH_LIT_RE.findall(body):
            if x and x not in lits and not MEDIA_TYPE_RE.match(x.lstrip("/")):
                lits.append(x)
        cfg = []
        for cm in CS_CONFIG_RE.finditer(body):
            v = next((g for g in cm.groups() if g), None)
            if v and v not in cfg:
                cfg.append(v)
        for ph in PLACEHOLDER_RE.findall(body):
            if ph not in cfg:
                cfg.append(ph)
        target = (lits[0] if lits else (paths[0] if paths else ""))
        if cfg:
            target = ("{%s}" % cfg[0]) + (target if target.startswith("/") else (" " + target if target else ""))
        req_t = resp_t = None
        op_name = None
        for rx in REQ_BODY_RES:
            mm = rx.search(body)
            if mm:
                req_t = mm.group(1) or _type_of_var(repo, f, m, mm.group(2))
                if req_t:
                    break
        mm = RESP_TYPE_RE.search(body)
        if mm:
            resp_t = mm.group(1) or mm.group(2)
        if kind == "SOAP" or not (req_t or resp_t):
            # generated SOAP/WCF proxy: client.Operation(request) on a variable whose type is a *Client / proxy class
            for recv, meth in CALL_RECV_RE.findall(body):
                t = _type_of_var(repo, f, m, recv) or (NEW_RE.search(near).group(1) if NEW_RE.search(near) and recv in near else None)
                tb = strip_generics(t or "").split(".")[-1]
                if not tb or not re.search(r"(Client|Proxy|Soap|Service|Channel)$", tb) or meth in COMMON_METHODS or meth in ("Close", "Abort", "Open", "Dispose"):
                    continue
                for pf, pm in repo.methods_named(tb, meth) or repo.methods_named(re.sub(r"Client$", "", tb), meth):
                    head = pm["sig"].split("(")[0]
                    tm_ = re.search(r"Task\s*<\s*([\w.]+(?:<[^<>()]*>)?)\s*>", head)
                    pre = strip_generics(head).split()
                    ret = tm_.group(1) if tm_ else (pre[-2] if len(pre) >= 2 else None)
                    args = pm["sig"].split("(", 1)[1] if "(" in pm["sig"] else ""
                    pt = re.match(r"\s*(?:ref\s+|out\s+)?([\w.]+(?:<[^()]*?>)?)\s+\w+", args)
                    req_t = req_t or (pt.group(1) if pt else None)
                    resp_t = resp_t or (ret if ret and ret not in ("void", "Task") else None)
                    op_name = meth
                    kind = "SOAP"
                    break
                if op_name:
                    break
        if op_name and not target:
            target = op_name
        if req_t and GENERIC_PARAM_RE.match(strip_generics(req_t)):
            req_t = self._generic_at_callers(m, 0) or req_t
        if resp_t and GENERIC_PARAM_RE.match(strip_generics(resp_t)):
            resp_t = self._generic_at_callers(m, -1) or resp_t
        if not lits and not op_name:
            cp = self._path_at_callers(m)
            if cp:
                target = (target + " " if target else "") + cp + " (from caller)"
        return {"kind": kind, "verb": None if kind == "SOAP" else verb, "target": target, "config": cfg[:3], "proxyOp": op_name,
                "request": req_t, "response": resp_t, "at": (f["path"], h["line"]), "method": self.qname(f, m),
                "requestShape": type_shape(repo, req_t) if req_t else None,
                "responseShape": type_shape(repo, resp_t) if resp_t else None}

    def _caller_lines(self, m):
        sl = getattr(self, "_slice", None)
        if not sl:
            return
        for pk, kids in sl.edges.items():
            for ck in kids:
                if sl.node.get(ck, (None, None))[1] is not m:
                    continue
                pf, pm = sl.node[pk]
                for i in range(pm["decl"] + 1, min(pm["end"] + 1, len(pf["clean"]))):
                    if re.search(r"\b%s\s*[<(]" % re.escape(m["name"]), pf["clean"][i]):
                        yield pf["clean"][i]

    @staticmethod
    def _generic_args_at(line, name):
        """'_h.Get<List<OrderDto>>(' -> ['List<OrderDto>'] (top-level comma split, nesting kept)."""
        mm = re.search(r"\b%s\s*<" % re.escape(name), line)
        if not mm:
            return []
        depth, cur, out = 1, "", []
        for ch in line[mm.end():]:
            if ch == "<":
                depth += 1
            elif ch == ">":
                depth -= 1
                if depth == 0:
                    break
            if ch == "," and depth == 1:
                out.append(cur.strip())
                cur = ""
                continue
            cur += ch
        if depth != 0:
            return []
        out.append(cur.strip())
        return [x for x in out if x]

    def _generic_at_callers(self, m, pos):
        """Generic helper Post<TReq,TRes>(...): take the concrete type from a caller line `.Post<A, B>(`."""
        for line in self._caller_lines(m):
            parts = self._generic_args_at(line, m["name"])
            if parts:
                return parts[pos]
        return None

    def _path_at_callers(self, m):
        for line in self._caller_lines(m):
            for x in PATH_LIT_RE.findall(line):
                if x and not MEDIA_TYPE_RE.match(x.lstrip("/")):
                    return x
        return None

    # ---- tree
    def is_interface(self, f, m):
        c = self.cls_of(f, m)
        return bool(c and c["kind"] == "interface")

    def _call_pos(self, pf, pm, name):
        rx = re.compile(r"\b%s\b" % re.escape(name))
        for i in range(pm["decl"] + 1, min(pm["end"] + 1, len(pf["clean"]))):
            if rx.search(pf["clean"][i]):
                return i
        return 10 ** 9

    def children(self, sl, k):
        pf, pm = sl.node[k]
        pc = self.cls_of(pf, pm)
        supers = set()
        if pc:
            for p_ in pc["parents"]:
                supers.add(p_)
                supers |= self.repo.superclasses(p_)
        kids = []
        for c in sl.edges.get(k, ()):
            if c not in sl.node:
                continue
            cf, cm = sl.node[c]
            cc = self.cls_of(cf, cm)
            if cm["name"] == pm["name"] and cc and cc["name"] in supers:
                continue                # the declaration this method implements/overrides - not a call
            kids.append(c)
        by_name = defaultdict(list)
        for c in kids:
            by_name[sl.node[c][1]["name"]].append(c)
        out = []
        for c in kids:
            f, m = sl.node[c]
            if self.is_interface(f, m) and any(not self.is_interface(*sl.node[o]) for o in by_name[m["name"]]):
                continue                # interface declaration next to its implementation: show the implementation only
            out.append(c)
        out.sort(key=lambda c: self._call_pos(pf, pm, sl.node[c][1]["name"]))
        return out

    def trivial(self, sl, k, depth=0):
        f, m = sl.node[k]
        if self.facts(f, m) or self.note(f, m):
            return False
        if depth < 3 and any(not self.trivial(sl, c, depth + 1) for c in self.children(sl, k)):
            return False
        c = self.cls_of(f, m)
        if c and m["name"] == c["name"]:
            return True                 # constructor without DB / external calls / checks: wiring only
        n = sum(1 for x in f["clean"][m["decl"]:m["end"] + 1] if x.strip())
        return n <= 3 or bool(self.LOGGY_RE.search(self.qname(f, m)) or self.LOGGY_RE.search(f["path"]))

    def tree(self, sl, entries):
        self._slice = sl
        L, shown = [], set()
        st = {"count": 0, "cut": 0, "hidden": 0}

        def walk(k, depth):
            f, m = sl.node[k]
            ind = "  " * depth
            name = self.qname(f, m)
            link = self.links.md(f["path"], m["decl"] + 1, m["end"] + 1, "%s:%d" % (os.path.basename(f["path"]), m["decl"] + 1))
            if k in shown:
                L.append("%s- %s _(shown above)_" % (ind, md_cell(name)))
                return
            if st["count"] >= self.max_nodes:
                st["cut"] += 1
                return
            shown.add(k)
            st["count"] += 1
            F = self.facts(f, m)
            kids = self.children(sl, k)
            iface = self.is_interface(f, m)
            desc = "; ".join(F)
            note = self.note(f, m)
            if note:
                desc = note + ((" <br>_Code:_ " + desc) if desc else "")
            if not desc:
                if iface and not kids:
                    desc = "Interface only - the implementation was not found in this repo (DI / another repo / package?)"
                elif kids:
                    desc = "Passes the work on (see below)"
                elif k not in sl.visited:
                    desc = "Not followed (call-path limit reached)"
                else:
                    desc = "(?) nothing notable detected"
            L.append("%s- **%s** - %s %s" % (ind, md_cell(name), desc, link))
            if not kids:
                return
            if depth + 1 >= self.max_depth:
                L.append("%s  - _... %d more call(s) below this level (raise --graph-depth)_" % (ind, len(kids)))
                return
            hidden = 0
            for c in kids:
                if not self.is_interface(*sl.node[c]) and self.trivial(sl, c):
                    hidden += 1
                    continue
                walk(c, depth + 1)
            if hidden:
                st["hidden"] += hidden
                L.append("%s  - _+%d small helper/logging call(s) not shown_" % (ind, hidden))
        for e in entries:
            if e in sl.node:
                walk(e, 0)
        if st["cut"]:
            L.append("- _... %d more method(s) not shown (limit --graph-nodes %d)_" % (st["cut"], self.max_nodes))
        return L, st

    def outbound_rows(self, sl):
        rows, seen = [], set()
        proxy_ops = {self.soap_proxy(f, m)["target"].split(".")[-1] for f, m in sl.methods if self.soap_proxy(f, m)}
        for f, m in sl.methods:
            px = self.soap_proxy(f, m)
            if px:
                rows.append(px)
                continue
            for h in self.method_hits(f, m):
                if h["cat"] not in ("outbound", "messaging") or not sl.contains(h):
                    continue
                if h["cat"] == "outbound" and re.search(r"\bnew\s+HttpClient\b|\bHttpClientFactory\b|\bIHttpClientFactory\b", h["text"]) \
                        and not re.search(r"\.(Get|Post|Put|Patch|Delete|Send)\w*Async\b", h["text"]):
                    continue            # client construction, the call itself is another hit
                key = (f["idx"], m["decl"], h["cat"])
                if key in seen:
                    continue
                seen.add(key)
                if h["cat"] == "messaging":
                    q = sorted({k[1] for k in h["keys"] if k[0] == "queue"})
                    tm = re.search(r"\(\s*(?:new\s+([A-Z]\w*)|([a-z_]\w*))", h["text"])
                    t = (tm.group(1) or _type_of_var(self.repo, f, m, tm.group(2))) if tm else None
                    rows.append({"kind": "message", "verb": "publish", "target": ", ".join(q) or "(queue/topic set outside this code)", "request": t,
                                 "requestShape": type_shape(self.repo, t) if t else None, "response": None, "responseShape": None,
                                 "at": (f["path"], h["line"]), "method": self.qname(f, m), "config": []})
                else:
                    d = self.outbound_detail(f, m, h)
                    if d["kind"] == "SOAP" and d.get("proxyOp") in proxy_ops:
                        continue        # the generated client method on the path is already listed
                    rows.append(d)
        return rows


def outbound_table(rows, links, side):
    if not rows:
        return ["_none found on the %s call path_" % side]
    L = ["| # | Type | Call | Sends (request) | Gets back (response) | Where |", "|---|---|---|---|---|---|"]
    for n, d in enumerate(rows, 1):
        call = ("%s %s" % (d["verb"] or "", d["target"] or "")).strip() or "?"
        sends = md_cell(d.get("requestShape") or (d.get("request") or "not detected"), 300)
        gets = md_cell(d.get("responseShape") or (d.get("response") or ("-" if d["kind"] == "message" else "not detected")), 300)
        L.append("| %d | %s | %s | %s | %s | %s %s |" % (n, d["kind"], md_code(call, 90, True), sends, gets, md_cell(d["method"], 60),
                                                         links.md(d["at"][0], d["at"][1])))
    cfg = sorted({c for d in rows for c in d.get("config", [])})
    if cfg:
        L.append("\nConfig keys used for addresses: " + ", ".join(md_code(c) for c in cfg[:10]))
    return L


def _anchor(s):
    return re.sub(r"[^\w\- ]", "", s.lower()).strip().replace(" ", "-")


def consumer_changes(r, c2, H):
    """'What callers must change': the migration notice for consumers of the SOAP operation, from the tool's facts.
    Moving to REST is planned, so these are changes to announce - not gaps. Real gaps (data not taken / not returned)
    are listed separately for the reviewer's decision."""
    L = ["%s# What callers must change\n" % H,
         "_Moving from SOAP to REST is planned, so these are changes to announce to consumers, not defects. "
         "Only the last two lines (inputs not taken, data not returned) can be real gaps._\n"]
    ep = ("%s %s" % (c2.get("verb") or "", c2.get("route") or "")).strip() if c2 else ""
    L.append("- **Call:** SOAP operation `%s`%s -> %s" % (r["operation"], (" (SOAPAction `%s`)" % r["soapAction"]) if r.get("soapAction") else "",
                                                          ("REST `%s`" % ep) if ep else "_no REST endpoint matched_"))
    con = r.get("contract") or {}
    req = [x for x in (con.get("request") or {}).get("rows", []) if x["status"] in ("MATCH", "FUZZY", "MISSING")]
    moved, renamed_in, not_taken = [], [], []
    for x in req:
        leaf = x["path"].split("/")[-1]
        if x["status"] == "MISSING":
            if x["path"].count("/") <= ((con.get("request") or {}).get("root") or "").count("/") + 1:
                not_taken.append(leaf)
            continue
        src = x.get("inputSource")
        new = x.get("repoFieldName") or x.get("repoField") or leaf
        if src in ("route", "query", "header", "form"):
            moved.append("`%s` -> %s" % (leaf, re.sub(r"^.*\((.*)\)$", r"\1", x.get("repoField") or src)))
        elif norm(new) != norm(leaf) or x["status"] == "FUZZY":
            renamed_in.append("`%s` -> body `%s`" % (leaf, new))
    if moved:
        L.append("- **Inputs now sent outside the body:** " + "; ".join(moved))
    if renamed_in:
        L.append("- **Inputs renamed:** " + "; ".join(renamed_in) + " _(confirm same meaning)_")
    res = [x for x in (con.get("response") or {}).get("rows", [])]
    ren = ["`%s` -> `%s`" % (x["path"].split("/")[-1], x.get("repoFieldName") or x.get("repoField")) for x in res
           if x["status"] == "FUZZY"]
    typ = ["`%s`: %s" % (x["path"].split("/")[-1], x.get("notes")) for x in res
           if x["status"] in ("MATCH", "FUZZY") and x.get("typeCheck") in ("WARN", "MISMATCH") and x.get("notes")]
    miss = [x["path"].split("/")[-1] for x in res if x["status"] in ("MISSING", "MISSING(parent)") and
            x["path"].count("/") <= ((con.get("response") or {}).get("root") or "").count("/") + 1]
    unset = sum(1 for x in res if x["status"] == "NOT_SET_IN_REPO1")
    if ren:
        L.append("- **Response fields renamed:** " + "; ".join(ren[:25]) + (" ..." if len(ren) > 25 else "") + " _(confirm same meaning)_")
    if typ:
        L.append("- **Response types changed:** " + "; ".join(typ[:15]) + (" ..." if len(typ) > 15 else ""))
    L.append("- **Format:** JSON instead of a SOAP envelope; errors come as HTTP status codes instead of SOAP faults "
             "(field-name casing usually changes too, e.g. `LastPrice` -> `lastPrice`).")
    if not_taken:
        L.append("- **Inputs the new endpoint does not take (decide: dropped, from login/config, or a gap):** " +
                 ", ".join("`%s`" % x for x in not_taken))
    if miss:
        L.append("- **Response data not returned by the new endpoint (%d)%s:** %s" % (
            len(miss), (" - %d other old field(s) were never filled by the old code and are left out" % unset) if unset else "",
            ", ".join("`%s`" % x for x in miss[:40]) + (" ..." if len(miss) > 40 else "")))
    L.append("")
    return L


def op_chapter(r, ctx, llm_text=None, h=2):
    """Lines for one operation: [LLM review] + call flows + external calls + DB objects. h = heading level of the chapter."""
    H = "#" * h
    o = ctx["graph"].get(r["operation"], {})
    p1, p2 = ctx.get("pack1"), ctx.get("pack2")
    L = ["\n---\n\n%s %s\n" % (H, r["operation"])]
    c2 = (r.get("repo2Candidates") or [None])[0]
    if o.get("entry1") and p1:
        f, m = o["entry1"]
        L.append("**Old entry:** %s  " % ctx["links1"].md(f["path"], m["decl"] + 1, None, p1.qname(f, m)))
    if o.get("has2") and c2 and o.get("entry2"):
        f, m = o["entry2"]
        L.append("**New endpoint:** %s - %s (match score %.2f%s)  " % (
            md_code(("%s %s" % (c2.get("verb") or "", c2.get("route") or "")).strip() or "-"),
            ctx["links2"].md(f["path"], m["decl"] + 1, None, p2.qname(f, m)), c2["score"], ", pinned" if r.get("repo2Forced") else ""))
    else:
        L.append("**New endpoint:** not found automatically - pin it with `--repo2-map` / `--repo2-entry` and re-run.  ")
    L.append("**Tool verdict:** %s _(automatic first guess; the review below decides)_\n" % r["verdict"])
    if llm_text:
        L.append(llm_text.strip() + "\n")
    try:
        L.extend(consumer_changes(r, c2 if o.get("has2") else None, H))
    except Exception as e:  # noqa - never lose the report over this section
        warn("report: 'What callers must change' skipped for %s (%s)" % (r["operation"], type(e).__name__))
    L.append("%s# At a glance\n" % H)
    L.append("| | Old (repo1) | New (repo2) |\n|---|---|---|")
    has2 = o.get("has2")
    L.append("| Methods on the call path | %s | %s |" % (o.get("m1", "-"), o.get("m2", "-") if has2 else "-"))
    L.append("| DB objects used directly | %d | %s |" % (o.get("db1", 0), o.get("db2", 0) if has2 else "-"))
    L.append("| External calls / messages | %d | %s |" % (o.get("out1", 0), o.get("out2", 0) if has2 else "-"))
    L.append("| Calls the tool could not follow | %d | %s |" % (len(o.get("unres1", [])), len(o.get("unres2", [])) if has2 else "-"))
    for side, key in (("Old (repo1)", "1"), ("New (repo2)", "2")):
        L.append("\n%s# %s call flow\n" % (H, side))
        tl = o.get("tree" + key)
        if not tl:
            L.append("_no call path (entry/endpoint not found)_")
            continue
        L.extend(tl)
        if o.get("unres" + key):
            L.append("\n_Calls the tool could not follow (check by hand - DI, reflection, another repo or a NuGet package):_ "
                     + ", ".join(md_code(x, 90) for x in o["unres" + key][:8]))
    L.append("\n%s# External calls and messages\n" % H)
    L.append("**Old (repo1)**\n")
    L.extend(outbound_table(o.get("outRows1", []), ctx["links1"], "old") if ctx.get("links1") else ["_repo1 not given_"])
    L.append("\n**New (repo2)**\n")
    L.extend(outbound_table(o.get("outRows2", []), ctx["links2"], "new") if has2 else ["_no endpoint matched_"])
    L.append("\n_Request/response shapes are the declared types and their fields (2 levels), not captured runtime values._")
    dbo = r.get("dbObjects", [])
    L.append("\n%s# Database objects\n" % H)
    if dbo:
        L.append("| Object | Type | Old (repo1) | New (repo2) | Same? | SQL definition |\n|---|---|---|---|---|---|")
        for x in dbo[:60]:
            L.append("| **%s** | %s | %s | %s | %s | %s |" % (
                md_cell(x["object"]), x["kind"], md_cell(x["repo1"]), md_cell(x["repo2"]), DB_STATUS_TEXT.get(x["status"], x["status"]),
                "seen" if x["definition"] else "missing (logic not reviewed)"))
        if len(dbo) > 60:
            L.append("\n_... %d more in the appendix_" % (len(dbo) - 60))
    else:
        L.append("_no database access detected on either path_")
    return L


def _header(title, ctx):
    return ["# %s" % title, "",
            "_Generated by soap_parity.py %s on %s. Code links: old (repo1) %s; new (repo2) %s._" % (
                VERSION, time.strftime("%Y-%m-%d %H:%M"),
                ctx["links1"].describe() if ctx.get("links1") else "-", ctx["links2"].describe() if ctx.get("links2") else "-"),
            ""]


HOW_TO_READ = ("**How to read the call flows:** each line is one method - **Class.Method** - what it does - link to the code. "
               "Indented lines are the methods it calls, in call order. _Code:_ = facts the tool read from the code "
               "(checks, DB use, external calls); _(code comment)_ = the developer's own comment; `(?)` = nothing notable detected.")


def write_call_graph(path, results, ctx):
    """Step-1 preview for humans: call flows, external calls, DB objects per operation (no LLM text)."""
    L = _header("Call graph and integrations (preview)", ctx)
    L += [HOW_TO_READ, "", "## Contents", ""]
    for r in results:
        o = ctx["graph"].get(r["operation"], {})
        L.append("- [%s](#%s) - old: %s methods, %d DB objects, %d external calls | new: %s" % (
            r["operation"], _anchor(r["operation"]), o.get("m1", "-"), o.get("db1", 0), o.get("out1", 0),
            ("%s methods, %d DB objects, %d external calls" % (o.get("m2", "-"), o.get("db2", 0), o.get("out2", 0))) if o.get("has2") else "no endpoint matched"))
    for r in results:
        L += op_chapter(r, ctx)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


# ---- reviewer text (<folder>/review/*.md) merged into the single final report

LLM_REF_RE = re.compile(r"\b(old|new|repo1|repo2):([\w./\\\-]+\.\w{1,8}):(\d{1,6})(?:-(\d{1,6}))?")


def read_text_any(path, limit=2 * 1024 * 1024):
    """Text of a (reviewer-written) file in UTF-8 / UTF-8-BOM / UTF-16 (PowerShell '>') / ANSI. Never raises on decoding."""
    try:
        with open(path, "rb") as fh:
            data = fh.read(limit)
    except OSError:
        return None
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16", errors="replace")
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return data.decode("cp1252", errors="replace")


def read_llm_review(path):
    """'# Bottom line' / '# Decisions needed' / '# Operation: X' / any other '# Title' sections -> {title: text}.
    Headings inside a section are demoted by one level so they nest under the report's own headings."""
    txt = read_text_any(path)
    if txt is None:
        return None
    secs, cur, fence = [], None, False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            fence = not fence
        if not fence and re.match(r"^#\s+\S", line):
            cur = [line[1:].strip(), []]
            secs.append(cur)
            continue
        if cur is None:
            cur = ["Notes", []]
            secs.append(cur)
        if not fence and re.match(r"^#{2,5}\s", line):
            line = "#" + line
        cur[1].append(line)
    return [(t, "\n".join(b).strip()) for t, b in secs if "\n".join(b).strip()]


def read_op_review(path, op_name):
    """review/<Operation>.md -> markdown for the operation chapter (headings nested below the chapter heading)."""
    txt = read_text_any(path)
    if txt is None:
        return None
    out, fence, first = [], False, True
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            fence = not fence
        hm = None if fence else re.match(r"^(#{1,6})\s+(.*)$", line)
        if hm:
            title = hm.group(2).strip()
            if first and len(hm.group(1)) == 1 and norm(re.sub(r"(?i)^operation\s*:?\s*", "", title).strip("`* ")) == norm(op_name):
                first = False
                continue            # "# Operation: X" / "# X" repeats the chapter title
            line = "#" * min(6, max(3, len(hm.group(1)) + 1)) + " " + title
        if line.strip():
            first = False
        out.append(line)
    return "\n".join(out).strip()


def linkify(text, ctx):
    """old:path/File.cs:123 -> link (also new:, repo1:, repo2:)."""
    files = ctx.setdefault("_files", {})
    for key in ("1", "2"):
        if key not in files and ctx.get("pack" + key):
            files[key] = {f["path"]: len(f["raw"]) for f in ctx["pack" + key].repo.files}

    def rep(m):
        side, p, a, b = m.group(1), m.group(2).replace("\\", "/").lstrip("./"), int(m.group(3)), m.group(4)
        key = "1" if side in ("old", "repo1") else "2"
        links = ctx.get("links" + key)
        n = (files.get(key) or {}).get(p)
        if not links or ".." in p.split("/") or n is None or a < 1 or a > n:
            return "`%s` _(unverified reference)_" % m.group(0)
        return links.md(p, a, int(b) if b and int(b) <= n else None, "%s %s:%d" % ("old" if key == "1" else "new", os.path.basename(p), a))
    out, fence = [], False
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            fence = not fence
        out.append(line if fence else LLM_REF_RE.sub(rep, line))
    return "\n".join(out)


SUGG_SEC_RE = re.compile(r"(?ims)^#{1,4}\s*suggested changes[^\n]*\n(.*?)(?=^#{1,4}\s|\Z)")
RISK_ORDER = {"HIGH": 0, "MEDIUM": 1, "MED": 1, "LOW": 2}


def suggested_changes_table(results, op_secs):
    """All reviewers' 'Suggested changes in repo2' tables in one list near the top of the report (highest risk first).
    Warns (W-REPORT) when a reviewer verdict says something is missing or different but no change is suggested."""
    rows, missing = [], []
    for r in results:
        txt = op_secs.get(norm(r["operation"])) or ""
        if not txt:
            continue
        vm = re.search(r"(?i)verdict\s*\*{0,2}\s*:\s*\*{0,2}\s*(FULL|PARTIAL|NOT_IMPLEMENTED|NOT IMPLEMENTED|MOSTLY_MISSING)", txt)
        sec = SUGG_SEC_RE.search(txt)
        if not sec:
            if vm and vm.group(1).upper() != "FULL":
                missing.append(r["operation"])
            continue
        for ln in sec.group(1).splitlines():
            ln = ln.strip()
            if not ln.startswith("|") or re.match(r"^\|[\s:|-]+\|?$", ln):
                continue
            cells = [c.strip() for c in re.split(r"(?<!\\)\|", ln.strip("|"))]
            if not cells or cells[0] in ("#", "") or re.match(r"(?i)^change", cells[0]):
                continue                    # header row
            risk = next((c.upper() for c in cells if c.upper() in RISK_ORDER), "")
            rows.append((RISK_ORDER.get(risk, 3), len(rows), r["operation"], cells))
    if missing:
        warn("report: review of %s is not FULL but has no 'Suggested changes in repo2' section - run /soap-parity for "
             "it again" % ", ".join(missing[:5]))
    if not rows:
        return []
    width = max(len(c) for _, _, _, c in rows)
    L = ["## Suggested changes (all operations)", "",
         "_Proposed by the AI reviewer from the code it read; details, code sketches and checks are in each operation's chapter._", "",
         "| Operation | " + " | ".join((["#", "Change", "Where (new)", "Risk", "Effort", "Type"] + [""] * width)[:width]) + " |",
         "|---" * (width + 1) + "|"]
    for _, _, op, cells in sorted(rows):
        L.append("| [%s](#%s) | %s |" % (op, _anchor(op), " | ".join(cells + [""] * (width - len(cells)))))
    L.append("")
    return L


def write_report(path, results, ctx, llm, args):
    """<folder>/parity_report.md - the ONE document for the human: decisions first, then per operation the review,
    call flows (with the LLM's method notes), external calls and DB objects, then the DB appendix."""
    title = os.path.basename(str(args.svc or args.wsdl or "service")).split("?")[0]
    L = _header("SOAP parity report: %s" % title, ctx)
    llm = llm or {"overall": None, "ops": {}}
    secs = llm.get("overall") or []
    by_title = {}
    op_secs = {k: linkify(v, ctx) for k, v in (llm.get("ops") or {}).items()}
    known = {norm(r["operation"]) for r in results}
    orphans = list(llm.get("orphans") or [])
    for t, b in secs:
        m = re.match(r"(?i)^operation\s*:?\s*(.+)$", t)
        if m and norm(m.group(1).strip("`* ")) in known and norm(m.group(1).strip("`* ")) not in op_secs:
            op_secs[norm(m.group(1).strip("`* "))] = linkify(b, ctx)
        elif m:
            orphans.append((t, linkify(b, ctx)))
        elif t in by_title:
            by_title[t] += "\n\n" + linkify(b, ctx)
        else:
            by_title[t] = linkify(b, ctx)
    if orphans:
        warn("report: %d reviewer section(s) match no operation of this service - shown under 'Other reviewer notes'" % len(orphans))
        by_title["Other reviewer notes (not matched to an operation)"] = "\n\n".join("**%s**\n\n%s" % (md_cell(t), b) for t, b in orphans)
    if not secs and not op_secs:
        L += ["> **The reviewer's part is missing.** This report has only the tool's facts. In Copilot, run `/soap-parity` "
              "(it writes the files in `review/` and builds this report again).", ""]
    first = [t for t in by_title if re.match(r"(?i)^(bottom line|summary|decisions?)", t)]
    last = [t for t in by_title if re.match(r"(?i)^(glossary|not verified|limitations)", t)]
    mid = [t for t in by_title if t not in first and t not in last]
    for t in sorted(first, key=lambda x: 0 if re.match(r"(?i)^(bottom|summary)", x) else 1):
        L += ["## %s" % t, "", by_title[t], ""]
    L += suggested_changes_table(results, op_secs)
    L += ["## Overview", "",
          "| Operation | Reviewer verdict | Tool verdict | New endpoint | DB objects only in old | External calls old / new |",
          "|---|---|---|---|---|---|"]
    for r in results:
        o = ctx["graph"].get(r["operation"], {})
        rv = op_secs.get(norm(r["operation"]), "")
        vm = re.search(r"(?m)^\s*[>*_\s]*(?i:verdict)\s*\*{0,2}\s*:\s*\*{0,2}\s*(FULL|PARTIAL|NOT_IMPLEMENTED|MOSTLY_MISSING|"
                       r"UNVERIFIED|NOT IMPLEMENTED)\b(\s*\([^)]*\))?", rv)
        c2 = (r.get("repo2Candidates") or [None])[0]
        ep = ("%s %s" % (c2.get("verb") or "", c2.get("route") or c2.get("method") or "")).strip() if (c2 and o.get("has2")) else "not found"
        only1 = sum(1 for x in r.get("dbObjects", []) if x["status"] == "ONLY_REPO1")
        L.append("| [%s](#%s) | %s | %s | %s | %d | %d / %s |" % (
            r["operation"], _anchor(r["operation"]), (vm.group(1) + (vm.group(2) or "")) if vm else ("_see review_" if rv else "_not reviewed_"), r["verdict"],
            md_code(ep, 60, True) if ep != "not found" else "_not found_", only1,
            o.get("out1", 0), o.get("out2", 0) if o.get("has2") else "-"))
    L.append("")
    for t in mid:
        L += ["## %s" % t, "", by_title[t], ""]
    L += ["", HOW_TO_READ, ""]
    for r in results:
        L += op_chapter(r, ctx, op_secs.get(norm(r["operation"])), 2)
    agg = all_db_objects(results)
    if agg:
        L += ["\n---\n\n## Appendix: all database objects\n",
              "| Object | Type | Operation(s) | Old (repo1) | New (repo2) | SQL definition |", "|---|---|---|---|---|---|"]
        for k in sorted(agg):
            a = agg[k]
            L.append("| **%s** | %s | %s | %s | %s | %s |" % (md_cell(k), a["kind"], md_cell(", ".join(sorted(set(a["ops"]))), 200),
                                                         md_cell(", ".join(sorted(a["r1"])) or "-"), md_cell(", ".join(sorted(a["r2"])) or "-"),
                                                         "seen" if a["def"] else "**missing** (logic not reviewed)"))
        miss = sum(1 for a in agg.values() if not a["def"])
        if miss:
            L.append("\n_%d object(s) have no SQL definition yet: run `export_db_schema.sql` (see db_objects.md) and re-run with "
                     "`--db-scripts`._" % miss)
    for t in last:
        L += ["", "## %s" % t, "", by_title[t]]
    L += ["", "## About this report", "",
          "- The tool (soap_parity.py) reads the code statically: call flows, contract fields, DB access, external calls and "
          "constants. It does not run the services, so runtime values, configuration per environment and data in the "
          "database are not seen.",
          "- Method descriptions marked _Code:_ come from the code itself; plain sentences before them were written by the AI "
          "reviewer from the method's code. The reviewer's verdicts and decisions are in the sections above.",
          "- Links point to %s." % "; ".join(x for x in (
              ("old code: " + ctx["links1"].describe()) if ctx.get("links1") else "",
              ("new code: " + ctx["links2"].describe()) if ctx.get("links2") else "") if x)]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


DB_STATUS_TEXT = {"BOTH": "yes, both use it", "ONLY_REPO1": "**only old**", "ONLY_REPO2": "only new",
                  "BOTH_DIFFERENT_USE": "**both, used differently**"}


def all_db_objects(results):
    """{object: {'kind','ops','r1','r2','def'}} across operations."""
    agg = {}
    for r in results:
        for x in r.get("dbObjects", []):
            a = agg.setdefault(x["object"], {"kind": x["kind"], "ops": [], "r1": set(), "r2": set(), "def": x["definition"],
                                             "r1At": [], "r2At": [], "st": []})
            a["ops"].append(r["operation"])
            a["st"].append((r["operation"], x["status"]))
            if x["repo1"] != "-":
                a["r1"].add(x["repo1"])
                a["r1At"] += [y for y in x.get("repo1At", []) if y not in a["r1At"]]
            if x["repo2"] != "-":
                a["r2"].add(x["repo2"])
                a["r2At"] += [y for y in x.get("repo2At", []) if y not in a["r2At"]]
            a["def"] = a["def"] or x["definition"]
    return agg


def _ref_link(links, ref):
    if not links or ":" not in ref:
        return md_code(ref, None, True)
    p, ln = ref.rsplit(":", 1)
    try:
        return links.md(p, int(ln))
    except ValueError:
        return md_code(ref, None, True)


def write_db_objects(path, results, ctx, export_name, export_count, db_dir="db_schema"):
    agg = all_db_objects(results)
    L = ["# Database objects on the call paths", "",
         "_Generated by soap_parity.py %s on %s._" % (VERSION, time.strftime("%Y-%m-%d %H:%M")), "",
         "Old = repo1 (legacy SOAP), New = repo2. **read / write / exec** = how the code uses it; `via X` = used inside "
         "stored procedure X (needs the SQL definitions). SQL definition **missing** means the tool has not seen the "
         "CREATE script yet.", ""]
    if not agg:
        L.append("_No database access was detected on any call path._")
    else:
        L.append("| Object | Type | Used by operation(s) | Old (repo1) | New (repo2) | Same? | SQL definition |")
        L.append("|---|---|---|---|---|---|---|")
        order = {"ONLY_REPO1": 0, "BOTH_DIFFERENT_USE": 1, "ONLY_REPO2": 2, "BOTH": 3}
        rows = []
        for k, a in agg.items():
            sts = {s_ for _, s_ in a["st"]}
            worst = min(sts, key=lambda x: order.get(x, 9))
            if len(sts) == 1:
                st = DB_STATUS_TEXT.get(worst, worst)
            else:                       # per operation - the same object can be "only old" in one and "both" in another
                st = "; ".join("%s: %s" % (op_, DB_STATUS_TEXT.get(s_, s_)) for op_, s_ in a["st"])
            rows.append((order.get(worst, 9), k, a, st))
        for _, k, a, st in sorted(rows, key=lambda x: (x[0], x[1])):
            r1 = ", ".join(sorted(a["r1"])) or "-"
            r2 = ", ".join(sorted(a["r2"])) or "-"
            at1 = " ".join(_ref_link(ctx.get("links1"), x) for x in a["r1At"][:2])
            at2 = " ".join(_ref_link(ctx.get("links2"), x) for x in a["r2At"][:2])
            L.append("| **%s** | %s | %s | %s %s | %s %s | %s | %s |" % (
                md_cell(k), a["kind"], md_cell(", ".join(sorted(set(a["ops"]))), 200), md_cell(r1), at1, md_cell(r2), at2,
                md_cell(st, 300), md_cell(a["def"]) if a["def"] else "**missing**"))
    L += ["", "## Get the SQL definitions (no tool needs database access)", ""]
    if export_count:
        L += ["`%s` lists the %d object(s) above. It only **reads** the database catalog (SELECT on sys.* views and "
              "OBJECT_DEFINITION); it creates, changes and deletes nothing. It also pulls the objects these depend on "
              "(procs called by procs, tables they use, triggers) up to 3 levels deep." % (export_name, export_count), "",
              "1. Open `%s` in SSMS (or Azure Data Studio), connect to the database the application uses, run it (F5)." % export_name,
              "2. Keep the default **Results to Grid**. Click any cell of the result, press **Ctrl+A**, then **Ctrl+C**.",
              "3. Paste into Notepad and save as UTF-8 in **`%s`** as `<database>.sql` (do not use *Results to Text*: it cuts "
              "long lines)." % db_dir,
              "4. The last line must read `-- END OF EXPORT`. If it does not, the copy was cut - copy again.",
              "5. If repo1 and repo2 use **different databases**, run the script on each and save one file per database in the same folder.",
              "6. Step 2: run `/soap-parity` with the same inputs - the files in that folder are read automatically.", "",
              "Alternative: `sqlcmd -S <server> -d <database> -E -i %s -o %s\\<database>.sql -y 0 -f 65001` "
              "(Windows auth; for a SQL login set the env var `SQLCMDPASSWORD` and use `-U <login>` instead of `-E`; "
              "create the folder first)." % (export_name, db_dir),
              "", "Rows starting with `-- NOT FOUND` / `-- NO ACCESS` name objects that are in another database, do not exist, "
              "or are encrypted / need VIEW DEFINITION permission."]
    else:
        L.append("_Nothing to export._")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    return agg


SQL_NAME_OK_RE = re.compile(r"^[\w$#@ \-]+(\.[\w$#@ \-]+){0,2}$")


def write_db_export_sql(path, names):
    """Read-only T-SQL that returns CREATE scripts (one result row per line) for the given objects, their dependencies
    (3 levels) and triggers on the tables. SQL Server 2008+; no temp tables, no dynamic SQL, no writes."""
    vals, skipped = [], []
    for i, n in enumerate(names, 1):
        n = n.strip()
        if not n or not SQL_NAME_OK_RE.match(n):
            skipped.append(n)
            continue
        parts = n.split(".")
        if len(parts) == 3:
            skipped.append(n + " (other database)")
            continue
        sch, obj = (parts[0], parts[1]) if len(parts) == 2 else (None, parts[0])
        q = lambda s: s.replace("'", "''")
        vals.append("(%d, %s, CAST(N'%s' AS nvarchar(128)))" % (i, ("CAST(N'%s' AS nvarchar(128))" % q(sch)) if sch else "CAST(NULL AS nvarchar(128))", q(obj)))
    if not vals:
        return 0
    S = []
    S.append("-- soap_parity %s: export of DB objects used on the SOAP call paths (generated %s)." % (VERSION, time.strftime("%Y-%m-%d %H:%M")))
    S.append("-- READ-ONLY: only SELECTs on catalog views (sys.objects, sys.columns, sys.sql_modules, sys.triggers,")
    S.append("-- sys.sql_expression_dependencies, ...). No temp tables, no dynamic SQL, nothing is created or changed.")
    S.append("-- Run with Results to Grid, click a cell, Ctrl+A, Ctrl+C, paste into a .sql file (see db_objects.md).")
    for s in skipped[:50]:
        S.append("-- skipped (not exportable from this database): %s" % re.sub(r"[\r\n]+", " ", s)[:120])
    S.append("SET NOCOUNT ON; SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON;   -- this session only")
    S.append(";WITH req (ord, sch, nm) AS (")
    S.append("    SELECT ord, CAST(sch AS nvarchar(128)), CAST(nm AS nvarchar(128)) FROM (VALUES")
    S.append("        " + ",\n        ".join(vals))
    S.append("    ) AS v (ord, sch, nm)")
    S.append("),")
    S.append("""found AS (       -- case-insensitive name match (also on case-sensitive databases)
    SELECT r.ord, o.object_id
    FROM req r
    JOIN sys.objects o ON UPPER(o.name COLLATE DATABASE_DEFAULT) = UPPER(r.nm COLLATE DATABASE_DEFAULT)
    WHERE (r.sch IS NULL OR UPPER(SCHEMA_NAME(o.schema_id) COLLATE DATABASE_DEFAULT) = UPPER(r.sch COLLATE DATABASE_DEFAULT))
      AND o.type IN ('P','PC','V','FN','IF','TF','FS','FT','TR','U','SN')
      AND o.is_ms_shipped = 0
),
deps AS (        -- objects the found objects use (procs, functions, views, tables), up to 3 levels
    SELECT f.ord, f.object_id, 0 AS lvl FROM found f
    UNION ALL
    SELECT d.ord, sed.referenced_id, d.lvl + 1
    FROM deps d
    JOIN sys.sql_expression_dependencies sed ON sed.referencing_id = d.object_id
    WHERE d.lvl < 3 AND sed.referenced_id IS NOT NULL AND sed.referenced_database_name IS NULL
),
alls AS (
    SELECT MIN(ord) AS ord, object_id FROM (
        SELECT ord, object_id FROM deps
        UNION ALL
        SELECT d.ord, t.object_id FROM deps d JOIN sys.triggers t ON t.parent_id = d.object_id
    ) x GROUP BY object_id
),
objs AS (
    SELECT a.ord, o.object_id, o.type,
           CAST(o.type_desc AS nvarchar(120)) COLLATE DATABASE_DEFAULT AS type_desc,
           CAST(QUOTENAME(SCHEMA_NAME(o.schema_id)) + N'.' + QUOTENAME(o.name) AS nvarchar(600)) COLLATE DATABASE_DEFAULT AS full_name,
           ROW_NUMBER() OVER (ORDER BY a.ord, CASE WHEN o.type = 'U' THEN 0 WHEN o.type = 'TR' THEN 2 ELSE 1 END, o.name, o.object_id) AS seq
    FROM alls a JOIN sys.objects o ON o.object_id = a.object_id
    WHERE o.is_ms_shipped = 0 AND o.type IN ('P','PC','V','FN','IF','TF','FS','FT','TR','U','SN')
),
mods AS (
    SELECT b.seq, b.def + NCHAR(10) AS def, DATALENGTH(b.def + NCHAR(10)) / 2 AS dl
    FROM (SELECT o.seq, CAST(OBJECT_DEFINITION(o.object_id) AS nvarchar(max)) COLLATE DATABASE_DEFAULT AS def
          FROM objs o WHERE o.type NOT IN ('U','SN')) b
    WHERE b.def IS NOT NULL
),
split AS (       -- one row per line of each definition
    SELECT m.seq, 1 AS n, CAST(1 AS bigint) AS s, CAST(CHARINDEX(NCHAR(10), m.def) AS bigint) AS e FROM mods m
    UNION ALL
    SELECT sp.seq, sp.n + 1, sp.e + 1, CAST(CHARINDEX(NCHAR(10), m.def, sp.e + 1) AS bigint)
    FROM split sp JOIN mods m ON m.seq = sp.seq
    WHERE sp.e > 0 AND sp.e < m.dl
),
cols AS (
    SELECT o.seq, c.column_id,
           CAST(CASE WHEN c.column_id = MIN(c.column_id) OVER (PARTITION BY o.object_id) THEN N'    ' ELSE N'  , ' END
           + QUOTENAME(c.name COLLATE DATABASE_DEFAULT) + N' '
           + CASE WHEN c.is_computed = 1 THEN N'AS ' + ISNULL(cc.definition COLLATE DATABASE_DEFAULT, N'?')
                  ELSE TYPE_NAME(c.user_type_id) COLLATE DATABASE_DEFAULT
                     + CASE WHEN TYPE_NAME(c.user_type_id) IN ('varchar','char','varbinary','binary')
                                 THEN N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length AS nvarchar(10)) END + N')'
                            WHEN TYPE_NAME(c.user_type_id) IN ('nvarchar','nchar')
                                 THEN N'(' + CASE WHEN c.max_length = -1 THEN N'max' ELSE CAST(c.max_length / 2 AS nvarchar(10)) END + N')'
                            WHEN TYPE_NAME(c.user_type_id) IN ('decimal','numeric')
                                 THEN N'(' + CAST(c.precision AS nvarchar(5)) + N',' + CAST(c.scale AS nvarchar(5)) + N')'
                            WHEN TYPE_NAME(c.user_type_id) IN ('datetime2','time','datetimeoffset')
                                 THEN N'(' + CAST(c.scale AS nvarchar(5)) + N')'
                            ELSE N'' END
                     + CASE WHEN c.is_identity = 1 THEN N' IDENTITY' ELSE N'' END
                     + CASE WHEN c.is_nullable = 1 THEN N' NULL' ELSE N' NOT NULL' END
                     + ISNULL(N' DEFAULT ' + dc.definition COLLATE DATABASE_DEFAULT, N'')
             END AS nvarchar(max)) COLLATE DATABASE_DEFAULT AS txt
    FROM objs o
    JOIN sys.columns c ON c.object_id = o.object_id
    LEFT JOIN sys.computed_columns cc ON cc.object_id = c.object_id AND cc.column_id = c.column_id
    LEFT JOIN sys.default_constraints dc ON dc.object_id = c.default_object_id
    WHERE o.type = 'U'
),
pks AS (
    SELECT o.seq, CAST(N'  , CONSTRAINT ' + QUOTENAME(k.name COLLATE DATABASE_DEFAULT) + N' PRIMARY KEY ('
           + STUFF((SELECT N', ' + QUOTENAME(c.name COLLATE DATABASE_DEFAULT)
                    FROM sys.index_columns ic JOIN sys.columns c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
                    WHERE ic.object_id = k.parent_object_id AND ic.index_id = k.unique_index_id
                    ORDER BY ic.key_ordinal FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'') + N')'
           AS nvarchar(max)) COLLATE DATABASE_DEFAULT AS txt
    FROM objs o JOIN sys.key_constraints k ON k.parent_object_id = o.object_id AND k.type = 'PK'
    WHERE o.type = 'U'
),
fks AS (
    SELECT o.seq, ROW_NUMBER() OVER (PARTITION BY o.seq ORDER BY fk.name) AS n,
           CAST(N'-- FK ' + fk.name COLLATE DATABASE_DEFAULT + N': ' + OBJECT_NAME(fk.parent_object_id) COLLATE DATABASE_DEFAULT
           + N' -> ' + QUOTENAME(OBJECT_SCHEMA_NAME(fk.referenced_object_id) COLLATE DATABASE_DEFAULT) + N'.'
           + QUOTENAME(OBJECT_NAME(fk.referenced_object_id) COLLATE DATABASE_DEFAULT) AS nvarchar(max)) COLLATE DATABASE_DEFAULT AS txt
    FROM objs o JOIN sys.foreign_keys fk ON fk.parent_object_id = o.object_id
    WHERE o.type = 'U'
),
outp AS (
    SELECT o.seq, 0 AS part, 0 AS n, CAST(N'-- ==== ' + o.full_name + N' (' + o.type_desc + N')' AS nvarchar(max)) COLLATE DATABASE_DEFAULT AS line
    FROM objs o
    UNION ALL SELECT o.seq, 1, 0, CAST(N'CREATE TABLE ' + o.full_name + N' (' AS nvarchar(max)) COLLATE DATABASE_DEFAULT FROM objs o WHERE o.type = 'U'
    UNION ALL SELECT c.seq, 2, c.column_id, c.txt FROM cols c
    UNION ALL SELECT p.seq, 3, 0, p.txt FROM pks p
    UNION ALL SELECT o.seq, 4, 0, CAST(N')' AS nvarchar(max)) COLLATE DATABASE_DEFAULT FROM objs o WHERE o.type = 'U'
    UNION ALL SELECT f.seq, 5, f.n, f.txt FROM fks f
    UNION ALL SELECT sp.seq, 6, sp.n,
                     REPLACE(SUBSTRING(m.def, sp.s, CASE WHEN sp.e > 0 THEN sp.e - sp.s ELSE m.dl - sp.s + 1 END), NCHAR(13), N'')
              FROM split sp JOIN mods m ON m.seq = sp.seq
    UNION ALL SELECT o.seq, 6, 0, CAST(N'-- synonym for ' + s.base_object_name COLLATE DATABASE_DEFAULT AS nvarchar(max)) COLLATE DATABASE_DEFAULT
              FROM objs o JOIN sys.synonyms s ON s.object_id = o.object_id
    UNION ALL SELECT o.seq, 7, 0, CAST(N'-- NO ACCESS: ' + o.full_name + N' definition is encrypted or needs VIEW DEFINITION permission'
                                       AS nvarchar(max)) COLLATE DATABASE_DEFAULT
              FROM objs o WHERE o.type NOT IN ('U','SN') AND OBJECT_DEFINITION(o.object_id) IS NULL
    UNION ALL SELECT o.seq, 8, 0, CAST(N'GO' AS nvarchar(max)) COLLATE DATABASE_DEFAULT FROM objs o
    UNION ALL SELECT 1000000 + r.ord, 0, 0, CAST(N'-- NOT FOUND in ' + DB_NAME() COLLATE DATABASE_DEFAULT + N': '
                                                + ISNULL(r.sch + N'.', N'') + r.nm AS nvarchar(max)) COLLATE DATABASE_DEFAULT
              FROM req r WHERE NOT EXISTS (SELECT 1 FROM found f WHERE f.ord = r.ord)
    UNION ALL SELECT 2000000, 0, 0, CAST(N'-- END OF EXPORT (' + DB_NAME() COLLATE DATABASE_DEFAULT + N', '
                                         + CAST((SELECT COUNT(*) FROM objs) AS nvarchar(10)) + N' objects)' AS nvarchar(max)) COLLATE DATABASE_DEFAULT
)
SELECT line AS [-- soap_parity export]
FROM outp
ORDER BY seq, part, n
OPTION (MAXRECURSION 0);""")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(S) + "\n")
    return len(vals)


def load_method_notes(path):
    """review/<Op>.notes.json written by the LLM: {"old:Class.Method": "...", "new:Class.Method": "..."}."""
    txt = read_text_any(path)
    if txt is None:
        return {}
    try:
        raw = json.loads(txt)
    except ValueError as e:
        warn("report: %s is not valid JSON (%s) - method notes ignored" % (os.path.basename(path), e))
        return {}
    if not isinstance(raw, dict):
        warn("report: %s must be a JSON object {\"old:Class.Method\": \"text\"} - ignored" % os.path.basename(path))
        return {}
    out = {}
    for k, v in raw.items():
        if isinstance(v, (list, tuple)):
            v = " ".join(x for x in v if isinstance(x, str))
        if not isinstance(v, str) or not v.strip():
            continue                    # null / numbers / objects are not descriptions
        k = str(k).strip()
        if not re.match(r"^(old|new):", k):
            continue
        out[k] = re.sub(r"\s+", " ", str(v)).strip()[:400]
    return out


def build_review_pack(args, results, repo1, repo2, notes=None, write_docs=True):
    """Builds the per-operation call graphs (ctx). write_docs: also writes call_graph.md, db_objects.md and
    export_db_schema.sql. Never raises (a doc problem must not fail the run)."""
    ctx = {"graph": {}}
    notes = notes or {}
    if repo1:
        ctx["links1"] = CodeLinks(repo1.root, args.out, args.repo1_url, args.repo1_ref, "repo1")
        ctx["pack1"] = ReviewPack(repo1, ctx["links1"], "old", args.graph_nodes, args.graph_depth, notes)
    ctx["links2"] = CodeLinks(repo2.root, args.out, args.repo2_url, args.repo2_ref, "repo2")
    ctx["pack2"] = ReviewPack(repo2, ctx["links2"], "new", args.graph_nodes, args.graph_depth, notes)
    LOG.info["links"] = "r1 %s | r2 %s" % (ctx["links1"].describe() if repo1 else "-", ctx["links2"].describe())
    no_desc = []
    for r in results:
        op_, s1, s2 = SLICES.get(r["operation"], (None, None, None))
        o = ctx["graph"][r["operation"]] = {"has2": bool(s2)}
        for key, sl, pack in (("1", s1, ctx.get("pack1")), ("2", s2, ctx.get("pack2"))):
            if not sl or not pack:
                continue
            try:
                entries = [k for k in sl.entries if k in sl.node]
                o["entry" + key] = sl.node[entries[0]] if entries else None
                o["tree" + key], st = pack.tree(sl, entries)
                o["m" + key] = len(sl.visited)
                o["outRows" + key] = pack.outbound_rows(sl)
                o["out" + key] = len(o["outRows" + key])
                o["db" + key] = sum(1 for x in r.get("dbObjects", []) if x["repo" + key] != "-" and " via " not in x["repo" + key])
                o["unres" + key] = list(sl.unresolved)
                for k in list(sl.visited):
                    f, m = sl.node[k]
                    if not pack.facts(f, m) and not sl.edges.get(k) and \
                            sum(1 for x in f["clean"][m["decl"]:m["end"] + 1] if x.strip()) > 6 and len(no_desc) < 200:
                        no_desc.append((key, pack.qname(f, m), f["path"], m["decl"] + 1, m["end"] + 1))
            except Exception as e:  # noqa
                LOG.write("call graph %s repo%s failed: %s\n%s" % (r["operation"], key, e, traceback.format_exc()))
                warn("link: call graph for %s (repo%s) failed: %s" % (r["operation"], key, e))
                o["tree" + key] = ["_call graph failed: %s (see run.log)_" % md_cell(e, 120)]
    out = {"ctx": ctx, "noDesc": no_desc}
    if not write_docs:
        return out
    try:
        write_call_graph(os.path.join(args.out, "call_graph.md"), results, ctx)
        out["callGraph"] = "call_graph.md"
    except Exception as e:  # noqa
        LOG.write("call_graph.md failed: %s\n%s" % (e, traceback.format_exc()))
        warn("link: call_graph.md could not be written: %s" % e)
    names = sorted(all_db_objects(results))
    exp = os.path.join(args.out, "export_db_schema.sql")
    try:
        n = write_db_export_sql(exp, names) if names else 0
        if not n and os.path.isfile(exp):
            os.remove(exp)                      # stale export from an earlier run would list the wrong objects
        write_db_objects(os.path.join(args.out, "db_objects.md"), results, ctx, os.path.join(args.out, "export_db_schema.sql"), n,
                         os.path.join(args.out, "db_schema"))
        out["dbExport"] = n
    except Exception as e:  # noqa
        LOG.write("db_objects.md failed: %s\n%s" % (e, traceback.format_exc()))
        warn("db: db_objects.md / export_db_schema.sql could not be written: %s" % e)
    return out


def analyze_operation(op, repo1, repo2, names, eps2, args):
    res = {"operation": op["name"], "soapAction": op.get("soapAction"), "address": op.get("address"),
           "requestFields": len(op["request"]), "responseFields": len(op["response"]), "review": []}
    # ---- repo1 slice
    s1 = None
    if repo1:
        entries = find_repo1_entries(repo1, op, names)
        res["repo1Entry"] = ["%s:%d %s" % (f["path"], m["decl"] + 1, m["name"]) for f, m in entries]
        if entries:
            s1 = Slice(repo1, entries, args.max_depth)
            res["repo1SliceFiles"] = s1.files()
            res["repo1SliceStats"] = s1.stats()
            res["repo1SliceVia"] = {repo1.files[i]["path"]: v for i, v in s1.via.items()}
        else:
            res["review"].append("repo1 entry method for %s not found - search manually" % op["wsdlName"])
    # ---- response fields repo1 never fills: excluded from ranking and from the gap count, shown separately
    unset = unset_response_paths(s1, repo1, op) if s1 else set()
    op_full = op
    if unset:
        op = dict(op, response=[f for f in op["response"] if f["path"] not in unset])
        res["repo1UnsetResponseFields"] = sorted(unset)
    # ---- repo2 candidate
    forced = None
    spec = repo2_entry_for(args, op_full)
    if spec:
        forced = forced_repo2_eps(spec, eps2, repo2)
        if not forced:
            sugg = pin_suggestions(spec, eps2)
            res["repo2PinFailed"] = {"pin": spec, "closest": sugg}
            warn("entry: repo2 pin %s (--repo2-entry / repo2_map.json) matched no method in repo2 (op %s); closest: %s - "
                 "write the value as path/File.cs:line" % (spec, op_full["name"], "; ".join(sugg) or "none"))
    ranked = rank_repo2(op, forced or eps2, repo2, names)
    res["repo2Forced"] = bool(forced)
    res["repo2Candidates"] = [{"score": r["score"], "at": "%s:%d" % (r["ep"]["file"], r["ep"]["line"]),
                               "method": r["ep"]["method"], "route": r["ep"]["route"], "verb": r["ep"]["verb"],
                               "requestClass": r["req_cls"]["name"] if r["req_cls"] else None,
                               "responseClass": r["res_cls"]["name"] if r["res_cls"] else None} for r in ranked[:3] if r["score"] > 0 or forced]
    best = ranked[0] if ranked and (forced or ranked[0]["score"] >= args.min_score) else None
    s2 = None
    if best:
        s2 = Slice(repo2, [(best["ep"]["f"], best["ep"]["m"])], args.max_depth)
        res["repo2SliceStats"] = s2.stats()
        res["repo2SliceFiles"] = s2.files()
    # ---- contract
    contract = {}
    for label, cls, flds in (("request", best and best["req_cls"], op["request"]),
                             ("response", best and best["res_cls"], op["response"])):
        if not flds:
            continue
        cm = ContractMatcher(flds, repo2, names)
        chain = root_chain(flds)
        note = ""
        ep_inputs = endpoint_inputs(best["ep"], repo2) if (best and label == "request") else []
        if not cls and not ep_inputs:
            pool = []
            for rp in chain:
                bc = cm.best_class(rp, top=1)
                if bc:
                    pool.append((bc[0][0], bc[0][1], rp))
            pool.sort(key=lambda x: -x[0])
            if pool and pool[0][0] >= 0.5:
                cls = pool[0][1]
                note = "no endpoint signature match; best DTO by field overlap (%.0f%%)" % (pool[0][0] * 100)
        root_path = chain[-1]
        if cls:
            root_path = max(chain, key=lambda rp: (cm.class_score(rp, cls)[0], chain.index(rp)))
            rows = cm.compare(root_path, cls)
        else:
            rows = [{"path": f["path"], "xsdType": f["type"], "min": f["min"], "max": f["max"], "restr": f.get("restr", {}),
                     "status": "MISSING", "repoField": None} for f in flds if f["path"].startswith(root_path + "/")]
        if ep_inputs:
            rows = match_request_inputs(rows, flds, root_path, best["ep"], repo2, names)
            srcs = sorted({x["source"] for x in ep_inputs})
            note = (note + "; " if note else "") + "REST inputs of %s: %s" % (best["ep"]["method"], ", ".join(
                "%s (%s)" % (x["name"], x["source"]) for x in ep_inputs[:12]))
            for r_ in rows:
                if r_["status"] == "MISSING" and r_["path"].count("/") == root_path.count("/") + 1:
                    r_["notes"] = ((r_.get("notes") or "") + "; " if r_.get("notes") else "") + \
                        "not a %s input of the new endpoint - may come from the login token/configuration, or is dropped" % "/".join(srcs)
        if root_path != chain[0]:
            note = (note + "; " if note else "") + "compared below SOAP wrapper element(s): %s" % root_path
        if label == "response" and unset:
            rows += [{"path": f["path"], "xsdType": f["type"], "min": f["min"], "max": f["max"], "restr": f.get("restr", {}),
                      "status": "NOT_SET_IN_REPO1", "repoField": None} for f in op_full["response"] if f["path"] in unset]
        contract[label] = {"rootClass": cls["name"] if cls else None, "rootFile": cls["file"] if cls else None,
                           "note": note, "rows": rows, "root": root_path}
    res["contract"] = contract
    # ---- integrations
    hits1 = [h for h in repo1.hits if s1 and s1.contains(h)] if repo1 else []
    hits2 = [h for h in repo2.hits if s2 and s2.contains(h)]
    k1 = integration_keys(hits1, repo1) if repo1 else {}
    if s1:
        for k, v in entity_keys(s1, repo1).items():
            k1.setdefault(k, []).extend(v)
    k2 = integration_keys(hits2, repo2)
    if s2:
        for k, v in entity_keys(s2, repo2).items():
            k2.setdefault(k, []).extend(v)
    k2_all = integration_keys(repo2.hits, repo2)

    def path_match(k, pool):
        if k[0] != "path":
            return pool.get(k)
        for kk, v in pool.items():
            if kk[0] == "path" and (kk[1] == k[1] or kk[1].startswith(k[1] + "/") or k[1].startswith(kk[1] + "/")) and min(len(kk[1]), len(k[1])) > 3:
                return v
        return None

    integ = []
    for k, hs in sorted(k1.items()):
        m2 = path_match(k, k2)
        st = "MATCH" if m2 else None
        if not m2:
            m2 = path_match(k, k2_all)
            st = "FOUND_ELSEWHERE" if m2 else "MISSING"
        integ.append({"kind": k[0], "key": k[1], "status": st,
                      "repo1": sorted({"%s:%s" % (h["file"], h["line"]) for h in hs})[:4],
                      "repo2": sorted({"%s:%s" % (h["file"], h["line"]) for h in (m2 or [])})[:4]})
    for k, hs in sorted(k2.items()):
        if not path_match(k, k1):
            integ.append({"kind": k[0], "key": k[1], "status": "EXTRA_IN_REPO2", "repo1": [],
                          "repo2": sorted({"%s:%s" % (h["file"], h["line"]) for h in hs})[:4]})
    res["integrations"] = integ
    # ---- DB objects (tables / procs / views / functions / triggers), expanded through SQL definitions when available
    d1, d2 = db_refs(k1), db_refs(k2)
    DBKEYS[op_full["name"]] = (d1, d2)
    res["dbObjects"] = db_inventory(d1, d2)
    SLICES[op_full["name"]] = (op_full, s1, s2)
    # unkeyed integration hits (could not extract table/url) - list for review
    res["repo1Hits"] = [{"cat": h["cat"], "sub": h["sub"], "at": hit_ref(h), "method": h["method"], "text": h["text"]}
                        for h in hits1 if h["cat"] in ("db", "outbound", "messaging", "cache", "validation", "error", "transaction", "security")]
    res["repo2Hits"] = [{"cat": h["cat"], "sub": h["sub"], "at": hit_ref(h), "method": h["method"], "text": h["text"]}
                        for h in hits2 if h["cat"] in ("db", "outbound", "messaging", "cache", "validation", "error", "transaction", "security")]
    # ---- validations
    imp2 = set()
    leaf_names = {norm(f["name"]) for f in op["request"]}
    for h in hits2:
        if h["cat"] == "validation" and h["sub"] == "imperative":
            f = repo2.files[h["fidx"]]
            ctx = " ".join(f["clean"][max(0, h["line"] - 3):h["line"]]).lower()
            for ln in leaf_names:
                if ln and ln in norm(ctx):
                    imp2.add(ln)
    vgaps = []
    by_path = {f["path"]: f for f in op["request"]}
    for row in contract.get("request", {}).get("rows", []):
        sf = by_path.get(row["path"])
        if not sf or sf["complex"] or row["status"].startswith("MISSING") or row["status"] in ("EXTRA_IN_REPO", "UNRESOLVED"):
            continue
        fd = {"type": row.get("repoType", ""), "annotations": row.get("annotations", [])}
        for rule, detail, imp in validation_gaps(sf, fd, repo2, imp2):
            if rule == "required" and row.get("inputSource") == "route":
                continue                    # a URL path segment is always present: the route does not match without it
            vgaps.append({"path": row["path"], "rule": rule, "xsd": detail, "repo2Field": row.get("repoField"),
                          "repo2": "%s:%s" % (row.get("repoFile"), row.get("repoLine")),
                          "status": imp if isinstance(imp, str) else "CHECK_IMPERATIVE" if imp else "GAP"})
    rv1 = []
    for h in hits1:
        if h["cat"] == "validation" and h["sub"] == "imperative":
            f = repo1.files[h["fidx"]]
            ctx = norm(" ".join(f["clean"][max(0, h["line"] - 3):h["line"]]))
            flds = sorted({f2["name"] for f2 in op["request"] if not f2["complex"] and len(norm(f2["name"])) > 2 and norm(f2["name"]) in ctx})
            rv1.append({"at": hit_ref(h), "fields": flds, "text": h["text"],
                        "repo2HasForFields": [x for x in flds if norm(x) in imp2 or any(
                            r.get("repoFieldName") and names.sim(r["repoFieldName"], x) >= 0.8 and r.get("annotations") for r in contract.get("request", {}).get("rows", []))]})
    res["validationGaps"] = vgaps
    res["repo1ImperativeValidations"] = rv1
    # ---- business rule signals
    rules = []

    def lits_of(line, repo):
        out = literal_set([line])
        for ident in re.findall(r"\b([A-Za-z_]\w*)\b", STR_RE.sub("", line)):
            if ident in repo.constants and not CONST_RE.search(line):
                out |= repo.constants[ident]
        return out
    if s1:
        lines2 = []
        if s2:
            for fidx, ls in s2.lines.items():
                lines2 += [repo2.files[fidx]["clean"][i] for i in ls]
        lits2 = set()
        for ln_ in lines2:
            lits2 |= lits_of(ln_, repo2)
        lits2_all = None
        for fidx, ls in sorted(s1.lines.items()):
            f = repo1.files[fidx]
            for i in sorted(ls):
                line = f["clean"][i]
                code_only = STR_RE.sub('""', line)
                uses_const = any(ident in repo1.constants for ident in re.findall(r"\b([A-Za-z_]\w*)\b", code_only))
                if not (RULE_LINE_RE.search(code_only) or re.search(r"\bBigDecimal\s*\(\s*\"", line) or
                        (uses_const and re.search(r"[*/+\-]|\b(Math|Decimal|BigDecimal)\.", code_only))) or LOG_LINE_RE.search(line):
                    continue
                if CONST_RE.search(line) or re.match(r"^\s*(throw|raise|@|\[)", line):
                    continue  # constant declarations are evaluated where they are used
                if re.search(r"==\s*null|!=\s*null|is\s+None|is\s+not\s+None|IsNullOrEmpty|IsNullOrWhiteSpace", line) and not literal_set([line]):
                    continue
                lits = lits_of(line, repo1)
                if not lits:
                    st = "REVIEW"
                    found = []
                else:
                    found = [v for v in lits if v in lits2]
                    if len(found) == len(lits):
                        st = "LITERALS_IN_REPO2_SLICE"
                    else:
                        if lits2_all is None:
                            lits2_all = literal_set([ln for fx in repo2.files for ln in fx["clean"]])
                        found_all = [v for v in lits if v in lits2_all]
                        st = "LITERALS_ELSEWHERE_IN_REPO2" if found_all and len(found_all) == len(lits) else ("PARTIAL" if found or found_all else "NOT_FOUND")
                m = repo1._enclosing_method(f, i)
                rules.append({"at": "%s:%d" % (f["path"], i + 1), "method": m["name"] if m else None,
                              "text": f["raw"][i].strip()[:160], "literals": sorted(v for _, v in lits), "status": st})
    res["businessRules"] = rules[:args.max_rules]
    # ---- auto verdict
    rows_req = [r for r in contract.get("request", {}).get("rows", []) if r["status"] != "EXTRA_IN_REPO"]
    rows_res = [r for r in contract.get("response", {}).get("rows", []) if r["status"] not in ("EXTRA_IN_REPO", "NOT_SET_IN_REPO1")]
    all_rows = rows_req + rows_res

    def pts(r):
        if r["status"] == "MATCH":
            return 1.0 if r.get("typeCheck", "OK") == "OK" else 0.7
        if r["status"] == "FUZZY":
            return 0.7 if r.get("typeCheck", "OK") == "OK" else 0.5
        return 0.0
    c_score = sum(pts(r) for r in all_rows) / len(all_rows) if all_rows else 0
    i_items = [x for x in integ if x["status"] != "EXTRA_IN_REPO2"]
    i_score = (sum(1 if x["status"] == "MATCH" else 0.5 if x["status"] == "FOUND_ELSEWHERE" else 0 for x in i_items) / len(i_items)) if i_items else None
    v_items = len(vgaps)
    r_items = [x for x in rules if x["status"] != "REVIEW"]
    r_score = (sum(1 if x["status"] == "LITERALS_IN_REPO2_SLICE" else 0.5 if x["status"] in ("PARTIAL", "LITERALS_ELSEWHERE_IN_REPO2") else 0 for x in r_items) / len(r_items)) if r_items else None
    parts = [(0.5, c_score)]
    if i_score is not None:
        parts.append((0.3, i_score))
    if r_score is not None:
        parts.append((0.2, r_score))
    total = sum(w * s for w, s in parts) / sum(w for w, _ in parts)
    total -= min(0.1, 0.01 * v_items)
    if not best and c_score < 0.3:
        verdict = "NOT_IMPLEMENTED"
    elif not best:
        verdict = "PARTIAL (DTOs exist, no endpoint found)"
    elif total >= 0.9:
        verdict = "FULL (verify)"
    elif total >= 0.3:
        verdict = "PARTIAL"
    else:
        verdict = "MOSTLY_MISSING"
    res["scores"] = {"contract": round(c_score, 3), "integrations": None if i_score is None else round(i_score, 3),
                     "rules": None if r_score is None else round(r_score, 3), "validationGaps": v_items,
                     "overall": round(max(0, total), 3)}
    res["verdict"] = verdict
    # ---- review queue for the LLM
    q_ = res["review"]
    for r in all_rows:
        if r["status"] == "FUZZY":
            q_.append("CONFIRM name mapping %s -> %s.%s (%s:%s)" % (r["path"], r.get("repoClass"), r["repoField"], r.get("repoFile"), r.get("repoLine")))
        if r.get("typeCheck") in ("WARN", "MISMATCH"):
            q_.append("TYPE %s: %s (%s:%s)" % (r["path"], r.get("notes"), r.get("repoFile"), r.get("repoLine")))
    for x in integ:
        if x["status"] in ("MISSING", "FOUND_ELSEWHERE"):
            q_.append("INTEGRATION %s %s is %s; repo1 %s; repo2 %s" % (x["kind"], x["key"], x["status"], ", ".join(x["repo1"][:2]), ", ".join(x["repo2"][:2]) or "-"))
    for x in rules:
        if x["status"] in ("NOT_FOUND", "PARTIAL", "REVIEW"):
            q_.append("RULE %s at %s: `%s`" % (x["status"], x["at"], x["text"][:100]))
    for x in rv1:
        if set(x["fields"]) - set(x["repo2HasForFields"]) or not x["fields"]:
            q_.append("VALIDATION repo1 %s `%s` - check repo2" % (x["at"], x["text"][:90]))
    n_db = 0
    for x in res.get("dbObjects", []):
        if x["status"] == "ONLY_REPO1" and n_db < 5 and (x["repo1"].startswith(("write", "exec")) or x["kind"] in ("proc", "function")):
            q_.append("DB %s `%s` is used by repo1 (%s%s) but not on the repo2 path - does repo2 get/keep this data another way?%s" % (
                x["kind"], x["object"], x["repo1"], (" at " + ", ".join(x["repo1At"][:2])) if x["repo1At"] else "",
                (" Definition: " + x["definition"]) if x["definition"] else ""))
            n_db += 1
    res["review"] = q_[:args.max_review]
    return res


# --------------------------------------------------------------------------- reporting

def md_table(rows, cols, limit):
    if not rows:
        return "_none_\n"
    out = ["| " + " | ".join(c[0] for c in cols) + " |", "|" + "---|" * len(cols)]
    for r in rows[:limit]:
        out.append("| " + " | ".join(str(c[1](r)).replace("|", "\\|").replace("\n", " ") for c in cols) + " |")
    if len(rows) > limit:
        out.append("\n_... %d more rows in parity.json_" % (len(rows) - limit))
    return "\n".join(out) + "\n"


def restr_s(r):
    if not r:
        return ""
    return ",".join("%s=%s" % (k, ("|".join(v[:5]) + ("..." if len(v) > 5 else "")) if isinstance(v, list) else v) for k, v in r.items())[:60]


def global_checks(ops, repo1, repo2):
    out = {"hosts": [], "delegation": []}
    if repo1:
        h1, h2 = repo1.config_hosts, repo2.config_hosts
        for h in sorted(set(h1) | set(h2)):
            if h in ("localhost", "127.0.0.1", "schemas.xmlsoap.org", "www.w3.org", "schemas.microsoft.com", "tempuri.org"):
                continue
            st = "BOTH" if h in h1 and h in h2 else "REPO1_ONLY" if h in h1 else "REPO2_ONLY"
            out["hosts"].append({"host": h, "status": st,
                                 "repo1": ", ".join("%s (%s)" % (k, rel) for k, rel, ln in h1.get(h, [])[:2]),
                                 "repo2": ", ".join("%s (%s)" % (k, rel) for k, rel, ln in h2.get(h, [])[:2])})
    addr_hosts = {urllib.parse.urlparse(o["address"]).hostname for o in ops if o.get("address")} - {None, "localhost"}
    addr_paths = {urllib.parse.urlparse(o["address"]).path.lower() for o in ops if o.get("address")} - {"", "/"}
    for h in addr_hosts:
        for k, rel, ln in repo2.config_hosts.get(h.lower(), []):
            out["delegation"].append("repo2 config %s:%s (%s) points to the SOAP service host %s" % (rel, ln, k, h))
    for hit in repo2.hits:
        if hit["sub"] == "soap-client" or any(p and p in hit["text"].lower() for p in addr_paths):
            out["delegation"].append("repo2 %s:%d `%s`" % (hit["file"], hit["line"], hit["text"][:100]))
    out["delegation"] = out["delegation"][:15]
    return out


def db_summary_lines(r, args):
    rows = r.get("dbObjects") or []
    if not rows:
        return ["\n### DB objects\n", "_none found on either call path_"]
    L = ["\n### DB objects (tables / procs / views / functions / triggers on each call path)\n"]
    L.append(md_table(rows, [("object", lambda x: "`%s`" % x["object"]), ("kind", lambda x: x["kind"]),
                             ("repo1 use", lambda x: x["repo1"]), ("repo2 use", lambda x: x["repo2"]), ("status", lambda x: x["status"]),
                             ("definition", lambda x: x["definition"] or "not provided"), ("details", lambda x: x["details"]),
                             ("repo1 at", lambda x: ", ".join(x["repo1At"][:2]))], args.max_rows))
    miss = [x["object"] for x in rows if not x["definition"]]
    if miss:
        L.append("\n_%d object(s) without SQL definition (see db_objects_to_export.txt; give `--db-scripts <folder>` or "
                 "`--db-server/--db-name` to include procedure logic and table columns)._" % len(miss))
    return L


QUEUE_REF_RE = re.compile(r"[\w./\\-]+\.(?:cs|vb|sql|config|xml|json|dbml|edmx|svc|asmx|wsdl|xsd)(?::\d+)?")


def render_review_queue(items):
    """The per-operation review queue as grouped, readable markdown (same items, same numbering budget).
    Field checks become one table row per field (name + type issues merged); the others are grouped by kind with a
    plain-language heading. File paths are shortened to the file name; a legend gives the full path once."""
    if not items:
        return ["_none_"]
    fields, order, groups = {}, [], defaultdict(list)
    kinds = (("INTEGRATION ", "Tables, procedures and external systems the old code uses but the new path does not reach"),
             ("DB ", "Database objects only the old code writes or executes"),
             ("RULE ", "Business rules: read the old code, find the same rule in the new code (SAME / DIFFERENT / MISSING)"),
             ("VALIDATION ", "Input checks in the old code: does the new code check the same thing?"))
    for it in items:
        m = re.match(r"^CONFIRM name mapping (\S+) -> (\S+) \((.*):(\w+)\)$", it)
        t = None if m else re.match(r"^TYPE (\S+): (.*) \((.*):(\w+)\)$", it)
        if m or t:
            key = (m or t).group(1)
            if key not in fields:
                fields[key] = {"new": "", "notes": [], "at": ""}
                order.append(key)
            f = fields[key]
            if m:
                f["new"] = m.group(2)
                f["notes"].insert(0, "name differs - same data?")
            else:
                f["notes"].append(t.group(2))
            at = "%s:%s" % ((m or t).group(3), (m or t).group(4))
            f["at"] = f["at"] or (at if (m or t).group(3) not in ("None", "") else "")
            continue
        for pfx, _ in kinds:
            if it.startswith(pfx):
                groups[pfx].append(it[len(pfx):])
                break
        else:
            groups["other"].append(it)
    # file legend: short name for every path that is unique by file name
    refs = []
    for it in items:
        refs += [r.split(":")[0].replace("\\", "/") for r in QUEUE_REF_RE.findall(it)]
    by_base = defaultdict(set)
    for r in refs:
        by_base[r.split("/")[-1]].add(r)
    legend = {next(iter(v)): k for k, v in by_base.items() if len(v) == 1 and "/" in next(iter(v))}

    def short(s):
        return QUEUE_REF_RE.sub(lambda mm: legend.get(mm.group(0).split(":")[0].replace("\\", "/"), mm.group(0).split(":")[0])
                                + ((":" + mm.group(0).rsplit(":", 1)[1]) if re.search(r":\d+$", mm.group(0)) else ""), s)

    def cell(s):
        return re.sub(r"\s+", " ", str(s)).strip().replace("|", "\\|")

    L, n = [], 0
    if order:
        L += ["**Response/request fields to check** (old SOAP field -> new field):", "",
              "| # | Old field | New field | What to check | Where (new) |", "|---|---|---|---|---|"]
        for key in order:
            n += 1
            f = fields[key]
            L.append("| %d | %s | %s | %s | %s |" % (n, cell(key), cell(f["new"] or "(same name)"), cell("; ".join(f["notes"])),
                                                   cell(short(f["at"])) if f["at"] else "-"))
        L.append("")
    for pfx, title in kinds + (("other", "Other checks"),):
        if not groups.get(pfx):
            continue
        L += ["**%s%s**" % (title, "" if title.endswith("?") else ":"), ""]
        for it in groups[pfx]:
            n += 1
            L.append("%d. %s" % (n, short(it)))
        L.append("")
    if legend:
        L.append("_Files: " + "; ".join("`%s` = `%s`" % (b, p) for p, b in sorted(legend.items(), key=lambda kv: kv[1])) + "_")
    return L


def write_summary(path, ops, results, args, repo1, repo2, extra_eps, glob=None):
    glob = glob or {}
    L = []
    L.append("# SOAP parity summary (auto-generated by soap_parity.py %s)\n" % VERSION)
    L.append("> **Working file for Copilot - not the report.** It lists raw machine findings (name/type matches, rule "
             "signals) that Copilot checks one by one. The document for people is **`parity_report.md`** in this folder: it "
             "holds the verdicts, the differences in plain words and the decisions needed.\n")
    L.append(RUN_ID_NOTE % LOG.run_id)
    L.append("WSDL: `%s`  \nrepo1: `%s`  \nrepo2: `%s`\n" % (args.wsdl, repo1.root if repo1 else "(not given)", repo2.root))
    L.append("Statuses are heuristic. `MATCH` = same normalized name; `FUZZY` = similar name, confirm; "
             "`MISSING` = no counterpart found; `FOUND_ELSEWHERE` = exists in repo2 but not reachable from the matched endpoint.\n")
    L.append("## Overview\n")
    L.append(md_table(results, [("Operation", lambda r: r["operation"]), ("Auto verdict", lambda r: r["verdict"]),
                                ("Overall", lambda r: r["scores"]["overall"]), ("Contract", lambda r: r["scores"]["contract"]),
                                ("Integrations", lambda r: r["scores"]["integrations"]), ("Rules", lambda r: r["scores"]["rules"]),
                                ("Val. gaps", lambda r: r["scores"]["validationGaps"]),
                                ("repo2 endpoint", lambda r: (r["repo2Candidates"][0]["method"] + " " + (r["repo2Candidates"][0]["verb"] or "") + " " + (r["repo2Candidates"][0]["route"] or "")) if r["repo2Candidates"] and r["verdict"] not in ("NOT_IMPLEMENTED",) and not r["verdict"].startswith("PARTIAL (DTO") else "-")], 500))
    for r in results:
        L.append("\n---\n## Operation `%s` -> **%s**\n" % (r["operation"], r["verdict"]))
        if r.get("soapAction"):
            L.append("soapAction: `%s`  " % r["soapAction"])
        if r.get("repo1Entry"):
            L.append("repo1 entry: " + "; ".join("`%s`" % x for x in r["repo1Entry"]) + "  ")
        if r.get("repo1SliceFiles"):
            L.append("repo1 reachable files (%d): %s  " % (len(r["repo1SliceFiles"]), ", ".join("`%s`" % x for x in r["repo1SliceFiles"][:args.max_rows])))
        L.append("repo2 candidates: " + ("; ".join("`%s` %s %s (score %.2f, req=%s, res=%s)" % (c["at"], c["method"], c["route"] or "", c["score"], c["requestClass"], c["responseClass"]) for c in r["repo2Candidates"]) or "none") + "  ")
        if not r.get("repo2SliceFiles") and not args.all_rows:
            # Compact form: nothing in repo2 was matched, so per-field / per-rule tables would only repeat "MISSING" (token waste).
            L.append("\n**No repo2 endpoint matched (best score below --min-score %.2f).** Details are compact on purpose.\n" % args.min_score)
            for label in ("request", "response"):
                c = r["contract"].get(label)
                if c:
                    cnt = defaultdict(int)
                    for x in c["rows"]:
                        cnt[x["status"]] += 1
                    tops = [x["path"].split("/")[-1] for x in c["rows"] if x["path"].count("/") == 1][:25]
                    L.append("- %s: repo2 class `%s` (%s); top-level fields: %s" % (label, c["rootClass"], ", ".join("%s=%d" % kv for kv in sorted(cnt.items())), ", ".join(tops)))
            keys = ["%s:%s" % (x["kind"], x["key"]) for x in r["integrations"] if x["status"] != "EXTRA_IN_REPO2"]
            L.append("- repo1 integrations on the call path (%d): %s" % (len(keys), ", ".join(keys[:30]) + (" ..." if len(keys) > 30 else "")))
            L.append("- repo1 business-rule signals: %d, validations: %d (full list in parity.json)" % (len(r["businessRules"]), len(r["repo1ImperativeValidations"])))
            L.extend(db_summary_lines(r, args))
            L.append("\n### LLM review queue\n")
            L.append("1. Search repo2 once for the operation name / key nouns (%s), the request field names and the top-level response "
                     "field names (repo2 often uses REST names: routes, controllers without the SOAP verb). If found, add "
                     "`\"%s\": \"Class.Method\"` to `%s/repo2_map.json` (collect ALL unmatched operations first, keep existing "
                     "entries) and re-run the same command ONCE (the map is picked up automatically); if not found, the operation is "
                     "NOT_IMPLEMENTED in repo2."
                     % (", ".join(sorted(nouns(r["operation"]))[:5]), r["operation"], args.out.replace("\\", "/")))
            L.append("")
            continue
        if r.get("repo2SliceFiles"):
            L.append("repo2 reachable files (%d): %s" % (len(r["repo2SliceFiles"]), ", ".join("`%s`" % x for x in r["repo2SliceFiles"][:args.max_rows])))
        for label in ("request", "response"):
            c = r["contract"].get(label)
            if not c:
                continue
            rows = c["rows"]
            cnt = defaultdict(int)
            for x in rows:
                cnt[x["status"]] += 1
            L.append("\n### %s contract (repo2 class: `%s` %s) - %s\n" % (
                label.capitalize(), c["rootClass"], ("`%s`" % c["rootFile"]) if c["rootFile"] else "", ", ".join("%s=%d" % kv for kv in sorted(cnt.items()))))
            if c["note"]:
                L.append("_%s_\n" % c["note"])
            unset = [x["path"].split("/")[-1] for x in rows if x["status"] == "NOT_SET_IN_REPO1"]
            if unset:
                L.append("_%d field(s) are never assigned on the repo1 call path (always empty in legacy responses) - not counted as gaps: %s%s_\n"
                         % (len(unset), ", ".join(unset[:40]), " ..." if len(unset) > 40 else ""))
            show = [x for x in rows if x["status"] != "NOT_SET_IN_REPO1" and (args.all_rows or x["status"] != "MATCH" or
                                                                              x.get("typeCheck") in ("WARN", "MISMATCH") or x.get("notes"))]
            L.append(md_table(show, [("XSD path", lambda x: x["path"]), ("xsd type", lambda x: x.get("xsdType") or ""),
                                     ("occ", lambda x: "%s..%s" % (x.get("min", ""), x.get("max", "")) if x.get("xsdType") else ""),
                                     ("restrictions", lambda x: restr_s(x.get("restr"))),
                                     ("repo2 field", lambda x: ("%s : %s" % (x["repoField"], x.get("repoType", ""))) if x.get("repoField") else "-"),
                                     ("status", lambda x: x["status"] + ("/" + x["typeCheck"] if x.get("typeCheck") not in (None, "OK") else "")),
                                     ("notes", lambda x: x.get("notes", ""))], args.max_rows))
        L.append("\n### Integrations (DB tables / procs / HTTP paths / hosts / queues)\n")
        L.append(md_table(r["integrations"], [("kind", lambda x: x["kind"]), ("key", lambda x: x["key"]), ("status", lambda x: x["status"]),
                                              ("repo1", lambda x: ", ".join(x["repo1"][:2])), ("repo2", lambda x: ", ".join(x["repo2"][:2]))], args.max_rows))
        unkeyed = [h for h in r["repo1Hits"] if h["cat"] in ("db", "outbound", "messaging")]
        if unkeyed:
            L.append("\nrepo1 integration call sites in slice:\n")
            L.append(md_table(unkeyed, [("cat", lambda x: x["cat"] + "/" + x["sub"]), ("at", lambda x: x["at"]), ("code", lambda x: "`%s`" % x["text"][:100])], args.max_rows))
        L.extend(db_summary_lines(r, args))
        L.append("\n### Validation gaps (XSD rule not enforced on repo2 DTO)\n")
        L.append(md_table(r["validationGaps"], [("path", lambda x: x["path"]), ("rule", lambda x: x["rule"]), ("xsd", lambda x: x["xsd"][:50]),
                                                ("repo2", lambda x: x["repo2"]), ("status", lambda x: x["status"])], args.max_rows))
        if r["repo1ImperativeValidations"]:
            L.append("\nrepo1 code-level validations:\n")
            L.append(md_table(r["repo1ImperativeValidations"], [("at", lambda x: x["at"]), ("fields", lambda x: ",".join(x["fields"])),
                                                                 ("repo2 has", lambda x: ",".join(x["repo2HasForFields"]) or "?"),
                                                                 ("code", lambda x: "`%s`" % x["text"][:90])], args.max_rows))
        L.append("\n### Business-rule signals (repo1 conditions/calculations; literal match in repo2)\n")
        L.append(md_table(r["businessRules"], [("at", lambda x: x["at"]), ("method", lambda x: x["method"]), ("literals", lambda x: ",".join(x["literals"])[:40]),
                                               ("status", lambda x: x["status"]), ("code", lambda x: "`%s`" % x["text"][:90])], args.max_rows))
        if r.get("logicPack"):
            L.append("\n### Deep review input\n")
            L.append("Logic pack (both call paths + SQL, size-capped): `%s` (%d KB). Use it for the business-logic comparison." % (
                r["logicPack"], r.get("logicPackKB", 0)))
        L.append("\n### LLM review queue (verify ONLY these; open +/-15 lines around each ref)\n")
        L.extend(render_review_queue(r["review"]))
        L.append("")
    if glob.get("delegation"):
        L.append("\n---\n## CHECK: repo2 has SOAP-client calls or references the legacy service address\n")
        L.extend("- %s" % x for x in glob["delegation"])
        L.append("\nIf so, matching DTOs do not prove reimplementation - verify whether repo2 is only a facade.\n")
    if glob.get("hosts"):
        L.append("\n---\n## External dependencies from configuration (whole repo, not per operation)\n")
        L.append(md_table(glob["hosts"], [("host", lambda x: x["host"]), ("status", lambda x: x["status"]),
                                          ("repo1 config", lambda x: x["repo1"]), ("repo2 config", lambda x: x["repo2"])], 60))
    if extra_eps:
        L.append("\n---\n## repo2 endpoints not matched to any WSDL operation\n")
        L.append(md_table(extra_eps, [("at", lambda e: "%s:%d" % (e["file"], e["line"])), ("method", lambda e: e["method"]),
                                      ("verb", lambda e: e["verb"]), ("route", lambda e: e["route"])], args.max_rows))
    if WARNINGS:
        L.append("\n---\n## Extraction warnings (fix these first - they reduce accuracy)\n")
        L.extend("- " + w for w in WARNINGS[:60])
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


def jsonable(o):
    if isinstance(o, dict):
        return {k: jsonable(v) for k, v in o.items() if k not in ("f", "m", "raw", "clean")}
    if isinstance(o, (list, tuple, set)):
        return [jsonable(x) for x in o]
    return o


# --------------------------------------------------------------------------- .svc -> contract from WCF source code

CS_XSD = {"string": "string", "int": "int", "int32": "int", "long": "long", "int64": "long", "short": "short", "int16": "short",
          "byte": "unsignedByte", "sbyte": "byte", "uint": "unsignedInt", "ulong": "unsignedLong", "ushort": "unsignedShort",
          "decimal": "decimal", "double": "double", "float": "float", "single": "float", "bool": "boolean", "boolean": "boolean",
          "datetime": "dateTime", "datetimeoffset": "dateTime", "dateonly": "date", "timespan": "duration", "guid": "string",
          "char": "int", "object": "anyType", "uri": "anyURI", "xmlelement": "anyType", "xelement": "anyType"}
CS_LIST_RE = re.compile(r"^(?:System\.Collections\.Generic\.)?(?:List|IList|ICollection|IEnumerable|Collection|IReadOnlyList|"
                        r"IReadOnlyCollection|HashSet|ISet|ObservableCollection)\s*<\s*(.+)>$")


def read_svc(path):
    """<%@ ServiceHost Service="Ns.QuoteService, Asm" CodeBehind="QuoteService.svc.cs" %> -> (class, codebehind)."""
    txt = RepoIndex._read(path)
    m = re.search(r"\bService\s*=\s*\"([^\"]+)\"", txt)
    cb = re.search(r"\bCodeBehind\s*=\s*\"([^\"]+)\"", txt)
    full = m.group(1).split(",")[0].strip() if m else ""
    cls = full.split(".")[-1] if full else None
    return cls, cb.group(1) if cb else None, txt.strip()[:200], full.rsplit(".", 1)[0] if "." in full else ""


def find_solution_root(start):
    """Walk up from the .svc folder to the folder holding the .sln (or .git). Fallback: two levels up."""
    d = os.path.abspath(start)
    for _ in range(8):
        try:
            names = os.listdir(d)
        except OSError:
            break
        if any(n.lower().endswith(".sln") for n in names) or ".git" in names:
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return os.path.dirname(os.path.abspath(start))


class SvcContract:
    """Build the same operation/field structure as the WSDL path, from [ServiceContract]/[DataContract] C# code."""
    MAX_DEPTH = 12

    def __init__(self, repo, impl_class):
        self.repo = repo
        self.impl = impl_class
        self.fields = []
        self._ambig_logged = set()
        self.ambiguous = []       # simple type names that needed the tie-break (shown as W-SVC)

    GEN_FILE_RE = re.compile(r"(^|[\\/])(Reference|[^\\/]*\.designer|[^\\/]*\.g|[^\\/]*\.generated)\.(cs|vb)$", re.I)

    def _cls(self, name, ctx=None):
        """Resolve a type name like the C# compiler would: namespace-qualified name first, then the referencing file's
        own namespace and its usings (ctx = file dict). Only if still ambiguous: hand-written over generated proxy files
        (Reference.cs, *.designer.cs), [DataContract] classes first, then by path - and the choice is logged."""
        name = (name or "").strip().rstrip("?")
        if "<" in name:
            qual, simple = "", name.split(".")[-1]
        else:
            qual, _, simple = name.rpartition(".")
        all_recs = recs = [c for c in self.repo.class_recs(simple) if c["lang"] in ("cs", "vb")]
        if len(recs) > 1:
            # a type nested inside another class is not visible by its simple name outside that class (C# rules):
            # e.g. an enum Result inside some request class must not replace the top-level Result class
            top = [c for c in recs if not self._nested(c)]
            recs = top or recs
        if len(recs) > 1 and qual:
            q = [c for c in recs if (c.get("ns") or "") == qual or (c.get("ns") or "").endswith("." + qual)]
            recs = q or recs
        if len(recs) > 1 and ctx is not None:
            ids = {id(c) for c in recs}
            vis = [c for c in self.repo.visible_recs(simple, ctx) if id(c) in ids]
            recs = vis or recs
        if len(recs) > 1:
            recs = sorted(recs, key=lambda c: (bool(self.GEN_FILE_RE.search(self.repo.files[c["fidx"]]["path"])),
                                               not any(a.startswith(("DataContract", "MessageContract")) for a in c["annotations"]),
                                               self.repo.files[c["fidx"]]["path"], c["start"]))
            key = (simple, id(ctx))
            if key not in self._ambig_logged:
                self._ambig_logged.add(key)
                LOG.write("svc: type %s is ambiguous (%d classes) - picked %s.%s in %s; others: %s" % (
                    name, len(recs), recs[0].get("ns") or "-", simple, self.repo.files[recs[0]["fidx"]]["path"],
                    ", ".join("%s (%s)" % (c.get("ns") or "-", self.repo.files[c["fidx"]]["path"]) for c in recs[1:5])))
                self.ambiguous.append(simple)
        if len(all_recs) > 1 and recs:
            key = ("res", simple, id(ctx))
            if key not in self._ambig_logged:      # every multi-candidate resolution is logged, so it can be checked
                self._ambig_logged.add(key)
                LOG.write("svc type %s -> %s.%s%s in %s (%d same-named types)" % (
                    name, recs[0].get("ns") or "-", simple, " [enum]" if recs[0]["is_enum"] else "",
                    self.repo.files[recs[0]["fidx"]]["path"], len(all_recs)))
        return recs[0] if recs else None

    def _nested(self, c):
        f = self.repo.files[c["fidx"]]
        return any(o is not c and o["start"] < c["start"] and c["end"] <= o["end"] for o in f["classes"])

    def _ctx_of(self, c):
        return self.repo.files[c["fidx"]] if c else None

    def contract_interfaces(self):
        names = {self.impl} | self.repo.superclasses(self.impl)
        out = []
        for n in sorted(names):
            for c in self.repo.class_recs(n):
                if any(a.startswith("ServiceContract") for a in c["annotations"]):
                    out.append(c)
        return out

    def operations(self):
        ops = []
        ifaces = self.contract_interfaces()
        if not ifaces:
            impl = self._cls(self.impl)
            if impl and any(a.startswith("ServiceContract") for a in impl["annotations"]):
                ifaces = [impl]
        for itf in ifaces:
            f = self.repo.files[itf["fidx"]]
            ns_m = re.search(r"Namespace\s*=\s*\"([^\"]+)\"", " ".join(itf["annotations"]))
            cname_m = re.search(r"ServiceContract\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"", " ".join(itf["annotations"]))
            ns = ns_m.group(1) if ns_m else "http://tempuri.org/"
            cname = cname_m.group(1) if cname_m else itf["name"]
            for m in f["methods"]:
                if not (itf["start"] < m["decl"] <= itf["end"]):
                    continue
                ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
                if "OperationContract" not in ann:
                    continue
                op = self._operation(f, m, ann, ns, cname, itf)
                if op:
                    ops.append(op)
        return ops

    def _operation(self, f, m, ann, ns, cname, itf):
        nm = re.search(r"OperationContract\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"", ann)
        opname = nm.group(1) if nm else base_name(m["name"])
        act = re.search(r"OperationContract\s*\([^)]*\bAction\s*=\s*\"([^\"]+)\"", ann)
        sm = re.match(r"\s*(?:\[[^\]]*\]\s*)*(?:(?:public|internal|virtual|abstract)\s+)*([\w.<>\[\],? ]+?)\s+(\w+)\s*\((.*)\)",
                      LEAD_ANN_RE.sub("", m["sig"]))
        if not sm:
            warn("svc: cannot parse signature of %s.%s at %s:%d" % (itf["name"], m["name"], f["path"], m["decl"] + 1))
            return None
        ret, params = sm.group(1).strip(), sm.group(3)
        tm = re.match(r"^(?:System\.Threading\.Tasks\.)?(?:Task|ValueTask)\s*<\s*(.+)>$", ret)
        ret = tm.group(1).strip() if tm else ("void" if re.match(r"^(?:Task|ValueTask)$", ret) else ret)
        rec = {"name": opname, "wsdlName": opname, "portType": cname, "address": None, "style": "document",
               "soapAction": act.group(1) if act else "%s/%s/%s" % (ns.rstrip("/"), cname, opname),
               "request": [], "response": [], "faults": [], "source": "svc-code",
               "codeMethod": m["name"], "codeAt": "%s:%d" % (f["path"], m["decl"] + 1), "implClass": self.impl}
        plist = [self.repo._param_field(p, "cs") for p in RepoIndex._split_params(params)]
        plist = [p for p in plist if p and not re.search(r"\b(out|ref)\b", p["type"]) and p["type"] != "CancellationToken"]
        # request
        if len(plist) == 1 and self._is_complex(plist[0]["type"], f):
            self.fields = []
            self._root(plist[0]["type"], rec, f)
            rec["request"] = self.fields
        else:
            self.fields = [self._f(opname, opname, "(wrapper)", complex_=True)]
            for p in plist:
                self._member(opname, p.get("alias") or p["name"], p["type"], 1, [], {}, f)
            rec["request"] = self.fields
        # response
        self.fields = []
        if ret == "void":
            self.fields = [self._f(opname + "Response", opname + "Response", "(wrapper)", complex_=True)]
        elif self._is_complex(ret, f):
            self._root(ret, rec, f)
        else:
            root = opname + "Response"
            self.fields = [self._f(root, root, "(wrapper)", complex_=True)]
            self._member(root, opname + "Result", ret, 0, [], {}, f)
        rec["response"] = self.fields
        # faults
        flt = []
        for ft in re.findall(r"FaultContract\s*\(\s*typeof\s*\(\s*([\w.]+)\s*\)", ann):
            self.fields = []
            self._root(ft, rec, f)
            flt.extend(self.fields)
        rec["faults"] = flt
        return rec

    def _is_complex(self, t, ctx=None):
        t = re.sub(r"^(?:System\.)?Nullable\s*<\s*(.+?)\s*>$", r"\1", t.strip()).rstrip("?")
        if CS_LIST_RE.match(t) or t.endswith("[]"):
            return False
        c = self._cls(t, ctx)
        return bool(c and not c["is_enum"])

    def _wire(self, c):
        m = re.search(r"(?:DataContract|MessageContract|XmlType|XmlRoot|CollectionDataContract)\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"",
                      " ".join(c["annotations"]))
        if not m:
            m = re.search(r"(?:XmlType|XmlRoot)\s*\(\s*\"([^\"]+)\"", " ".join(c["annotations"]))
        return m.group(1) if m else c["name"]

    def _f(self, path, name, typ, mn=1, mx=1, complex_=False, restr=None, lst=False):
        return {"path": path, "name": name, "type": typ, "min": mn, "max": mx, "complex": complex_, "attr": False,
                "choice": False, "nillable": False, "list": lst, "restr": restr or {}}

    def _root(self, t, rec, ctx=None):
        c = self._cls(t, ctx)
        if not c:
            self.fields.append(self._f(t, t, "UNRESOLVED:" + t))
            return
        wire = self._wire(c)
        if any(a.startswith("MessageContract") for a in c["annotations"]):
            wm = re.search(r"WrapperName\s*=\s*\"([^\"]+)\"", " ".join(c["annotations"]))
            wire = wm.group(1) if wm else wire
        self.fields.append(self._f(wire, wire, c["name"], complex_=True))
        self._members(c, wire, [c["name"]])

    def _class_members(self, c, depth=0):
        out = []
        if depth < 6:
            for p in c["parents"]:
                pc = self._cls(p, self._ctx_of(c))
                if pc and pc["kind"] in ("class", "record", "struct") and not pc["is_enum"]:
                    out.extend(self._class_members(pc, depth + 1))
        anns_all = " ".join(c["annotations"])
        explicit = bool(re.search(r"\b(DataContract|MessageContract)\b", anns_all))
        # Without [DataContract] WCF's DataContractSerializer uses: [Serializable] (and no Xml* attributes) -> ALL fields,
        # private ones too, but not properties; otherwise (POCO, LINQ to SQL / EF entity, XmlSerializer types) -> public
        # properties and public fields. So a LINQ to SQL entity is sent as ID/Name, not as its _ID/_Name storage fields.
        serializable = bool(re.search(r"\bSerializable(?:Attribute)?\b", anns_all)) and \
            not re.search(r"\bXml(?:Type|Root)(?:Attribute)?\b", anns_all)
        kept = []
        for fd in c["fields"]:
            fa = " ".join(fd.get("annotations", []))
            if re.search(r"\b(IgnoreDataMember|XmlIgnore|NonSerialized|JsonIgnore)\b", fa):
                continue
            if explicit and not re.search(r"\b(DataMember|MessageBodyMember|MessageHeader)\b", fa):
                continue
            kept.append(fd)
        if not explicit and c.get("lang") in ("cs", "vb") and any("access" in fd for fd in kept):
            if serializable:
                rule = [fd for fd in kept if not fd.get("prop")]
            else:
                rule = [fd for fd in kept if fd.get("access") == "public"]
            if rule:                       # never drop everything because of a parse gap
                kept = rule
        out.extend(kept)
        return out

    def _members(self, c, path, stack):
        for fd in self._class_members(c):
            fa = " ".join(fd.get("annotations", []))
            req = 1 if ("Required(DataMember)" in fd.get("annotations", []) or re.search(r"\bRequired\b", fa)) else 0
            k = len(self.fields)
            self._member(path, fd.get("alias") or fd["name"], fd["type"], req, stack, self._restr(fa), self._ctx_of(c))
            if len(self.fields) > k:
                self.fields[k]["codeName"] = fd["name"]

    @staticmethod
    def _restr(fa):
        r = {}
        m = re.search(r"StringLength\s*\(\s*(\d+)", fa) or re.search(r"MaxLength\s*\(\s*(\d+)", fa)
        if m:
            r["maxLength"] = m.group(1)
        m = re.search(r"MinimumLength\s*=\s*(\d+)", fa) or re.search(r"MinLength\s*\(\s*(\d+)", fa)
        if m:
            r["minLength"] = m.group(1)
        m = re.search(r"Range\s*\(\s*([-\d.]+)\s*,\s*([-\d.]+)", fa)
        if m:
            r["minInclusive"], r["maxInclusive"] = m.group(1), m.group(2)
        m = re.search(r"RegularExpression\s*\(\s*@?\"((?:[^\"]|\"\")*)\"", fa)
        if m:
            r["pattern"] = m.group(1)
        return r

    def _member(self, parent, name, t, req, stack, restr, ctx=None):
        t = t.strip()
        nm_ = re.match(r"^(?:System\.)?Nullable\s*<\s*(.+?)\s*>$", t)
        if nm_:
            t = nm_.group(1) + "?"
        nullable = t.endswith("?")
        t = t.rstrip("?")
        lm = CS_LIST_RE.match(t)
        lst = bool(lm) or (t.endswith("[]") and t not in ("byte[]", "Byte[]"))
        if t in ("byte[]", "Byte[]"):
            self.fields.append(dict(self._f(parent + "/" + name, name, "base64Binary", req, 1, restr=restr), nillable=nullable))
            return
        if re.match(r"^(?:System\.Collections\.Generic\.)?I?(?:Dictionary|ReadOnlyDictionary)\s*<", t):
            self.fields.append(self._f(parent + "/" + name, name, "map", req, 1, complex_=True))
            return
        inner = lm.group(1).strip() if lm else (t[:-2] if lst else t)
        base = inner.rstrip("?").split(".")[-1]
        path = parent + "/" + name + ("[]" if lst else "")
        mx = "unbounded" if lst else 1
        prim = CS_XSD.get(base.lower())
        if prim:
            self.fields.append(dict(self._f(path, name, prim, req, mx, restr=restr, lst=lst), nillable=nullable))
            return
        c = self._cls(inner.rstrip("?"), ctx)
        if c is None:
            self.fields.append(self._f(path, name, "UNRESOLVED:" + base, req, mx, lst=lst))
            return
        if c["is_enum"]:
            vals = self._enum_values(c)
            self.fields.append(dict(self._f(path, name, "string", req, mx, restr=dict(restr, enumeration=vals) if vals else restr,
                                            lst=lst), typeName=c["name"]))
            return
        if c["name"] in stack or len(stack) > self.MAX_DEPTH:
            self.fields.append(self._f(path, name, "RECURSIVE:" + c["name"], req, mx, complex_=True, lst=lst))
            return
        self.fields.append(self._f(path, name, c["name"], req, mx, complex_=True, lst=lst))
        self._members(c, path, stack + [c["name"]])

    def _enum_values(self, c):
        f = self.repo.files[c["fidx"]]
        body = " ".join(f["clean"][c["start"]:c["end"] + 1])
        body = body.split("{", 1)[1] if "{" in body else ""
        body = body.rsplit("}", 1)[0]
        vals = []
        for part in body.split(","):
            em = re.search(r"EnumMember\s*\([^)]*Value\s*=\s*\"([^\"]+)\"", part)
            part2 = re.sub(r"\[[^\]]*\]", "", part).strip()
            nm = re.match(r"([A-Za-z_]\w*)", part2)
            if em:
                vals.append(em.group(1))
            elif nm:
                vals.append(nm.group(1))
        return vals[:60]


def svc_operations(svc_path, repo1):
    """Returns (ops, impl_class). Logs everything needed to debug a wrong/missing contract."""
    cls, codebehind, head, cls_ns = read_svc(svc_path)
    LOG.write("svc header: %s" % head)
    if not cls:
        warn("svc: no Service=\"...\" attribute in %s (Factory-only .svc?) - using every [ServiceContract] in repo1" % svc_path)
        impls = set()
        for c_list in repo1.classes.values():
            for c in c_list:
                if any(a.startswith("ServiceContract") for a in c["annotations"]):
                    impls |= {n for n in repo1.children.get(c["name"], ())} or {c["name"]}
        ops = []
        for impl in sorted(impls):
            ops.extend(SvcContract(repo1, impl).operations())
        return ops, None
    LOG.info["svcClass"] = cls
    if not repo1.class_recs(cls):
        close = difflib.get_close_matches(cls, list(repo1.classes.keys()), n=5, cutoff=0.6)
        warn("svc: service class %s not found in repo1 (is --repo1 the solution root?). Similar: %s" % (cls, ", ".join(close) or "-"))
        return [], cls
    sc = SvcContract(repo1, cls)
    ifaces = sc.contract_interfaces()
    LOG.write("svc: class %s at %s; contract interfaces: %s" % (cls, ", ".join("%s:%d" % (c["file"], c["start"] + 1) for c in repo1.class_recs(cls)),
                                                                ", ".join("%s(%s:%d)" % (c["name"], c["file"], c["start"] + 1) for c in ifaces) or "-"))
    ops = sc.operations()
    if sc.ambiguous:
        amb = sorted(set(sc.ambiguous))
        warn("svc: %d contract type name(s) exist in several namespaces and could not be resolved by namespace/usings: %s - "
             "picked a hand-written [DataContract] class first; check run.log ('ambiguous'), or pass the WSDL with "
             "--wsdl <file> --svc <.svc>" % (len(amb), ", ".join(amb[:6]) + (" ..." if len(amb) > 6 else "")))
    for o in ops:
        o["implNs"] = cls_ns
    if not ops:
        warn("svc: %s has no [OperationContract] methods reachable via its interfaces (%s)" % (cls, ", ".join(c["name"] for c in ifaces) or "none found"))
    for o in ops:
        unresolved = [x["path"] for x in o["request"] + o["response"] if str(x["type"]).startswith("UNRESOLVED")]
        LOG.write("svc op %s at %s: req=%d resp=%d faults=%d" % (o["name"], o["codeAt"], len(o["request"]), len(o["response"]), len(o["faults"])))
        if unresolved:
            warn("svc: %s - type(s) not found in repo1 source (external assembly / NuGet?): %s" % (o["name"], ", ".join(unresolved[:5])))
    return ops, cls


# --------------------------------------------------------------------------- main

def discover_wsdl(repo1_path):
    best = None
    for root, dirs, files in os.walk(repo1_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not is_out_dir(root, d)]
        for f in files:
            if f.lower().endswith(".wsdl"):
                p = os.path.join(root, f)
                n = 0
                try:
                    with open(p, "rb") as fh:
                        n = len(re.findall(rb"<(?:\w+:)?operation\b", fh.read()))
                except OSError:
                    pass
                if best is None or n > best[0]:
                    best = (n, p)
    return best[1] if best else None


def _cnt(rows, pred):
    return sum(1 for x in rows if pred(x))


def peak_mem_mb():
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + \
                           [(n, ctypes.c_size_t) for n in ("PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                                                         "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
                                                         "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]
            c = PMC()
            c.cb = ctypes.sizeof(PMC)
            k32 = ctypes.WinDLL("kernel32")
            k32.GetCurrentProcess.restype = wintypes.HANDLE
            psapi = ctypes.WinDLL("psapi")
            psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
            if psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(), ctypes.byref(c), c.cb):
                return c.PeakWorkingSetSize // (1024 * 1024)
        else:
            import resource
            v = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            return v // (1024 * 1024) if sys.platform == "darwin" else v // 1024
    except Exception:  # noqa
        return None
    return None


def write_card(args, ops, results, repo1, repo2, exit_code, crash=None):
    """diag.txt: <= ~40 lines, fixed layout, paths redacted. Designed to be screenshotted or pasted."""
    L = []
    W = 92
    total = time.time() - LOG.t0
    L.append("=" * 28 + " SOAP-PARITY DIAG v%s %s " % (VERSION, getattr(args, "phase", "full")) + "=" * 28)
    mem = peak_mem_mb()
    L.append("run    id %s | %s | py %s | %s | exit=%s | %.0fs | mem %s | jobs %d" % (
        LOG.run_id, time.strftime("%Y-%m-%d %H:%M"), sys.version.split()[0], platform.system() + " " + platform.release(), exit_code, total,
        ("%dMB" % mem) if mem is not None else "n/a", JOBS))
    inp = LOG.info
    L.append("folder %s%s" % (LOG.r(args.out).replace("\\", "/"), ("  | " + inp["scope"]) if inp.get("scope") else ""))
    L.append("input  mode=%s | contract=%s | ops=%s%s" % (inp.get("mode", "?"), LOG.r(inp.get("contractSrc", "?")),
                                                       inp.get("opsTotal", "?"),
                                                       (" (selected: %s)" % ",".join(args.operation)) if getattr(args, "operation", None) else ""))
    L.append("       repo1=%s | repo2=%s%s" % (inp.get("repo1Name", "-"), inp.get("repo2Name", "-"),
                                               (" | svcClass=%s" % inp["svcClass"]) if inp.get("svcClass") else ""))
    ph = list(LOG.phases) + [(LOG.cur_phase, time.time() - LOG.cur_t)]
    L.append("phase  " + " | ".join("%s %.1fs" % (n, s) for n, s in ph if n != "startup"))
    for label, repo in (("repo1", repo1), ("repo2", repo2)):
        if not repo:
            continue
        st = getattr(repo, "stats", {})
        sm = repo.summary()
        L.append("%-6s seen %d code %d conf %d xml %d orm %d | skip test %d+%dd gen %d vendorJs %d big %d fail %d walkErr %d%s"
                 % (label, st.get("seen", 0), st.get("code", 0), st.get("config", 0), st.get("xml", 0),
                    st.get("ormModel", 0) + st.get("bigDesignerLight", 0), st.get("testFilesSkipped", 0), st.get("testDirsSkipped", 0),
                    st.get("generatedSkipped", 0), st.get("vendorSkipped", 0), st.get("bigSkipped", 0), st.get("failed", 0),
                    st.get("walkErrors", 0), " CACHED" if getattr(repo, "from_cache", False) else ""))
        L.append("       classes %d methods %d hits %d tables %d procs %d%s"
                 % (sm["classes"], sm["methods"], sm["hits"], len(repo.entity_table), len(repo.db_funcs),
                    " NRT" if repo.nullable_enabled else ""))
        if getattr(repo, "slow_files", None):
            L.append("       slowest: " + ", ".join("%.0fs %s" % (s, os.path.basename(f)[:30]) for s, f in repo.slow_files[:3]))
    if results:
        L.append("-" * W)
        L.append("OPERATION / VERDICT / score   (2 lines per operation)")
        for r in results:
            req = (r.get("contract", {}).get("request") or {}).get("rows", [])
            rsp = (r.get("contract", {}).get("response") or {}).get("rows", [])
            ent = (r.get("repo1Entry") or ["-"])[0].split(" ")[0]
            s1st = r.get("repo1SliceStats") or {}
            if ent != "-":
                ent = "%s:%s %dfiles/%dm%s" % (os.path.basename(ent.split(":")[0])[:24], ent.split(":")[-1], s1st.get("files", 0),
                                               s1st.get("methods", 0), " CAP" if s1st.get("capped") else "")
            else:
                ent = "NOT FOUND" if repo1 else "no repo1"
            c2 = r.get("repo2Candidates") or []
            ep = ("%s %.2f %dfiles%s" % (os.path.basename(c2[0]["at"])[:28], c2[0]["score"], len(r.get("repo2SliceFiles", [])),
                                         " FORCED" if r.get("repo2Forced") else "")) if c2 else "NONE"
            ints = r.get("integrations", [])
            rules = r.get("businessRules", [])
            vtxt = r["verdict"].split(" (")[0]
            if getattr(args, "phase", "full") == "extract" and not r.get("repo2SliceFiles") and not r.get("repo2Forced"):
                vtxt = "UNMAPPED"    # step 1: repo2 not followed yet - no verdict, so nobody reads it as "not implemented"
            L.append("%-28s %-16s %.2f  review %d" % (r["operation"][:28], vtxt[:16], r["scores"]["overall"],
                                                      len(r.get("review", []))))
            L.append("   r1 %s | r2 %s" % (ent, ep))
            if s1st.get("unresolved") and s1st.get("files", 99) <= 3:
                L.append("   r1 unresolved: %s" % ", ".join(s1st["unresolved"][:3])[:W - 20])
            L.append("   req %d/%d/%d/%d  resp %d/%d/%d unset %d  int %d/%d  rules %d/%d%s" % (
                _cnt(req, lambda x: x["status"] == "MATCH"), _cnt(req, lambda x: x["status"] == "FUZZY"),
                _cnt(req, lambda x: x["status"].startswith("MISSING")), _cnt(req, lambda x: x["status"] == "UNRESOLVED"),
                _cnt(rsp, lambda x: x["status"] == "MATCH"), _cnt(rsp, lambda x: x["status"] == "FUZZY"),
                _cnt(rsp, lambda x: x["status"].startswith("MISSING")), _cnt(rsp, lambda x: x["status"] == "NOT_SET_IN_REPO1"),
                _cnt(ints, lambda x: x["status"] == "MATCH"), _cnt(ints, lambda x: x["status"] in ("MISSING", "FOUND_ELSEWHERE")),
                _cnt(rules, lambda x: x["status"].startswith("LITERALS_IN_REPO2_SLICE")), len(rules),
                ("  fanout-cut %d" % len(s1st.get("fanoutSkipped", []))) if s1st.get("fanoutSkipped") else ""))
        L.append("legend: req/resp match/fuzzy/missing/unresolved | int match/missing | rules matched/total")
        dbo = [x for r in results for x in r.get("dbObjects", [])]
        if dbo or CATALOG.files:
            uniq = {}
            for x in dbo:
                u = uniq.setdefault(x["object"], {"r1": False, "r2": False, "def": bool(x["definition"])})
                u["r1"] |= x["repo1"] != "-"
                u["r2"] |= x["repo2"] != "-"
            L.append("db     objects %d (r1 %d, r2 %d) | SQL definitions %d/%d | sql files %d%s" % (
                len(uniq), sum(1 for u in uniq.values() if u["r1"]), sum(1 for u in uniq.values() if u["r2"]),
                sum(1 for u in uniq.values() if u["def"]), len(uniq), CATALOG.files,
                (" | extracted %s" % LOG.info["dbExtract"]) if LOG.info.get("dbExtract") else ""))
        packs = [r for r in results if r.get("logicPack")]
        if packs:
            kb = sum(r.get("logicPackKB", 0) for r in packs)
            L.append("deep   logic pack(s) %d, %d KB ~ %dk tokens (turn off: --no-deep)" % (len(packs), kb, max(1, round(kb / 4))))
        try:
            kb = os.path.getsize(os.path.join(args.out, "parity_summary.md")) / 1024.0
            L.append("summary parity_summary.md %.0f KB ~ %dk tokens for Copilot" % (kb, max(1, round(kb / 4))))
        except OSError:
            pass
    warns = [e for e in LOG.events if e[0] == "WARN"]
    L.append("-" * W)
    if warns:
        by = defaultdict(list)
        for _, code, msg in warns:
            by[code].append(msg)
        L.append("WARNINGS %d (grouped by code, first example each; full list in run.log)" % len(warns))
        for code, msgs in sorted(by.items(), key=lambda x: -len(x[1]))[:8]:
            L.append("  %-17s x%-4d %s" % (code, len(msgs), msgs[0][:W - 26]))
    else:
        L.append("WARNINGS none")
    for _, code, msg in [e for e in LOG.events if e[0] == "ERROR"][:4]:
        L.append("ERROR  %s %s" % (code, msg[:W - 14]))
    if crash:
        L.append("CRASH  phase=%s file=%s" % (LOG.cur_phase, LOG.r(LOG.cur_file or "-")))
        for line in crash[-6:]:
            L.append("  " + LOG.r(line)[:W - 2])
    if LOG.info.get("links"):
        L.append("links  %s" % LOG.info["links"][:W - 7])
    if LOG.info.get("docs") or LOG.info.get("report"):
        L.append("docs   %s" % (LOG.info.get("report") or LOG.info.get("docs"))[:W - 7])
    # map line, always: shows at a glance whether the mapping step (Copilot -> repo2_map.json) happened and worked
    focus_ = getattr(args, "_focus", None)
    rs_ = [r for r in (results or []) if not focus_ or r.get("operation") in focus_]
    n_map = len(getattr(args, "_repo2_map", None) or {})
    n_used = sum(1 for r in rs_ if r.get("repo2Forced"))
    n_fail = sum(1 for r in rs_ if r.get("repo2PinFailed"))
    n_none = sum(1 for r in rs_ if not r.get("repo2SliceFiles") and not r.get("repo2Forced"))
    if rs_ and getattr(args, "phase", "full") != "report":
        L.append(("map    %s | pinned %d failed %d | unmatched %d op(s)%s" % (
            ("repo2_map.json %d%s" % (n_map, " re-used" if LOG.info.get("mapReused") else "")) if n_map else "no repo2_map.json",
            n_used, n_fail, n_none, " -> map them" if (n_none or n_fail) else ""))[:W])
    ph_ = getattr(args, "phase", "full")
    L.append("files  diag.txt run.log %s" % {"extract": "extract_next_steps.md call_graph.md db_objects.md export_db_schema.sql",
                                             "report": "parity_report.md"}.get(ph_, "parity_summary.md logic_*.md call_graph.md"))
    L.append("=" * W)
    txt = "\n".join(L)
    targets = [args.out]
    if getattr(args, "_root_out", None):              # parity_out/diag.txt = the latest run, whatever the service
        targets.append(args._root_out)
    for d in targets:                                 # each copy on its own: one failing must not stop the other
        try:
            with open(os.path.join(d, "diag.txt"), "w", encoding="utf-8") as fh:
                fh.write(txt + "\n")
        except OSError as e:
            LOG.write("could not write %s/diag.txt: %s" % (d, type(e).__name__))
            print("NOTE: could not write %s/diag.txt (%s)" % (d, type(e).__name__), flush=True)
    LOG.write("diag card:\n" + txt)
    print("\n" + txt, flush=True)


def build_parser():
    ap = argparse.ArgumentParser(description="SOAP (repo1) vs repo2 parity extractor")
    ap.add_argument("--wsdl", help="WSDL URL or file, OR a WCF .svc file/URL. A local .svc file means: read the contract from repo1 C# code "
                                   "([ServiceContract]/[DataContract]). If omitted, a *.wsdl (or the only *.svc) in repo1 is used.")
    ap.add_argument("--svc", help="local WCF .svc file. Pins the repo1 implementing class; contract comes from code unless --wsdl is also given.")
    ap.add_argument("--repo1", help="path to repo1 (SOAP implementation). With a .svc it defaults to the folder holding the .sln.")
    ap.add_argument("--repo2", required=False, help="path to repo2 (target implementation) - a sub-folder is fine and faster")
    ap.add_argument("--operation", "-o", action="append", help="limit to operation(s); repeatable")
    ap.add_argument("--out", help="output folder (default parity_out/<ServiceName>: one folder per service; runs for single "
                                   "operations add to it, one diag.txt covers them all)")
    ap.add_argument("--fresh", action="store_true", help="start this service folder over (earlier results and reviewer files "
                                                         "are moved to an _old_<time> folder inside it)")
    ap.add_argument("--schema-dir", action="append", default=[], help="extra folder with local .xsd/.wsdl copies (used when imports cannot be fetched)")
    ap.add_argument("--synonyms", help="JSON file {canonicalName: [alias, ...]} for field/class name mapping")
    ap.add_argument("--insecure", action="store_true", help="skip TLS verification for WSDL fetch (self-signed certs)")
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--include-tests", action="store_true", help="also scan test folders")
    ap.add_argument("--max-depth", type=int, default=8, help="call-graph depth for slicing")
    ap.add_argument("--min-score", type=float, default=0.35, help="minimum score for a repo2 endpoint to count as a match")
    ap.add_argument("--max-rows", type=int, default=40, help="max rows per table in the markdown summary")
    ap.add_argument("--max-rules", type=int, default=30)
    ap.add_argument("--max-review", type=int, default=25)
    ap.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 1),
                    help="parallel processes for parsing source files (default min(8, CPUs)); 1 = single process")
    ap.add_argument("--repo2-entry", action="append", default=[],
                    help="force the repo2 method: 'Class.Method' | 'Method' | 'path/File.cs:line' (applies to all selected ops), "
                         "or 'Operation=Class.Method' per operation; repeatable")
    ap.add_argument("--repo2-map", help="JSON file {\"Operation\": \"Class.Method\", ...} - pins the repo2 method for many operations at once")
    ap.add_argument("--max-fanout", type=int, default=6,
                    help="do not follow a call into more than N implementations of a base class/interface (default 6)")
    ap.add_argument("--max-file-kb", type=int, default=MAX_FILE // 1024, help="skip source files bigger than this (default %d)" % (MAX_FILE // 1024))
    ap.add_argument("--all-rows", action="store_true", help="show MATCH rows too in summary")
    ap.add_argument("--list-ops", action="store_true", help="only list operations and exit")
    ap.add_argument("--collect", nargs="?", const="parity_out", default=None, metavar="FOLDER",
                    help="write FOLDER/share_all.txt (default parity_out) with the checks of every service folder and exit; "
                         "no source code, nothing else is changed")
    ap.add_argument("--no-deep", action="store_true", help="skip the logic pack for the deep business-logic review (saves Copilot tokens)")
    ap.add_argument("--deep-lines", type=int, default=600, help="max source lines in each logic pack (default 600, about 8-10k tokens)")
    ap.add_argument("--db-scripts", action="append", default=[], help="folder/file with .sql scripts (procs, tables, views); repeatable")
    ap.add_argument("--db-server", help="SQL Server to pull definitions from with sqlcmd (read-only catalog queries)")
    ap.add_argument("--db-name", help="database name for --db-server")
    ap.add_argument("--db-user", help="SQL login (password from env var SQLCMDPASSWORD); default Windows auth (-E)")
    ap.add_argument("--db-trust-cert", action="store_true", help="pass -C to sqlcmd (self-signed server certificate)")
    ap.add_argument("--phase", choices=("extract", "full", "report"), default="full",
                    help="extract = step 1 (call graphs, DB object list, SSMS export script - no SQL needed); "
                         "full = complete analysis + logic packs (default); report = build the one final document "
                         "parity_report.md from this analysis plus the reviewer files in <folder>/review/")
    ap.add_argument("--repo1-url", help="web base URL of repo1 for code links (GitHub, GitHub Enterprise, Azure DevOps, GitLab, "
                                        "Bitbucket). Default: the git remote of the checkout")
    ap.add_argument("--repo2-url", help="web base URL of repo2 for code links (see --repo1-url)")
    ap.add_argument("--repo1-ref", help="branch, tag or commit for repo1 links (default: checked-out commit if pushed, else branch)")
    ap.add_argument("--repo2-ref", help="branch, tag or commit for repo2 links")
    ap.add_argument("--graph-nodes", type=int, default=150, help="max methods shown per call flow in the documents (default 150)")
    ap.add_argument("--graph-depth", type=int, default=6, help="max call depth shown in the documents (default 6)")
    ap.add_argument("--no-cache", action="store_true", help="always re-index (default: re-use the index when no file changed)")
    ap.add_argument("--quiet", action="store_true", help="console: only errors and the DIAG card (saves Copilot tokens)")
    ap.add_argument("--no-redact", action="store_true", help="show absolute repo paths in run.log/diag.txt (default: <repo1>/<repo2>)")
    return ap


def input_error(msg, hint=None):
    LOG.event("ERROR", "E-INPUT", msg)
    print("ERROR: " + LOG.r(msg), file=sys.stderr)
    if hint:
        LOG.write("HINT: " + hint)
        print("HINT: " + LOG.r(hint), file=sys.stderr)
    return 2


def collect_share(root):
    """--collect: one text file with everything needed to review step 1/2 results of all service folders.
    Reads only files this tool wrote (paths are already redacted there); writes root/share_all.txt."""
    if not os.path.isdir(root):
        print("ERROR: folder not found: %s (run this from the folder that holds parity_out)" % root)
        return 2
    folders = sorted(d for d in os.listdir(root) if os.path.isfile(os.path.join(root, d, "diag.txt")))
    if not folders:
        print("ERROR: no service folders with diag.txt in %s" % root)
        return 2
    out = ["SOAP-PARITY SHARE  (soap_parity %s, %s)  services: %s" % (VERSION, time.strftime("%Y-%m-%d %H:%M"), ", ".join(folders)), ""]

    def lines(path, pat=None, limit=None):
        try:
            with io.open(path, encoding="utf-8", errors="replace") as fh:
                rows = [ln.rstrip("\r\n") for ln in fh]
        except OSError:
            return ["(missing: %s)" % os.path.basename(path)]
        if pat:
            rows = [ln for ln in rows if re.search(pat, ln)]
        return [ln[:400] for ln in rows[:limit]]

    for name in folders:
        d = os.path.join(root, name)
        out += ["#" * 100, "##### SERVICE %s" % name, "#" * 100, "", "----- diag.txt"]
        out += lines(os.path.join(d, "diag.txt"))
        out += ["", "----- extract_next_steps.md (operations, mappings, CONFIRM)"]
        out += lines(os.path.join(d, "extract_next_steps.md"), r"^- \*\*|^  - |^Run id|^Operations:", 80)
        out += ["", "----- contract types (name:type) - '!' marks something to check"]
        try:
            with io.open(os.path.join(d, "data", "contract.json"), encoding="utf-8") as fh:
                ops = json.load(fh)
            for o in ops:
                for side in ("request", "response"):
                    rows = o.get(side) or []
                    flag = []
                    if any(re.search(r"Field$", str(f.get("name", ""))) or str(f.get("name", "")).startswith("_") for f in rows):
                        flag.append("private-field names")
                    if any(str(f.get("type", "")).startswith(("UNRESOLVED", "RECURSIVE")) for f in rows):
                        flag.append("unresolved types")
                    if side == "response" and len(rows) == 2 and rows[0].get("type") == "(wrapper)" and not rows[1].get("complex"):
                        flag.append("single value: %s" % rows[1].get("type"))
                    out.append("%s %-8s %3d fields%s: %s" % (
                        o.get("name"), side, len(rows), ("  ! " + "; ".join(flag)) if flag else "",
                        ", ".join("%s:%s" % (f.get("name"), f.get("type")) for f in rows[:10]) + (" ..." if len(rows) > 10 else "")))
        except (OSError, ValueError, TypeError, AttributeError) as e:
            out.append("(contract.json not readable: %s)" % type(e).__name__)
        out += ["", "----- run.log: type resolution, skipped files, unresolved calls, svc ops"]
        out += lines(os.path.join(d, "run.log"),
                     r"svc type|ambiguous|svc op |svc:|skipped big file|big designer file|unresolved|ERROR|Traceback", 80)
        out += ["", "----- files"]
        for sub_ in ("db_schema", "review"):
            p_ = os.path.join(d, sub_)
            fl = sorted(os.listdir(p_)) if os.path.isdir(p_) else []
            out.append("%s/: %s" % (sub_, ", ".join("%s (%d KB)" % (f_, os.path.getsize(os.path.join(p_, f_)) // 1024)
                                                   for f_ in fl if os.path.isfile(os.path.join(p_, f_))) or "(none)"))
        out.append("parity_report.md: %s" % ("yes" if os.path.isfile(os.path.join(d, "parity_report.md")) else "no"))
        out.append("")
    dest = os.path.join(root, "share_all.txt")
    with io.open(dest, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    print("written: %s  (%d services, %d KB) - share this file" % (dest, len(folders), os.path.getsize(dest) // 1024))
    return 0


def main(argv=None):
    global MAX_FILE, JOBS, MAX_FANOUT
    ap = build_parser()
    args = ap.parse_args(argv)
    if args.collect:
        return collect_share(args.collect)
    MAX_FANOUT = max(1, args.max_fanout)
    LOG.quiet = args.quiet
    MAX_FILE = max(64, args.max_file_kb) * 1024
    JOBS = max(1, args.jobs)
    args._root_out = None
    if not args.out:
        args._root_out = "parity_out"
        args.out = os.path.join("parity_out", service_folder_name(args))
    for d_ in (args.out, args._root_out):
        if d_:
            OUT_ABS.add(os.path.normcase(os.path.abspath(d_)))
    try:
        os.makedirs(os.path.join(args.out, "data"), exist_ok=True)
    except OSError as e:
        ap.error("cannot create output folder %s: %s" % (args.out, e))
    LOG.open(args.out)
    state = {"ops": [], "results": [], "repo1": None, "repo2": None}
    code, crash = 3, None
    try:
        code = _run(args, state)
    except KeyboardInterrupt:
        code, crash = 130, ["interrupted by user (Ctrl+C)"]
        LOG.event("ERROR", "E-INTERRUPTED", crash[0])
    except Exception as e:  # noqa
        tb = traceback.extract_tb(sys.exc_info()[2])
        crash = ["%s: %s" % (type(e).__name__, e)] + ["at %s:%d in %s" % (os.path.basename(t.filename), t.lineno, t.name) for t in tb[-4:]]
        LOG.event("ERROR", "E-CRASH", crash[0])
        LOG.write(traceback.format_exc())
        code = 3
    LOG.write("exit code %s" % code)
    if not (args.list_ops and code == 0):
        write_card(args, state["ops"], state["results"], state["repo1"], state["repo2"], code, crash)
    if args._root_out and os.path.isdir(args._root_out):
        # parity_out/share_all.txt is refreshed after EVERY run: the one file to share, no extra command needed
        try:
            quiet_, LOG.quiet = LOG.quiet, True
            buf = io.StringIO()
            old_out, sys.stdout = sys.stdout, buf
            try:
                collect_share(args._root_out)
            finally:
                sys.stdout, LOG.quiet = old_out, quiet_
            print("share  %s" % os.path.join(args._root_out, "share_all.txt").replace("\\", "/"), flush=True)
        except Exception as e:  # noqa - the share file is a convenience; never fail the run for it
            LOG.write("share_all.txt not written: %s" % e)
    return code


def service_folder_name(args):
    """parity_out/<this>: the .svc / WSDL file name without extension (URL: last path segment), else repo1's folder name."""
    src = args.svc or args.wsdl or ""
    name = ""
    if src:
        if is_url(src):
            pth = urllib.parse.urlparse(src).path.rstrip("/")
            name = os.path.splitext(pth.rsplit("/", 1)[-1])[0] or urllib.parse.urlparse(src).netloc
        else:
            name = os.path.splitext(os.path.basename(src.rstrip("/\\")))[0]
    if not name and args.repo1:
        name = os.path.basename(os.path.abspath(args.repo1))
    name = re.sub(r"[^\w.\-]+", "_", name).strip("._") or "service"
    return name[:60]


def data_path(args, name):
    return os.path.join(args.out, "data", name)


# files this tool writes into a service folder (moved away by --fresh / when the inputs change)
OWN_OUTPUTS = ("diag.txt", "run.log", "parity_report.md", "call_graph.md", "db_objects.md", "export_db_schema.sql",
               "extract_next_steps.md", "parity_summary.md", "repo2_map.json", "data", "review", "db_scripts")
# also allowed in a service folder: the user's SQL export and moved-away earlier results
USER_OUTPUTS = ("db_schema",)
RUN_ID_NOTE = ("Run id: `%s` - quote this id in your reply. It proves the script ran; never write documents "
               "into this folder yourself except `repo2_map.json` and the files under `review/`.\n")
REVIEW_FILE_RE = re.compile(r"^(?:_overall\.md|[\w.-]+\.md|[\w.-]+\.notes\.json)$")


def check_foreign_files(args):
    """Warn (never delete) about files in the service folder that this tool did not write - typically documents an LLM
    wrote by hand instead of running the script. They would be mistaken for script output."""
    found = []
    try:
        for n in sorted(os.listdir(args.out)):
            p = os.path.join(args.out, n)
            if n in OWN_OUTPUTS or n in USER_OUTPUTS or n.startswith("_old_") or re.match(r"^logic_.*\.md$", n):
                continue
            found.append(n + ("/" if os.path.isdir(p) else ""))
        rv = os.path.join(args.out, "review")
        if os.path.isdir(rv):
            found += ["review/" + n for n in sorted(os.listdir(rv))
                      if not (os.path.isfile(os.path.join(rv, n)) and REVIEW_FILE_RE.match(n))]
    except OSError as e:
        LOG.write("foreign file check skipped: %s" % type(e).__name__)
        return
    if found:
        warn("foreign: %s - %d file(s) not written by soap_parity.py, not used; delete them if an assistant wrote them "
             "by hand" % (", ".join(found[:6]) + (" ..." if len(found) > 6 else ""), len(found)))


def start_over(args, reason):
    """Move earlier results of this folder to _old_<time>/ (nothing is deleted). run.log/diag.txt of THIS run stay."""
    old = os.path.join(args.out, "_old_" + time.strftime("%Y%m%d_%H%M%S"))
    moved = []
    for n in sorted(os.listdir(args.out)):
        if n in ("run.log", "diag.txt") or n.startswith("_old_"):
            continue
        if n in OWN_OUTPUTS or re.match(r"^logic_.*\.md$", n):
            os.makedirs(old, exist_ok=True)
            src = os.path.join(args.out, n)
            try:
                os.replace(src, os.path.join(old, n))
                moved.append(n)
            except OSError as e:
                LOG.write("start over: could not move %s: %s" % (n, e))
    os.makedirs(os.path.join(args.out, "data"), exist_ok=True)
    if moved:
        warn("report: %s - earlier results moved to %s" % (reason, os.path.basename(old)))
    LOG.write("start over (%s): moved %s" % (reason, ", ".join(moved) or "nothing"))


def _run(args, state):
    LOG.write("args: " + " ".join("%s=%s" % (k, v) for k, v in sorted(vars(args).items()) if v not in (None, False, [])))
    # ---- normalise inputs (.svc file / URL)
    if args.wsdl and not is_url(args.wsdl) and args.wsdl.lower().endswith(".svc"):
        if args.svc:
            return input_error("give the .svc either as --wsdl or --svc, not both")
        args.svc, args.wsdl = args.wsdl, None
    if args.svc and not os.path.isfile(args.svc):
        return input_error("svc file not found: %s" % args.svc,
                           "pass the path of the .svc file inside repo1 (e.g. ...\\MyService.svc), or the service URL as --wsdl")
    if args.svc and not args.repo1:
        args.repo1 = find_solution_root(os.path.dirname(os.path.abspath(args.svc)))
        print("repo1 not given: using %s (folder with the .sln above the .svc)" % args.repo1)
        LOG.info["repo1Auto"] = True
    for p, nm in ((args.repo1, "repo1"), (args.repo2, "repo2")):
        if p and not os.path.isdir(p):
            return input_error("%s folder not found: %s" % (nm, p), "check the path; quote it if it contains spaces")
    if not args.list_ops and not args.repo2:
        return input_error("--repo2 is required (unless --list-ops)")
    if not args.no_redact:
        LOG.add_redaction(args.repo1, "<repo1>")
        LOG.add_redaction(args.repo2, "<repo2>")
        LOG.add_redaction(os.path.expanduser("~"), "<home>")
    LOG.info["repo1Name"] = (os.path.basename(os.path.abspath(args.repo1)) + (" (auto from .svc)" if LOG.info.get("repo1Auto") else "")) if args.repo1 else "-"
    LOG.info["repo2Name"] = os.path.basename(os.path.abspath(args.repo2)) if args.repo2 else "-"
    if not args.wsdl and not args.svc:
        if args.repo1:
            args.wsdl = discover_wsdl(args.repo1)
            if args.wsdl:
                print("Using WSDL discovered in repo1: %s" % LOG.r(args.wsdl))
            else:
                svcs = discover_svc(args.repo1)
                if len(svcs) == 1:
                    args.svc = svcs[0]
                    print("Using the only .svc in repo1: %s" % LOG.r(args.svc))
                elif svcs:
                    return input_error("no --wsdl given and repo1 has %d .svc files" % len(svcs),
                                       "pass one with --wsdl <file.svc>. Found: " + ", ".join(os.path.relpath(s, args.repo1) for s in svcs[:10]))
        if not args.wsdl and not args.svc:
            return input_error("--wsdl is required (no *.wsdl or *.svc found in repo1)")
    if args.wsdl and is_url(args.wsdl) and urllib.parse.urlparse(args.wsdl).path.lower().endswith(".svc") \
            and not urllib.parse.urlparse(args.wsdl).query:
        args.wsdl += "?singleWsdl"     # WCF: one document with all schemas inlined
        LOG.write("WCF URL: trying %s first" % args.wsdl)
    if args.synonyms:
        try:
            with open(args.synonyms, encoding="utf-8-sig") as fh:
                syn = json.load(fh)
        except (OSError, ValueError) as e:
            return input_error("cannot read synonyms file %s: %s" % (args.synonyms, e))
    else:
        syn = {}
    names = Names(syn)
    args._repo2_map = {}
    args.graph_nodes, args.graph_depth = max(10, args.graph_nodes), max(1, min(args.graph_depth, 30))
    prev = read_run_info(args)
    if args.fresh:
        start_over(args, "--fresh")
        prev = None
    elif prev and prev.get("inputs") != run_inputs(args):
        start_over(args, "this folder held results for other inputs (service/repo1/repo2 changed)")
        prev = None
    same_inputs = bool(prev)
    args._prev = prev
    auto_map = os.path.join(args.out, "repo2_map.json")
    if not args.repo2_map and os.path.isfile(auto_map):
        if same_inputs:
            args.repo2_map = auto_map
            LOG.info["mapReused"] = True
            LOG.write("re-using %s from the previous run with the same inputs" % auto_map)
        else:
            LOG.write("ignoring %s: it belongs to a run with other inputs" % auto_map)
    if args.repo2_map:
        try:
            with open(args.repo2_map, encoding="utf-8-sig") as fh:
                args._repo2_map = json.load(fh)
        except (OSError, ValueError) as e:
            return input_error("cannot read --repo2-map %s: %s" % (args.repo2_map, e))
        if not isinstance(args._repo2_map, dict):
            return input_error("--repo2-map %s must be a JSON object {\"Operation\": \"Class.Method\"}" % args.repo2_map)
        args._repo2_map = {str(k): str(v) for k, v in args._repo2_map.items() if v}

    repo1 = None
    if args.svc and not args.wsdl:
        # ---- contract from code: index repo1 first
        LOG.info["mode"] = "svc-code"
        LOG.info["contractSrc"] = "svc:" + os.path.basename(args.svc)
        LOG.phase("index-repo1")
        repo1 = state["repo1"] = load_index(args.repo1, args.include_tests, "repo1", not args.no_cache)
        LOG.write("repo1 stats: %s" % dict(repo1.stats))
        LOG.phase("contract-from-svc")
        ops, impl = svc_operations(args.svc, repo1)
        if not ops:
            return input_error("no operations could be built from %s" % args.svc,
                               "check the Service=\"...\" class exists under repo1 and implements a [ServiceContract] interface; "
                               "or pass the service URL / a saved ?singleWsdl file as --wsdl")
    else:
        LOG.info["mode"] = "wsdl" + ("+svc" if args.svc else "")
        LOG.info["contractSrc"] = ("url:" + urllib.parse.urlparse(args.wsdl).netloc) if is_url(args.wsdl) else "file:" + os.path.basename(args.wsdl)
        LOG.phase("load-contract")
        local_dirs = list(args.schema_dir) + ([args.repo1] if args.repo1 else [])
        if not is_url(args.wsdl):
            local_dirs.append(os.path.dirname(os.path.abspath(args.wsdl)))
        loader = Loader(args.insecure, args.timeout, data_path(args, "wsdl_cache"), local_dirs)
        c = Contract(loader)
        c.load(args.wsdl)
        c.resolve_pending()
        ops = c.operations()
        if not ops and args.wsdl.endswith("?singleWsdl"):
            alt = args.wsdl[:-len("?singleWsdl")] + "?wsdl"
            LOG.write("no operations via ?singleWsdl; retrying %s" % alt)
            c = Contract(loader)
            c.load(alt)
            c.resolve_pending()
            ops = c.operations()
        if not ops:
            print("Warnings:\n  " + "\n  ".join(LOG.r(w) for w in WARNINGS[:15]), file=sys.stderr)
            hint = None
            if is_url(args.wsdl):
                hint = ("if the URL needs Windows/NTLM auth, VPN or a proxy, open it in a browser with '?singleWsdl' (WCF) or '?wsdl', "
                        "save it as service.wsdl and pass --wsdl service.wsdl. Or pass the .svc FILE from repo1 (--wsdl X.svc) "
                        "to read the contract from code.")
            return input_error("no operations found in WSDL %s" % args.wsdl, hint)
        if args.svc:
            impl, _, _, impl_ns = read_svc(args.svc)
            LOG.info["svcClass"] = impl
            for o in ops:
                o["implClass"] = impl
                o["implNs"] = impl_ns
    LOG.info["opsTotal"] = len(ops)
    all_ops = ops
    if args.operation:
        wanted = {norm(o) for o in args.operation}
        missing = wanted - {norm(o["name"]) for o in ops} - {norm(o["wsdlName"]) for o in ops}
        if missing:
            return input_error("operation(s) not found: %s" % ", ".join(sorted(missing)),
                               "available: " + ", ".join(o["name"] for o in ops[:60]))
        ops = [o for o in ops if norm(o["name"]) in wanted or norm(o["wsdlName"]) in wanted]
    # one folder per service: operations analysed earlier in this folder stay in the documents and the DIAG card;
    # only the operations asked for now (the "focus") get a new summary / logic pack for Copilot
    prev_ops = set((args._prev or {}).get("ops") or [])
    if args.phase == "report" and not args.operation:
        focus = set()
        keep = prev_ops or {o["name"] for o in all_ops}
    else:
        focus = {o["name"] for o in ops}
        keep = prev_ops | focus
    if not args.list_ops:
        ops = [o for o in all_ops if o["name"] in keep]
    args._focus = focus
    LOG.info["scope"] = "this run %s | folder %d op(s)" % (
        (",".join(sorted(focus))[:50] if len(focus) < len(ops) else "all") if focus else "report only", len(ops))
    state["ops"] = ops
    with open(data_path(args, "contract.json"), "w", encoding="utf-8") as fh:
        json.dump(ops, fh, indent=1)
    if args.list_ops:
        for o in ops:
            print("%-40s req_fields=%-4d resp_fields=%-4d %s" % (o["name"], len(o["request"]), len(o["response"]),
                                                                o.get("codeAt") or o.get("soapAction") or ""))
        return 0

    if repo1 is None and args.repo1:
        LOG.phase("index-repo1")
        repo1 = state["repo1"] = load_index(args.repo1, args.include_tests, "repo1", not args.no_cache)
        LOG.write("repo1 stats: %s" % dict(repo1.stats))
    elif not args.repo1:
        print("repo1 not given: logic/integration comparison will be skipped")
    LOG.phase("index-repo2")
    repo2 = state["repo2"] = load_index(args.repo2, args.include_tests, "repo2", not args.no_cache)
    LOG.write("repo2 stats: %s" % dict(repo2.stats))
    eps2 = repo2_endpoints(repo2)
    LOG.write("repo2 endpoints found: %d" % len(eps2))
    if not eps2:
        warn("entry: no HTTP/SOAP endpoints found in repo2 - is --repo2 the right folder?")
    if args.db_server and not args.db_name:
        return input_error("--db-server needs --db-name")
    own_db = os.path.join(args.out, "db_schema")
    if os.path.isdir(own_db) and not any(os.path.abspath(d) == os.path.abspath(own_db) for d in args.db_scripts):
        args.db_scripts = list(args.db_scripts) + [own_db]
        LOG.write("using SQL scripts saved in %s" % own_db)
    sql_paths = [os.path.join(r.root, rel) for r in (repo1, repo2) if r for rel in r.sql_files] + list(args.db_scripts)
    for d in args.db_scripts:
        if not os.path.exists(d):
            warn("db: --db-scripts path not found: %s" % d)
    if sql_paths:
        CATALOG.add_paths(sql_paths)
        LOG.write("sql catalog: %d file(s), %d object(s)" % (CATALOG.files, len(CATALOG.objects)))
    LOG.phase("analyze")
    results = state["results"]
    for i, op in enumerate(ops, 1):
        t1 = time.time()
        say("  [%d/%d] %s" % (i, len(ops), op["name"]))
        LOG.cur_file = "operation " + op["name"]
        r = analyze_operation(op, repo1, repo2, names, eps2, args)
        LOG.cur_file = None
        results.append(r)
        LOG.write("op %s: verdict=%s overall=%.2f r1Entry=%s r1Files=%d r2=%s r2Files=%d review=%d (%.1fs)" % (
            op["name"], r["verdict"], r["scores"]["overall"], (r.get("repo1Entry") or ["-"])[0], len(r.get("repo1SliceFiles", [])),
            (r.get("repo2Candidates") or [{"at": "-"}])[0]["at"], len(r.get("repo2SliceFiles", [])), len(r.get("review", [])), time.time() - t1))
        for cnd in r.get("repo2Candidates", []):
            LOG.write("   candidate %.2f %s %s %s %s" % (cnd["score"], cnd["at"], cnd.get("method"), cnd.get("verb"), cnd.get("route")))
        s1st = r.get("repo1SliceStats") or {}
        if s1st:
            LOG.write("   repo1 slice: %d methods, %d files%s; fan-out not followed: %s" % (
                s1st["methods"], s1st["files"], " (CAPPED at 400 methods)" if s1st["capped"] else "", ", ".join(s1st["fanoutSkipped"]) or "-"))
            if s1st.get("unresolved"):
                LOG.write("   repo1 calls near the entry that could not be resolved: %s" % ", ".join(s1st["unresolved"]))
            for path, via in sorted((r.get("repo1SliceVia") or {}).items())[:80]:
                LOG.write("   slice file %s  <- %s" % (path, via))
            if s1st["files"] > 40:
                warn("entry: repo1 call path for %s spans %d files - likely over-broad (see 'slice file' lines in run.log)" % (op["name"], s1st["files"]))
        if repo1 and not r.get("repo1Entry"):
            warn("entry: repo1 entry method for %s not found" % op["name"])
        elif repo1 and len(r.get("repo1SliceFiles", [])) <= 2 and (r.get("repo1SliceStats") or {}).get("unresolved"):
            warn("entry: repo1 call path for %s stops after %d file(s); unresolved calls: %s" % (
                op["name"], len(r.get("repo1SliceFiles", [])), ", ".join(r["repo1SliceStats"]["unresolved"][:4])))
        elif repo1 and len(r.get("repo1SliceFiles", [])) <= 1:
            warn("entry: repo1 call path for %s covers only %d file - DI/reflection may hide the logic" % (op["name"], len(r.get("repo1SliceFiles", []))))
        if not r.get("repo2Forced") and (not r.get("repo2Candidates") or r["repo2Candidates"][0]["score"] < args.min_score):
            warn("entry: no repo2 endpoint above --min-score %.2f for %s" % (args.min_score, op["name"]))
    matched = set()
    for r in results:
        if r["repo2Candidates"] and (r.get("repo2Forced") or r["repo2Candidates"][0]["score"] >= args.min_score):
            matched.add(r["repo2Candidates"][0]["at"])
    extra = [e for e in eps2 if "%s:%d" % (e["file"], e["line"]) not in matched]

    pulled = os.path.join(args.out, "db_scripts")
    src_ok = False
    try:
        with open(os.path.join(pulled, "_source.json"), encoding="utf-8") as fh:
            src_ok = json.load(fh) == {"server": args.db_server, "database": args.db_name}
    except (OSError, ValueError):
        pass
    if args.db_server and args.phase == "report" and os.path.isdir(pulled) and src_ok:
        CATALOG.add_paths([pulled])         # report step: re-use what the analysis run pulled, no second DB round-trip
        for r in results:
            d1, d2 = DBKEYS.get(r["operation"], ({}, {}))
            r["dbObjects"] = db_inventory(d1, d2)
    elif args.db_server:
        LOG.phase("db-extract")
        need = db_missing_definitions(results)
        if need:
            say("  pulling %d DB object definition(s) from %s/%s (read-only) ..." % (len(need), args.db_server, args.db_name))
            try:
                n, failed = db_extract(args, need, os.path.join(args.out, "db_scripts"))
                with open(os.path.join(pulled, "_source.json"), "w", encoding="utf-8") as fh:
                    json.dump({"server": args.db_server, "database": args.db_name}, fh)
            except Exception as e:  # noqa
                n, failed = 0, ["%s: %s" % (type(e).__name__, e)]
            LOG.info["dbExtract"] = "%d ok, %d failed" % (n, len(failed))
            for f_ in failed[:20]:
                LOG.write("db-extract: %s" % f_)
            if failed and not n:
                warn("db: --db-extract got nothing (%s) - check sqlcmd is installed, server/db names, and VIEW DEFINITION permission"
                     % failed[0][:120])
            if n:
                CATALOG.add_paths([os.path.join(args.out, "db_scripts")])
                for r in results:
                    d1, d2 = DBKEYS.get(r["operation"], ({}, {}))
                    r["dbObjects"] = db_inventory(d1, d2)
    missing = db_missing_definitions(results)
    with open(data_path(args, "db_objects_to_export.txt"), "w", encoding="utf-8") as fh:
        fh.write("# DB objects used on the call paths whose SQL definition was not found.\n"
                 "# Script them (SSMS: right-click database > Tasks > Generate Scripts > select these objects) into a folder\n"
                 "# and re-run with --db-scripts <folder>, or use --db-server <server> --db-name <db>.\n")
        fh.write("\n".join(missing) + ("\n" if missing else ""))
    LOG.phase("documents")
    check_foreign_files(args)
    if args.phase == "report":
        return finish_report(args, results, repo1, repo2, prev)
    for stale in ("parity_report.md",):
        try:
            os.remove(os.path.join(args.out, stale))     # a report from an earlier analysis must never be mistaken for this one
        except OSError:
            pass
    rp = build_review_pack(args, results, repo1, repo2, {}, True)
    LOG.info["docs"] = "call_graph.md, db_objects.md%s" % ((", export_db_schema.sql (%d objects)" % rp["dbExport"]) if rp.get("dbExport") else "")
    if not args.no_deep and args.phase == "full":
        for r in results:
            op_, s1_, s2_ = SLICES.get(r["operation"], (None, None, None))
            if op_ is None or r["operation"] not in args._focus:
                continue
            fn = os.path.join(args.out, "logic_%s.md" % re.sub(r"[^\w.-]+", "_", r["operation"]))
            r["logicPackKB"] = int(round(write_logic_pack(fn, op_, r, repo1, s1_, repo2, s2_, args.deep_lines, rp["ctx"]) / 1024.0))
            r["logicPack"] = fn.replace("\\", "/")
    LOG.phase("write")
    with open(data_path(args, "parity.json"), "w", encoding="utf-8") as fh:
        json.dump(jsonable({"version": VERSION, "wsdl": args.wsdl or args.svc, "repo1": repo1.summary() if repo1 else None,
                            "repo2": repo2.summary(), "results": results, "warnings": WARNINGS,
                            "repo2Endpoints": [{k: v for k, v in e.items() if k not in ("f", "m")} for e in eps2]}), fh, indent=1)
    for label, repo in (("repo1", repo1), ("repo2", repo2)):
        if repo:
            with open(data_path(args, label + "_index.json"), "w", encoding="utf-8") as fh:
                json.dump({"summary": repo.summary(), "stats": dict(repo.stats), "bigFilesSkipped": repo.big_files[:200],
                           "hits": [{k: v for k, v in h.items() if k != "fidx"} for h in repo.hits],
                           "classes": {n: [{"file": c_["file"], "line": c_["start"] + 1, "kind": c_["kind"], "parents": c_["parents"],
                                            "table": c_["table"], "fields": [(f["name"], f["type"]) for f in c_["fields"]]} for c_ in v]
                                       for n, v in repo.classes.items()},
                           "config": {k: v[0] for k, v in repo.config.items() if HOST_RE.search(v[0]) or JDBC_RE.search(v[0])}},
                          fh, indent=1)
    summary = os.path.join(args.out, "parity_summary.md")
    if not args.wsdl:
        args.wsdl = "svc:" + os.path.basename(args.svc)
    f_ops = [o for o in ops if o["name"] in args._focus]
    f_res = [r for r in results if r["operation"] in args._focus]
    write_summary(summary, f_ops, f_res, args, repo1, repo2, extra, global_checks(f_ops, repo1, repo2))
    say("\nDone. %d operation(s)." % len(results))
    for r in results:
        say("  %-35s %-40s overall=%.2f" % (r["operation"], r["verdict"], r["scores"]["overall"]))
    if args.phase == "extract":
        write_next_steps(os.path.join(args.out, "extract_next_steps.md"), f_res, args, rp)
    write_run_info(args, [r["operation"] for r in results])
    say("\nSummary for the LLM : %s\nFull detail         : %s" % (summary, data_path(args, "parity.json")))
    return 0


def run_inputs(args):
    """What identifies a service folder: service + repos (paths normalised). The operation filter is NOT part of it -
    runs for single operations add to the same folder."""
    n = lambda x: os.path.normcase(os.path.abspath(x)) if x else None
    svc = args.svc or args.wsdl
    if svc and svc.startswith("svc:"):
        svc = args.svc
    svc = re.sub(r"\?(singleWsdl|wsdl)$", "", svc, flags=re.I) if (svc and is_url(svc)) else svc
    return {"service": svc if (svc and is_url(svc)) else n(svc), "repo1": n(args.repo1), "repo2": n(args.repo2)}


def read_run_info(args):
    try:
        with open(data_path(args, "run_info.json"), encoding="utf-8") as fh:
            v = json.load(fh)
        return v if isinstance(v, dict) else None
    except (OSError, ValueError):
        return None


def write_run_info(args, ops_in_folder):
    """ops: every operation in this folder; opsTime: when each was last analysed on request (reviews older than that
    are marked as possibly out of date in the report)."""
    prev = args._prev or {}
    t = time.time()
    ops_time = dict(prev.get("opsTime") or {})
    for o in args._focus:
        ops_time[o] = t
    try:
        with open(data_path(args, "run_info.json"), "w", encoding="utf-8") as fh:
            json.dump({"version": VERSION, "phase": args.phase, "created": prev.get("created") or t, "analysisTime": t,
                       "inputs": run_inputs(args), "ops": sorted(set(ops_in_folder)), "opsTime": ops_time}, fh, indent=1)
    except OSError as e:
        LOG.write("run_info.json not written: %s" % e)


def op_file(op_name):
    return re.sub(r"[^\w.\-]+", "_", op_name).strip("._") or "operation"


def finish_report(args, results, repo1, repo2, prev):
    """--phase report. Reviewer files live in <folder>/review/: _overall.md, <Operation>.md, <Operation>.notes.json.
    The folder belongs to one service + repos (start_over() moves everything away when they change), so files of
    another service can never be merged. A review written before the latest analysis of its operation is kept but
    marked as possibly out of date."""
    rdir = os.path.join(args.out, "review")
    ops_time = (prev or {}).get("opsTime") or {}
    notes, llm, stale = {}, {"overall": None, "ops": {}}, []
    ov = os.path.join(rdir, "_overall.md")
    if os.path.isfile(ov):
        llm["overall"] = read_llm_review(ov)
    wanted = {op_file(r["operation"]) + ".md" for r in results} | {"_overall.md"}
    if os.path.isdir(rdir):
        llm["orphans"] = []
        for fn in sorted(os.listdir(rdir)):
            if fn.lower().endswith(".md") and fn not in wanted:
                t_ = read_text_any(os.path.join(rdir, fn))
                if t_ and t_.strip():
                    llm["orphans"].append((fn, t_.strip()))
    for r in results:
        name = r["operation"]
        fp = os.path.join(rdir, op_file(name) + ".md")
        if os.path.isfile(fp):
            txt = read_op_review(fp, name)
            if txt:
                old = os.path.getmtime(fp) + 2 < (ops_time.get(name) or 0)
                if old:
                    stale.append(name)
                    txt = ("> **Note:** this review was written on %s, before the latest analysis of this operation (%s). "
                           "It may be out of date.\n\n" % (time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(fp))),
                                                             time.strftime("%Y-%m-%d %H:%M", time.localtime(ops_time[name])))) + txt
                llm["ops"][norm(name)] = txt
        npth = os.path.join(rdir, op_file(name) + ".notes.json")
        if os.path.isfile(npth):
            notes.update(load_method_notes(npth))
    if stale:
        warn("report: review older than the latest analysis for %s (marked in the report)" % ", ".join(stale[:5]))
    rp = build_review_pack(args, results, repo1, repo2, notes, False)
    out = os.path.join(args.out, "parity_report.md")
    write_report(out, results, rp["ctx"], llm, args)
    ctx = rp["ctx"]
    used = set()
    for p_ in (ctx.get("pack1"), ctx.get("pack2")):
        if p_:
            used |= p_.used_notes
    unused = sorted(set(notes) - used)
    if unused:
        LOG.write("method notes not matching any method on the call paths: %s" % ", ".join(unused[:30]))
    n_rev = len(llm["ops"])
    LOG.info["report"] = "parity_report.md | reviews %d/%d op(s)%s | method notes %d/%d used" % (
        n_rev, len(results), "" if llm["overall"] else ", NO _overall.md", len(used), len(notes))
    if n_rev < len(results) or not llm["overall"]:
        miss = [r["operation"] for r in results if norm(r["operation"]) not in llm["ops"]]
        warn("report: parity_report.md built without reviewer text for %s" % (
            ", ".join(miss[:5] + (["_overall.md"] if not llm["overall"] else []))))
    say("\nReport: %s" % out)
    return 0


OP_VERB_RE = re.compile(r"^(Get|Cancel|Process|Submit|Create|Calculate|Generate|Update|Delete|Remove|Add|Find|Search|Save|"
                        r"Run|Retrieve|Fetch|Set|Send|Validate|Check|Insert|Load|Execute|Do|Handle|Post|Put)(?=[A-Z])")


def search_terms(op_name):
    """Search hints for an unmapped operation: the name without its verb, its words (compounds such as PostDated kept)."""
    rest = OP_VERB_RE.sub("", op_name or "") or op_name or ""
    toks = tokens(rest)
    out, i = [], 0
    while i < len(toks):                 # keep compounds a verb list would split: PostDated, PreAuth, ...
        t = toks[i]
        if t in ("post", "pre", "re", "non", "multi", "sub") and i + 1 < len(toks):
            t, i = t + toks[i + 1], i + 1
        if t not in VERBS and not t.isdigit() and t not in out:
            out.append(t)
        i += 1
    terms = ([rest] if rest and rest != op_name and rest.lower() not in out else []) + out
    return terms[:7] or [op_name]


def write_next_steps(path, results, args, rp):
    """Step 1 hand-off: tiny file for Copilot (what to map) and the user (what to export)."""
    unmatched = [r for r in results if not r.get("repo2SliceFiles") or r.get("repo2PinFailed")]
    L = ["# Step 1 result (auto-generated by soap_parity.py %s)" % VERSION, "", RUN_ID_NOTE % LOG.run_id,
         "Operations: %d | repo2 endpoint found: %d | not found: %d" % (len(results), len(results) - len(unmatched), len(unmatched)), ""]
    if unmatched:
        L += ["## For Copilot: operations without a repo2 endpoint", "",
              "**MANDATORY before you reply.** These operations are UNMAPPED - repo2 was not followed yet. That is NOT a "
              "verdict: never report them as not implemented in step 1.", "",
              "Batch-style operations (Process/Run/Recover/Queued/Postdated...) are usually background jobs in repo2, not "
              "HTTP endpoints: search for BackgroundService, IHostedService, Quartz IJob, Hangfire RecurringJob, Azure "
              "Functions triggers or queue consumers, and pin the job's Execute/Run method with `path:line`.", "",
              "Candidates below are picked only by name/field similarity - low scores are usually UNRELATED. Use one only if "
              "its method name and route clearly do the same thing as the operation.", "",
              "For each operation: if a listed candidate is clearly the counterpart, use it. Otherwise search repo2 (the "
              "search terms, request field names, top-level response field names; repo2 may use REST names). Write each "
              "counterpart to `%s/repo2_map.json` as `{\"Operation\": \"path/File.cs:line\"}` - the path and line exactly as "
              "listed below or of the method/`MapPost` line you found (`Class.Method` also works but is less precise). Keep "
              "entries already in it, fix entries marked PIN FAILED, and re-run step 1 ONCE (the map is picked up "
              "automatically). Not found after searching: report `no repo2 counterpart found (searched: <terms>)` - that is not a "
              "verdict either; verdicts are made in step 2." % args.out.replace("\\", "/"), ""]
        for r in unmatched:
            c = r.get("contract", {})
            req = [x["path"].split("/")[-1] for x in (c.get("request") or {}).get("rows", [])
                   if x["path"].count("/") <= 2 and x.get("status") != "EXTRA_IN_REPO"][:8]
            res = [x["path"].split("/")[-1] for x in (c.get("response") or {}).get("rows", [])
                   if x["path"].count("/") <= 2 and x.get("status") != "EXTRA_IN_REPO"][:8]
            L.append("- **%s** - search terms: %s; request: %s; response: %s" % (
                r["operation"], ", ".join(search_terms(r["operation"])), ", ".join(req) or "-", ", ".join(res) or "-"))
            pf = r.get("repo2PinFailed")
            if pf:
                L.append("  - PIN FAILED: `%s` matched nothing in repo2. Closest: %s" % (
                    pf["pin"], "; ".join("`%s`" % x for x in pf["closest"]) or "none"))
            cands = [c for c in (r.get("repo2Candidates") or []) if c.get("score", 0) > 0][:3]
            if cands:
                L.append("  - candidates (score; below %.2f is not followed): %s" % (args.min_score, "; ".join(
                    "`%s` %s%s (%.2f)" % (c["at"], c["method"], (" " + (c.get("verb") or "") + " " + c["route"]) if c.get("route") else "",
                                          c["score"]) for c in cands)))
        L.append("")
    mapped = [r for r in results if r not in unmatched]
    if mapped:
        L += ["## Operations already mapped to repo2", "",
              "Full path of each repo2 counterpart (for your reply and for the user to check). `auto` = picked by the script, "
              "`pinned` = from `repo2_map.json`. Every match marked CONFIRM has a low score (contracts of a REST rewrite often "
              "differ, so a low score alone is no proof it is wrong): open ±15 lines at that path and check it does the same "
              "thing, and say what you saw. If it does not, pin the right one in `repo2_map.json` (path:line) and re-run step 1 "
              "once.", ""]
        for r in mapped:
            c = (r.get("repo2Candidates") or [{}])[0]
            auto = not r.get("repo2Forced")
            L.append("- **%s** -> `%s` %s%s (score %.2f, %s)%s" % (
                r["operation"], c.get("at", "-"), c.get("method", ""),
                (" " + (c.get("verb") or "") + " " + c["route"]) if c.get("route") and c["route"] != "(forced)" else "",
                c.get("score", 0), "auto" if auto else "pinned",
                " - CONFIRM" if c.get("score", 0) < (0.5 if auto else 0.35) else ""))
        L.append("")
    n = rp.get("dbExport") or 0
    L += ["## For the user", "",
          "- `call_graph.md` - preview of the old and new call flows, external calls and DB objects per operation.",
          "- `db_objects.md` - %s" % ("%d DB object(s) on the call paths and how to export their SQL definitions." % n if n else "no DB objects found."),
          ]
    if n:
        L += ["- `export_db_schema.sql` - run it in SSMS (read-only), save the result as `%s\\db_schema\\<database>.sql` "
              "(this folder; it is picked up automatically)." % args.out.replace("/", "\\"),
              "- Then step 2: `/soap-parity` with the same inputs."]
    else:
        L += ["- Then step 2: `/soap-parity` with the same inputs."]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


def discover_svc(repo1_path):
    out = []
    for root, dirs, files in os.walk(repo1_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".") and not is_out_dir(root, d)]
        out.extend(os.path.join(root, f) for f in files if f.lower().endswith(".svc"))
    return sorted(out)


if __name__ == "__main__":
    sys.exit(main())
