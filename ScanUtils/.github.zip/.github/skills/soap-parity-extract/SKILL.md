---
name: soap-parity-extract
description: SOAP parity STEP 1 (no database access needed). Runs the bundled script soap_parity.py - never analyse the code by hand. For a legacy SOAP/WCF service (.svc, WSDL URL or file) in repo1 and a new codebase (repo2), map each operation to its repo2 endpoint, draw the old and new call flows with code links, list the DB objects (procs, tables) and create a read-only SSMS script the user runs to export their SQL. Use when asked to start a SOAP parity check, "extract the call graph / DB objects", or before /soap-parity when the DB schema is needed. Step 2 is the soap-parity skill.
---

# SOAP parity - step 1: extract (token-budgeted)

## HARD RULES (non-negotiable - a run that breaks one is invalid)
1. **Your FIRST action is running the script command below in the terminal.** Do not open, search or read any file of
   repo1/repo2 before the script has finished successfully.
2. **Never do the analysis yourself.** Call flows, DB object lists, SQL export scripts and summaries come ONLY from the
   script. Never write `INDEX.md`, `diag.txt`, `call_graph.md`, `db_objects.md`, a summary or any other document by hand.
   The only file you may write is `FOLDER/repo2_map.json`.
3. **If the script cannot run** (python not found, error, exit code not 0), STOP: show the error and the DIAG card (if
   any) and ask the user to share it. Do NOT fall back to reading the code and producing results yourself.
4. **Proof:** the first line of your reply is the card's `run    id <id>` value and its `folder` line, copied exactly.
   If you do not have them, you did not run the script - go back to rule 1.
5. **Step 1 gives no verdicts.** Never call an operation NOT_IMPLEMENTED, MISSING, PARTIAL or "done" in your reply -
   verdicts are made in step 2. An operation whose card line shows `0files` or `r2 NONE` is UNMAPPED (repo2 was not
   followed yet), not "not implemented". The verdict words on the card are provisional and must not be repeated.
6. **You may not reply before step 3 is done** for every operation listed in `extract_next_steps.md`. A reply that
   only summarises the first script run is invalid.

This skill uses the script of the `soap-parity` skill: `.github/skills/soap-parity/soap_parity.py` (Python 3.8+,
standard library only). Run it from the workspace root. If that path does not exist, look for `soap_parity.py` in the
sibling folder `../soap-parity/` of this file. Never copy or edit the script.

## Inputs
Take them from the user's message; ask once for a missing required one, do not guess. Optional ones may stay empty.
- **service** (required): the `.svc` file in repo1, OR a WSDL URL / `.wsdl` file
- **repo2** (required): path to repo2 (prefer the solution root so dependent projects are included)
- repo1: path to repo1 (optional with a `.svc` - defaults to the `.sln` folder)
- operation: one operation name (empty = all operations in one run)
- repo2entry: `Class.Method` of the repo2 endpoint, if known
- repo1url / repo2url: web URLs of the repos for code links (e.g. `https://github.com/org/repo`)

Never put a password or connection string on the command line or in chat.

## Output folder
The script always uses ONE folder per service, `parity_out/<ServiceName>` (shown on the DIAG card's `folder` line;
called FOLDER below). Never pass `--out` and never create other `parity_out_*` folders. Runs for single operations add
to the same FOLDER; one `diag.txt` covers all of them.

## Budget
You read ONE small file (`FOLDER/extract_next_steps.md`) plus the repo2 searches of step 3 (±15 lines per hit). Never
open `call_graph.md`, `db_objects.md` or the SQL script - they are for the user. No other browsing of the repos.

## Steps
1. **Run**:
   ```
   python .github/skills/soap-parity/soap_parity.py --phase extract --wsdl "<service>" --repo2 "<repo2>" [--repo1 "<repo1>"] [-o <operation>] [--repo2-entry <Class.Method>] [--repo1-url "<repo1url>"] [--repo2-url "<repo2url>"] --quiet
   ```
   Use `py -3` if `python` is missing. Quote paths. Omit empty options. Wait for it to finish; never start it twice.
2. Exit code 2/3: show the ERROR/HINT and the DIAG card, ask the user to share `parity_out/diag.txt`, stop.
3. **Map repo2 (MANDATORY - step 1 is not finished without it).** Read `FOLDER/extract_next_steps.md`. For EVERY
   operation under **"For Copilot: operations without a repo2 endpoint"** (also those marked PIN FAILED):
   a. look at its listed candidates (`path:line`, score); if one is the counterpart, use it;
   b. otherwise search repo2 for it (the nouns / field names it lists, and REST-style names: `Cancel...` -> `cancel`,
      `Get...List` -> `GET` + plural noun, `Submit...` -> `POST`); open at most ±15 lines per hit to confirm.
      Batch-style operations (`Process...`, `Run...`, `Recover...`, `...Queued...`, `...Postdated...`) are usually background jobs in repo2, not HTTP endpoints: also search for `BackgroundService`, `IHostedService`, `IJob` (Quartz), `RecurringJob`/`BackgroundJob` (Hangfire), `[Function]`/`TimerTrigger`/`ServiceBusTrigger` (Azure Functions), queue consumers (`IConsumer<`, `ProcessMessageAsync`), and pin the job's `Execute`/`Run`/`ExecuteAsync` method with `path:line`. If repo2 has no job project, say so: the job may live in another repo.;
   c. write each counterpart you are reasonably sure of to `FOLDER/repo2_map.json` as
      `{"Operation": "path/File.cs:line"}` - the path and line as listed, or of the method / `MapPost(...)` line you
      found; never guess class names. Keep the other entries; replace PIN FAILED ones.
   d. under **"Operations already mapped to repo2"**, check each match marked CONFIRM - auto or pinned, also pins re-used from an earlier run (±15 lines at its path; say
      in the reply what the method does); if it
      is wrong, pin the right one as in c.
   Then re-run the SAME command once if you changed `repo2_map.json` (the map is picked up automatically). Check the card's `map` line: `failed 0`,
   and `unmatched` only for operations you searched for and did not find. Do not compare code yourself.
4. Reply in at most ~15 lines:
   - line 1: `Run id: <id> | folder: <folder line>` from the LAST card (rule 4);
   - line 2: the card's `map` line, copied exactly;
   - per operation: `mapped -> <full path:line from extract_next_steps.md> (auto / pinned; sure / likely)` or
     `no repo2 counterpart found (searched: <terms>)`;
   - DIAG warnings (codes + one line each), if any;
   - for the user: open `FOLDER/call_graph.md` and `FOLDER/db_objects.md`; run `FOLDER/export_db_schema.sql` in SSMS
     (read-only; Results to Grid, Ctrl+A, Ctrl+C) and save the result as `FOLDER/db_schema/<database>.sql` - it is
     picked up automatically;
   - next step: `/soap-parity` with the same inputs;
   - last line: `To share the results: parity_out/share_all.txt (updated by every run).`
