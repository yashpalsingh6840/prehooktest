---
applyTo: '**'
description: 'SOAP parity requests must use the soap-parity skills and their script - never a hand-made analysis.'
---

# SOAP parity: always use the script

When the user asks for a SOAP/WCF parity check, a SOAP-to-REST migration comparison, a call graph or DB object list of a
`.svc`/WSDL service, or mentions `soap-parity` or `parity_out`:

- Use the skills `soap-parity-extract` (step 1) and `soap-parity` (step 2) in `.github/skills/`, or the prompts
  `/soap-parity-extract` and `/soap-parity`. Your first action is running `.github/skills/soap-parity/soap_parity.py`
  in the terminal, exactly as the skill says.
- Never produce the analysis by reading the code yourself, and never write files into `parity_out/` except
  `repo2_map.json` and the files under `review/` that the skill asks for.
- If the script fails, stop and show the error and the DIAG card. Do not improvise a result.
- Start the reply with the `run id` and `folder` line from the last DIAG card.
