---
description: 'SOAP parity check: compare a legacy SOAP/WCF operation (repo1) with repo2 - contract, DB, outbound calls, messaging, validations, business rules. A local script does the extraction so the LLM only verifies evidence.'
agent: 'agent'
argument-hint: 'service=<.svc file | WSDL url/file> repo2=<path> [repo1=<path>] [operation=<name>]'
---

# SOAP parity check

Inputs (ask once for any that are missing, do not guess):
- Service: ${input:service:Path to the .svc file in repo1, OR WSDL URL / .wsdl file}
- repo2 (new implementation - a sub-folder that likely holds the match is fine): ${input:repo2:Path to repo2}
- repo1 (optional when a .svc file is given - defaults to the folder holding the .sln): ${input:repo1:Path to repo1 or leave empty}
- Operation (recommended for big services): ${input:operation:Operation name or leave empty for all}

Follow the `soap-parity` skill in `.github/skills/soap-parity/SKILL.md` exactly. Short form:

1. **Run the extractor - do not analyse the repos yourself.** (Skip this step only if the user says it was already run.)
   ```
   python .github/skills/soap-parity/soap_parity.py --wsdl "<service>" --repo2 "<repo2>" [--repo1 "<repo1>"] [-o <operation>] --out parity_out
   ```
   - Use `py -3` if `python` is not found. Quote every path. Omit `--repo1` / `-o` when empty.
   - Big repos take minutes (progress lines are printed). Let the command finish; do not start it twice.
   - The run always ends with a `SOAP-PARITY DIAG` card (also saved to `parity_out/diag.txt`).
2. **Exit code 2 or 3**: show the ERROR/HINT lines and the DIAG card to the user, tell them to share `parity_out/diag.txt` (or a screenshot of the card) for a fix, and stop.
3. If the card has warnings `W-SVC`, `W-ENTRY`, `W-INDEX-FAIL`, `W-LIMIT` or `W-XSD-*`, tell the user before continuing (results may be incomplete).
4. Read **only** `parity_out/parity_summary.md`. Do not open `parity.json`, `*_index.json`, `run.log` or whole source files.
5. Verify **only** the items in each operation's "LLM review queue" (max 25 per operation). For each item read just the referenced lines ±15 (one range read per ref). Use text search inside the listed "repo2 reachable files" when you need the repo2 counterpart of a repo1 rule.
6. Write `parity_out/parity_report.md` in the format defined in the skill, then reply with the overview table, the top gaps, and the DIAG card's OPERATION table.
