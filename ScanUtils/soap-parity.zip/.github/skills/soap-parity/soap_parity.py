#!/usr/bin/env python3
"""
soap_parity.py - Deterministic SOAP (repo1) vs codebase (repo2) parity extractor.

Python 3.8+, standard library only (no pip install needed).

It does the heavy lifting OUTSIDE the LLM so Copilot only has to read a small
summary and verify a short list of file:line evidence:

  1. Reads the WSDL (URL or file), follows wsdl:import / xsd:import / xsd:include,
     flattens request/response/fault payloads into field paths with types,
     cardinality and XSD restrictions.
  2. Indexes repo1 and repo2 source code (Java/Kotlin/C#/TS/JS/Python/Go):
     classes, DTO fields + validation annotations, methods, endpoints,
     outbound HTTP/SOAP calls, DB access (SQL tables, stored procs, repositories),
     messaging, validations, error handling, config URLs.
  3. Per SOAP operation, finds the entry method in repo1 and the best candidate
     endpoint in repo2, slices the reachable code (method-level call graph,
     best effort), and compares contract, integrations, validations and
     business-rule literals.
  4. Writes out/parity_summary.md (small, for the LLM) + out/parity.json (full).

Usage:
  python soap_parity.py --wsdl "https://host/Service?wsdl" --repo1 C:\\src\\legacy --repo2 C:\\src\\new
  python soap_parity.py --wsdl path\\to\\service.wsdl --repo2 C:\\src\\new --operation GetQuote
  python soap_parity.py --wsdl ... --list-ops

Auth for WSDL URLs (never pass secrets on the command line):
  set SOAP_PARITY_USER / SOAP_PARITY_PASSWORD   -> HTTP Basic
  set SOAP_PARITY_HEADER="Authorization: Bearer xyz" -> any single header
  HTTPS_PROXY / HTTP_PROXY are honoured.
"""
import argparse
import base64
import difflib
import io
import json
import os
import platform
import re
import ssl
import sys
import time
import traceback
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from collections import defaultdict, deque

VERSION = "1.1.0"
XSD = "http://www.w3.org/2001/XMLSchema"
WSDL11 = "http://schemas.xmlsoap.org/wsdl/"
WSDL20 = "http://www.w3.org/ns/wsdl"
SOAP_NS = ("http://schemas.xmlsoap.org/wsdl/soap/", "http://schemas.xmlsoap.org/wsdl/soap12/")

WARNINGS = []

# Warning codes: shown in the diagnostic card (diag.txt) so a screenshot is enough to diagnose a run.
WARN_CODES = [
    ("W-WSDL-LOAD", r"could not load|could not parse|not a WSDL"),
    ("W-XSD-UNRESOLVED", r"unresolved|not found for|element .* not found"),
    ("W-XSD-NS", r"imported without schemaLocation|unknown prefix|resolved by local name"),
    ("W-INDEX-FAIL", r"failed to index"),
    ("W-SVC", r"^svc:"),
    ("W-ENTRY", r"^entry:"),
    ("W-LIMIT", r"^limit:"),
]


def warn_code(msg):
    for code, rx in WARN_CODES:
        if re.search(rx, msg):
            return code
    return "W-OTHER"


class RunLog:
    """run.log (full, timestamped) + diag.txt (crisp card, screenshot-friendly). Absolute roots are redacted."""

    def __init__(self):
        self.t0 = time.time()
        self.fh = None
        self.phases = []          # (name, seconds)
        self.cur_phase = "startup"
        self.cur_t = self.t0
        self.cur_file = None      # file being indexed (shown on crash)
        self.redact = []          # (abs path, token)
        self.info = {}
        self.events = []          # (level, code, msg)
        self.out_dir = None

    def open(self, out_dir):
        self.out_dir = out_dir
        try:
            self.fh = open(os.path.join(out_dir, "run.log"), "w", encoding="utf-8")
        except OSError:
            self.fh = None
        self.write("soap_parity %s  python %s  %s" % (VERSION, sys.version.split()[0], platform.platform()))

    def add_redaction(self, path, token):
        if path:
            ap = os.path.abspath(path)
            self.redact.append((ap, token))
            self.redact.append((ap.replace("\\", "/"), token))
            self.redact.sort(key=lambda x: -len(x[0]))

    def r(self, s):
        s = str(s)
        for p, tok in self.redact:
            if p and p in s:
                s = s.replace(p, tok)
        return s

    def write(self, msg, echo=False):
        line = "%7.1fs [%s] %s" % (time.time() - self.t0, self.cur_phase, self.r(msg))
        if self.fh:
            try:
                self.fh.write(line + "\n")
                self.fh.flush()
            except OSError:
                pass
        if echo:
            print(self.r(msg), flush=True)

    def phase(self, name):
        now = time.time()
        if self.cur_phase != "startup":
            self.phases.append((self.cur_phase, now - self.cur_t))
        self.write("phase end: %s (%.1fs)" % (self.cur_phase, now - self.cur_t))
        self.cur_phase, self.cur_t = name, now
        print("[%s] %s ..." % (time.strftime("%H:%M:%S"), name), flush=True)

    def event(self, level, code, msg):
        self.events.append((level, code, self.r(msg)))
        self.write("%s %s %s" % (level, code, msg))


LOG = RunLog()


def warn(msg):
    if msg not in WARNINGS:
        WARNINGS.append(msg)
        LOG.event("WARN", warn_code(msg), msg)
        if len(WARNINGS) <= 25:
            print("WARN: " + LOG.r(msg), file=sys.stderr)
        elif len(WARNINGS) == 26:
            print("WARN: (more warnings - see run.log)", file=sys.stderr)


def q(ns, tag):
    return "{%s}%s" % (ns, tag)


def local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


# --------------------------------------------------------------------------- names

def norm(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def tokens(s):
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", s or "")
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", s)
    return [t for t in re.split(r"[^A-Za-z0-9]+", s.lower()) if t]


VERBS = {"get", "create", "add", "update", "delete", "remove", "find", "fetch", "retrieve", "process",
         "do", "handle", "submit", "post", "put", "patch", "save", "search", "list", "query", "request",
         "response", "api", "v1", "v2", "v3", "v4", "by", "for", "and", "the", "async", "op", "operation"}


def stem(t):
    return t[:-1] if len(t) > 3 and t.endswith("s") and not t.endswith("ss") else t


def nouns(*names):
    out = set()
    for n in names:
        for t in tokens(n):
            if t not in VERBS and not t.isdigit():
                out.add(stem(t))
    return out


class Names:
    def __init__(self, synonyms):
        self.syn = {}
        for canon, aliases in (synonyms or {}).items():
            c = norm(canon)
            self.syn[c] = c
            for a in aliases if isinstance(aliases, list) else [aliases]:
                self.syn[norm(a)] = c

    def sim(self, a, b):
        na, nb = norm(a), norm(b)
        if not na or not nb:
            return 0.0
        if na == nb:
            return 1.0
        if self.syn.get(na) and self.syn.get(na) == self.syn.get(nb):
            return 0.95
        ta, tb = tokens(a), tokens(b)
        if ta and len(ta) == len(tb) and all(
                (x == y) or (min(len(x), len(y)) >= 2 and (x.startswith(y) or y.startswith(x))) for x, y in zip(ta, tb)):
            return 0.85
        if min(len(na), len(nb)) >= 4 and (na.endswith(nb) or nb.endswith(na) or na.startswith(nb) or nb.startswith(na)):
            return 0.8
        return round(difflib.SequenceMatcher(None, na, nb).ratio() * 0.9, 3)


# --------------------------------------------------------------------------- WSDL / XSD loading

def is_url(s):
    return bool(re.match(r"^https?://", s or "", re.I))


def join_loc(base, rel):
    if re.match(r"^[a-z][a-z0-9+.-]*://", rel, re.I):
        return rel
    if is_url(base):
        return urllib.parse.urljoin(base, rel)
    return os.path.normpath(os.path.join(os.path.dirname(base), rel))


def parse_xml(data):
    """Parse XML keeping in-scope namespace prefixes for every element."""
    if b"<!ENTITY" in data[:20000]:
        raise ValueError("document declares XML entities; refused for safety")
    stack, pending, nsmaps, root = [{}], {}, {}, None
    for ev, obj in ET.iterparse(io.BytesIO(data), events=("start-ns", "start", "end")):
        if ev == "start-ns":
            pending[obj[0] or ""] = obj[1]
        elif ev == "start":
            m = dict(stack[-1])
            m.update(pending)
            pending = {}
            nsmaps[obj] = m
            stack.append(m)
            if root is None:
                root = obj
        else:
            stack.pop()
    return root, nsmaps


class Loader:
    def __init__(self, insecure=False, timeout=30, cache_dir=None, local_dirs=()):
        self.insecure, self.timeout, self.cache_dir = insecure, timeout, cache_dir
        self.manifest = {}
        self.by_ns, self.by_base = defaultdict(list), defaultdict(list)
        for d in local_dirs:
            self._index_local(d)

    def _index_local(self, d):
        if not d or not os.path.isdir(d):
            return
        for root, dirs, files in os.walk(d):
            dirs[:] = [x for x in dirs if x not in SKIP_DIRS]
            for f in files:
                if f.lower().endswith((".xsd", ".wsdl")):
                    p = os.path.join(root, f)
                    self.by_base[f.lower()].append(p)
                    try:
                        with open(p, "rb") as fh:
                            head = fh.read(8000).decode("utf-8", "replace")
                        m = re.search(r'targetNamespace\s*=\s*["\']([^"\']+)', head)
                        if m:
                            self.by_ns[m.group(1)].append(p)
                    except OSError:
                        pass

    def fetch(self, loc):
        if is_url(loc):
            req = urllib.request.Request(loc, headers={"User-Agent": "soap-parity/" + VERSION})
            user = os.environ.get("SOAP_PARITY_USER")
            if user:
                tok = base64.b64encode(("%s:%s" % (user, os.environ.get("SOAP_PARITY_PASSWORD", ""))).encode()).decode()
                req.add_header("Authorization", "Basic " + tok)
            hdr = os.environ.get("SOAP_PARITY_HEADER", "")
            if ":" in hdr:
                k, v = hdr.split(":", 1)
                req.add_header(k.strip(), v.strip())
            ctx = ssl._create_unverified_context() if self.insecure else None
            with urllib.request.urlopen(req, timeout=self.timeout, context=ctx) as r:
                data = r.read()
        else:
            p = loc
            if loc.lower().startswith("file:"):
                p = urllib.request.url2pathname(urllib.parse.urlparse(loc).path)
            with open(p, "rb") as fh:
                data = fh.read()
        self._save(loc, data)
        return data

    def _save(self, loc, data):
        if not self.cache_dir:
            return
        os.makedirs(self.cache_dir, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9._-]+", "_", loc)[-80:]
        fn = "%03d_%s" % (len(self.manifest) + 1, name)
        if not fn.lower().endswith((".xsd", ".wsdl", ".xml")):
            fn += ".xml"
        with open(os.path.join(self.cache_dir, fn), "wb") as fh:
            fh.write(data)
        self.manifest[loc] = fn
        with open(os.path.join(self.cache_dir, "manifest.json"), "w", encoding="utf-8") as fh:
            json.dump(self.manifest, fh, indent=1)

    def fallback(self, loc, namespace=None):
        base = os.path.basename(urllib.parse.urlparse(loc).path if is_url(loc) else loc).lower() if loc else ""
        for p in self.by_base.get(base, []):
            return p
        if namespace:
            for p in self.by_ns.get(namespace, []):
                return p
        return None


class Contract:
    def __init__(self, loader):
        self.loader = loader
        self.nsmap = {}
        self.owner_tns = {}
        self.elements, self.types, self.groups, self.attr_groups, self.attributes = {}, {}, {}, {}, {}
        self.messages, self.port_types, self.bindings, self.services = {}, {}, {}, {}
        self.wsdl2_ops = []
        self.loaded = set()
        self.loaded_ns = set()
        self.pending_ns = set()

    # ---- loading
    def load(self, loc, override_tns=None, namespace=None):
        key = (loc, override_tns)
        if key in self.loaded:
            return
        self.loaded.add(key)
        try:
            data = self.loader.fetch(loc)
        except Exception as e:  # noqa
            fb = self.loader.fallback(loc, namespace)
            if fb and (fb, override_tns) not in self.loaded:
                warn("could not load %s (%s); using local copy %s" % (loc, e, fb))
                return self.load(fb, override_tns)
            warn("could not load %s: %s" % (loc, e))
            return
        try:
            root, nsm = parse_xml(data)
        except Exception as e:  # noqa
            if is_url(loc) and "wsdl" not in loc.lower():
                self.loaded.discard(key)
                return self.load(loc + ("&" if "?" in loc else "?") + "wsdl", override_tns, namespace)
            warn("could not parse %s: %s" % (loc, e))
            return
        self.nsmap.update(nsm)
        tag = root.tag
        if tag == q(WSDL11, "definitions"):
            self._wsdl11(root, loc)
        elif tag == q(WSDL20, "description"):
            self._wsdl20(root, loc)
        elif tag == q(XSD, "schema"):
            self._schema(root, loc, override_tns)
        elif is_url(loc) and "wsdl" not in loc.lower():
            self.loaded.discard(key)
            self.load(loc + ("&" if "?" in loc else "?") + "wsdl", override_tns, namespace)
        else:
            warn("%s is not a WSDL/XSD document (root=%s)" % (loc, local(tag)))

    def _schema(self, s, loc, override_tns=None):
        tns = s.get("targetNamespace") or override_tns or ""
        self.loaded_ns.add(tns)
        for ch in s:
            t = local(ch.tag)
            if t in ("import", "include", "redefine", "override"):
                sl = ch.get("schemaLocation")
                ns = ch.get("namespace")
                if sl:
                    self.load(join_loc(loc, sl), tns if t != "import" else None, ns)
                elif ns:
                    self.pending_ns.add(ns)
                if t in ("redefine", "override"):
                    self._register(ch, tns)
            self._register_one(ch, t, tns)

    def _register(self, parent, tns):
        for ch in parent:
            self._register_one(ch, local(ch.tag), tns)

    def _register_one(self, ch, t, tns):
        name = ch.get("name")
        if not name:
            return
        reg = {"element": self.elements, "complexType": self.types, "simpleType": self.types,
               "group": self.groups, "attributeGroup": self.attr_groups, "attribute": self.attributes}.get(t)
        if reg is not None:
            reg[(tns, name)] = ch
            self.owner_tns[ch] = tns

    def _wsdl11(self, root, loc):
        tns = root.get("targetNamespace", "")
        for imp in root.findall(q(WSDL11, "import")):
            if imp.get("location"):
                self.load(join_loc(loc, imp.get("location")), namespace=imp.get("namespace"))
        types = root.find(q(WSDL11, "types"))
        if types is not None:
            for s in types.findall(q(XSD, "schema")):
                self._schema(s, loc)
        for m in root.findall(q(WSDL11, "message")):
            self.messages[(tns, m.get("name"))] = m
        for pt in root.findall(q(WSDL11, "portType")):
            self.port_types[(tns, pt.get("name"))] = pt
        for b in root.findall(q(WSDL11, "binding")):
            self.bindings[(tns, b.get("name"))] = b
        for sv in root.findall(q(WSDL11, "service")):
            for port in sv.findall(q(WSDL11, "port")):
                addr = None
                for ch in port:
                    if local(ch.tag) == "address":
                        addr = ch.get("location")
                self.services[self.resolve(port, port.get("binding"), tns)] = {
                    "service": sv.get("name"), "port": port.get("name"), "address": addr}

    def _wsdl20(self, root, loc):
        tns = root.get("targetNamespace", "")
        types = root.find(q(WSDL20, "types"))
        if types is not None:
            for s in types.findall(q(XSD, "schema")):
                self._schema(s, loc)
        for itf in root.findall(q(WSDL20, "interface")):
            for op in itf.findall(q(WSDL20, "operation")):
                rec = {"name": op.get("name"), "portType": itf.get("name"), "parts": {}}
                for d in ("input", "output"):
                    el = op.find(q(WSDL20, d))
                    if el is not None and el.get("element"):
                        rec["parts"][d] = [("element", self.resolve(el, el.get("element"), tns), "body", el)]
                rec["parts"]["faults"] = []
                self.wsdl2_ops.append(rec)

    def resolve_pending(self):
        for ns in list(self.pending_ns):
            if ns in self.loaded_ns or ns == XSD:
                continue
            p = self.loader.fallback(None, ns)
            if p:
                warn("namespace %s imported without schemaLocation; using local %s" % (ns, p))
                self.load(p)
            else:
                warn("namespace %s imported without schemaLocation and no local copy found" % ns)

    # ---- qname helpers
    def resolve(self, el, qn, ctx_tns=""):
        if not qn:
            return ("", "")
        if ":" in qn:
            p, n = qn.split(":", 1)
            ns = self.nsmap.get(el, {}).get(p)
            if ns is None:
                warn("unknown prefix '%s' in %s" % (p, qn))
                ns = ""
            return (ns, n)
        return (self.nsmap.get(el, {}).get("", ctx_tns), qn)

    def lookup(self, reg, key, what):
        if key in reg:
            return reg[key]
        cands = [v for (ns, n), v in reg.items() if n == key[1]]
        if len(cands) == 1:
            warn("%s {%s}%s resolved by local name only" % (what, key[0], key[1]))
            return cands[0]
        return None

    # ---- operations
    def operations(self):
        ops = []
        if self.wsdl2_ops:
            for r in self.wsdl2_ops:
                ops.append(self._op_payloads(r["name"], r["portType"], r["parts"], {}, None))
        bind_info = {}
        for bkey, b in self.bindings.items():
            ptkey = self.resolve(b, b.get("type"), bkey[0])
            style = "document"
            for ch in b:
                if local(ch.tag) == "binding" and ch.get("style"):
                    style = ch.get("style")
            for op in b.findall(q(WSDL11, "operation")):
                info = {"style": style, "soapAction": None, "binding": bkey[1],
                        "address": (self.services.get(bkey) or {}).get("address")}
                for ch in op:
                    if local(ch.tag) == "operation":
                        info["soapAction"] = ch.get("soapAction") or info["soapAction"]
                        info["style"] = ch.get("style") or info["style"]
                bind_info.setdefault((ptkey, op.get("name")), info)
        seen = set()
        for ptkey, pt in self.port_types.items():
            for op in pt.findall(q(WSDL11, "operation")):
                name = op.get("name")
                parts = {"input": [], "output": [], "faults": []}
                for d in ("input", "output", "fault"):
                    for io_el in op.findall(q(WSDL11, d)):
                        mkey = self.resolve(io_el, io_el.get("message"), ptkey[0])
                        msg = self.lookup(self.messages, mkey, "message")
                        if msg is None:
                            warn("message %s not found for %s" % (mkey[1], name))
                            continue
                        for part in msg.findall(q(WSDL11, "part")):
                            if part.get("element"):
                                pk = ("element", self.resolve(part, part.get("element"), mkey[0]), part.get("name"), part)
                            else:
                                pk = ("type", self.resolve(part, part.get("type"), mkey[0]), part.get("name"), part)
                            parts["faults" if d == "fault" else d].append(pk)
                uniq = name if name not in seen else "%s.%s" % (ptkey[1], name)
                seen.add(name)
                ops.append(self._op_payloads(uniq, ptkey[1], parts, bind_info.get((ptkey, name), {}), name))
        return ops

    def _op_payloads(self, name, pt, parts, info, wsdl_name):
        rec = {"name": name, "wsdlName": wsdl_name or name, "portType": pt,
               "soapAction": info.get("soapAction"), "style": info.get("style"),
               "address": info.get("address"), "request": [], "response": [], "faults": []}
        for d, target in (("input", "request"), ("output", "response"), ("faults", "faults")):
            for kind, key, pname, el in parts.get(d, []):
                fl = Flattener(self)
                if kind == "element":
                    g = self.lookup(self.elements, key, "element")
                    if g is None:
                        warn("element %s not found (op %s)" % (key[1], name))
                        continue
                    fl.elem(g, "", self.owner_tns.get(g, key[0]), [])
                else:
                    prefix = rec["wsdlName"] if target != "faults" else ""
                    fl.typed(pname, key, prefix, el, [])
                rec[target].extend(fl.fields)
        return rec


class Flattener:
    MAX_DEPTH = 25

    def __init__(self, c):
        self.c = c
        self.fields = []

    @staticmethod
    def _occ(v, default):
        if v is None:
            return default
        return "unbounded" if v == "unbounded" else int(v)

    def _add(self, **kw):
        kw.setdefault("restr", {})
        self.fields.append(kw)

    def elem(self, e, prefix, tns, stack, choice=False, mn=None, mx=None):
        if len(stack) > self.MAX_DEPTH:
            return
        mn = mn if mn is not None else e.get("minOccurs")
        mx = mx if mx is not None else e.get("maxOccurs")
        ref = e.get("ref")
        if ref:
            key = self.c.resolve(e, ref, tns)
            g = self.c.lookup(self.c.elements, key, "element")
            if g is None:
                warn("element ref %s unresolved" % key[1])
                self._add(path=(prefix + "/" if prefix else "") + key[1], name=key[1], type="UNRESOLVED",
                          min=self._occ(mn, 1), max=self._occ(mx, 1), complex=False, attr=False, choice=choice)
                return
            return self.elem(g, prefix, self.c.owner_tns.get(g, key[0]), stack, choice, mn, mx)
        name = e.get("name")
        mn_i, mx_i = self._occ(mn, 1), self._occ(mx, 1)
        is_list = mx_i == "unbounded" or (isinstance(mx_i, int) and mx_i > 1)
        path = (prefix + "/" if prefix else "") + name + ("[]" if is_list else "")
        base = dict(path=path, name=name, min=mn_i, max=mx_i, attr=False, choice=choice,
                    nillable=e.get("nillable") == "true", list=is_list)
        ct = e.find(q(XSD, "complexType"))
        st = e.find(q(XSD, "simpleType"))
        if ct is not None:
            self._add(type="(anonymous)", complex=True, **base)
            self.complex(ct, path, tns, stack)
        elif st is not None:
            b, r = self.simple(st, tns, 0)
            self._add(type=b, complex=False, restr=r, **base)
        elif e.get("type"):
            self._typed_into(base, self.c.resolve(e, e.get("type"), tns), stack)
        else:
            self._add(type="anyType", complex=False, **base)

    def typed(self, name, key, prefix, el, stack):
        path = (prefix + "/" if prefix else "") + name
        self._typed_into(dict(path=path, name=name, min=1, max=1, attr=False, choice=False, nillable=False, list=False),
                         key, stack)

    def _typed_into(self, base, key, stack):
        if key[0] == XSD:
            self._add(type=key[1], complex=False, **base)
            return
        if key[0] == WCF_SER_NS and key[1] in WCF_SER_TYPES:
            self._add(type=WCF_SER_TYPES[key[1]], complex=False, typeName=key[1], **base)
            return
        t = self.c.lookup(self.c.types, key, "type")
        if t is None:
            warn("type %s unresolved (field %s)" % (key[1], base["path"]))
            self._add(type="UNRESOLVED:" + key[1], complex=False, **base)
        elif local(t.tag) == "simpleType":
            b, r = self.simple(t, self.c.owner_tns.get(t, key[0]), 0)
            self._add(type=b, complex=False, restr=r, typeName=key[1], **base)
        elif key in stack:
            self._add(type="RECURSIVE:" + key[1], complex=True, **base)
        else:
            self._add(type=key[1], complex=True, **base)
            self.complex(t, base["path"], self.c.owner_tns.get(t, key[0]), stack + [key])

    def simple(self, st, tns, depth):
        restr = {}
        if depth > 10:
            return "string", restr
        for ch in st:
            t = local(ch.tag)
            if t == "restriction":
                b = "string"
                inner = ch.find(q(XSD, "simpleType"))
                if ch.get("base"):
                    key = self.c.resolve(ch, ch.get("base"), tns)
                    if key[0] == XSD:
                        b = key[1]
                    else:
                        bt = self.c.lookup(self.c.types, key, "type")
                        if bt is not None and local(bt.tag) == "simpleType":
                            b, restr = self.simple(bt, self.c.owner_tns.get(bt, key[0]), depth + 1)
                            restr = dict(restr)
                elif inner is not None:
                    b, restr = self.simple(inner, tns, depth + 1)
                for f in ch:
                    fn = local(f.tag)
                    if fn == "enumeration":
                        restr.setdefault("enumeration", []).append(f.get("value"))
                    elif fn in ("pattern", "length", "minLength", "maxLength", "minInclusive", "maxInclusive",
                                "minExclusive", "maxExclusive", "totalDigits", "fractionDigits"):
                        restr[fn] = f.get("value")
                return b, restr
            if t == "list":
                return "list", restr
            if t == "union":
                return "union", restr
        return "string", restr

    def complex(self, ct, path, tns, stack, choice=False):
        for ch in ct:
            t = local(ch.tag)
            if t in ("sequence", "all"):
                self.particles(ch, path, tns, stack, choice)
            elif t == "choice":
                self.particles(ch, path, tns, stack, True)
            elif t == "group":
                self._group(ch, path, tns, stack, choice)
            elif t == "complexContent":
                for d in ch:
                    if local(d.tag) == "extension" and d.get("base"):
                        key = self.c.resolve(d, d.get("base"), tns)
                        if key[0] != XSD:
                            bt = self.c.lookup(self.c.types, key, "type")
                            if bt is None:
                                warn("base type %s unresolved (at %s)" % (key[1], path))
                            elif key in stack:
                                warn("recursive base type %s" % key[1])
                            else:
                                self.complex(bt, path, self.c.owner_tns.get(bt, key[0]), stack + [key], choice)
                    if local(d.tag) in ("extension", "restriction"):
                        self.complex(d, path, tns, stack, choice)
            elif t == "simpleContent":
                for d in ch:
                    if local(d.tag) in ("extension", "restriction"):
                        key = self.c.resolve(d, d.get("base"), tns)
                        self._add(path=path + "/#value", name="#value", type=key[1] if key[0] == XSD else "string",
                                  min=1, max=1, complex=False, attr=False, choice=False)
                        self.complex(d, path, tns, stack, choice)
            elif t == "attribute":
                self._attr(ch, path, tns)
            elif t == "attributeGroup" and ch.get("ref"):
                key = self.c.resolve(ch, ch.get("ref"), tns)
                ag = self.c.lookup(self.c.attr_groups, key, "attributeGroup")
                if ag is not None:
                    self.complex(ag, path, self.c.owner_tns.get(ag, key[0]), stack, choice)

    def particles(self, node, path, tns, stack, choice):
        for ch in node:
            t = local(ch.tag)
            if t == "element":
                self.elem(ch, path, tns, stack, choice)
            elif t in ("sequence", "all"):
                self.particles(ch, path, tns, stack, choice)
            elif t == "choice":
                self.particles(ch, path, tns, stack, True)
            elif t == "group":
                self._group(ch, path, tns, stack, choice)
            elif t == "any":
                self._add(path=path + "/*any*", name="*any*", type="any", min=0, max=1, complex=False,
                          attr=False, choice=choice)

    def _group(self, ch, path, tns, stack, choice):
        if not ch.get("ref"):
            return
        key = self.c.resolve(ch, ch.get("ref"), tns)
        g = self.c.lookup(self.c.groups, key, "group")
        if g is None:
            warn("group %s unresolved" % key[1])
        elif ("group",) + key not in stack:
            self.complex(g, path, self.c.owner_tns.get(g, key[0]), stack + [("group",) + key], choice)

    def _attr(self, a, path, tns):
        if a.get("ref"):
            key = self.c.resolve(a, a.get("ref"), tns)
            g = self.c.lookup(self.c.attributes, key, "attribute")
            name, typ, restr = key[1], "string", {}
            if g is not None and g.get("type"):
                tk = self.c.resolve(g, g.get("type"), tns)
                typ = tk[1]
        else:
            name, typ, restr = a.get("name"), "string", {}
            st = a.find(q(XSD, "simpleType"))
            if st is not None:
                typ, restr = self.simple(st, tns, 0)
            elif a.get("type"):
                tk = self.c.resolve(a, a.get("type"), tns)
                if tk[0] == XSD:
                    typ = tk[1]
                else:
                    t = self.c.lookup(self.c.types, tk, "type")
                    if t is not None and local(t.tag) == "simpleType":
                        typ, restr = self.simple(t, self.c.owner_tns.get(t, tk[0]), 0)
        self._add(path=path + "/@" + name, name=name, type=typ, restr=restr,
                  min=1 if a.get("use") == "required" else 0, max=1, complex=False, attr=True, choice=False)


# --------------------------------------------------------------------------- code scanning

SKIP_DIRS = {".git", ".svn", ".hg", "node_modules", "target", "build", "bin", "obj", "dist", "out", ".idea", ".vs",
             ".vscode", ".gradle", "__pycache__", "vendor", "packages", ".mvn", "coverage", ".next", "venv", ".venv",
             "site-packages", "TestResults", "logs"}
TEST_DIR_RE = re.compile(r"(^|[\\/])([\w\-]*[.\-_])?(test|tests|__tests__|spec|specs|it|integration-?tests?|testing|unit-?tests?|"
                         r"functionaltests?|acceptancetests?|benchmarks?)([\\/]|$)", re.I)
# NOTE: *.designer.cs is NOT skipped - LINQ to SQL DataContext/entities and EF6 code live there.
GENERATED_FILE_RE = re.compile(r"(\.g\.cs|\.g\.i\.cs|AssemblyInfo\.cs|\.AssemblyAttributes\.cs|GlobalUsings\.g\.cs|Resources\.Designer\.cs|Settings\.Designer\.cs)$", re.I)
CODE_EXT = {".java": "java", ".kt": "kotlin", ".kts": "kotlin", ".scala": "scala", ".groovy": "groovy", ".cs": "cs",
            ".vb": "vb", ".ts": "ts", ".tsx": "ts", ".js": "js", ".jsx": "js", ".mjs": "js", ".py": "py", ".go": "go"}
CONF_EXT = {".properties", ".yml", ".yaml", ".config", ".json", ".env", ".ini", ".toml"}
SKIP_FILES = {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "tsconfig.json", "package.json", "angular.json",
              "pom.xml", "launchsettings.json", "composer.lock"}
MAX_FILE = 1_500_000

KEYWORDS = {"if", "for", "while", "switch", "catch", "return", "new", "else", "throw", "throws", "try", "do", "synchronized",
            "using", "lock", "foreach", "when", "sizeof", "typeof", "nameof", "await", "yield", "super", "this", "assert",
            "case", "in", "is", "as", "function", "def", "fun", "func", "class", "elif", "with", "except", "lambda",
            "print", "default", "base", "select", "from", "where", "var", "val", "let", "const"}
MODS = ("public|private|protected|internal|static|final|abstract|synchronized|async|override|virtual|sealed|default|"
        "open|suspend|inline|operator|native|transient|extern|unsafe|partial|fun|readonly|export")
METHOD_RE = re.compile(r"^\s*(?P<mods>(?:(?:%s)\s+)*)(?:<[^>()]*>\s*)?(?P<ret>[\w.\[\]?]+(?:\s*<[^()=;]*>)?(?:\[\])*\??\s+)?"
                       r"(?P<name>[A-Za-z_]\w*)\s*(?:<[^>()]*>\s*)?\(" % MODS)
PY_DEF_RE = re.compile(r"^(\s*)(?:async\s+)?def\s+(\w+)\s*\(")
GO_FUNC_RE = re.compile(r"^\s*func\s+(?:\(\s*\w*\s*\*?(\w+)[^)]*\)\s*)?(\w+)\s*\(")
JS_FUNC_RE = re.compile(r"^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:function\s*\*?\s*(\w+)\s*\(|"
                        r"(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*(?::\s*[\w<>\[\]]+\s*)?=>|\w+\s*=>))")
CLASS_RE = re.compile(r"\b(class|interface|enum|record|struct|object|trait)\s+([A-Za-z_]\w*)([^{;]*)")
LEAD_ANN_RE = re.compile(r"^\s*(?:(?:@[\w.]+(?:\([^()]*(?:\([^()]*\)[^()]*)*\))?|\[[^\]]*\])\s*)+")
JAVA_FIELD_RE = re.compile(r"^\s*(?:(?:private|protected|public|internal)\s+)?(?:(?:final|volatile|transient|readonly|required|lateinit)\s+)*"
                           r"(?P<type>[A-Z][\w.]*(?:\s*<[^;=()]*>)?(?:\[\])?|int|long|short|byte|double|float|boolean|char|bool|string|decimal|object)\??\s+"
                           r"(?P<name>[A-Za-z_]\w*)\s*(?:=[^;]*)?;")
CS_PROP_RE = re.compile(r"^\s*public\s+(?:virtual\s+|required\s+|override\s+|new\s+)*(?P<type>[\w.]+(?:\s*<[^;=()]*>)?(?:\[\])?\??)\s+"
                        r"(?P<name>[A-Za-z_]\w*)\s*\{\s*(?:get|init|set)")
KT_PROP_RE = re.compile(r"(?:val|var)\s+(?P<name>\w+)\s*:\s*(?P<type>[\w.]+(?:<[^>]*>)?\??)")
TS_PROP_RE = re.compile(r"^\s*(?:(?:public|private|protected|readonly)\s+)*(?P<name>[A-Za-z_]\w*)\??\s*[:!]\s*(?P<type>[\w.]+(?:<[^>]*>)?(?:\[\])?)\s*[;,=]?\s*$")
PY_PROP_RE = re.compile(r"^\s+(?P<name>[a-z_]\w*)\s*:\s*(?P<type>[\w.\[\], ]+?)\s*(?:=.*)?$")
VAR_RE = re.compile(r"\b([A-Z]\w*)(?:\s*<[^;()=]*>)?(?:\[\])?\s+([a-z_]\w*)\s*(?=[;=,):])")
VAR2_RE = re.compile(r"\b([a-z_]\w*)\s*:\s*([A-Z]\w*)")
VAR3_RE = re.compile(r"\bvar\s+(\w+)\s*=\s*new\s+([A-Z]\w*)")
CALL_RECV_RE = re.compile(r"\b([A-Za-z_]\w*)\s*(?:\?\.|\.|->|::)\s*([A-Za-z_]\w*)\s*(?:<[^>()]*>)?\(")
CALL_RE = re.compile(r"(?<![\w.$])([A-Za-z_]\w*)\s*\(")
METHREF_RE = re.compile(r"\b([A-Za-z_]\w*)::([A-Za-z_]\w*)")
NEW_RE = re.compile(r"\bnew\s+([A-Z]\w*)")
TYPE_TOKEN_RE = re.compile(r"\b([A-Z][A-Za-z0-9_]+)\b")
STR_RE = re.compile(r'"((?:\\.|[^"\\])*)"|\'((?:\\.|[^\'\\])*)\'')

# (category, subtype, regex)
HIT_PATTERNS = [
    ("endpoint", "soap", r"@WebService\b|@WebMethod\b|@Endpoint\b|@PayloadRoot\b|@SoapAction\b|\[OperationContract|\[ServiceContract|@ResponsePayload|\[WebMethod\b|\[WebService\b|\[SoapDocumentMethod"),
    ("endpoint", "rest", r"@(Get|Post|Put|Delete|Patch|Request)Mapping\b|@(GET|POST|PUT|DELETE|PATCH)\b|@Path\s*\(|\[Http(Get|Post|Put|Delete|Patch)\b|\[Route\s*\(|\bMap(Get|Post|Put|Delete)\s*\("),
    ("endpoint", "js-py-go", r"\b(app|router|server)\.(get|post|put|delete|patch)\s*\(|@(app|router|api)\.(route|get|post|put|delete|patch)\b|\bHandleFunc\s*\("),
    ("endpoint", "listener", r"@(JmsListener|KafkaListener|RabbitListener|SqsListener|StreamListener)\b"),
    ("outbound", "rest-template", r"\.(getForObject|getForEntity|postForObject|postForEntity|patchForObject)\s*\(|\b\w*[Tt]emplate\s*\.\s*(exchange|put|delete)\s*\(|\bnew\s+RestTemplate\b"),
    ("outbound", "webclient", r"\bWebClient\b|\bRestClient\b|\.retrieve\s*\(\)|\.bodyToMono\s*\(|\.uri\s*\("),
    ("outbound", "feign", r"@FeignClient\b|@HttpExchange\b|@(Get|Post)Exchange\b"),
    ("outbound", "http-client", r"\bHttpClients?\b|new\s+Http(Get|Post|Put|Delete)\b|\bOkHttpClient\b|new\s+URL\s*\(|HttpURLConnection|HttpRequest\.newBuilder|ClientBuilder\.|\.(GetAsync|PostAsync|PutAsync|PatchAsync|SendAsync|DeleteAsync|GetStringAsync|GetStreamAsync|GetByteArrayAsync|GetFromJsonAsync|PostAsJsonAsync|PutAsJsonAsync|PatchAsJsonAsync|DeleteFromJsonAsync)\s*(?:<[^>()]*>)?\s*\(|\.(Get|Post|Put|Delete)Json(Async)?\s*<|\bRestSharp\b|new\s+RestRequest|\baxios\b|\bfetch\s*\(|\brequests\.(get|post|put|delete|request)\s*\(|\bhttpx\.|\bhttp\.(Get|Post|NewRequest)\b"),
    ("outbound", "soap-client", r"WebServiceTemplate|marshalSendAndReceive|\.getPort\s*\(|JaxWsProxyFactoryBean|SOAPConnection|ChannelFactory<|\bSoapClient\b|zeep\.Client|ClientBase<|\bSoapHttpClientProtocol\b|new\s+\w+(Soap|Service|Ws)Client\s*\("),
    ("outbound", "grpc", r"ManagedChannelBuilder|GrpcChannel\.|grpc\.Dial"),
    ("messaging", "publish", r"jmsTemplate\.|convertAndSend|kafkaTemplate\.send|rabbitTemplate\.|CreateSender\s*\(|SendMessageAsync\s*\(|BasicPublish|SendMessageRequest|PublishRequest|\.[Pp]ublish(Async)?\s*\(|IPublishEndpoint|\.Produce(Async)?\s*\(|MessageQueue\s*\(|\.Send\s*\(\s*new\s+Message\b"),
    ("db", "jdbc", r"\bJdbcTemplate\b|NamedParameterJdbcTemplate|jdbcTemplate\.|\.query(ForObject|ForList|ForMap|ForRowSet)?\s*\(\s*\"|\.batchUpdate\s*\(|PreparedStatement|\.executeQuery\s*\(|\.executeUpdate\s*\("),
    ("db", "stored-proc", r"SimpleJdbcCall|withProcedureName|withFunctionName|@Procedure\b|StoredProcedureQuery|createStoredProcedureQuery|prepareCall|CommandType\.StoredProcedure|callproc\s*\("),
    ("db", "linq2sql", r"\bDataContext\b|\bGetTable\s*<|\bExecuteQuery\s*<|\bExecuteCommand\s*\(|\bSubmitChanges\s*\(|\b(Insert|Delete|InsertAll|DeleteAll)OnSubmit\s*\(|CompiledQuery\.Compile|\bExecuteMethodCall\s*\("),
    ("db", "linq-query", r"\bfrom\s+\w+\s+in\s+(?:this\.)?_?\w+\.\w+"),
    ("db", "orm", r"@Query\b|\bEntityManager\b|\.createQuery\s*\(|\.createNativeQuery\s*\(|extends\s+\w*(Jpa|Crud|PagingAndSorting|Mongo|Reactive\w*)Repository|@Select\b|@Insert\b|@Update\b|@Delete\b|SqlSession|\bDbSet<|FromSqlRaw|FromSqlInterpolated|ExecuteSqlRaw|\.SaveChanges(Async)?\s*\(|\bSqlCommand\b|OracleCommand|NpgsqlCommand|\.Query(Async|First\w*|Single\w*)?<|MongoTemplate|session\.query\s*\(|\.objects\.(filter|get|create)\s*\("),
    ("db", "sql", r"[\"'`]\s*(SELECT\s|INSERT\s+INTO\s|UPDATE\s+\w|DELETE\s+FROM\s|MERGE\s+INTO\s|CALL\s|EXEC(UTE)?\s|\{\s*call\s)"),
    ("cache", "cache", r"@Cacheable\b|@CacheEvict\b|RedisTemplate|IDistributedCache|IMemoryCache|\bJedis\b"),
    ("validation", "annotation", r"@(NotNull|NotBlank|NotEmpty|Size|Pattern|Min|Max|DecimalMin|DecimalMax|Positive|PositiveOrZero|Negative|Email|Past|Future|PastOrPresent|FutureOrPresent|Valid|Validated|Digits|Length|Range)\b|\[(Required|StringLength|MaxLength|MinLength|Range|RegularExpression|EmailAddress)\b"),
    ("validation", "imperative", r"throw\s+new\s+\w*(Validation|Invalid|IllegalArgument|BadRequest|Business|Constraint|Argument\w*)\w*|Objects\.requireNonNull|\bAssert\.\w+\s*\(|Preconditions\.check|\bValidate\.\w+\s*\(|StringUtils\.(isBlank|isEmpty|hasText|isNotBlank|isNotEmpty)|\bRuleFor\s*\(|ArgumentNullException|ValidationResult|BindingResult|\bvalidator\.validate\s*\(|raise\s+\w*(Validation|Value)Error"),
    ("error", "fault", r"@WebFault\b|SOAPFaultException|SoapFault\w*|FaultException|@ExceptionHandler\b|@ControllerAdvice\b|ResponseStatusException|@ResponseStatus\b|throw\s+new\s+\w+Exception|raise\s+\w+(Error|Exception)"),
    ("transaction", "tx", r"@Transactional\b|TransactionScope|BeginTransaction|\.commit\s*\(\s*\)|\.rollback\s*\(\s*\)"),
    ("security", "authz", r"@PreAuthorize\b|@Secured\b|@RolesAllowed\b|\[Authorize\b|@login_required"),
    ("mapping", "mapper", r"@Mapper\b|ModelMapper|ObjectMapper|\bMapStruct\b|IMapper\b|\.Map<"),
]
IMPORT_LINE_RE = re.compile(r"^\s*(import|using|package|namespace|from\s+\S+\s+import)\b")
HIT_RES = [(c, s, re.compile(r, re.I if s == "sql" else 0)) for c, s, r in HIT_PATTERNS]
SQL_TABLE_RE =re.compile(r"\b(?:FROM|JOIN|INTO|UPDATE|MERGE\s+INTO|DELETE\s+FROM)\s+([A-Za-z_][\w$#]*(?:\.[A-Za-z_][\w$#]*)?)", re.I)
SQL_NOT_TABLE = {"SELECT", "WHERE", "SET", "VALUES", "DUAL", "TABLE", "THE", "A", "AN", "AND", "OR", "ON", "AS", "TO", "OF",
                 "EACH", "ANY", "ALL", "LATERAL", "UNNEST", "JSON_TABLE"}
PROC_RES = [re.compile(p, re.I) for p in (
    r"with(?:Procedure|Function)Name\s*\(\s*\"([^\"]+)\"",
    r"@Procedure\s*\(\s*(?:\w+\s*=\s*)?\"([^\"]+)\"",
    r"createStoredProcedureQuery\s*\(\s*\"([^\"]+)\"",
    r"\{\s*\??=?\s*call\s+([\w.$#]+)",
    r"[\"'`]\s*(?:CALL|EXEC(?:UTE)?)\s+([\w.$#\[\]]+)",
    r"callproc\s*\(\s*[\"']([^\"']+)")]
PATH_LIT_RE = re.compile(r"[\"'`]((?:https?://[^\"'`\s]*)|(?:\$\{[^}]+\})?/[A-Za-z0-9_\-./{}$:]*)[\"'`]")
REL_PATH_RE = re.compile(r"\$?[\"'`]([A-Za-z][\w\-]*(?:/[\w\-{}.]*)+)[\"'`]")
HOST_RE = re.compile(r"https?://([A-Za-z0-9.\-]+)(?::\d+)?")
JDBC_RE = re.compile(r"jdbc:[\w:]+(?://|@)?([A-Za-z0-9.\-]+)")
PLACEHOLDER_RE = re.compile(r"\$\{([\w.\-]+)(?::[^}]*)?\}")
CS_CONFIG_RE = re.compile(r"(?:Configuration|_config\w*|config\w*|AppSettings|_settings)\s*\[\s*\"([^\"]+)\"\s*\]|GetValue<[^>]*>\s*\(\s*\"([^\"]+)\""
                          r"|GetConnectionString\s*\(\s*\"([^\"]+)\"|ConnectionStrings\s*\[\s*\"([^\"]+)\"\s*\]|GetSection\s*\(\s*\"([^\"]+)\"")
RULE_LINE_RE = re.compile(r"\b(if|elif|switch|case|when|while)\b|\?[^:;?.]+:|\.equals(IgnoreCase)?\s*\(|==|!=|>=|<=|[*/+\-]=|"
                          r"\b(multiply|add|subtract|divide|setScale|compareTo|max|min|round|floor|ceil|Round|Floor|Ceiling|Max|Min|Abs|Multiply|Divide)\s*\(|"
                          r"[*/]\s*\(?\s*\d|\d\s*[*/]|\bBigDecimal\s*\(\s*\"")
LOG_LINE_RE = re.compile(r"\b(log|logger|LOG|LOGGER|_logger|console|System\.out|print|Debug|Trace)\s*[.(]")
NUM_RE = re.compile(r"(?<![\w.])(\d+\.\d+|\d{2,})[mMdDfFlLuU]?(?![\w.])")
MEDIA_TYPE_RE = re.compile(r"^(application|text|image|audio|video|multipart|font)/", re.I)
CONST_RE = re.compile(r"\b(?:const|static\s+final|static\s+readonly|final\s+static|readonly\s+static)\s+[\w.<>?\[\]]+\s+([A-Za-z_]\w*)\s*=\s*([^;]+);"
                      r"|^\s*(?:private\s+|public\s+)?(?:const\s+)?(?:val\s+)?([A-Z][A-Z0-9_]{2,})\s*(?::\s*\w+)?\s*=\s*([^;\n]+)")
HANDLER_IFACE_RE = re.compile(r"\b(?:IRequestHandler|INotificationHandler|ICommandHandler|IQueryHandler|IConsumer|IHandleMessages|IEventHandler|RequestHandler)\s*<\s*([A-Za-z_]\w*)")
VALIDATOR_RE = re.compile(r"\bAbstractValidator\s*<\s*([A-Za-z_]\w*)")
FLUENT_MAP = [(re.compile(r"^(NotEmpty|NotNull)$"), "Required(fluent)"),
              (re.compile(r"^(Matches|EmailAddress|IsInEnum|IsEnumName|Must)$"), "Pattern(fluent)"),
              (re.compile(r"^(Length|MaximumLength|MinimumLength)$"), "Length(fluent)"),
              (re.compile(r"^(GreaterThan|GreaterThanOrEqualTo|LessThan|LessThanOrEqualTo|InclusiveBetween|ExclusiveBetween|PrecisionScale)$"), "Range(fluent)")]
ALIAS_RE = re.compile(r"(?:DataMember|MessageBodyMember|XmlElement|XmlAttribute|XmlArray|XmlArrayItem)\s*\([^)]*?\bName\s*=\s*\"([^\"]+)\""
                      r"|(?:XmlElement|XmlAttribute|XmlArray|JsonPropertyName|JsonProperty|SerializedName|JsonAlias|XmlElementAttribute)\s*\(\s*\"([^\"]+)\""
                      r"|@(?:JsonProperty|XmlElement|XmlAttribute|SerializedName)\s*\(\s*(?:value\s*=\s*|name\s*=\s*)?\"([^\"]+)\"")
IGNORED_FIELDS = {"extensiondata", "propertychanged", "serialversionuid"}
WCF_SER_NS = "http://schemas.microsoft.com/2003/10/Serialization/"
WCF_SER_TYPES = {"guid": "string", "char": "int", "duration": "duration", "anyURI": "string"}


def proc_key(name):
    """Normalize stored-procedure names: strip brackets and default schema (dbo.)."""
    n = name.replace("[", "").replace("]", "").upper().strip()
    return n[4:] if n.startswith("DBO.") else n


def value_hosts(v):
    """hosts referenced by a config value: URLs, JDBC urls, ADO.NET connection strings."""
    out = {h.lower() for h in HOST_RE.findall(v) + JDBC_RE.findall(v)}
    m = re.search(r"(?:Server|Data Source|Host|Addr|Address)\s*=\s*(?:tcp:)?([^;,\\]+)", v, re.I)
    if m and "=" in v and ";" in v:
        out.add("db:" + m.group(1).strip().lower())
    return out


def clean_lines(lines, lang):
    """Strip comments (keep strings). Returns list of same length."""
    out, in_block = [], False
    for s in lines:
        res, i, n, inq = [], 0, len(s), None
        while i < n:
            c = s[i]
            if in_block:
                if s.startswith("*/", i):
                    in_block = False
                    i += 2
                else:
                    i += 1
                continue
            if inq:
                res.append(c)
                if c == "\\" and i + 1 < n:
                    res.append(s[i + 1])
                    i += 2
                    continue
                if c == inq:
                    inq = None
                i += 1
                continue
            if lang == "py" and c == "#":
                break
            if lang != "py" and s.startswith("//", i):
                break
            if lang != "py" and s.startswith("/*", i):
                in_block = True
                i += 2
                continue
            if c in "\"`" or (c == "'" and lang in ("py", "js", "ts")):
                inq = c
            res.append(c)
            i += 1
        out.append("".join(res))
    return out


def blank_strings(s):
    return STR_RE.sub('""', s)


def block_end(blank, start, lang, raw=None):
    if lang == "py":
        ind = len(raw[start]) - len(raw[start].lstrip())
        end = start
        for i in range(start + 1, len(raw)):
            t = raw[i]
            if not t.strip():
                continue
            if len(t) - len(t.lstrip()) <= ind:
                break
            end = i
        return end
    depth, seen = 0, False
    for i in range(start, min(len(blank), start + 20000)):
        for ch in blank[i]:
            if ch == "{":
                depth += 1
                seen = True
            elif ch == "}":
                depth -= 1
                if seen and depth <= 0:
                    return i
            elif ch == ";" and not seen and depth == 0:
                return i
            elif ch == "(":
                depth += 0  # parentheses ignored
        if not seen and i - start > 12:
            return start
    return len(blank) - 1


def ann_start(clean, i):
    """Walk back over annotations/attributes stacked above line i."""
    j = i
    while j - 1 >= 0 and i - (j - 1) <= 10:
        t = clean[j - 1].strip()
        if not t or t.endswith((";", "{", "}")) or t.startswith(("//", "*", "/*")):
            break
        if t.startswith(("@", "[")) or not re.match(r"^(public|private|protected|internal|static|class|def|fun|func)\b", t):
            j -= 1
            continue
        break
    return j


def parse_annotations(txt):
    """Java @Ann(args) and C# [Ann(args), Other] -> ['Ann(args)', 'Other'] (Attribute suffix removed)."""
    out = []
    for n, args in re.findall(r"@(\w+)(\([^)]*\))?", txt):
        out.append(n + (args or ""))
    for block in re.findall(r"\[([A-Za-z][^\[\]]*)\]", txt):
        for part in RepoIndex._split_params(block):
            m = re.match(r"\s*(?:\w+\s*:\s*)?(\w+)\s*(\(.*\))?\s*$", part)
            if m:
                out.append(re.sub(r"Attribute$", "", m.group(1)) + (m.group(2) or ""))
    return out


def strip_generics(t):
    prev = None
    while prev != t:
        prev = t
        t = re.sub(r"<[^<>]*>", "", t)
    return t


def generic_args(t):
    m = re.search(r"<(.*)>", t or "")
    if not m:
        return []
    return [x for x in re.findall(r"[A-Za-z_]\w*", m.group(1))]


class RepoIndex:
    def __init__(self, root, include_tests=False, label="repo"):
        self.root = os.path.abspath(root)
        self.label = label
        self.files = []          # dicts
        self.classes = defaultdict(list)   # name -> [class rec]
        self.children = defaultdict(set)   # parent simple name -> child class names
        self.hits = []
        self.config = {}         # key -> (value, file, line)
        self.config_hosts = defaultdict(list)
        self.mapper_stmts = defaultdict(list)  # MyBatis id -> [(file, line, text)]
        self.entity_table = {}
        self.sql_files = []
        self.include_tests = include_tests
        self.nullable_enabled = False
        self.handlers = defaultdict(set)    # request/message type -> handler class names (MediatR etc.)
        self.dbsets = {}                    # DbSet property name -> entity class
        self.constants = defaultdict(set)   # CONST_NAME -> literal values
        self.typed_client_cfg = defaultdict(set)  # .NET typed HttpClient class -> config keys / hosts
        self.db_funcs = {}                  # LINQ to SQL / EF function wrapper method -> stored proc name
        self.orm_models = []                # .dbml / .edmx files found
        self._scan()
        self._post()

    def _post(self):
        """Cross-file facts: EF table mappings, DbSet props, FluentValidation rules, handlers, constants."""
        for f in self.files:
            if f["lang"] not in ("cs", "java", "kotlin", "ts", "js", "py", "vb"):
                continue
            text = "\n".join(f["clean"])
            for m in re.finditer(r"Entity<\s*(\w+)\s*>\s*\(\s*\)[\s\S]{0,300}?\.ToTable\s*\(\s*\"([^\"]+)\"", text):
                self.entity_table[m.group(1)] = m.group(2).split(".")[-1]
            m = re.search(r"IEntityTypeConfiguration<\s*(\w+)\s*>", text)
            if m:
                t = re.search(r"\.ToTable\s*\(\s*\"([^\"]+)\"", text)
                if t:
                    self.entity_table[m.group(1)] = t.group(1).split(".")[-1]
            for m in re.finditer(r"AddHttpClient\s*<\s*(?:\w+\s*,\s*)?(\w+)\s*>\s*\(([\s\S]{0,400}?)\)\s*;", text):
                for cm in CS_CONFIG_RE.finditer(m.group(2)):
                    self.typed_client_cfg[m.group(1)].add(next(g for g in cm.groups() if g).replace(":", "."))
                for h in HOST_RE.findall(m.group(2)):
                    self.typed_client_cfg[m.group(1)].add("host:" + h.lower())
            # EF DbSet<T> Prop, LINQ to SQL Table<T> Prop  -> entity set property
            for m in re.finditer(r"\b(?:DbSet|IDbSet|Table|ITable)\s*<\s*(\w+)\s*>\s+(\w+)\s*(?:\{|=>|;)", text):
                self.dbsets[m.group(2)] = m.group(1)
                self.entity_table.setdefault(m.group(1), m.group(2))
            # LINQ to SQL stored procedure wrappers: [Function(Name="dbo.usp_X")] public int usp_X(...)
            for m in re.finditer(r"\[(?:[\w:.]*\.)?Function(?:Attribute)?\s*\(\s*Name\s*=\s*\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                                 r"(?:public|internal|private|protected)\s+[\w.<>\[\], ]+?\s+(\w+)\s*\(", text):
                self.db_funcs[m.group(2)] = m.group(1).replace("[", "").replace("]", "")
            for i, line in enumerate(f["clean"]):
                cm = CONST_RE.search(line)
                if cm:
                    name = cm.group(1) or cm.group(3)
                    for v in literal_set([cm.group(2) or cm.group(4)]):
                        self.constants[name].add(v)
            for c in f["classes"]:
                for hm in HANDLER_IFACE_RE.finditer(c.get("rest", "")):
                    self.handlers[hm.group(1)].add(c["name"])
                vm = VALIDATOR_RE.search(c.get("rest", ""))
                if vm:
                    body = "\n".join(f["clean"][c["start"]:c["end"] + 1])
                    for rm in re.finditer(r"RuleFor(?:Each)?\s*\(\s*\w+\s*=>\s*\w+\.(\w+)\s*\)([^;]*)", body):
                        prop, chain = rm.group(1), rm.group(2)
                        anns = []
                        for call in re.findall(r"\.(\w+)\s*[(<]", chain):
                            for rx, label in FLUENT_MAP:
                                if rx.match(call):
                                    anns.append(label + ":" + call)
                        for tc in self.classes.get(vm.group(1), []):
                            for fd in tc["fields"]:
                                if fd["name"] == prop:
                                    fd.setdefault("annotations", []).extend(anns)
                                    fd["validatedBy"] = "%s:%d" % (f["path"], c["start"] + 1)
        for c_list in self.classes.values():
            for c in c_list:
                if c["table"]:
                    self.entity_table[c["name"]] = c["table"]
        upper_entities = {k.upper(): v for k, v in self.entity_table.items()}
        for h in self.hits:
            new = []
            for k in h["keys"]:
                if k[0] == "proc-const":
                    for kind, v in self.constants.get(k[1], ()):
                        if kind == "str":
                            new.append(("proc", proc_key(v)))
                    continue
                if k[0] == "table":
                    t = k[1]
                    jvm = self.files[h["fidx"]]["lang"] in ("java", "kotlin", "scala", "groovy")
                    if jvm and t in upper_entities:  # JPQL / HQL entity name -> mapped table
                        t = upper_entities[t].upper()
                    elif jvm and t.endswith("ENTITY") and len(t) > 6:
                        t = t[:-6]
                    new.append(("table", t))
                    continue
                new.append(k)
            h["keys"] = sorted(set(new))

    # ---- walk
    def _scan(self):
        st = self.stats = defaultdict(int)
        self.slow_files = []      # (seconds, rel)
        self.big_files = []       # rel paths over MAX_FILE
        code_jobs = []            # source files are parsed after the walk (in parallel when there are many)
        t_last = time.time()

        def walk_err(e):
            st["walkErrors"] += 1
            LOG.write("%s: cannot list %s: %s" % (self.label, getattr(e, "filename", "?"), e))

        for root, dirs, files in os.walk(self.root, onerror=walk_err):
            n0 = len(dirs)
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            st["dirsSkipped"] += n0 - len(dirs)
            rel_root = os.path.relpath(root, self.root)
            if not self.include_tests and TEST_DIR_RE.search(rel_root):
                st["testDirsSkipped"] += 1
                dirs[:] = []
                continue
            for f in files:
                st["seen"] += 1
                if time.time() - t_last > 10:
                    t_last = time.time()
                    print("  %s: %d files seen, %d indexed (%.0fs)" % (self.label, st["seen"], st["indexed"], time.time() - LOG.cur_t), flush=True)
                p = os.path.join(root, f)
                ext = os.path.splitext(f)[1].lower()
                fl = f.lower()
                if fl in SKIP_FILES or GENERATED_FILE_RE.search(f):
                    st["generatedSkipped"] += 1
                    continue
                if ext == ".csproj":
                    try:
                        if re.search(r"<Nullable>\s*enable", self._read(p), re.I):
                            self.nullable_enabled = True
                    except OSError:
                        pass
                    continue
                if ext not in CODE_EXT and ext not in CONF_EXT and ext not in (".xml", ".sql", ".dbml", ".edmx") \
                        and not fl.endswith(".config"):
                    continue
                rel = os.path.relpath(p, self.root).replace("\\", "/")
                try:
                    size = os.path.getsize(p)
                except OSError:
                    st["unreadable"] += 1
                    continue
                if size > MAX_FILE and ext not in (".dbml", ".edmx"):
                    if ext in (".cs", ".vb") and fl.endswith((".designer.cs", ".designer.vb")) and size < 40 * MAX_FILE:
                        try:
                            self._light_orm(self._read(p), rel)   # big LINQ to SQL / EF6 designer: mappings only
                            st["bigDesignerLight"] += 1
                        except Exception as e:  # noqa
                            warn("%s: failed to index %s: %s" % (self.label, rel, e))
                        continue
                    st["bigSkipped"] += 1
                    self.big_files.append(rel)
                    LOG.write("%s: skipped big file (%d KB) %s" % (self.label, size // 1024, rel))
                    continue
                if not self.include_tests and re.search(r"(Tests?|Spec|IT)\.(java|kt|cs|ts|js|py|go)$|_test\.(py|go)$|\.(spec|test)\.(ts|js)$", f):
                    st["testFilesSkipped"] += 1
                    continue
                if ext in CODE_EXT:
                    code_jobs.append((p, rel, CODE_EXT[ext]))
                    continue
                LOG.cur_file = "%s/%s" % (self.label, rel)
                t1 = time.time()
                try:
                    if ext in CONF_EXT or fl.endswith((".config",)):
                        self._conf(p, rel, ext)
                        st["config"] += 1
                    elif ext == ".xml":
                        self._xml(p, rel)
                        st["xml"] += 1
                    elif ext == ".sql":
                        self.sql_files.append(rel)
                        st["sql"] += 1
                    elif ext in (".dbml", ".edmx"):
                        self._orm_model(p, rel, ext)
                        st["ormModel"] += 1
                    st["indexed"] += 1
                except Exception as e:  # noqa
                    st["failed"] += 1
                    warn("%s: failed to index %s: %s" % (self.label, rel, e))
                    LOG.write(traceback.format_exc(limit=3))
                dt = time.time() - t1
                if dt > 1.0:
                    self.slow_files.append((round(dt, 1), rel))
                    LOG.write("%s: slow file %.1fs %s" % (self.label, dt, rel))
        LOG.cur_file = None
        self._index_code(code_jobs)
        for c_list in self.classes.values():
            for c in c_list:
                for par in c["parents"]:
                    self.children[par].add(c["name"])
                if c["table"]:
                    self.entity_table[c["name"]] = c["table"]
        self.slow_files.sort(reverse=True)
        if st["bigSkipped"]:
            warn("limit: %s skipped %d file(s) over %d KB (see run.log); raise with --max-file-kb" % (self.label, st["bigSkipped"], MAX_FILE // 1024))
        if st["walkErrors"]:
            warn("limit: %s: %d folder(s) could not be listed (permissions / path > 260 chars?) - see run.log" % (self.label, st["walkErrors"]))
        if st["seen"] and not st["code"]:
            warn("%s: no source files indexed under %s - wrong folder?" % (self.label, self.root))

    def _merge(self, files, hits, outcomes):
        remap = {}
        for f in files:
            old = f["idx"]
            f["idx"] = remap[old] = len(self.files)
            self.files.append(f)
            for c in f["classes"]:
                c["fidx"] = f["idx"]
                self.classes[c["name"]].append(c)
        for h in hits:
            h["fidx"] = remap[h["fidx"]]
            self.hits.append(h)
        st = self.stats
        for rel, dt, err in outcomes:
            if err:
                st["failed"] += 1
                warn("%s: failed to index %s: %s" % (self.label, rel, err.splitlines()[0] if err else err))
                LOG.write(err)
            else:
                st["code"] += 1
                st["indexed"] += 1
            if dt > 1.0:
                self.slow_files.append((round(dt, 1), rel))
                LOG.write("%s: slow file %.1fs %s" % (self.label, dt, rel))

    def _index_code(self, jobs):
        jobs.sort(key=lambda j: j[1])
        n = len(jobs)
        workers = min(JOBS, max(1, n // 150))
        LOG.write("%s: parsing %d source files with %d process(es)" % (self.label, n, workers))
        if workers > 1:
            try:
                from concurrent.futures import ProcessPoolExecutor
                size = max(20, min(400, n // (workers * 4) or 1))
                chunks = [jobs[i:i + size] for i in range(0, n, size)]
                done, t_last = 0, time.time()
                with ProcessPoolExecutor(max_workers=workers) as ex:
                    for files, hits, outcomes in ex.map(_index_worker, chunks):
                        self._merge(files, hits, outcomes)
                        done += len(outcomes)
                        if time.time() - t_last > 10:
                            t_last = time.time()
                            print("  %s: %d/%d source files parsed (%.0fs)" % (self.label, done, n, time.time() - LOG.cur_t), flush=True)
                return
            except Exception as e:  # noqa - e.g. process creation blocked by policy: fall back to one process
                warn("limit: %s: parallel indexing failed (%s: %s) - falling back to 1 process (use --jobs 1 to skip)" % (
                    self.label, type(e).__name__, e))
                self.files, self.hits, self.classes = [], [], defaultdict(list)
                self.stats["code"] = self.stats["failed"] = 0
                self.slow_files = []
        t_last = time.time()
        for i in range(0, n, 200):
            files, hits, outcomes = _index_worker(jobs[i:i + 200], self.label)
            self._merge(files, hits, outcomes)
            if time.time() - t_last > 10:
                t_last = time.time()
                print("  %s: %d/%d source files parsed (%.0fs)" % (self.label, min(n, i + 200), n, time.time() - LOG.cur_t), flush=True)

    def _light_orm(self, text, rel):
        """Mappings only, for designer files too big for full indexing."""
        for m in re.finditer(r"\[(?:[\w:.]*\.)?Table(?:Attribute)?\s*\(\s*(?:Name\s*=\s*)?\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                             r"(?:public|internal)?\s*(?:partial\s+)?class\s+(\w+)", text):
            self.entity_table[m.group(2)] = m.group(1).replace("[", "").replace("]", "").split(".")[-1]
        for m in re.finditer(r"\[(?:[\w:.]*\.)?Function(?:Attribute)?\s*\(\s*Name\s*=\s*\"([^\"]+)\"[^\]]*\]\s*(?:\[[^\]]*\]\s*)*"
                             r"(?:public|internal|private|protected)\s+[\w.<>\[\], ]+?\s+(\w+)\s*\(", text):
            self.db_funcs[m.group(2)] = m.group(1).replace("[", "").replace("]", "")
        for m in re.finditer(r"\b(?:DbSet|IDbSet|Table|ITable)\s*<\s*(\w+)\s*>\s+(\w+)\s*(?:\{|=>|;)", text):
            self.dbsets[m.group(2)] = m.group(1)
            self.entity_table.setdefault(m.group(1), m.group(2))
        LOG.write("%s: big designer file indexed for mappings only: %s" % (self.label, rel))

    @staticmethod
    def _read(p):
        with open(p, "rb") as fh:
            data = fh.read()
        if data[:2] in (b"\xff\xfe", b"\xfe\xff"):          # UTF-16 with BOM (common for old VS / designer files)
            return data.decode("utf-16", "replace")
        if len(data) > 3 and data[1:2] == b"\x00" and data[3:4] == b"\x00":   # UTF-16LE without BOM
            return data.decode("utf-16-le", "replace")
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                return data.decode(enc)
            except UnicodeDecodeError:
                continue
        return data.decode("utf-8", "replace")

    # ---- code files
    def _code(self, p, rel, lang):
        raw = self._read(p).splitlines()
        clean = clean_lines(raw, lang)
        blank = [blank_strings(x) for x in clean]
        f = {"path": rel, "lang": lang, "raw": raw, "clean": clean, "classes": [], "methods": [],
             "vars": defaultdict(set), "placeholders": set(), "idx": len(self.files)}
        self.files.append(f)
        # classes
        for i, line in enumerate(clean):
            for m in CLASS_RE.finditer(blank[i]):
                kind, name, rest = m.group(1), m.group(2), m.group(3)
                if kind == "object" and lang not in ("kotlin", "scala"):
                    continue
                if name in KEYWORDS:
                    continue
                end = block_end(blank, i, lang, raw)
                rest_ng = strip_generics(rest)
                params = ""
                if "(" in rest_ng and kind in ("record", "class", "struct") and lang not in ("py",):
                    pm = re.match(r"\s*\((.*?)\)(.*)", rest_ng)
                    if pm:
                        params, rest_ng = pm.group(1), pm.group(2)
                if lang == "py":
                    parents = re.findall(r"[A-Za-z_][\w.]*", rest_ng.split(":")[0])
                else:
                    parents = [x for x in re.findall(r"[A-Z][\w]*", rest_ng) if x not in ("Extends", "Implements")]
                astart = ann_start(clean, i)
                ann_txt = " ".join(clean[astart:i + 1])
                tm = re.search(r"@Table\s*\(\s*(?:name\s*=\s*)?\"([^\"]+)\"|\[(?:[\w:.]*\.)?Table(?:Attribute)?\s*\(\s*(?:Name\s*=\s*)?\"([^\"]+)\"|__tablename__\s*=\s*['\"](\w+)",
                               ann_txt + " " + " ".join(clean[i:min(end + 1, i + 6)]))
                is_entity = bool(re.search(r"@Entity\b|\[(?:[\w:.]*\.)?Table(?:Attribute)?\b|__tablename__", ann_txt + " ".join(clean[i:min(end + 1, i + 6)])))
                table = next(g for g in tm.groups() if g).replace("[", "").replace("]", "").split(".")[-1] if tm else (name if is_entity else None)
                c = {"name": name, "kind": kind, "file": rel, "fidx": f["idx"], "start": i, "end": end,
                     "parents": [x.split(".")[-1] for x in parents], "fields": [], "lang": lang,
                     "is_enum": kind == "enum", "table": table, "annotations": parse_annotations(ann_txt),
                     "rest": rest + " " + " ".join(clean[i + 1:min(i + 3, end + 1)]).split("{")[0] if "{" not in rest else rest}
                if params:
                    for pp in self._split_params(params):
                        fd = self._param_field(pp, lang)
                        if fd:
                            fd["line"] = i + 1
                            c["fields"].append(fd)
                f["classes"].append(c)
                self.classes[name].append(c)
        # methods
        for i, line in enumerate(clean):
            name, cls_hint = self._method_decl(line, blank[i], lang, raw, i)
            if not name:
                continue
            end = block_end(blank, i, lang, raw)
            astart = ann_start(clean, i) if lang != "py" else i
            if lang == "py":
                j = i
                while j - 1 >= 0 and clean[j - 1].strip().startswith("@"):
                    j -= 1
                astart = j
            cls = self._enclosing_class(f, i)
            sig = " ".join(clean[i:min(i + 6, end + 1)])
            sig = sig.split("{")[0] if lang != "py" else sig.split(":")[0]
            f["methods"].append({"name": name, "start": astart, "decl": i, "end": end, "cls": cls_hint or (cls["name"] if cls else None),
                                 "sig": sig[:400]})
        # fields (DTO properties)
        for c in f["classes"]:
            inner_methods = [m for m in f["methods"] if c["start"] < m["decl"] <= c["end"]]
            for i in range(c["start"] + 1, c["end"] + 1):
                if any(m["start"] <= i <= m["end"] for m in inner_methods):
                    continue
                own = self._enclosing_class(f, i)
                if own is not c:
                    continue
                fd = self._field_decl(clean[i], lang)
                if fd and norm(fd["name"]) not in IGNORED_FIELDS:
                    a = ann_start(clean, i)
                    ann_txt = " ".join(clean[a:i + 1])
                    fd["annotations"] = parse_annotations(ann_txt)
                    al = ALIAS_RE.search(ann_txt)
                    if al:
                        fd["alias"] = next(g for g in al.groups() if g)
                    if lang == "cs" and re.search(r"\brequired\s", LEAD_ANN_RE.sub("", clean[i])):
                        fd["annotations"].append("Required(modifier)")
                    if re.search(r"IsRequired\s*=\s*true", ann_txt):
                        fd["annotations"].append("Required(DataMember)")
                    fd["line"] = i + 1
                    c["fields"].append(fd)
            if c["is_enum"]:
                body = " ".join(clean[c["start"] + 1:c["end"] + 1]).split(";")[0]
                c["enum_values"] = re.findall(r"\b([A-Z][A-Z0-9_]+)\b", body)[:50]
        # variables / placeholders
        for i, line in enumerate(clean):
            for m in VAR_RE.finditer(line):
                f["vars"][m.group(2)].add(m.group(1))
            for m in VAR2_RE.finditer(line):
                f["vars"][m.group(1)].add(m.group(2))
            for m in VAR3_RE.finditer(line):
                f["vars"][m.group(1)].add(m.group(2))
            for m in PLACEHOLDER_RE.finditer(line):
                f["placeholders"].add(m.group(1))
            for m in CS_CONFIG_RE.finditer(line):
                f["placeholders"].add(next(g for g in m.groups() if g).replace(":", "."))
            for m in re.finditer(r"(?:getenv|environ(?:\.get)?|process\.env)\s*[\[(.]\s*['\"]?([A-Z_][A-Z0-9_]*)", line):
                f["placeholders"].add(m.group(1))
        # hits
        for i, line in enumerate(clean):
            if not line.strip() or IMPORT_LINE_RE.match(line):
                continue
            decl_only = "(" not in line and self._field_decl(line, lang) is not None
            for cat, sub, rx in HIT_RES:
                if rx.search(line):
                    if decl_only and cat in ("db", "outbound", "messaging", "cache"):
                        continue
                    self._hit(f, i, cat, sub)

    @staticmethod
    def _split_params(s):
        out, depth, cur = [], 0, ""
        for ch in s:
            if ch in "<([":
                depth += 1
            elif ch in ">)]":
                depth -= 1
            if ch == "," and depth == 0:
                out.append(cur)
                cur = ""
            else:
                cur += ch
        if cur.strip():
            out.append(cur)
        return out

    @staticmethod
    def _param_field(pp, lang):
        anns = parse_annotations(pp)
        al = ALIAS_RE.search(pp)
        pp2 = re.sub(r"@\w+(\([^)]*\))?\s*|\[[^\]]*\]\s*", "", pp).strip()
        pp2 = pp2.split("=")[0].strip()
        rec = None
        m = re.match(r"(?:val|var)?\s*(\w+)\s*:\s*([\w.<>\[\]?, ]+)", pp2) if lang in ("kotlin", "scala", "ts", "py") else None
        if m:
            rec = {"name": m.group(1), "type": m.group(2).strip(), "annotations": anns}
        else:
            m = re.match(r"(?:final\s+)?([\w.<>\[\]?, ]+?)\s+(\w+)$", pp2)
            if m:
                rec = {"name": m.group(2), "type": m.group(1).strip(), "annotations": anns}
        if rec and al:
            rec["alias"] = next(g for g in al.groups() if g)
        return rec

    def _field_decl(self, line, lang):
        s = LEAD_ANN_RE.sub("", line)
        if re.search(r"\bstatic\b|\bconst\b", s) and not re.search(r"\bdata\b", s):
            return None
        rx = {"cs": CS_PROP_RE, "kotlin": KT_PROP_RE, "scala": KT_PROP_RE, "ts": TS_PROP_RE, "js": None, "py": PY_PROP_RE}.get(lang, JAVA_FIELD_RE)
        if rx is None:
            return None
        m = rx.search(s) if rx in (KT_PROP_RE,) else rx.match(s)
        if not m and lang == "cs":
            m = JAVA_FIELD_RE.match(s)
        if not m:
            return None
        name, typ = m.group("name"), m.group("type").strip()
        if name in KEYWORDS or typ in ("return", "new", "throw", "else", "package", "import"):
            return None
        return {"name": name, "type": typ}

    def _method_decl(self, line, blank, lang, raw, i):
        if lang == "py":
            m = PY_DEF_RE.match(line)
            return (m.group(2), None) if m else (None, None)
        if lang == "go":
            m = GO_FUNC_RE.match(line)
            return (m.group(2), m.group(1)) if m else (None, None)
        if lang in ("js", "ts"):
            m = JS_FUNC_RE.match(line)
            if m:
                return (m.group(1) or m.group(2), None)
        s = LEAD_ANN_RE.sub("", blank)
        m = METHOD_RE.match(s)
        if not m:
            return None, None
        name = m.group("name")
        ret = (m.group("ret") or "").strip()
        mods = (m.group("mods") or "").strip()
        if name in KEYWORDS or ret.split("<")[0] in KEYWORDS or ret.endswith("."):
            return None, None
        if not mods and not ret:
            if lang in ("js", "ts") and re.search(r"\)\s*(?::\s*[^={;]+)?\{\s*$", s) and line.startswith((" ", "\t")):
                return name, None
            return None, None
        if "=" in s.split("(")[0]:
            return None, None
        return name, None

    @staticmethod
    def _enclosing_class(f, i):
        best = None
        for c in f["classes"]:
            if c["start"] <= i <= c["end"] and (best is None or c["start"] >= best["start"]):
                best = c
        return best

    def _enclosing_method(self, f, i):
        best = None
        for m in f["methods"]:
            if m["start"] <= i <= m["end"] and (best is None or m["start"] >= best["start"]):
                best = m
        return best

    def _hit(self, f, i, cat, sub):
        line = f["clean"][i]
        ctx = " ".join(f["clean"][i:i + 4])
        keys = []
        if cat == "db":
            sql_ctx = (ctx if sub in ("sql", "orm", "jdbc", "linq2sql") else line).replace("[", "").replace("]", "")
            for t in SQL_TABLE_RE.findall(sql_ctx) if sub != "linq-query" else []:
                tn = t.upper()
                if tn.split(".")[-1] not in SQL_NOT_TABLE and not tn.isdigit():
                    keys.append(("table", tn.split(".")[-1]))
            for rx in PROC_RES:
                for pn in rx.findall(ctx):
                    keys.append(("proc", proc_key(pn)))
            if sub == "stored-proc" and re.search(r"StoredProcedure", line):
                win = " ".join(f["clean"][max(0, i - 6):i + 3])
                for pn in re.findall(r"(?:SqlCommand|OracleCommand|NpgsqlCommand|DbCommand|Query\w*|Execute\w*|CommandText\s*=)\s*(?:<[^>]*>)?\s*\(?\s*\$?\"([\w.\[\]$#]+)\"", win):
                    keys.append(("proc", proc_key(pn)))
            if sub == "stored-proc" and not any(k[0] == "proc" for k in keys):
                for ident in re.findall(r"with(?:Procedure|Function)Name\s*\(\s*([A-Za-z_]\w*)\s*\)|StoredProcedureQuery\s*\(\s*([A-Za-z_]\w*)", ctx):
                    keys.append(("proc-const", next(x for x in ident if x)))
        if cat in ("outbound", "endpoint"):
            for lit in PATH_LIT_RE.findall(ctx) + [x for x in REL_PATH_RE.findall(ctx) if not MEDIA_TYPE_RE.match(x)]:
                k = self.path_key(lit)
                if k:
                    keys.append(("path", k))
        if cat in ("outbound", "messaging"):
            for ph in PLACEHOLDER_RE.findall(ctx):
                keys.append(("config", ph))
        if cat == "messaging":
            for s in re.findall(r"(?:CreateSender|CreateReceiver|convertAndSend|[Ss]end|Produce|BasicPublish|GetQueue\w*|QueueClient|TopicClient|"
                                r"Destination|Topic|Queue|routingKey|exchange)\w*\s*\(\s*\"([\w.\-/:]{3,80})\"", line):
                keys.append(("queue", s.upper()))
        meth = self._enclosing_method(f, i)
        self.hits.append({"cat": cat, "sub": sub, "file": f["path"], "fidx": f["idx"], "line": i + 1,
                          "method": meth["name"] if meth else None,
                          "text": f["raw"][i].strip()[:180], "keys": sorted(set(keys))})

    @staticmethod
    def path_key(lit):
        p = lit
        if is_url(p):
            p = urllib.parse.urlparse(p).path
        p = PLACEHOLDER_RE.sub("", p)
        segs = [s for s in p.split("/") if s and not s.startswith("{") and not s.startswith(":") and s not in (".", "..")]
        segs = [s for s in segs if re.match(r"^[A-Za-z0-9_\-.]+$", s)]
        if not segs:
            return None
        if len(segs) == 1 and "." in segs[0]:
            return None  # file name, not an API path
        return "/" + "/".join(s.lower() for s in segs)

    # ---- config
    def _conf(self, p, rel, ext):
        txt = self._read(p)
        entries = []
        if ext in (".yml", ".yaml"):
            stack = []
            for ln, line in enumerate(txt.splitlines(), 1):
                if not line.strip() or line.lstrip().startswith(("#", "-")):
                    continue
                m = re.match(r"^(\s*)([\w.\-\[\]\"']+)\s*:\s*(.*)$", line)
                if not m:
                    continue
                ind = len(m.group(1))
                while stack and stack[-1][0] >= ind:
                    stack.pop()
                key = m.group(2).strip("\"'")
                val = m.group(3).strip().strip("\"'")
                full = ".".join([s[1] for s in stack] + [key])
                if val and not val.startswith("#"):
                    entries.append((full, val, ln))
                else:
                    stack.append((ind, key))
        elif ext == ".json":
            try:
                obj = json.loads(txt)
            except ValueError:
                return

            def walk(o, pre):
                if isinstance(o, dict):
                    for k, v in o.items():
                        walk(v, pre + [str(k)])
                elif isinstance(o, (str, int, float, bool)):
                    entries.append((".".join(pre), str(o), 0))
            walk(obj, [])
        elif ext == ".config" or rel.lower().endswith(".config"):
            for ln, line in enumerate(txt.splitlines(), 1):
                for m in re.finditer(r"<add\s+(?:key|name)=\"([^\"]+)\"[^>]*?(?:value|connectionString)=\"([^\"]+)\"", line):
                    entries.append((m.group(1), m.group(2), ln))
                for m in re.finditer(r"address=\"([^\"]+)\"", line):
                    entries.append(("endpoint.address", m.group(1), ln))
        else:
            for ln, line in enumerate(txt.splitlines(), 1):
                m = re.match(r"^\s*([\w.\-\[\]]+)\s*[=:]\s*(.*)$", line)
                if m and not line.lstrip().startswith(("#", "!", ";")):
                    entries.append((m.group(1), m.group(2).strip(), ln))
        for k, v, ln in entries:
            self.config[k] = (v, rel, ln)
            for h in value_hosts(v):
                self.config_hosts[h].append((k, rel, ln))

    def _orm_model(self, p, rel, ext):
        """LINQ to SQL .dbml / EF6 .edmx: entity-set property -> table, method -> stored procedure."""
        txt = self._read(p)
        self.orm_models.append(rel)
        if ext == ".dbml":
            def attr(tag, name):
                a = re.search(r"\b%s=\"([^\"]+)\"" % name, tag)
                return a.group(1) if a else None
            for m in re.finditer(r"<Table\s+([^>]*)>\s*<Type\s+([^>]*)>", txt):
                tname, member, typ = attr(m.group(1), "Name"), attr(m.group(1), "Member"), attr(m.group(2), "Name")
                if tname and typ:
                    self.entity_table[typ] = tname.replace("[", "").replace("]", "").split(".")[-1]
                    if member:
                        self.dbsets[member] = typ
            for m in re.finditer(r"<Function\s+([^>]*)>", txt):
                fname, meth = attr(m.group(1), "Name"), attr(m.group(1), "Method")
                if fname:
                    self.db_funcs[meth or fname.split(".")[-1]] = fname.replace("[", "").replace("]", "")
        else:  # edmx: EntitySetMapping / FunctionImportMapping (best effort)
            for m in re.finditer(r"<EntitySetMapping\s+Name=\"(\w+)\"[\s\S]{0,400}?TypeName=\"[\w.()]*?\.?(\w+)\)?\"[\s\S]{0,300}?StoreEntitySet=\"(\w+)\"", txt):
                self.dbsets[m.group(1)] = m.group(2)
                self.entity_table[m.group(2)] = m.group(3)
            for m in re.finditer(r"<FunctionImportMapping\s+FunctionImportName=\"(\w+)\"\s+FunctionName=\"[\w.]*?\.?(\w+)\"", txt):
                self.db_funcs[m.group(1)] = m.group(2)

    def _xml(self, p, rel):
        txt = self._read(p)
        if "<mapper" in txt[:3000]:
            lines = txt.splitlines()
            for i, line in enumerate(lines):
                m = re.search(r"<(select|insert|update|delete)\s+[^>]*id=\"(\w+)\"", line)
                if m:
                    body = " ".join(lines[i:i + 15])
                    self.mapper_stmts[m.group(2)].append((rel, i + 1, body))
        elif re.search(r"<(beans|configuration|jaxws|cxf|spring)", txt[:3000]) or rel.lower().endswith(".config"):
            self._conf(p, rel, ".config")
            for ln, line in enumerate(txt.splitlines(), 1):
                for h in HOST_RE.findall(line):
                    self.config_hosts[h.lower()].append(("xml", rel, ln))

    def resolve_hosts(self, placeholder):
        """config key (or section) -> hosts. Matches exact key, section prefix, or suffix (ConnectionStrings.X)."""
        out = set()

        def kn(s):
            return s.lower().replace("-", "").replace("_", ".").replace(":", ".")
        c = kn(placeholder)
        for k, (v, rel, ln) in self.config.items():
            k2 = kn(k)
            if k2 == c or k2.startswith(c + ".") or k2.endswith("." + c):
                out |= value_hosts(v)
        return out

    # ---- lookup helpers
    def class_recs(self, name):
        return self.classes.get(name, [])

    def methods_named(self, cls_name, mname):
        out = []
        for c in self.class_recs(cls_name):
            f = self.files[c["fidx"]]
            for m in f["methods"]:
                if m["name"] == mname and c["start"] <= m["decl"] <= c["end"]:
                    out.append((f, m))
        return out

    def subclasses(self, name, depth=0):
        out = set()
        if depth > 6:
            return out
        for ch in self.children.get(name, ()):
            out.add(ch)
            out |= self.subclasses(ch, depth + 1)
        return out

    def superclasses(self, name, depth=0):
        out = set()
        if depth > 6:
            return out
        for c in self.class_recs(name):
            for p in c["parents"]:
                if p in self.classes:
                    out.add(p)
                    out |= self.superclasses(p, depth + 1)
        return out

    def summary(self):
        return {"root": self.root, "files": len(self.files), "classes": sum(len(v) for v in self.classes.values()),
                "methods": sum(len(f["methods"]) for f in self.files), "hits": len(self.hits),
                "sqlFiles": self.sql_files[:50]}


JOBS = 1   # set from --jobs


def _index_worker(batch, label="repo"):
    """Parse a batch of source files in isolation (runs in a worker process). Returns (files, hits, outcomes)."""
    w = RepoIndex.__new__(RepoIndex)
    w.files, w.hits, w.classes, w.label = [], [], defaultdict(list), label
    outcomes = []
    for p, rel, lang in batch:
        t1 = time.time()
        n_files, n_hits = len(w.files), len(w.hits)
        try:
            w._code(p, rel, lang)
            outcomes.append((rel, time.time() - t1, None))
        except Exception as e:  # noqa
            del w.files[n_files:]
            del w.hits[n_hits:]
            outcomes.append((rel, time.time() - t1, "%s: %s\n%s" % (type(e).__name__, e, traceback.format_exc(limit=3))))
    return w.files, w.hits, outcomes


# --------------------------------------------------------------------------- slicing

class Slice:
    """Best-effort method-level reachability from entry methods."""

    def __init__(self, repo, entries, max_depth=8, max_methods=400):
        self.repo = repo
        self.lines = defaultdict(set)       # fidx -> set(line index)
        self.methods = []                   # (file, method)
        self.types = set()
        self.visited = set()
        self.visited_classes = set()
        self.method_lines = defaultdict(set)  # only lines inside visited method bodies
        q_ = deque((f, m, 0) for f, m in entries)
        while q_ and len(self.visited) < max_methods:
            f, m, d = q_.popleft()
            key = (f["idx"], m["decl"])
            if key in self.visited:
                continue
            self.visited.add(key)
            self.methods.append((f, m))
            for i in range(m["start"], m["end"] + 1):
                self.lines[f["idx"]].add(i)
                self.method_lines[f["idx"]].add(i)
            cls = self.repo._enclosing_class(f, m["decl"])
            if cls and (f["idx"], cls["start"]) not in self.visited_classes:
                self.visited_classes.add((f["idx"], cls["start"]))
                # lifecycle code runs for every call: constructors, @PostConstruct, afterPropertiesSet
                for x in f["methods"]:
                    if cls["start"] <= x["decl"] <= cls["end"] and (
                            x["name"] == cls["name"] or x["name"] in ("afterPropertiesSet", "__init__") or
                            re.search(r"@PostConstruct", " ".join(f["clean"][x["start"]:x["decl"] + 1]))):
                        q_.append((f, x, d))
            if cls:  # class-level lines (fields/constants/annotations) are shared context
                inner = [x for x in f["methods"] if cls["start"] <= x["decl"] <= cls["end"]]
                for i in range(cls["start"], cls["end"] + 1):
                    if not any(x["start"] <= i <= x["end"] for x in inner):
                        self.lines[f["idx"]].add(i)
            if d >= max_depth:
                continue
            for nf, nm in self._callees(f, m, cls):
                q_.append((nf, nm, d + 1))

    def _callees(self, f, m, cls):
        repo = self.repo
        body = "\n".join(f["clean"][m["decl"]:m["end"] + 1])
        own = cls["name"] if cls else None
        out = []
        targets = []  # (class name, method name)
        for recv, meth in CALL_RECV_RE.findall(body) + METHREF_RE.findall(body):
            types = set()
            if recv in ("this", "self", "base", "super"):
                types.add(own)
                if recv in ("super", "base") and own:
                    types |= repo.superclasses(own)
            elif recv in repo.classes:
                types.add(recv)
            for t in f["vars"].get(recv, ()):
                types.add(t)
            for t in types:
                if t:
                    targets.append((t, meth))
            if not types and recv[:1].islower():
                # unknown receiver: try classes referenced by this file that define the method
                for t in self._file_types(f):
                    targets.append((t, meth))
        for name in CALL_RE.findall(body):
            if name in KEYWORDS:
                continue
            if own:
                targets.append((own, name))
                for sup in repo.superclasses(own):
                    targets.append((sup, name))
            if name in repo.classes:  # constructor
                targets.append((name, name))
        for t in NEW_RE.findall(body):
            targets.append((t, t))
        # interface / abstract method -> implementations of the same method
        if own:
            for sub in repo.subclasses(own):
                targets.append((sub, m["name"]))
        for t in TYPE_TOKEN_RE.findall(body):
            if t in repo.classes:
                self.types.add(t)
            # mediator / bus dispatch: Send(new XCommand()) -> XCommandHandler.Handle
            for h in repo.handlers.get(t, ()):
                for hm in ("Handle", "HandleAsync", "Consume", "Execute", "ExecuteAsync", "handle", "Process"):
                    targets.append((h, hm))
        # MyBatis mapper statements
        for name in set(CALL_RE.findall(body)) | {mm for _, mm in CALL_RECV_RE.findall(body)}:
            for rel, ln, text in repo.mapper_stmts.get(name, []):
                self.types.add("mapper:" + name)
        seen = set()
        for t, meth in targets:
            for cname in {t} | repo.subclasses(t):
                if (cname, meth) in seen:
                    continue
                seen.add((cname, meth))
                for nf, nm in repo.methods_named(cname, meth):
                    out.append((nf, nm))
                if cname in repo.classes:
                    self.types.add(cname)
        return out

    def _file_types(self, f):
        ts = set()
        for v in f["vars"].values():
            ts |= {t for t in v if t in self.repo.classes}
        return ts

    def contains(self, hit):
        return (hit["line"] - 1) in self.lines.get(hit["fidx"], ())

    def files(self):
        return sorted({self.repo.files[i]["path"] for i in self.lines})


# --------------------------------------------------------------------------- comparison helpers

XSD_FAMILY = {}
for _t in ("string", "normalizedString", "token", "anyURI", "ID", "IDREF", "NCName", "Name", "language", "QName",
           "NMTOKEN", "ENTITY", "union", "list"):
    XSD_FAMILY[_t] = "string"
for _t in ("int", "integer", "long", "short", "byte", "unsignedInt", "unsignedLong", "unsignedShort", "unsignedByte",
           "positiveInteger", "negativeInteger", "nonNegativeInteger", "nonPositiveInteger"):
    XSD_FAMILY[_t] = "int"
XSD_FAMILY.update({"decimal": "decimal", "double": "float", "float": "float", "boolean": "bool", "dateTime": "datetime",
                   "date": "date", "time": "time", "base64Binary": "binary", "hexBinary": "binary", "duration": "duration",
                   "anyType": "any", "anySimpleType": "any", "any": "any", "gYear": "int"})

CODE_FAMILY = {
    "string": "string", "str": "string", "charsequence": "string", "uuid": "string", "guid": "string", "char[]": "string",
    "int": "int", "integer": "int", "long": "int", "short": "int", "byte": "int", "biginteger": "int", "int32": "int",
    "int64": "int", "int16": "int", "uint": "int", "ulong": "int", "atomicinteger": "int", "atomiclong": "int",
    "bigdecimal": "decimal", "decimal": "decimal", "double": "float", "float": "float", "single": "float",
    "number": "number", "boolean": "bool", "bool": "bool",
    "localdatetime": "datetime", "offsetdatetime": "datetime", "zoneddatetime": "datetime", "instant": "datetime",
    "datetime": "datetime", "datetimeoffset": "datetime", "xmlgregoriancalendar": "datetime", "calendar": "datetime",
    "timestamp": "datetime", "date": "date|datetime", "localdate": "date", "dateonly": "date", "localtime": "time",
    "timeonly": "time", "timespan": "duration", "duration": "duration", "byte[]": "binary", "bytes": "binary",
    "object": "any", "jsonnode": "any", "any": "any", "dynamic": "any",
}
COLLECTION_RE = re.compile(r"^(List|ArrayList|Set|HashSet|Collection|Iterable|IEnumerable|IList|ICollection|IReadOnlyList|"
                           r"Array|Seq|MutableList|Sequence|list|set|tuple|Flux)\b|\[\]$")


def code_type_info(t):
    t = (t or "").strip().rstrip("?")
    t = re.sub(r"^(Optional|Nullable|Mono|Task|ResponseEntity|ActionResult|Maybe)\s*<(.*)>$", r"\2", t)
    is_list = bool(COLLECTION_RE.search(t)) or t.endswith("[]") and t.lower() not in ("byte[]", "char[]")
    elem = t
    if is_list:
        ga = generic_args(t)
        elem = ga[-1] if ga else t[:-2] if t.endswith("[]") else t
    base = strip_generics(elem).split(".")[-1].strip()
    fam = CODE_FAMILY.get(base.lower()) or CODE_FAMILY.get(t.lower())
    return {"base": base, "list": is_list, "family": fam}


def type_compat(xsd_type, code_t, repo):
    xf = XSD_FAMILY.get(xsd_type)
    info = code_type_info(code_t)
    cf = info["family"]
    if xf is None or xf == "any":
        return "OK", ""
    if cf is None:
        cls = repo.class_recs(info["base"])
        if cls and cls[0]["is_enum"] and xf == "string":
            return "OK", "enum"
        return "WARN", "code type %s vs xsd %s" % (info["base"], xsd_type)
    if cf == "any":
        return "OK", ""
    if xf == cf or (xf in ("date", "datetime") and "date" in cf and cf != "date") or (xf == "datetime" and cf == "date|datetime") or (xf == "date" and cf == "date|datetime"):
        return "OK", ""
    if xf == "decimal" and cf == "float":
        return "WARN", "precision drift: xsd decimal -> floating point %s" % info["base"]
    if xf == "datetime" and cf == "date":
        return "WARN", "time part lost: xsd dateTime -> %s" % info["base"]
    if cf == "number" and xf in ("int", "decimal", "float"):
        return "OK", ""
    if xf in ("int",) and cf in ("decimal", "float"):
        return "WARN", "int -> %s" % info["base"]
    if xf in ("decimal", "float") and cf == "int":
        return "WARN", "fraction lost: xsd %s -> %s" % (xsd_type, info["base"])
    return "MISMATCH", "xsd %s vs code %s" % (xsd_type, info["base"])


REQ_ANN = re.compile(r"^(NotNull|NotBlank|NotEmpty|Required|NonNull|Nonnull|JsonProperty\(.*required\s*=\s*true)", re.I)
PAT_ANN = re.compile(r"^(Pattern|RegularExpression|Email|EmailAddress)", re.I)
LEN_ANN = re.compile(r"^(Size|Length|MaxLength|StringLength|MinLength)", re.I)
RANGE_ANN = re.compile(r"^(Min|Max|DecimalMin|DecimalMax|Positive|PositiveOrZero|Negative|Range|Digits)", re.I)


def validation_gaps(sf, fd, repo, imperative_fields):
    gaps = []
    anns = fd.get("annotations", []) if fd else []
    typ = fd.get("type", "") if fd else ""
    nm = norm(sf["name"])
    imp = nm in imperative_fields
    r = sf.get("restr", {})
    required = isinstance(sf.get("min"), int) and sf["min"] >= 1 and not sf.get("choice") and not sf.get("nillable")
    value_type = re.match(r"^(int|long|double|boolean|bool|short|float|decimal|byte|char|DateTime|DateTimeOffset|DateOnly|TimeOnly|Guid|TimeSpan)$", typ)
    implicit_nrt = repo.nullable_enabled and typ and not typ.endswith("?") and re.match(r"^(string|[A-Z]\w*)$", typ) and not typ.startswith(("List", "IList", "IEnumerable"))
    if required and not any(REQ_ANN.match(a) for a in anns) and not value_type:
        gaps.append(("required", "minOccurs=1", "IMPLICIT_NRT" if implicit_nrt and not imp else imp))
    if "pattern" in r and not any(PAT_ANN.match(a) for a in anns):
        gaps.append(("pattern", r["pattern"], imp))
    if any(k in r for k in ("length", "maxLength", "minLength")) and not any(LEN_ANN.match(a) for a in anns):
        gaps.append(("length", ",".join("%s=%s" % (k, r[k]) for k in ("length", "minLength", "maxLength") if k in r), imp))
    if any(k in r for k in ("minInclusive", "maxInclusive", "minExclusive", "maxExclusive", "totalDigits")) and not any(RANGE_ANN.match(a) for a in anns):
        gaps.append(("range", ",".join("%s=%s" % (k, r[k]) for k in ("minInclusive", "maxInclusive", "minExclusive", "maxExclusive", "totalDigits") if k in r), imp))
    if "enumeration" in r:
        info = code_type_info(typ)
        cls = repo.class_recs(info["base"])
        if not (cls and cls[0]["is_enum"]) and not any(PAT_ANN.match(a) for a in anns):
            gaps.append(("enumeration", "|".join(r["enumeration"][:10]), imp))
        elif cls and cls[0]["is_enum"]:
            missing = [v for v in r["enumeration"] if norm(v) not in {norm(x) for x in cls[0].get("enum_values", [])}]
            if missing:
                gaps.append(("enumeration", "enum %s lacks %s" % (info["base"], ",".join(missing[:10])), imp))
    return gaps


class ContractMatcher:
    def __init__(self, fields, repo, names):
        self.fields = fields
        self.repo = repo
        self.names = names
        self.by_parent = defaultdict(list)
        for f in fields:
            parent = f["path"].rsplit("/", 1)[0] if "/" in f["path"] else ""
            self.by_parent[parent].append(f)
        self.rows = []

    def children(self, path):
        return self.by_parent.get(path, [])

    def class_score(self, path, cls):
        kids = self.children(path)
        if not kids or not cls["fields"]:
            return 0.0, {}
        mapping, used = {}, set()
        for k in kids:
            best, bf = 0.0, None
            for fd in cls["fields"]:
                if fd["name"] in used:
                    continue
                s = self.names.sim(k["name"], fd["name"])
                if fd.get("alias"):
                    s = max(s, self.names.sim(k["name"], fd["alias"]))
                if s > best:
                    best, bf = s, fd
            if bf and best >= 0.8:
                mapping[k["path"]] = (bf, best)
                used.add(bf["name"])
        score = sum(s for _, s in mapping.values()) / len(kids)
        return round(score, 3), mapping

    def best_class(self, path, candidates=None, top=3):
        pool = []
        names = candidates if candidates is not None else list(self.repo.classes.keys())
        for n in names:
            for c in self.repo.class_recs(n):
                if c["is_enum"]:
                    continue
                s, _ = self.class_score(path, c)
                if s > 0:
                    pool.append((s, c))
        pool.sort(key=lambda x: (-x[0], len(x[1]["fields"])))
        return pool[:top]

    def compare(self, root_path, cls, depth=0, out=None):
        out = out if out is not None else []
        score, mapping = self.class_score(root_path, cls)
        used = set()
        for k in self.children(root_path):
            m = mapping.get(k["path"])
            row = {"path": k["path"], "xsdType": k["type"], "min": k["min"], "max": k["max"],
                   "restr": k.get("restr", {}), "choice": k.get("choice"), "attr": k.get("attr"),
                   "repoClass": cls["name"], "repoFile": cls["file"]}
            if not m:
                row.update(status="MISSING", repoField=None)
                out.append(row)
                if k["complex"]:
                    for d in self._descendants(k["path"]):
                        out.append({"path": d["path"], "xsdType": d["type"], "min": d["min"], "max": d["max"],
                                    "restr": d.get("restr", {}), "status": "MISSING(parent)", "repoField": None,
                                    "repoClass": None, "repoFile": None})
                continue
            fd, sim = m
            used.add(fd["name"])
            row.update(repoField=fd["name"] + ((" (wire: %s)" % fd["alias"]) if fd.get("alias") else ""),
                       repoFieldName=fd["name"], repoType=fd["type"], repoLine=fd.get("line"), sim=sim,
                       annotations=fd.get("annotations", []), validatedBy=fd.get("validatedBy"),
                       status="MATCH" if sim >= 0.95 else "FUZZY")
            info = code_type_info(fd["type"])
            notes = []
            if k.get("list") and not info["list"]:
                notes.append("xsd repeating, code single")
            if not k.get("list") and info["list"] and not k["complex"]:
                notes.append("code collection, xsd single")
            if not k["complex"]:
                st, msg = type_compat(k["type"], fd["type"], self.repo)
                row["typeCheck"] = st
                if msg:
                    notes.append(msg)
            row["notes"] = "; ".join(notes)
            out.append(row)
            if k["complex"] and depth < 12 and not k["type"].startswith("RECURSIVE"):
                child_path = k["path"]
                kids = self.children(child_path)
                # wrapper collapse: <items><item[]/></items>  <->  List<LineItem> items  (also WCF ArrayOfX)
                if len(kids) == 1 and kids[0].get("list") and info["list"]:
                    row_w = {"path": kids[0]["path"], "xsdType": kids[0]["type"], "min": kids[0]["min"],
                             "max": kids[0]["max"], "restr": kids[0].get("restr", {}), "status": "MATCH",
                             "repoField": fd["name"] + "[]", "repoType": info["base"],
                             "repoClass": cls["name"], "repoFile": cls["file"], "repoLine": fd.get("line"),
                             "notes": "wrapper collapsed"}
                    out.append(row_w)
                    if not kids[0]["complex"]:
                        st, msg = type_compat(kids[0]["type"], info["base"], self.repo)
                        row_w["typeCheck"] = st
                        if msg:
                            row_w["notes"] += "; " + msg
                        continue
                    child_path = kids[0]["path"]
                target = [c for c in self.repo.class_recs(info["base"]) if not c["is_enum"]]
                if not target:
                    for ga in generic_args(fd["type"]):
                        target = [c for c in self.repo.class_recs(ga) if not c["is_enum"]]
                        if target:
                            break
                if target:
                    self.compare(child_path, target[0], depth + 1, out)
                else:
                    bc = self.best_class(child_path, top=1)
                    if bc and bc[0][0] >= 0.5:
                        self.compare(child_path, bc[0][1], depth + 1, out)
                    else:
                        for d in self._descendants(child_path):
                            out.append({"path": d["path"], "xsdType": d["type"], "min": d["min"], "max": d["max"],
                                        "restr": d.get("restr", {}), "status": "UNRESOLVED", "repoField": None,
                                        "repoClass": None, "repoFile": None,
                                        "notes": "code type %s not found in repo" % info["base"]})
        for fd in cls["fields"]:
            if fd["name"] not in used:
                out.append({"path": root_path + "/(" + fd["name"] + ")", "xsdType": None, "status": "EXTRA_IN_REPO",
                            "repoField": fd["name"], "repoType": fd["type"], "repoClass": cls["name"],
                            "repoFile": cls["file"], "repoLine": fd.get("line")})
        return out

    def _descendants(self, path):
        return [f for f in self.fields if f["path"].startswith(path + "/")]


def method_sig_types(repo, f, m):
    toks = set(TYPE_TOKEN_RE.findall(m["sig"]))
    ret = set()
    pre = m["sig"].split("(")[0]
    for t in TYPE_TOKEN_RE.findall(pre):
        ret.add(t)
    params = set(TYPE_TOKEN_RE.findall(m["sig"][len(pre):]))
    return {t for t in params if t in repo.classes}, {t for t in ret if t in repo.classes}, toks


def literal_set(lines):
    out = set()
    for line in lines:
        if LOG_LINE_RE.search(line):
            continue
        for s1, s2 in STR_RE.findall(line):
            s = s1 or s2
            if 1 <= len(s) <= 40 and not re.search(r"\s(FROM|WHERE|SELECT)\s", s, re.I) and not s.startswith(("http", "/", "$")):
                try:
                    out.add(("num", "%g" % float(s)))
                except ValueError:
                    out.add(("str", s.lower()))
        for n in NUM_RE.findall(STR_RE.sub("", line)):
            try:
                out.add(("num", "%g" % float(n)))
            except ValueError:
                pass
    return out


# --------------------------------------------------------------------------- per-operation analysis

SOAP_MARK_RE = re.compile(r"@WebService|@WebMethod|@Endpoint\b|@PayloadRoot|@SoapAction|OperationContract|ServiceContract|@ResponsePayload|"
                          r"WebServiceGatewaySupport|\[WebMethod|\[WebService|\[SoapDocumentMethod|System\.Web\.Services")
ENDPOINT_ANN_RE = re.compile(r"@(Get|Post|Put|Delete|Patch|Request)Mapping|@(GET|POST|PUT|DELETE|PATCH)\b|@Path\b|\[Http(Get|Post|Put|Delete|Patch)|"
                             r"@WebMethod|@PayloadRoot|@SoapAction|\bOperationContract\b|\[WebMethod|@(app|router|api)\.(route|get|post|put|delete|patch)|"
                             r"\bMap(Get|Post|Put|Delete)\s*\(|@(JmsListener|KafkaListener|RabbitListener)")


def base_name(n):
    return re.sub(r"(Async|_async)$", "", n or "")


def find_repo1_entries(repo, op, names):
    cands = []
    opn = op["wsdlName"]
    req_root = op["request"][0]["name"] if op["request"] else None
    impl = op.get("implClass")
    if impl:   # .svc given: the implementing class is known -> pin the entry to it
        want = {norm(op.get("codeMethod") or ""), norm(opn)} - {""}
        pinned = []
        for c in repo.class_recs(impl):
            f = repo.files[c["fidx"]]
            for m in f["methods"]:
                if c["start"] < m["decl"] <= c["end"] and (norm(m["name"]) in want or norm(base_name(m["name"])) in want):
                    pinned.append((f, m))
        if pinned:
            return pinned[:4]
        warn("entry: %s.%s not found in implementing class - falling back to name search" % (impl, op.get("codeMethod") or opn))
    for f in repo.files:
        file_soap = any(SOAP_MARK_RE.search(x) for x in f["clean"][:400])
        for m in f["methods"]:
            ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
            s = names.sim(base_name(m["name"]), opn)
            strong = bool(re.search(r"operationName\s*=\s*\"%s\"|localPart\s*=\s*\"(%s|%s)\"|SoapAction\([^)]*%s|"
                                    r"OperationContract\s*\([^)]*Name\s*=\s*\"%s\"|Action\s*=\s*\"[^\"]*[/:]%s\"|MessageName\s*=\s*\"%s\"" % (
                re.escape(opn), re.escape(opn), re.escape(req_root or opn), re.escape(opn), re.escape(opn), re.escape(opn), re.escape(opn)), ann))
            if req_root and re.search(r"\b%s\b" % re.escape(req_root), m["sig"]) and file_soap:
                strong = True
            if strong:
                score = 3.0
            elif s >= 0.95:
                score = 2.0 + (0.5 if file_soap or SOAP_MARK_RE.search(ann) else 0)
            else:
                continue
            cands.append((score, f, m))
    cands.sort(key=lambda x: -x[0])
    if not cands:
        return []
    top = cands[0][0]
    return [(f, m) for s, f, m in cands if s >= top - 0.5][:4]


def repo2_endpoints(repo):
    eps = []
    for f in repo.files:
        class_route = {}
        for c in f["classes"]:
            a = ann_start(f["clean"], c["start"])
            txt = " ".join(f["clean"][a:c["start"] + 1])
            m = re.search(r"@RequestMapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?\"([^\"]*)\"|\[Route\(\s*\"([^\"]*)\"|@Path\(\s*\"([^\"]*)\"", txt)
            if m:
                class_route[c["name"]] = m.group(1) or m.group(2) or m.group(3)
        for m in f["methods"]:
            ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
            if not ENDPOINT_ANN_RE.search(ann):
                continue
            rm = re.search(r"Mapping\s*\(\s*(?:value\s*=\s*|path\s*=\s*)?\"([^\"]*)\"|\[Http\w+\(\s*\"([^\"]*)\"|\[Route\(\s*\"([^\"]*)\"|@Path\(\s*\"([^\"]*)\"|\.(?:route|get|post|put|delete|patch)\(\s*['\"]([^'\"]*)|Map\w+\(\s*\"([^\"]*)\"", ann)
            route = next((g for g in (rm.groups() if rm else ()) if g), "")
            verb = re.search(r"@(Get|Post|Put|Delete|Patch)Mapping|\[Http(Get|Post|Put|Delete|Patch)|@(GET|POST|PUT|DELETE)|\.(get|post|put|delete|patch)\(", ann)
            verb = next((g for g in (verb.groups() if verb else ()) if g), "SOAP" if re.search(r"WebMethod|PayloadRoot|SoapAction|OperationContract", ann) else "")
            croute = class_route.get(m["cls"], "")
            full = (croute + "/" + route).replace("//", "/") if route or croute else ""
            full = full.replace("[controller]", re.sub(r"Controller$", "", m["cls"] or "").lower()).replace("[action]", m["name"].lower())
            eps.append({"file": f["path"], "fidx": f["idx"], "line": m["decl"] + 1, "method": m["name"], "cls": m["cls"],
                        "route": full, "verb": verb.upper(), "f": f, "m": m})
        # ASP.NET Core minimal API: app.MapPost("/x", handler | lambda)
        for i, line in enumerate(f["clean"]):
            mm = re.search(r"\.Map(Get|Post|Put|Delete|Patch)\s*\(\s*\"([^\"]+)\"\s*,\s*(.*)", line)
            if not mm:
                continue
            rest = mm.group(3)
            hm = re.match(r"\s*(?:\w+\.)*(\w+)\s*\)", rest)
            found = False
            if hm and "=>" not in rest:
                for f2 in repo.files:
                    for m2 in f2["methods"]:
                        if m2["name"] == hm.group(1):
                            eps.append({"file": f2["path"], "fidx": f2["idx"], "line": m2["decl"] + 1, "method": m2["name"],
                                        "cls": m2["cls"], "route": mm.group(2), "verb": mm.group(1).upper(), "f": f2, "m": m2})
                            found = True
            if not found:
                end = block_end([blank_strings(x) for x in f["clean"]], i, f["lang"], f["raw"])
                pseudo = {"name": "lambda@%d" % (i + 1), "start": i, "decl": i, "end": max(end, i), "cls": None,
                          "sig": " ".join(f["clean"][i:min(end + 1, i + 3)])[:400]}
                eps.append({"file": f["path"], "fidx": f["idx"], "line": i + 1, "method": pseudo["name"], "cls": None,
                            "route": mm.group(2), "verb": mm.group(1).upper(), "f": f, "m": pseudo})
        # JS/Express style: router.post('/x', handler)
        for i, line in enumerate(f["clean"]):
            mm = re.search(r"\b(app|router|server)\.(get|post|put|delete|patch)\s*\(\s*['\"`]([^'\"`]+)['\"`]\s*,\s*(?:[\w.]+\s*,\s*)*([\w.]+)\s*\)", line)
            if mm:
                handler = mm.group(4).split(".")[-1]
                for f2 in repo.files:
                    for m2 in f2["methods"]:
                        if m2["name"] == handler:
                            eps.append({"file": f2["path"], "fidx": f2["idx"], "line": m2["decl"] + 1, "method": handler,
                                        "cls": m2["cls"], "route": mm.group(3), "verb": mm.group(2).upper(), "f": f2, "m": m2})
    return eps


def rank_repo2(op, eps, repo2, names):
    req_root = op["request"][0]["path"] if op["request"] else None
    res_root = op["response"][0]["path"] if op["response"] else None
    cm_req = ContractMatcher(op["request"], repo2, names)
    cm_res = ContractMatcher(op["response"], repo2, names)
    op_nouns = nouns(op["wsdlName"])
    ranked = []
    for ep in eps:
        params, rets, _ = method_sig_types(repo2, ep["f"], ep["m"])
        name_s = names.sim(base_name(ep["method"]), op["wsdlName"])
        ep_nouns = nouns(ep["method"], ep["route"] or "")
        noun_s = len(op_nouns & ep_nouns) / max(1, len(op_nouns)) if op_nouns else 0
        req_s, req_cls = 0.0, None
        for t in params:
            for c in repo2.class_recs(t):
                s, _ = cm_req.class_score(req_root, c) if req_root else (0, None)
                if s > req_s:
                    req_s, req_cls = s, c
        res_s, res_cls = 0.0, None
        for t in rets | set(generic_args(ep["m"]["sig"].split("(")[0])):
            for c in repo2.class_recs(t):
                s, _ = cm_res.class_score(res_root, c) if res_root else (0, None)
                if s > res_s:
                    res_s, res_cls = s, c
        total = 0.25 * max(name_s if name_s >= 0.8 else 0, noun_s) + 0.5 * req_s + 0.25 * res_s
        if name_s >= 0.95:
            total = max(total, 0.6)
        ranked.append({"score": round(total, 3), "ep": ep, "req_cls": req_cls, "res_cls": res_cls,
                       "req_s": req_s, "res_s": res_s, "name_s": max(name_s, noun_s)})
    ranked.sort(key=lambda x: -x["score"])
    return ranked


def hit_ref(h):
    return "%s:%d" % (h["file"], h["line"])


def integration_keys(hits, repo):
    keys = defaultdict(list)
    for h in hits:
        if h["cat"] not in ("db", "outbound", "messaging", "cache"):
            continue
        for k in h["keys"]:
            if k[0] == "config":
                for host in repo.resolve_hosts(k[1]):
                    keys[("host", host)].append(h)
                continue
            keys[k].append(h)
        f = repo.files[h["fidx"]]
        if h["cat"] == "outbound":
            phs = set(f["placeholders"])
            for c in f["classes"]:
                phs |= repo.typed_client_cfg.get(c["name"], set())
            for ph in phs:
                hosts = {ph[5:]} if ph.startswith("host:") else repo.resolve_hosts(ph)
                for host in hosts:
                    keys[("host", host)].append(h)
    return keys


def entity_keys(slice_, repo):
    out = defaultdict(list)
    for fidx, ls in slice_.method_lines.items():
        f = repo.files[fidx]
        for i in ls:
            m_ = repo._enclosing_method(f, i)
            if m_ and m_["decl"] == i and re.search(r"\{\s*get\b", f["clean"][i]):
                continue  # property declaration of the context class, not a usage
            line = STR_RE.sub('""', f["clean"][i])
            # EF DbSet / LINQ to SQL Table<T> usage: _db.Customers.Where(..), from c in db.Customers, db.Orders.InsertOnSubmit(..)
            for prop in set(re.findall(r"\.\s*(\w+)\b(?!\s*\()", line)):
                ent = repo.dbsets.get(prop)
                if ent:
                    out[("table", repo.entity_table.get(ent, prop).split(".")[-1].upper())].append(
                        {"file": f["path"], "line": i + 1, "text": "entity set " + prop})
            for ent in re.findall(r"\b(?:Set|GetTable)\s*<\s*(\w+)\s*>\s*\(", line):
                if ent in repo.entity_table:
                    out[("table", repo.entity_table[ent].split(".")[-1].upper())].append({"file": f["path"], "line": i + 1, "text": "Set<%s>" % ent})
            # stored-procedure wrapper methods (LINQ to SQL [Function], EF6 function imports)
            for fn in set(re.findall(r"\.\s*(\w+)\s*\(", line)):
                if fn in repo.db_funcs:
                    out[("proc", proc_key(repo.db_funcs[fn]))].append({"file": f["path"], "line": i + 1, "text": "proc wrapper " + fn})
    for t in slice_.types:
        tbl = repo.entity_table.get(t)
        if tbl:
            c = repo.class_recs(t)[0]
            out[("table", tbl.upper())].append({"file": c["file"], "line": c["start"] + 1, "text": "entity " + t})
    for f, m in slice_.methods:
        cls = repo._enclosing_class(f, m["decl"])
        if cls and any(re.search(r"Repository|Dao|DAO|Mapper|DbContext|CrudRepository", p) for p in cls["parents"] + [cls["name"]]):
            for ga in generic_args(" ".join(f["clean"][cls["start"]:cls["start"] + 2])):
                tbl = repo.entity_table.get(ga)
                if tbl:
                    out[("table", tbl.upper())].append({"file": f["path"], "line": m["decl"] + 1, "text": "repository " + cls["name"] + "." + m["name"]})
    return out


def analyze_operation(op, repo1, repo2, names, eps2, args):
    res = {"operation": op["name"], "soapAction": op.get("soapAction"), "address": op.get("address"),
           "requestFields": len(op["request"]), "responseFields": len(op["response"]), "review": []}
    # ---- repo1 slice
    s1 = None
    if repo1:
        entries = find_repo1_entries(repo1, op, names)
        res["repo1Entry"] = ["%s:%d %s" % (f["path"], m["decl"] + 1, m["name"]) for f, m in entries]
        if entries:
            s1 = Slice(repo1, entries, args.max_depth)
            res["repo1SliceFiles"] = s1.files()
        else:
            res["review"].append("repo1 entry method for %s not found - search manually" % op["wsdlName"])
    # ---- repo2 candidate
    ranked = rank_repo2(op, eps2, repo2, names)
    res["repo2Candidates"] = [{"score": r["score"], "at": "%s:%d" % (r["ep"]["file"], r["ep"]["line"]),
                               "method": r["ep"]["method"], "route": r["ep"]["route"], "verb": r["ep"]["verb"],
                               "requestClass": r["req_cls"]["name"] if r["req_cls"] else None,
                               "responseClass": r["res_cls"]["name"] if r["res_cls"] else None} for r in ranked[:3] if r["score"] > 0]
    best = ranked[0] if ranked and ranked[0]["score"] >= args.min_score else None
    s2 = None
    if best:
        s2 = Slice(repo2, [(best["ep"]["f"], best["ep"]["m"])], args.max_depth)
        res["repo2SliceFiles"] = s2.files()
    # ---- contract
    req_root = op["request"][0] if op["request"] else None
    res_root = op["response"][0] if op["response"] else None
    contract = {}
    for label, root, cls, flds in (("request", req_root, best and best["req_cls"], op["request"]),
                                   ("response", res_root, best and best["res_cls"], op["response"])):
        if not root:
            continue
        cm = ContractMatcher(flds, repo2, names)
        note = ""
        if not cls:
            bc = cm.best_class(root["path"], top=1)
            if bc and bc[0][0] >= 0.5:
                cls = bc[0][1]
                note = "no endpoint signature match; best DTO by field overlap (%.0f%%)" % (bc[0][0] * 100)
        if cls:
            rows = cm.compare(root["path"], cls)
        else:
            rows = [{"path": f["path"], "xsdType": f["type"], "min": f["min"], "max": f["max"], "restr": f.get("restr", {}),
                     "status": "MISSING", "repoField": None} for f in flds[1:]]
        contract[label] = {"rootClass": cls["name"] if cls else None, "rootFile": cls["file"] if cls else None,
                           "note": note, "rows": rows}
    res["contract"] = contract
    # ---- integrations
    hits1 = [h for h in repo1.hits if s1 and s1.contains(h)] if repo1 else []
    hits2 = [h for h in repo2.hits if s2 and s2.contains(h)]
    k1 = integration_keys(hits1, repo1) if repo1 else {}
    if s1:
        for k, v in entity_keys(s1, repo1).items():
            k1.setdefault(k, []).extend(v)
    k2 = integration_keys(hits2, repo2)
    if s2:
        for k, v in entity_keys(s2, repo2).items():
            k2.setdefault(k, []).extend(v)
    k2_all = integration_keys(repo2.hits, repo2)

    def path_match(k, pool):
        if k[0] != "path":
            return pool.get(k)
        for kk, v in pool.items():
            if kk[0] == "path" and (kk[1] == k[1] or kk[1].startswith(k[1] + "/") or k[1].startswith(kk[1] + "/")) and min(len(kk[1]), len(k[1])) > 3:
                return v
        return None

    integ = []
    for k, hs in sorted(k1.items()):
        m2 = path_match(k, k2)
        st = "MATCH" if m2 else None
        if not m2:
            m2 = path_match(k, k2_all)
            st = "FOUND_ELSEWHERE" if m2 else "MISSING"
        integ.append({"kind": k[0], "key": k[1], "status": st,
                      "repo1": sorted({"%s:%s" % (h["file"], h["line"]) for h in hs})[:4],
                      "repo2": sorted({"%s:%s" % (h["file"], h["line"]) for h in (m2 or [])})[:4]})
    for k, hs in sorted(k2.items()):
        if not path_match(k, k1):
            integ.append({"kind": k[0], "key": k[1], "status": "EXTRA_IN_REPO2", "repo1": [],
                          "repo2": sorted({"%s:%s" % (h["file"], h["line"]) for h in hs})[:4]})
    res["integrations"] = integ
    # unkeyed integration hits (could not extract table/url) - list for review
    res["repo1Hits"] = [{"cat": h["cat"], "sub": h["sub"], "at": hit_ref(h), "method": h["method"], "text": h["text"]}
                        for h in hits1 if h["cat"] in ("db", "outbound", "messaging", "cache", "validation", "error", "transaction", "security")]
    res["repo2Hits"] = [{"cat": h["cat"], "sub": h["sub"], "at": hit_ref(h), "method": h["method"], "text": h["text"]}
                        for h in hits2 if h["cat"] in ("db", "outbound", "messaging", "cache", "validation", "error", "transaction", "security")]
    # ---- validations
    imp2 = set()
    leaf_names = {norm(f["name"]) for f in op["request"]}
    for h in hits2:
        if h["cat"] == "validation" and h["sub"] == "imperative":
            f = repo2.files[h["fidx"]]
            ctx = " ".join(f["clean"][max(0, h["line"] - 3):h["line"]]).lower()
            for ln in leaf_names:
                if ln and ln in norm(ctx):
                    imp2.add(ln)
    vgaps = []
    by_path = {f["path"]: f for f in op["request"]}
    for row in contract.get("request", {}).get("rows", []):
        sf = by_path.get(row["path"])
        if not sf or sf["complex"] or row["status"].startswith("MISSING") or row["status"] in ("EXTRA_IN_REPO", "UNRESOLVED"):
            continue
        fd = {"type": row.get("repoType", ""), "annotations": row.get("annotations", [])}
        for rule, detail, imp in validation_gaps(sf, fd, repo2, imp2):
            vgaps.append({"path": row["path"], "rule": rule, "xsd": detail, "repo2Field": row.get("repoField"),
                          "repo2": "%s:%s" % (row.get("repoFile"), row.get("repoLine")),
                          "status": imp if isinstance(imp, str) else "CHECK_IMPERATIVE" if imp else "GAP"})
    rv1 = []
    for h in hits1:
        if h["cat"] == "validation" and h["sub"] == "imperative":
            f = repo1.files[h["fidx"]]
            ctx = norm(" ".join(f["clean"][max(0, h["line"] - 3):h["line"]]))
            flds = sorted({f2["name"] for f2 in op["request"] if not f2["complex"] and len(norm(f2["name"])) > 2 and norm(f2["name"]) in ctx})
            rv1.append({"at": hit_ref(h), "fields": flds, "text": h["text"],
                        "repo2HasForFields": [x for x in flds if norm(x) in imp2 or any(
                            r.get("repoFieldName") and names.sim(r["repoFieldName"], x) >= 0.8 and r.get("annotations") for r in contract.get("request", {}).get("rows", []))]})
    res["validationGaps"] = vgaps
    res["repo1ImperativeValidations"] = rv1
    # ---- business rule signals
    rules = []

    def lits_of(line, repo):
        out = literal_set([line])
        for ident in re.findall(r"\b([A-Za-z_]\w*)\b", STR_RE.sub("", line)):
            if ident in repo.constants and not CONST_RE.search(line):
                out |= repo.constants[ident]
        return out
    if s1:
        lines2 = []
        if s2:
            for fidx, ls in s2.lines.items():
                lines2 += [repo2.files[fidx]["clean"][i] for i in ls]
        lits2 = set()
        for ln_ in lines2:
            lits2 |= lits_of(ln_, repo2)
        lits2_all = None
        for fidx, ls in sorted(s1.lines.items()):
            f = repo1.files[fidx]
            for i in sorted(ls):
                line = f["clean"][i]
                code_only = STR_RE.sub('""', line)
                uses_const = any(ident in repo1.constants for ident in re.findall(r"\b([A-Za-z_]\w*)\b", code_only))
                if not (RULE_LINE_RE.search(code_only) or re.search(r"\bBigDecimal\s*\(\s*\"", line) or
                        (uses_const and re.search(r"[*/+\-]|\b(Math|Decimal|BigDecimal)\.", code_only))) or LOG_LINE_RE.search(line):
                    continue
                if CONST_RE.search(line) or re.match(r"^\s*(throw|raise|@|\[)", line):
                    continue  # constant declarations are evaluated where they are used
                if re.search(r"==\s*null|!=\s*null|is\s+None|is\s+not\s+None|IsNullOrEmpty|IsNullOrWhiteSpace", line) and not literal_set([line]):
                    continue
                lits = lits_of(line, repo1)
                if not lits:
                    st = "REVIEW"
                    found = []
                else:
                    found = [v for v in lits if v in lits2]
                    if len(found) == len(lits):
                        st = "LITERALS_IN_REPO2_SLICE"
                    else:
                        if lits2_all is None:
                            lits2_all = literal_set([ln for fx in repo2.files for ln in fx["clean"]])
                        found_all = [v for v in lits if v in lits2_all]
                        st = "LITERALS_ELSEWHERE_IN_REPO2" if found_all and len(found_all) == len(lits) else ("PARTIAL" if found or found_all else "NOT_FOUND")
                m = repo1._enclosing_method(f, i)
                rules.append({"at": "%s:%d" % (f["path"], i + 1), "method": m["name"] if m else None,
                              "text": f["raw"][i].strip()[:160], "literals": sorted(v for _, v in lits), "status": st})
    res["businessRules"] = rules[:args.max_rules]
    # ---- auto verdict
    rows_req = [r for r in contract.get("request", {}).get("rows", []) if r["status"] != "EXTRA_IN_REPO"]
    rows_res = [r for r in contract.get("response", {}).get("rows", []) if r["status"] != "EXTRA_IN_REPO"]
    all_rows = rows_req + rows_res

    def pts(r):
        if r["status"] == "MATCH":
            return 1.0 if r.get("typeCheck", "OK") == "OK" else 0.7
        if r["status"] == "FUZZY":
            return 0.7 if r.get("typeCheck", "OK") == "OK" else 0.5
        return 0.0
    c_score = sum(pts(r) for r in all_rows) / len(all_rows) if all_rows else 0
    i_items = [x for x in integ if x["status"] != "EXTRA_IN_REPO2"]
    i_score = (sum(1 if x["status"] == "MATCH" else 0.5 if x["status"] == "FOUND_ELSEWHERE" else 0 for x in i_items) / len(i_items)) if i_items else None
    v_items = len(vgaps)
    r_items = [x for x in rules if x["status"] != "REVIEW"]
    r_score = (sum(1 if x["status"] == "LITERALS_IN_REPO2_SLICE" else 0.5 if x["status"] in ("PARTIAL", "LITERALS_ELSEWHERE_IN_REPO2") else 0 for x in r_items) / len(r_items)) if r_items else None
    parts = [(0.5, c_score)]
    if i_score is not None:
        parts.append((0.3, i_score))
    if r_score is not None:
        parts.append((0.2, r_score))
    total = sum(w * s for w, s in parts) / sum(w for w, _ in parts)
    total -= min(0.1, 0.01 * v_items)
    if not best and c_score < 0.3:
        verdict = "NOT_IMPLEMENTED"
    elif not best:
        verdict = "PARTIAL (DTOs exist, no endpoint found)"
    elif total >= 0.9:
        verdict = "FULL (verify)"
    elif total >= 0.3:
        verdict = "PARTIAL"
    else:
        verdict = "MOSTLY_MISSING"
    res["scores"] = {"contract": round(c_score, 3), "integrations": None if i_score is None else round(i_score, 3),
                     "rules": None if r_score is None else round(r_score, 3), "validationGaps": v_items,
                     "overall": round(max(0, total), 3)}
    res["verdict"] = verdict
    # ---- review queue for the LLM
    q_ = res["review"]
    for r in all_rows:
        if r["status"] == "FUZZY":
            q_.append("CONFIRM name mapping %s -> %s.%s (%s:%s)" % (r["path"], r.get("repoClass"), r["repoField"], r.get("repoFile"), r.get("repoLine")))
        if r.get("typeCheck") in ("WARN", "MISMATCH"):
            q_.append("TYPE %s: %s (%s:%s)" % (r["path"], r.get("notes"), r.get("repoFile"), r.get("repoLine")))
    for x in integ:
        if x["status"] in ("MISSING", "FOUND_ELSEWHERE"):
            q_.append("INTEGRATION %s %s is %s; repo1 %s; repo2 %s" % (x["kind"], x["key"], x["status"], ", ".join(x["repo1"][:2]), ", ".join(x["repo2"][:2]) or "-"))
    for x in rules:
        if x["status"] in ("NOT_FOUND", "PARTIAL", "REVIEW"):
            q_.append("RULE %s at %s: `%s`" % (x["status"], x["at"], x["text"][:100]))
    for x in rv1:
        if set(x["fields"]) - set(x["repo2HasForFields"]) or not x["fields"]:
            q_.append("VALIDATION repo1 %s `%s` - check repo2" % (x["at"], x["text"][:90]))
    res["review"] = q_[:args.max_review]
    return res


# --------------------------------------------------------------------------- reporting

def md_table(rows, cols, limit):
    if not rows:
        return "_none_\n"
    out = ["| " + " | ".join(c[0] for c in cols) + " |", "|" + "---|" * len(cols)]
    for r in rows[:limit]:
        out.append("| " + " | ".join(str(c[1](r)).replace("|", "\\|").replace("\n", " ") for c in cols) + " |")
    if len(rows) > limit:
        out.append("\n_... %d more rows in parity.json_" % (len(rows) - limit))
    return "\n".join(out) + "\n"


def restr_s(r):
    if not r:
        return ""
    return ",".join("%s=%s" % (k, ("|".join(v[:5]) + ("..." if len(v) > 5 else "")) if isinstance(v, list) else v) for k, v in r.items())[:60]


def global_checks(ops, repo1, repo2):
    out = {"hosts": [], "delegation": []}
    if repo1:
        h1, h2 = repo1.config_hosts, repo2.config_hosts
        for h in sorted(set(h1) | set(h2)):
            if h in ("localhost", "127.0.0.1", "schemas.xmlsoap.org", "www.w3.org", "schemas.microsoft.com", "tempuri.org"):
                continue
            st = "BOTH" if h in h1 and h in h2 else "REPO1_ONLY" if h in h1 else "REPO2_ONLY"
            out["hosts"].append({"host": h, "status": st,
                                 "repo1": ", ".join("%s (%s)" % (k, rel) for k, rel, ln in h1.get(h, [])[:2]),
                                 "repo2": ", ".join("%s (%s)" % (k, rel) for k, rel, ln in h2.get(h, [])[:2])})
    addr_hosts = {urllib.parse.urlparse(o["address"]).hostname for o in ops if o.get("address")} - {None, "localhost"}
    addr_paths = {urllib.parse.urlparse(o["address"]).path.lower() for o in ops if o.get("address")} - {"", "/"}
    for h in addr_hosts:
        for k, rel, ln in repo2.config_hosts.get(h.lower(), []):
            out["delegation"].append("repo2 config %s:%s (%s) points to the SOAP service host %s" % (rel, ln, k, h))
    for hit in repo2.hits:
        if hit["sub"] == "soap-client" or any(p and p in hit["text"].lower() for p in addr_paths):
            out["delegation"].append("repo2 %s:%d `%s`" % (hit["file"], hit["line"], hit["text"][:100]))
    out["delegation"] = out["delegation"][:15]
    return out


def write_summary(path, ops, results, args, repo1, repo2, extra_eps, glob=None):
    glob = glob or {}
    L = []
    L.append("# SOAP parity summary (auto-generated by soap_parity.py %s)\n" % VERSION)
    L.append("WSDL: `%s`  \nrepo1: `%s`  \nrepo2: `%s`\n" % (args.wsdl, repo1.root if repo1 else "(not given)", repo2.root))
    L.append("Statuses are heuristic. `MATCH` = same normalized name; `FUZZY` = similar name, confirm; "
             "`MISSING` = no counterpart found; `FOUND_ELSEWHERE` = exists in repo2 but not reachable from the matched endpoint.\n")
    L.append("## Overview\n")
    L.append(md_table(results, [("Operation", lambda r: r["operation"]), ("Auto verdict", lambda r: r["verdict"]),
                                ("Overall", lambda r: r["scores"]["overall"]), ("Contract", lambda r: r["scores"]["contract"]),
                                ("Integrations", lambda r: r["scores"]["integrations"]), ("Rules", lambda r: r["scores"]["rules"]),
                                ("Val. gaps", lambda r: r["scores"]["validationGaps"]),
                                ("repo2 endpoint", lambda r: (r["repo2Candidates"][0]["method"] + " " + (r["repo2Candidates"][0]["verb"] or "") + " " + (r["repo2Candidates"][0]["route"] or "")) if r["repo2Candidates"] and r["verdict"] not in ("NOT_IMPLEMENTED",) and not r["verdict"].startswith("PARTIAL (DTO") else "-")], 500))
    for r in results:
        L.append("\n---\n## Operation `%s` -> **%s**\n" % (r["operation"], r["verdict"]))
        if r.get("soapAction"):
            L.append("soapAction: `%s`  " % r["soapAction"])
        if r.get("repo1Entry"):
            L.append("repo1 entry: " + "; ".join("`%s`" % x for x in r["repo1Entry"]) + "  ")
        if r.get("repo1SliceFiles"):
            L.append("repo1 reachable files (%d): %s  " % (len(r["repo1SliceFiles"]), ", ".join("`%s`" % x for x in r["repo1SliceFiles"][:args.max_rows])))
        L.append("repo2 candidates: " + ("; ".join("`%s` %s %s (score %.2f, req=%s, res=%s)" % (c["at"], c["method"], c["route"] or "", c["score"], c["requestClass"], c["responseClass"]) for c in r["repo2Candidates"]) or "none") + "  ")
        if r.get("repo2SliceFiles"):
            L.append("repo2 reachable files (%d): %s" % (len(r["repo2SliceFiles"]), ", ".join("`%s`" % x for x in r["repo2SliceFiles"][:args.max_rows])))
        for label in ("request", "response"):
            c = r["contract"].get(label)
            if not c:
                continue
            rows = c["rows"]
            cnt = defaultdict(int)
            for x in rows:
                cnt[x["status"]] += 1
            L.append("\n### %s contract (repo2 class: `%s` %s) - %s\n" % (
                label.capitalize(), c["rootClass"], ("`%s`" % c["rootFile"]) if c["rootFile"] else "", ", ".join("%s=%d" % kv for kv in sorted(cnt.items()))))
            if c["note"]:
                L.append("_%s_\n" % c["note"])
            show = [x for x in rows if args.all_rows or x["status"] != "MATCH" or x.get("typeCheck") in ("WARN", "MISMATCH") or x.get("notes")]
            L.append(md_table(show, [("XSD path", lambda x: x["path"]), ("xsd type", lambda x: x.get("xsdType") or ""),
                                     ("occ", lambda x: "%s..%s" % (x.get("min", ""), x.get("max", "")) if x.get("xsdType") else ""),
                                     ("restrictions", lambda x: restr_s(x.get("restr"))),
                                     ("repo2 field", lambda x: ("%s : %s" % (x["repoField"], x.get("repoType", ""))) if x.get("repoField") else "-"),
                                     ("status", lambda x: x["status"] + ("/" + x["typeCheck"] if x.get("typeCheck") not in (None, "OK") else "")),
                                     ("notes", lambda x: x.get("notes", ""))], args.max_rows))
        L.append("\n### Integrations (DB tables / procs / HTTP paths / hosts / queues)\n")
        L.append(md_table(r["integrations"], [("kind", lambda x: x["kind"]), ("key", lambda x: x["key"]), ("status", lambda x: x["status"]),
                                              ("repo1", lambda x: ", ".join(x["repo1"][:2])), ("repo2", lambda x: ", ".join(x["repo2"][:2]))], args.max_rows))
        unkeyed = [h for h in r["repo1Hits"] if h["cat"] in ("db", "outbound", "messaging")]
        if unkeyed:
            L.append("\nrepo1 integration call sites in slice:\n")
            L.append(md_table(unkeyed, [("cat", lambda x: x["cat"] + "/" + x["sub"]), ("at", lambda x: x["at"]), ("code", lambda x: "`%s`" % x["text"][:100])], args.max_rows))
        L.append("\n### Validation gaps (XSD rule not enforced on repo2 DTO)\n")
        L.append(md_table(r["validationGaps"], [("path", lambda x: x["path"]), ("rule", lambda x: x["rule"]), ("xsd", lambda x: x["xsd"][:50]),
                                                ("repo2", lambda x: x["repo2"]), ("status", lambda x: x["status"])], args.max_rows))
        if r["repo1ImperativeValidations"]:
            L.append("\nrepo1 code-level validations:\n")
            L.append(md_table(r["repo1ImperativeValidations"], [("at", lambda x: x["at"]), ("fields", lambda x: ",".join(x["fields"])),
                                                                 ("repo2 has", lambda x: ",".join(x["repo2HasForFields"]) or "?"),
                                                                 ("code", lambda x: "`%s`" % x["text"][:90])], args.max_rows))
        L.append("\n### Business-rule signals (repo1 conditions/calculations; literal match in repo2)\n")
        L.append(md_table(r["businessRules"], [("at", lambda x: x["at"]), ("method", lambda x: x["method"]), ("literals", lambda x: ",".join(x["literals"])[:40]),
                                               ("status", lambda x: x["status"]), ("code", lambda x: "`%s`" % x["text"][:90])], args.max_rows))
        L.append("\n### LLM review queue (verify ONLY these; open +/-15 lines around each ref)\n")
        L.append("\n".join("%d. %s" % (i + 1, x) for i, x in enumerate(r["review"])) or "_none_")
        L.append("")
    if glob.get("delegation"):
        L.append("\n---\n## CHECK: repo2 has SOAP-client calls or references the legacy service address\n")
        L.extend("- %s" % x for x in glob["delegation"])
        L.append("\nIf so, matching DTOs do not prove reimplementation - verify whether repo2 is only a facade.\n")
    if glob.get("hosts"):
        L.append("\n---\n## External dependencies from configuration (whole repo, not per operation)\n")
        L.append(md_table(glob["hosts"], [("host", lambda x: x["host"]), ("status", lambda x: x["status"]),
                                          ("repo1 config", lambda x: x["repo1"]), ("repo2 config", lambda x: x["repo2"])], 60))
    if extra_eps:
        L.append("\n---\n## repo2 endpoints not matched to any WSDL operation\n")
        L.append(md_table(extra_eps, [("at", lambda e: "%s:%d" % (e["file"], e["line"])), ("method", lambda e: e["method"]),
                                      ("verb", lambda e: e["verb"]), ("route", lambda e: e["route"])], args.max_rows))
    if WARNINGS:
        L.append("\n---\n## Extraction warnings (fix these first - they reduce accuracy)\n")
        L.extend("- " + w for w in WARNINGS[:60])
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


def jsonable(o):
    if isinstance(o, dict):
        return {k: jsonable(v) for k, v in o.items() if k not in ("f", "m", "raw", "clean")}
    if isinstance(o, (list, tuple, set)):
        return [jsonable(x) for x in o]
    return o


# --------------------------------------------------------------------------- .svc -> contract from WCF source code

CS_XSD = {"string": "string", "int": "int", "int32": "int", "long": "long", "int64": "long", "short": "short", "int16": "short",
          "byte": "unsignedByte", "sbyte": "byte", "uint": "unsignedInt", "ulong": "unsignedLong", "ushort": "unsignedShort",
          "decimal": "decimal", "double": "double", "float": "float", "single": "float", "bool": "boolean", "boolean": "boolean",
          "datetime": "dateTime", "datetimeoffset": "dateTime", "dateonly": "date", "timespan": "duration", "guid": "string",
          "char": "int", "object": "anyType", "uri": "anyURI", "xmlelement": "anyType", "xelement": "anyType"}
CS_LIST_RE = re.compile(r"^(?:System\.Collections\.Generic\.)?(?:List|IList|ICollection|IEnumerable|Collection|IReadOnlyList|"
                        r"IReadOnlyCollection|HashSet|ISet|ObservableCollection)\s*<\s*(.+)>$")


def read_svc(path):
    """<%@ ServiceHost Service="Ns.QuoteService, Asm" CodeBehind="QuoteService.svc.cs" %> -> (class, codebehind)."""
    txt = RepoIndex._read(path)
    m = re.search(r"\bService\s*=\s*\"([^\"]+)\"", txt)
    cb = re.search(r"\bCodeBehind\s*=\s*\"([^\"]+)\"", txt)
    cls = m.group(1).split(",")[0].strip().split(".")[-1] if m else None
    return cls, cb.group(1) if cb else None, txt.strip()[:200]


def find_solution_root(start):
    """Walk up from the .svc folder to the folder holding the .sln (or .git). Fallback: two levels up."""
    d = os.path.abspath(start)
    for _ in range(8):
        try:
            names = os.listdir(d)
        except OSError:
            break
        if any(n.lower().endswith(".sln") for n in names) or ".git" in names:
            return d
        parent = os.path.dirname(d)
        if parent == d:
            break
        d = parent
    return os.path.dirname(os.path.abspath(start))


class SvcContract:
    """Build the same operation/field structure as the WSDL path, from [ServiceContract]/[DataContract] C# code."""
    MAX_DEPTH = 12

    def __init__(self, repo, impl_class):
        self.repo = repo
        self.impl = impl_class
        self.fields = []

    def _cls(self, name):
        recs = [c for c in self.repo.class_recs(name) if c["lang"] in ("cs", "vb")]
        return recs[0] if recs else None

    def contract_interfaces(self):
        names = {self.impl} | self.repo.superclasses(self.impl)
        out = []
        for n in sorted(names):
            for c in self.repo.class_recs(n):
                if any(a.startswith("ServiceContract") for a in c["annotations"]):
                    out.append(c)
        return out

    def operations(self):
        ops = []
        ifaces = self.contract_interfaces()
        if not ifaces:
            impl = self._cls(self.impl)
            if impl and any(a.startswith("ServiceContract") for a in impl["annotations"]):
                ifaces = [impl]
        for itf in ifaces:
            f = self.repo.files[itf["fidx"]]
            ns_m = re.search(r"Namespace\s*=\s*\"([^\"]+)\"", " ".join(itf["annotations"]))
            cname_m = re.search(r"ServiceContract\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"", " ".join(itf["annotations"]))
            ns = ns_m.group(1) if ns_m else "http://tempuri.org/"
            cname = cname_m.group(1) if cname_m else itf["name"]
            for m in f["methods"]:
                if not (itf["start"] < m["decl"] <= itf["end"]):
                    continue
                ann = " ".join(f["clean"][m["start"]:m["decl"] + 1])
                if "OperationContract" not in ann:
                    continue
                op = self._operation(f, m, ann, ns, cname, itf)
                if op:
                    ops.append(op)
        return ops

    def _operation(self, f, m, ann, ns, cname, itf):
        nm = re.search(r"OperationContract\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"", ann)
        opname = nm.group(1) if nm else base_name(m["name"])
        act = re.search(r"OperationContract\s*\([^)]*\bAction\s*=\s*\"([^\"]+)\"", ann)
        sm = re.match(r"\s*(?:\[[^\]]*\]\s*)*(?:(?:public|internal|virtual|abstract)\s+)*([\w.<>\[\],? ]+?)\s+(\w+)\s*\((.*)\)",
                      LEAD_ANN_RE.sub("", m["sig"]))
        if not sm:
            warn("svc: cannot parse signature of %s.%s at %s:%d" % (itf["name"], m["name"], f["path"], m["decl"] + 1))
            return None
        ret, params = sm.group(1).strip(), sm.group(3)
        tm = re.match(r"^(?:System\.Threading\.Tasks\.)?(?:Task|ValueTask)\s*<\s*(.+)>$", ret)
        ret = tm.group(1).strip() if tm else ("void" if re.match(r"^(?:Task|ValueTask)$", ret) else ret)
        rec = {"name": opname, "wsdlName": opname, "portType": cname, "address": None, "style": "document",
               "soapAction": act.group(1) if act else "%s/%s/%s" % (ns.rstrip("/"), cname, opname),
               "request": [], "response": [], "faults": [], "source": "svc-code",
               "codeMethod": m["name"], "codeAt": "%s:%d" % (f["path"], m["decl"] + 1), "implClass": self.impl}
        plist = [self.repo._param_field(p, "cs") for p in RepoIndex._split_params(params)]
        plist = [p for p in plist if p and not re.search(r"\b(out|ref)\b", p["type"]) and p["type"] != "CancellationToken"]
        # request
        if len(plist) == 1 and self._is_complex(plist[0]["type"]):
            self.fields = []
            self._root(plist[0]["type"], rec)
            rec["request"] = self.fields
        else:
            self.fields = [self._f(opname, opname, "(wrapper)", complex_=True)]
            for p in plist:
                self._member(opname, p.get("alias") or p["name"], p["type"], 1, [], {})
            rec["request"] = self.fields
        # response
        self.fields = []
        if ret == "void":
            self.fields = [self._f(opname + "Response", opname + "Response", "(wrapper)", complex_=True)]
        elif self._is_complex(ret):
            self._root(ret, rec)
        else:
            root = opname + "Response"
            self.fields = [self._f(root, root, "(wrapper)", complex_=True)]
            self._member(root, opname + "Result", ret, 0, [], {})
        rec["response"] = self.fields
        # faults
        flt = []
        for ft in re.findall(r"FaultContract\s*\(\s*typeof\s*\(\s*([\w.]+)\s*\)", ann):
            self.fields = []
            self._root(ft.split(".")[-1], rec)
            flt.extend(self.fields)
        rec["faults"] = flt
        return rec

    def _is_complex(self, t):
        t = t.strip().rstrip("?")
        if CS_LIST_RE.match(t) or t.endswith("[]"):
            return False
        c = self._cls(t.split(".")[-1])
        return bool(c and not c["is_enum"])

    def _wire(self, c):
        m = re.search(r"(?:DataContract|MessageContract|XmlType|XmlRoot|CollectionDataContract)\s*\([^)]*\bName\s*=\s*\"([^\"]+)\"",
                      " ".join(c["annotations"]))
        if not m:
            m = re.search(r"(?:XmlType|XmlRoot)\s*\(\s*\"([^\"]+)\"", " ".join(c["annotations"]))
        return m.group(1) if m else c["name"]

    def _f(self, path, name, typ, mn=1, mx=1, complex_=False, restr=None, lst=False):
        return {"path": path, "name": name, "type": typ, "min": mn, "max": mx, "complex": complex_, "attr": False,
                "choice": False, "nillable": False, "list": lst, "restr": restr or {}}

    def _root(self, t, rec):
        c = self._cls(t.strip().rstrip("?").split(".")[-1])
        if not c:
            self.fields.append(self._f(t, t, "UNRESOLVED:" + t))
            return
        wire = self._wire(c)
        if any(a.startswith("MessageContract") for a in c["annotations"]):
            wm = re.search(r"WrapperName\s*=\s*\"([^\"]+)\"", " ".join(c["annotations"]))
            wire = wm.group(1) if wm else wire
        self.fields.append(self._f(wire, wire, c["name"], complex_=True))
        self._members(c, wire, [c["name"]])

    def _class_members(self, c, depth=0):
        out = []
        if depth < 6:
            for p in c["parents"]:
                pc = self._cls(p)
                if pc and pc["kind"] in ("class", "record", "struct") and not pc["is_enum"]:
                    out.extend(self._class_members(pc, depth + 1))
        anns_all = " ".join(c["annotations"])
        explicit = bool(re.search(r"\b(DataContract|MessageContract)\b", anns_all))
        for fd in c["fields"]:
            fa = " ".join(fd.get("annotations", []))
            if re.search(r"\b(IgnoreDataMember|XmlIgnore|NonSerialized|JsonIgnore)\b", fa):
                continue
            if explicit and not re.search(r"\b(DataMember|MessageBodyMember|MessageHeader)\b", fa):
                continue
            out.append(fd)
        return out

    def _members(self, c, path, stack):
        for fd in self._class_members(c):
            fa = " ".join(fd.get("annotations", []))
            req = 1 if ("Required(DataMember)" in fd.get("annotations", []) or re.search(r"\bRequired\b", fa)) else 0
            self._member(path, fd.get("alias") or fd["name"], fd["type"], req, stack, self._restr(fa))

    @staticmethod
    def _restr(fa):
        r = {}
        m = re.search(r"StringLength\s*\(\s*(\d+)", fa) or re.search(r"MaxLength\s*\(\s*(\d+)", fa)
        if m:
            r["maxLength"] = m.group(1)
        m = re.search(r"MinimumLength\s*=\s*(\d+)", fa) or re.search(r"MinLength\s*\(\s*(\d+)", fa)
        if m:
            r["minLength"] = m.group(1)
        m = re.search(r"Range\s*\(\s*([-\d.]+)\s*,\s*([-\d.]+)", fa)
        if m:
            r["minInclusive"], r["maxInclusive"] = m.group(1), m.group(2)
        m = re.search(r"RegularExpression\s*\(\s*@?\"((?:[^\"]|\"\")*)\"", fa)
        if m:
            r["pattern"] = m.group(1)
        return r

    def _member(self, parent, name, t, req, stack, restr):
        t = t.strip()
        nullable = t.endswith("?")
        t = t.rstrip("?")
        lm = CS_LIST_RE.match(t)
        lst = bool(lm) or (t.endswith("[]") and t not in ("byte[]", "Byte[]"))
        if t in ("byte[]", "Byte[]"):
            self.fields.append(dict(self._f(parent + "/" + name, name, "base64Binary", req, 1, restr=restr), nillable=nullable))
            return
        if re.match(r"^(?:System\.Collections\.Generic\.)?I?(?:Dictionary|ReadOnlyDictionary)\s*<", t):
            self.fields.append(self._f(parent + "/" + name, name, "map", req, 1, complex_=True))
            return
        inner = lm.group(1).strip() if lm else (t[:-2] if lst else t)
        base = inner.rstrip("?").split(".")[-1]
        path = parent + "/" + name + ("[]" if lst else "")
        mx = "unbounded" if lst else 1
        prim = CS_XSD.get(base.lower())
        if prim:
            self.fields.append(dict(self._f(path, name, prim, req, mx, restr=restr, lst=lst), nillable=nullable))
            return
        c = self._cls(base)
        if c is None:
            self.fields.append(self._f(path, name, "UNRESOLVED:" + base, req, mx, lst=lst))
            return
        if c["is_enum"]:
            vals = self._enum_values(c)
            self.fields.append(dict(self._f(path, name, "string", req, mx, restr=dict(restr, enumeration=vals) if vals else restr,
                                            lst=lst), typeName=c["name"]))
            return
        if c["name"] in stack or len(stack) > self.MAX_DEPTH:
            self.fields.append(self._f(path, name, "RECURSIVE:" + c["name"], req, mx, complex_=True, lst=lst))
            return
        self.fields.append(self._f(path, name, c["name"], req, mx, complex_=True, lst=lst))
        self._members(c, path, stack + [c["name"]])

    def _enum_values(self, c):
        f = self.repo.files[c["fidx"]]
        body = " ".join(f["clean"][c["start"]:c["end"] + 1])
        body = body.split("{", 1)[1] if "{" in body else ""
        body = body.rsplit("}", 1)[0]
        vals = []
        for part in body.split(","):
            em = re.search(r"EnumMember\s*\([^)]*Value\s*=\s*\"([^\"]+)\"", part)
            part2 = re.sub(r"\[[^\]]*\]", "", part).strip()
            nm = re.match(r"([A-Za-z_]\w*)", part2)
            if em:
                vals.append(em.group(1))
            elif nm:
                vals.append(nm.group(1))
        return vals[:60]


def svc_operations(svc_path, repo1):
    """Returns (ops, impl_class). Logs everything needed to debug a wrong/missing contract."""
    cls, codebehind, head = read_svc(svc_path)
    LOG.write("svc header: %s" % head)
    if not cls:
        warn("svc: no Service=\"...\" attribute in %s (Factory-only .svc?) - using every [ServiceContract] in repo1" % svc_path)
        impls = set()
        for c_list in repo1.classes.values():
            for c in c_list:
                if any(a.startswith("ServiceContract") for a in c["annotations"]):
                    impls |= {n for n in repo1.children.get(c["name"], ())} or {c["name"]}
        ops = []
        for impl in sorted(impls):
            ops.extend(SvcContract(repo1, impl).operations())
        return ops, None
    LOG.info["svcClass"] = cls
    if not repo1.class_recs(cls):
        close = difflib.get_close_matches(cls, list(repo1.classes.keys()), n=5, cutoff=0.6)
        warn("svc: service class %s not found in repo1 (is --repo1 the solution root?). Similar: %s" % (cls, ", ".join(close) or "-"))
        return [], cls
    sc = SvcContract(repo1, cls)
    ifaces = sc.contract_interfaces()
    LOG.write("svc: class %s at %s; contract interfaces: %s" % (cls, ", ".join("%s:%d" % (c["file"], c["start"] + 1) for c in repo1.class_recs(cls)),
                                                                ", ".join("%s(%s:%d)" % (c["name"], c["file"], c["start"] + 1) for c in ifaces) or "-"))
    ops = sc.operations()
    if not ops:
        warn("svc: %s has no [OperationContract] methods reachable via its interfaces (%s)" % (cls, ", ".join(c["name"] for c in ifaces) or "none found"))
    for o in ops:
        unresolved = [x["path"] for x in o["request"] + o["response"] if str(x["type"]).startswith("UNRESOLVED")]
        LOG.write("svc op %s at %s: req=%d resp=%d faults=%d" % (o["name"], o["codeAt"], len(o["request"]), len(o["response"]), len(o["faults"])))
        if unresolved:
            warn("svc: %s - type(s) not found in repo1 source (external assembly / NuGet?): %s" % (o["name"], ", ".join(unresolved[:5])))
    return ops, cls


# --------------------------------------------------------------------------- main

def discover_wsdl(repo1_path):
    best = None
    for root, dirs, files in os.walk(repo1_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if f.lower().endswith(".wsdl"):
                p = os.path.join(root, f)
                n = 0
                try:
                    with open(p, "rb") as fh:
                        n = len(re.findall(rb"<(?:\w+:)?operation\b", fh.read()))
                except OSError:
                    pass
                if best is None or n > best[0]:
                    best = (n, p)
    return best[1] if best else None


def _cnt(rows, pred):
    return sum(1 for x in rows if pred(x))


def peak_mem_mb():
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + \
                           [(n, ctypes.c_size_t) for n in ("PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
                                                         "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
                                                         "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]
            c = PMC()
            c.cb = ctypes.sizeof(PMC)
            k32 = ctypes.WinDLL("kernel32")
            k32.GetCurrentProcess.restype = wintypes.HANDLE
            psapi = ctypes.WinDLL("psapi")
            psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
            if psapi.GetProcessMemoryInfo(k32.GetCurrentProcess(), ctypes.byref(c), c.cb):
                return c.PeakWorkingSetSize // (1024 * 1024)
        else:
            import resource
            v = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            return v // (1024 * 1024) if sys.platform == "darwin" else v // 1024
    except Exception:  # noqa
        return None
    return None


def write_card(args, ops, results, repo1, repo2, exit_code, crash=None):
    """diag.txt: <= ~40 lines, fixed layout, paths redacted. Designed to be screenshotted or pasted."""
    L = []
    W = 110
    total = time.time() - LOG.t0
    L.append("=" * 34 + " SOAP-PARITY DIAG v%s " % VERSION + "=" * 34)
    mem = peak_mem_mb()
    L.append("run    %s | py %s | %s | exit=%s | total %.1fs | peak mem %s | jobs %d" % (
        time.strftime("%Y-%m-%d %H:%M"), sys.version.split()[0], platform.system() + " " + platform.release(), exit_code, total,
        ("%d MB (main process)" % mem) if mem is not None else "n/a", JOBS))
    inp = LOG.info
    L.append("input  mode=%s | contract=%s | ops=%s%s" % (inp.get("mode", "?"), LOG.r(inp.get("contractSrc", "?")),
                                                       inp.get("opsTotal", "?"),
                                                       (" (selected: %s)" % ",".join(args.operation)) if getattr(args, "operation", None) else ""))
    L.append("       repo1=%s | repo2=%s%s" % (inp.get("repo1Name", "-"), inp.get("repo2Name", "-"),
                                               (" | svcClass=%s" % inp["svcClass"]) if inp.get("svcClass") else ""))
    ph = list(LOG.phases) + [(LOG.cur_phase, time.time() - LOG.cur_t)]
    L.append("phase  " + " | ".join("%s %.1fs" % (n, s) for n, s in ph if n != "startup"))
    for label, repo in (("repo1", repo1), ("repo2", repo2)):
        if not repo:
            continue
        st = getattr(repo, "stats", {})
        sm = repo.summary()
        L.append("%-6s seen %d | code %d conf %d xml %d orm %d | skip: tests %d files+%d dirs, gen %d, big %d, fail %d, walkErr %d"
                 % (label, st.get("seen", 0), st.get("code", 0), st.get("config", 0), st.get("xml", 0),
                    st.get("ormModel", 0) + st.get("bigDesignerLight", 0), st.get("testFilesSkipped", 0), st.get("testDirsSkipped", 0),
                    st.get("generatedSkipped", 0), st.get("bigSkipped", 0), st.get("failed", 0), st.get("walkErrors", 0)))
        L.append("       classes %d | methods %d | integration hits %d | tables mapped %d | procs mapped %d%s"
                 % (sm["classes"], sm["methods"], sm["hits"], len(repo.entity_table), len(repo.db_funcs),
                    " | nullable-ref-types ON" if repo.nullable_enabled else ""))
        if getattr(repo, "slow_files", None):
            L.append("       slowest: " + ", ".join("%.1fs %s" % (s, f[-45:]) for s, f in repo.slow_files[:3]))
    if results:
        L.append("-" * W)
        L.append("%-22s %-15s %4s | %-26s | %-30s | %-11s %-9s %-7s %-5s %s" % (
            "OPERATION", "VERDICT", "SCR", "R1 ENTRY (slice files)", "R2 ENDPOINT (score, files)", "REQ m/f/x/u", "RESP m/f/x",
            "INT m/x", "RULE", "REVIEW"))
        for r in results:
            req = (r.get("contract", {}).get("request") or {}).get("rows", [])
            rsp = (r.get("contract", {}).get("response") or {}).get("rows", [])
            ent = (r.get("repo1Entry") or ["-"])[0].split(" ")[0]
            if ent != "-":
                ent = "%s (%d)" % (os.path.basename(ent)[:20], len(r.get("repo1SliceFiles", [])))
            else:
                ent = "NOT FOUND" if repo1 else "no repo1"
            c2 = r.get("repo2Candidates") or []
            ep = "%s (%.2f, %d)" % (os.path.basename(c2[0]["at"])[:20], c2[0]["score"], len(r.get("repo2SliceFiles", []))) if c2 else "NONE"
            ints = r.get("integrations", [])
            rules = r.get("businessRules", [])
            L.append("%-22s %-15s %4.2f | %-26s | %-30s | %-11s %-9s %-7s %-5s %d" % (
                r["operation"][:22], r["verdict"].split(" (")[0][:15], r["scores"]["overall"], ent[:26], ep[:30],
                "%d/%d/%d/%d" % (_cnt(req, lambda x: x["status"] == "MATCH"), _cnt(req, lambda x: x["status"] == "FUZZY"),
                                 _cnt(req, lambda x: x["status"].startswith("MISSING")), _cnt(req, lambda x: x["status"] == "UNRESOLVED")),
                "%d/%d/%d" % (_cnt(rsp, lambda x: x["status"] == "MATCH"), _cnt(rsp, lambda x: x["status"] == "FUZZY"),
                              _cnt(rsp, lambda x: x["status"].startswith("MISSING"))),
                "%d/%d" % (_cnt(ints, lambda x: x["status"] == "MATCH"), _cnt(ints, lambda x: x["status"] in ("MISSING", "FOUND_ELSEWHERE"))),
                "%d/%d" % (_cnt(rules, lambda x: x["status"].startswith("LITERALS_IN_REPO2_SLICE")), len(rules)),
                len(r.get("review", []))))
        L.append("legend: REQ/RESP match/fuzzy/missing/unresolved | INT match/missing-or-elsewhere | RULE matched/total")
    warns = [e for e in LOG.events if e[0] == "WARN"]
    L.append("-" * W)
    if warns:
        by = defaultdict(list)
        for _, code, msg in warns:
            by[code].append(msg)
        L.append("WARNINGS %d (grouped by code, first example each; full list in run.log)" % len(warns))
        for code, msgs in sorted(by.items(), key=lambda x: -len(x[1]))[:8]:
            L.append("  %-17s x%-4d %s" % (code, len(msgs), msgs[0][:W - 26]))
    else:
        L.append("WARNINGS none")
    for _, code, msg in [e for e in LOG.events if e[0] == "ERROR"][:4]:
        L.append("ERROR  %s %s" % (code, msg[:W - 14]))
    if crash:
        L.append("CRASH  phase=%s file=%s" % (LOG.cur_phase, LOG.r(LOG.cur_file or "-")))
        for line in crash[-6:]:
            L.append("  " + LOG.r(line)[:W - 2])
    L.append("files  " + " | ".join(os.path.join(args.out, n) for n in ("diag.txt", "run.log", "parity_summary.md")))
    L.append("=" * (70 + len(VERSION) + 20))
    txt = "\n".join(L)
    try:
        with open(os.path.join(args.out, "diag.txt"), "w", encoding="utf-8") as fh:
            fh.write(txt + "\n")
    except OSError:
        pass
    LOG.write("diag card:\n" + txt)
    print("\n" + txt, flush=True)


def build_parser():
    ap = argparse.ArgumentParser(description="SOAP (repo1) vs repo2 parity extractor")
    ap.add_argument("--wsdl", help="WSDL URL or file, OR a WCF .svc file/URL. A local .svc file means: read the contract from repo1 C# code "
                                   "([ServiceContract]/[DataContract]). If omitted, a *.wsdl (or the only *.svc) in repo1 is used.")
    ap.add_argument("--svc", help="local WCF .svc file. Pins the repo1 implementing class; contract comes from code unless --wsdl is also given.")
    ap.add_argument("--repo1", help="path to repo1 (SOAP implementation). With a .svc it defaults to the folder holding the .sln.")
    ap.add_argument("--repo2", required=False, help="path to repo2 (target implementation) - a sub-folder is fine and faster")
    ap.add_argument("--operation", "-o", action="append", help="limit to operation(s); repeatable")
    ap.add_argument("--out", default="parity_out", help="output folder (default parity_out)")
    ap.add_argument("--schema-dir", action="append", default=[], help="extra folder with local .xsd/.wsdl copies (used when imports cannot be fetched)")
    ap.add_argument("--synonyms", help="JSON file {canonicalName: [alias, ...]} for field/class name mapping")
    ap.add_argument("--insecure", action="store_true", help="skip TLS verification for WSDL fetch (self-signed certs)")
    ap.add_argument("--timeout", type=int, default=30)
    ap.add_argument("--include-tests", action="store_true", help="also scan test folders")
    ap.add_argument("--max-depth", type=int, default=8, help="call-graph depth for slicing")
    ap.add_argument("--min-score", type=float, default=0.35, help="minimum score for a repo2 endpoint to count as a match")
    ap.add_argument("--max-rows", type=int, default=40, help="max rows per table in the markdown summary")
    ap.add_argument("--max-rules", type=int, default=60)
    ap.add_argument("--max-review", type=int, default=40)
    ap.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 1),
                    help="parallel processes for parsing source files (default min(8, CPUs)); 1 = single process")
    ap.add_argument("--max-file-kb", type=int, default=MAX_FILE // 1024, help="skip source files bigger than this (default %d)" % (MAX_FILE // 1024))
    ap.add_argument("--all-rows", action="store_true", help="show MATCH rows too in summary")
    ap.add_argument("--list-ops", action="store_true", help="only list operations and exit")
    ap.add_argument("--no-redact", action="store_true", help="show absolute repo paths in run.log/diag.txt (default: <repo1>/<repo2>)")
    return ap


def input_error(msg, hint=None):
    LOG.event("ERROR", "E-INPUT", msg)
    print("ERROR: " + LOG.r(msg), file=sys.stderr)
    if hint:
        LOG.write("HINT: " + hint)
        print("HINT: " + LOG.r(hint), file=sys.stderr)
    return 2


def main(argv=None):
    global MAX_FILE, JOBS
    ap = build_parser()
    args = ap.parse_args(argv)
    MAX_FILE = max(64, args.max_file_kb) * 1024
    JOBS = max(1, args.jobs)
    try:
        os.makedirs(args.out, exist_ok=True)
    except OSError as e:
        ap.error("cannot create output folder %s: %s" % (args.out, e))
    LOG.open(args.out)
    state = {"ops": [], "results": [], "repo1": None, "repo2": None}
    code, crash = 3, None
    try:
        code = _run(args, state)
    except KeyboardInterrupt:
        code, crash = 130, ["interrupted by user (Ctrl+C)"]
        LOG.event("ERROR", "E-INTERRUPTED", crash[0])
    except Exception as e:  # noqa
        tb = traceback.extract_tb(sys.exc_info()[2])
        crash = ["%s: %s" % (type(e).__name__, e)] + ["at %s:%d in %s" % (os.path.basename(t.filename), t.lineno, t.name) for t in tb[-4:]]
        LOG.event("ERROR", "E-CRASH", crash[0])
        LOG.write(traceback.format_exc())
        code = 3
    LOG.write("exit code %s" % code)
    if not (args.list_ops and code == 0):
        write_card(args, state["ops"], state["results"], state["repo1"], state["repo2"], code, crash)
    return code


def _run(args, state):
    LOG.write("args: " + " ".join("%s=%s" % (k, v) for k, v in sorted(vars(args).items()) if v not in (None, False, [])))
    # ---- normalise inputs (.svc file / URL)
    if args.wsdl and not is_url(args.wsdl) and args.wsdl.lower().endswith(".svc"):
        if args.svc:
            return input_error("give the .svc either as --wsdl or --svc, not both")
        args.svc, args.wsdl = args.wsdl, None
    if args.svc and not os.path.isfile(args.svc):
        return input_error("svc file not found: %s" % args.svc,
                           "pass the path of the .svc file inside repo1 (e.g. ...\\MyService.svc), or the service URL as --wsdl")
    if args.svc and not args.repo1:
        args.repo1 = find_solution_root(os.path.dirname(os.path.abspath(args.svc)))
        print("repo1 not given: using %s (folder with the .sln above the .svc)" % args.repo1)
        LOG.info["repo1Auto"] = True
    for p, nm in ((args.repo1, "repo1"), (args.repo2, "repo2")):
        if p and not os.path.isdir(p):
            return input_error("%s folder not found: %s" % (nm, p), "check the path; quote it if it contains spaces")
    if not args.list_ops and not args.repo2:
        return input_error("--repo2 is required (unless --list-ops)")
    if not args.no_redact:
        LOG.add_redaction(args.repo1, "<repo1>")
        LOG.add_redaction(args.repo2, "<repo2>")
        LOG.add_redaction(os.path.expanduser("~"), "<home>")
    LOG.info["repo1Name"] = (os.path.basename(os.path.abspath(args.repo1)) + (" (auto from .svc)" if LOG.info.get("repo1Auto") else "")) if args.repo1 else "-"
    LOG.info["repo2Name"] = os.path.basename(os.path.abspath(args.repo2)) if args.repo2 else "-"
    if not args.wsdl and not args.svc:
        if args.repo1:
            args.wsdl = discover_wsdl(args.repo1)
            if args.wsdl:
                print("Using WSDL discovered in repo1: %s" % LOG.r(args.wsdl))
            else:
                svcs = discover_svc(args.repo1)
                if len(svcs) == 1:
                    args.svc = svcs[0]
                    print("Using the only .svc in repo1: %s" % LOG.r(args.svc))
                elif svcs:
                    return input_error("no --wsdl given and repo1 has %d .svc files" % len(svcs),
                                       "pass one with --wsdl <file.svc>. Found: " + ", ".join(os.path.relpath(s, args.repo1) for s in svcs[:10]))
        if not args.wsdl and not args.svc:
            return input_error("--wsdl is required (no *.wsdl or *.svc found in repo1)")
    if args.wsdl and is_url(args.wsdl) and urllib.parse.urlparse(args.wsdl).path.lower().endswith(".svc") \
            and not urllib.parse.urlparse(args.wsdl).query:
        args.wsdl += "?singleWsdl"     # WCF: one document with all schemas inlined
        LOG.write("WCF URL: trying %s first" % args.wsdl)
    if args.synonyms:
        try:
            with open(args.synonyms, encoding="utf-8-sig") as fh:
                syn = json.load(fh)
        except (OSError, ValueError) as e:
            return input_error("cannot read synonyms file %s: %s" % (args.synonyms, e))
    else:
        syn = {}
    names = Names(syn)

    repo1 = None
    if args.svc and not args.wsdl:
        # ---- contract from code: index repo1 first
        LOG.info["mode"] = "svc-code"
        LOG.info["contractSrc"] = "svc:" + os.path.basename(args.svc)
        LOG.phase("index-repo1")
        repo1 = state["repo1"] = RepoIndex(args.repo1, args.include_tests, "repo1")
        LOG.write("repo1 stats: %s" % dict(repo1.stats))
        LOG.phase("contract-from-svc")
        ops, impl = svc_operations(args.svc, repo1)
        if not ops:
            return input_error("no operations could be built from %s" % args.svc,
                               "check the Service=\"...\" class exists under repo1 and implements a [ServiceContract] interface; "
                               "or pass the service URL / a saved ?singleWsdl file as --wsdl")
    else:
        LOG.info["mode"] = "wsdl" + ("+svc" if args.svc else "")
        LOG.info["contractSrc"] = ("url:" + urllib.parse.urlparse(args.wsdl).netloc) if is_url(args.wsdl) else "file:" + os.path.basename(args.wsdl)
        LOG.phase("load-contract")
        local_dirs = list(args.schema_dir) + ([args.repo1] if args.repo1 else [])
        if not is_url(args.wsdl):
            local_dirs.append(os.path.dirname(os.path.abspath(args.wsdl)))
        loader = Loader(args.insecure, args.timeout, os.path.join(args.out, "wsdl_cache"), local_dirs)
        c = Contract(loader)
        c.load(args.wsdl)
        c.resolve_pending()
        ops = c.operations()
        if not ops and args.wsdl.endswith("?singleWsdl"):
            alt = args.wsdl[:-len("?singleWsdl")] + "?wsdl"
            LOG.write("no operations via ?singleWsdl; retrying %s" % alt)
            c = Contract(loader)
            c.load(alt)
            c.resolve_pending()
            ops = c.operations()
        if not ops:
            print("Warnings:\n  " + "\n  ".join(LOG.r(w) for w in WARNINGS[:15]), file=sys.stderr)
            hint = None
            if is_url(args.wsdl):
                hint = ("if the URL needs Windows/NTLM auth, VPN or a proxy, open it in a browser with '?singleWsdl' (WCF) or '?wsdl', "
                        "save it as service.wsdl and pass --wsdl service.wsdl. Or pass the .svc FILE from repo1 (--wsdl X.svc) "
                        "to read the contract from code.")
            return input_error("no operations found in WSDL %s" % args.wsdl, hint)
        if args.svc:
            impl, _, _ = read_svc(args.svc)
            LOG.info["svcClass"] = impl
            for o in ops:
                o["implClass"] = impl
    LOG.info["opsTotal"] = len(ops)
    if args.operation:
        wanted = {norm(o) for o in args.operation}
        missing = wanted - {norm(o["name"]) for o in ops} - {norm(o["wsdlName"]) for o in ops}
        if missing:
            return input_error("operation(s) not found: %s" % ", ".join(sorted(missing)),
                               "available: " + ", ".join(o["name"] for o in ops[:60]))
        ops = [o for o in ops if norm(o["name"]) in wanted or norm(o["wsdlName"]) in wanted]
    state["ops"] = ops
    with open(os.path.join(args.out, "contract.json"), "w", encoding="utf-8") as fh:
        json.dump(ops, fh, indent=1)
    if args.list_ops:
        for o in ops:
            print("%-40s req_fields=%-4d resp_fields=%-4d %s" % (o["name"], len(o["request"]), len(o["response"]),
                                                                o.get("codeAt") or o.get("soapAction") or ""))
        return 0

    if repo1 is None and args.repo1:
        LOG.phase("index-repo1")
        repo1 = state["repo1"] = RepoIndex(args.repo1, args.include_tests, "repo1")
        LOG.write("repo1 stats: %s" % dict(repo1.stats))
    elif not args.repo1:
        print("repo1 not given: logic/integration comparison will be skipped")
    LOG.phase("index-repo2")
    repo2 = state["repo2"] = RepoIndex(args.repo2, args.include_tests, "repo2")
    LOG.write("repo2 stats: %s" % dict(repo2.stats))
    eps2 = repo2_endpoints(repo2)
    LOG.write("repo2 endpoints found: %d" % len(eps2))
    if not eps2:
        warn("entry: no HTTP/SOAP endpoints found in repo2 - is --repo2 the right folder?")
    LOG.phase("analyze")
    results = state["results"]
    for i, op in enumerate(ops, 1):
        t1 = time.time()
        print("  [%d/%d] %s" % (i, len(ops), op["name"]), flush=True)
        LOG.cur_file = "operation " + op["name"]
        r = analyze_operation(op, repo1, repo2, names, eps2, args)
        LOG.cur_file = None
        results.append(r)
        LOG.write("op %s: verdict=%s overall=%.2f r1Entry=%s r1Files=%d r2=%s r2Files=%d review=%d (%.1fs)" % (
            op["name"], r["verdict"], r["scores"]["overall"], (r.get("repo1Entry") or ["-"])[0], len(r.get("repo1SliceFiles", [])),
            (r.get("repo2Candidates") or [{"at": "-"}])[0]["at"], len(r.get("repo2SliceFiles", [])), len(r.get("review", [])), time.time() - t1))
        for cnd in r.get("repo2Candidates", []):
            LOG.write("   candidate %.2f %s %s %s" % (cnd["score"], cnd["at"], cnd.get("verb"), cnd.get("route")))
        if repo1 and not r.get("repo1Entry"):
            warn("entry: repo1 entry method for %s not found" % op["name"])
        elif repo1 and len(r.get("repo1SliceFiles", [])) <= 1:
            warn("entry: repo1 call path for %s covers only %d file - DI/reflection may hide the logic" % (op["name"], len(r.get("repo1SliceFiles", []))))
        if not r.get("repo2Candidates") or r["repo2Candidates"][0]["score"] < args.min_score:
            warn("entry: no repo2 endpoint above --min-score %.2f for %s" % (args.min_score, op["name"]))
    matched = set()
    for r in results:
        if r["repo2Candidates"] and r["repo2Candidates"][0]["score"] >= args.min_score:
            matched.add(r["repo2Candidates"][0]["at"])
    extra = [e for e in eps2 if "%s:%d" % (e["file"], e["line"]) not in matched]

    LOG.phase("write")
    with open(os.path.join(args.out, "parity.json"), "w", encoding="utf-8") as fh:
        json.dump(jsonable({"version": VERSION, "wsdl": args.wsdl or args.svc, "repo1": repo1.summary() if repo1 else None,
                            "repo2": repo2.summary(), "results": results, "warnings": WARNINGS,
                            "repo2Endpoints": [{k: v for k, v in e.items() if k not in ("f", "m")} for e in eps2]}), fh, indent=1)
    for label, repo in (("repo1", repo1), ("repo2", repo2)):
        if repo:
            with open(os.path.join(args.out, label + "_index.json"), "w", encoding="utf-8") as fh:
                json.dump({"summary": repo.summary(), "stats": dict(repo.stats), "bigFilesSkipped": repo.big_files[:200],
                           "hits": [{k: v for k, v in h.items() if k != "fidx"} for h in repo.hits],
                           "classes": {n: [{"file": c_["file"], "line": c_["start"] + 1, "kind": c_["kind"], "parents": c_["parents"],
                                            "table": c_["table"], "fields": [(f["name"], f["type"]) for f in c_["fields"]]} for c_ in v]
                                       for n, v in repo.classes.items()},
                           "config": {k: v[0] for k, v in repo.config.items() if HOST_RE.search(v[0]) or JDBC_RE.search(v[0])}},
                          fh, indent=1)
    summary = os.path.join(args.out, "parity_summary.md")
    if not args.wsdl:
        args.wsdl = "svc:" + os.path.basename(args.svc)
    write_summary(summary, ops, results, args, repo1, repo2, extra, global_checks(ops, repo1, repo2))
    print("\nDone. %d operation(s)." % len(results))
    for r in results:
        print("  %-35s %-40s overall=%.2f" % (r["operation"], r["verdict"], r["scores"]["overall"]))
    print("\nSummary for the LLM : %s\nFull detail         : %s" % (summary, os.path.join(args.out, "parity.json")))
    return 0


def discover_svc(repo1_path):
    out = []
    for root, dirs, files in os.walk(repo1_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        out.extend(os.path.join(root, f) for f in files if f.lower().endswith(".svc"))
    return sorted(out)


if __name__ == "__main__":
    sys.exit(main())
