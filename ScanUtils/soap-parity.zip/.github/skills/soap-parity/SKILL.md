---
name: soap-parity
description: Compare a legacy SOAP service (repo1, WSDL URL or file) with another codebase (repo2) and report whether each operation is fully, partially or not implemented - request/response contract, DB access, outbound HTTP/SOAP calls, messaging, validations and business rules. Use when asked to check SOAP-to-REST/.NET/Java migration parity or "does repo2 cover this SOAP service".
---

# SOAP parity skill

The script `soap_parity.py` (this folder, Python 3.8+, standard library only) does all extraction deterministically.
**Your job is only to run it, read its compact summary and verify the short review queue.**
Never read the repositories broadly - that wastes tokens and is less accurate than the script.

## 1. Run

```
python .github/skills/soap-parity/soap_parity.py --wsdl "<.svc file | wsdl url | wsdl file>" --repo2 "<repo2>" [--repo1 "<repo1>"] --out parity_out
```

What `--wsdl` accepts:
| Input | What happens |
|---|---|
| `...\MyService.svc` (file in repo1) | Reads `Service="..."` from the .svc, finds that class and its `[ServiceContract]` interface in repo1, and builds the contract from `[OperationContract]` + `[DataContract]/[DataMember]` code. repo1 defaults to the folder with the `.sln` above the .svc. The repo1 entry point is pinned to that class. |
| `https://host/MyService.svc` | Fetches `?singleWsdl`, then `?wsdl` |
| `service.wsdl` / `?wsdl` URL | Parses the WSDL + imported XSDs (the XSD facets give richer validation checks) |
| (omitted) | The largest `*.wsdl` in repo1, else the only `*.svc` in repo1 |
Use `--wsdl <wsdl> --svc <file.svc>` together to get the WSDL contract and the pinned entry class.

Options to use when relevant:
| Situation | Add |
|---|---|
| Many operations (> 5) or a big summary | `-o <OperationName>` (repeatable) - run per operation |
| Only want the operation list | `--list-ops` |
| Large repos | narrow `--repo2` to the sub-folder that likely holds the match; set `--repo1` to the service's solution folder instead of a monorepo root; `-o` per operation |
| WSDL URL unreachable / needs Windows auth / VPN | pass the `.svc` file instead, or save `<url>?singleWsdl` from a browser and pass `--wsdl <file>` |
| Imported XSDs are in another folder | `--schema-dir <folder>` |
| Self-signed TLS on the WSDL host | `--insecure` |
| Known renames between repos (custId vs customerId) | `--synonyms synonyms.json` (see `synonyms.example.json`) |
| Test code should count | `--include-tests` |
| Process creation blocked / low memory | `--jobs 1` |
| Huge generated source files skipped (`W-LIMIT`) | `--max-file-kb 4000` |

Credentials for the WSDL URL go in env vars `SOAP_PARITY_USER` / `SOAP_PARITY_PASSWORD` or `SOAP_PARITY_HEADER` - never on the command line, never in chat.

Exit code 2 = bad input (missing file/folder, unknown operation, no operations found), 3 = script crash. Show the ERROR/HINT lines and the DIAG card, ask the user to share `parity_out/diag.txt`, and stop. Do not try to parse the WSDL or the repos yourself.

### Diagnostics (every run)
- Console + `parity_out/diag.txt`: the **SOAP-PARITY DIAG card** (about 25 lines; repo paths are redacted to `<repo1>`/`<repo2>`). It is the thing to share when something looks wrong.
- `parity_out/run.log`: the full timestamped log (every warning, slow and skipped files, candidate endpoints with scores, crash tracebacks).
- Warning codes on the card: `W-SVC` (.svc class/contract problem), `W-ENTRY` (repo1 entry or repo2 endpoint not found, or tiny call path), `W-WSDL-LOAD`, `W-XSD-UNRESOLVED`, `W-XSD-NS`, `W-INDEX-FAIL` (file could not be parsed), `W-LIMIT` (big files skipped, unreadable folders, parallel fallback), `E-INPUT`, `E-CRASH`.

## 2. Read

Read only `parity_out/parity_summary.md`. Meaning of statuses:
- Contract: `MATCH` same normalized name; `FUZZY` similar name (confirm); `MISSING`; `MISSING(parent)`; `UNRESOLVED` (type not found in repo2); `/WARN` or `/MISMATCH` type issues (e.g. xsd decimal -> double).
- Integrations: `MATCH`; `FOUND_ELSEWHERE` (exists in repo2 but not reachable from the matched endpoint - may be dead code or a different flow); `MISSING`; `EXTRA_IN_REPO2`.
- Validation: `GAP`; `CHECK_IMPERATIVE` (a code check mentions the field); `IMPLICIT_NRT` (C# non-nullable reference type - only enforced if `[ApiController]` + nullable context; confirm).
- Business rules: `LITERALS_IN_REPO2_SLICE` (same constants found on the repo2 path), `LITERALS_ELSEWHERE_IN_REPO2`, `PARTIAL`, `NOT_FOUND`, `REVIEW` (no literal to compare - needs reading).
- Auto verdicts are heuristics: `FULL (verify)`, `PARTIAL`, `MOSTLY_MISSING`, `NOT_IMPLEMENTED`, `PARTIAL (DTOs exist, no endpoint found)`.

If an "Extraction warnings" section exists (or the DIAG card shows warnings), report it to the user first. If a "CHECK: repo2 has SOAP-client calls..." section exists, check whether repo2 is only a facade over the legacy service (that changes the verdict).

## 3. Verify (token budget)

For each operation, work only through its "LLM review queue" (stop after 25 items; say how many were skipped):
- Open only the referenced line range ±15 lines. One read per reference. No full files.
- `RULE ...` items: understand the repo1 rule, then search for the equivalent concept (identifier, constant, keyword) only inside that operation's "repo2 reachable files". Classify: `SAME`, `DIFFERENT` (state the difference: formula, rounding, threshold, order), `MISSING`.
- `CONFIRM name mapping`: confirm the fields carry the same data (check wire names, e.g. `[JsonPropertyName]`, `[DataMember(Name)]`).
- `INTEGRATION ... MISSING/FOUND_ELSEWHERE`: one search in repo2 for the table/proc/host/queue name; check it is not reached via config, a different repository class, or a message handler.
- `VALIDATION`: check repo2 for the equivalent rule (DataAnnotations, FluentValidation, guard clauses, model binding).
- `TYPE`: decide if the drift is harmful (money in double = harmful; DateTime vs DateTimeOffset = check time zone semantics).
Do NOT re-check rows already marked MATCH, and do not hunt for new problems outside the queue unless the user asks.

## 4. Report - write `parity_out/parity_report.md`

```
# SOAP parity report
Inputs: WSDL, repo1, repo2, date, script version
## Overview
| Operation | Final verdict (FULL / PARTIAL / NOT_IMPLEMENTED) | Confidence (H/M/L) | repo2 entry point | Key gaps |
## <Operation>
### Capability matrix
| Area | repo1 (evidence file:line) | repo2 (evidence file:line) | Status (SAME / DIFFERENT / MISSING / EXTRA) | Note |
Areas: Request contract, Response contract, Faults/error mapping, Validations, DB reads, DB writes / procs, Outbound HTTP/SOAP, Messaging, Business rules, Transactions, Security.
### Gaps to implement in repo2 (actionable, ordered by risk)
### Verified review items (item -> SAME/DIFFERENT/MISSING/FALSE_POSITIVE + one-line reason)
### Not verified (skipped items, low-confidence areas)
```
Rules: every claim cites `file:line` from the summary or from what you read; never invent evidence; mark anything unverified as such.
Final verdict guidance: FULL only if contract has no MISSING/MISMATCH, no MISSING integrations, and no DIFFERENT/MISSING rules after verification.

## 5. Re-run tips
- Many FUZZY confirmations -> put them in a synonyms JSON and re-run so the next summary is smaller.
- Wrong repo2 endpoint chosen -> look at "repo2 candidates"; re-run with `--min-score` higher, or tell the user which endpoint was used.
- Output too large -> run per operation with `-o`, or lower `--max-rows`.
- Card shows `R1 ENTRY NOT FOUND` or `(1)` slice file -> pass the `.svc` with `--svc` (pins the class), or check `--repo1` contains the implementation.
- Card shows `R2 ENDPOINT NONE` but the user knows where it is -> narrow `--repo2` to that project, or lower `--min-score`; the candidate list with scores is in `run.log`.
