# soap-parity - SOAP service (repo1) vs repo2 parity check for GitHub Copilot

Answers, per SOAP operation: **does repo2 implement it fully, partially, or not at all?** It compares the request and response contract, DB access, outbound HTTP/SOAP calls, messaging, validations and business rules, and cites `file:line` evidence for each.

## Why a script + a prompt (and not just a prompt)

Asking Copilot to "read both repos and compare" fails in a token-limited client environment. It runs out of context, skips files, and invents evidence. Here the work is split in two:

| Step | Who | Cost |
|---|---|---|
| Parse WSDL/XSD (imports, extensions, choices, restrictions), index both repos, trace each operation's call path, match fields/tables/procs/hosts/queues/constants | `soap_parity.py` (deterministic, local, Python stdlib only) | 0 tokens |
| Read one compact summary (`parity_summary.md`), verify a capped review queue with ±15-line reads, write the report | Copilot | small and bounded |

## Layout

```
.github/
  prompts/soap-parity.prompt.md        -> run as /soap-parity in Copilot Chat (agent mode)
  skills/soap-parity/SKILL.md          -> the procedure + report format (also usable as an Agent Skill)
  skills/soap-parity/soap_parity.py    -> the extractor (single file, no pip install)
  skills/soap-parity/synonyms.example.json
samples/                               -> test fixtures (Java, .NET WCF/ASP.NET Core, LINQ to SQL)
```

## Setup (client machine)

1. Copy the `.github` folder into the workspace you open in VS Code. That is usually a parent folder containing both repos, or repo2.
2. Check that Python 3.8+ is available: `python --version` (or `py -3 --version`). Nothing else is needed.
3. In Copilot Chat (Agent mode), type `/soap-parity` and provide the service (the `.svc` file path from repo1, or a WSDL URL or file), the repo2 path, optionally repo1 (defaults to the `.sln` folder above the `.svc`), and optionally an operation.
   - If your VS Code version does not pick up the prompt file, attach `SKILL.md` to the chat and say "follow this skill".
   - Older VS Code versions use `mode: 'agent'` instead of `agent: 'agent'` in the prompt front matter.

You can also run the script yourself and give Copilot only the summary. For large repos this is recommended: run it once in a terminal, then tell Copilot "already run" so it skips straight to reading the summary.

Using the `.svc` file from repo1. The contract is read from the WCF code, and repo1 defaults to the folder holding the `.sln`:

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl "D:\src\legacy\Quote.Web\QuoteService.svc" --repo2 "D:\src\new\Quotes.Api" -o GetQuote --out parity_out
```

Using a WSDL URL or a saved file:

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl "https://host/QuoteService.svc" --repo1 "D:\src\legacy" --repo2 "D:\src\new" --out parity_out
```

### Which input to use

| You have | Pass | Notes |
|---|---|---|
| The `.svc` file in repo1 | `--wsdl X.svc` | Works offline with no auth. The contract comes from `[ServiceContract]/[OperationContract]/[DataContract]/[DataMember(Name, IsRequired)]`, plus DataAnnotations (`[StringLength]`, `[Range]`, `[RegularExpression]`) and enums. Types that live only in a referenced DLL or NuGet package show as `UNRESOLVED` (`W-SVC`). |
| A reachable service URL | `--wsdl https://.../X.svc` | Tries `?singleWsdl`, then `?wsdl`. Brings XSD facets such as pattern, length and enumeration. |
| Both | `--wsdl <url or file> --svc X.svc` | WSDL contract plus the entry point pinned to the `.svc` class. This is the most accurate option. |

The repo2 path can be the sub-folder you think holds the match. It is faster and makes false endpoint matches less likely. If the match turns out to be elsewhere, the summary and `run.log` list the candidates.

Outputs in `parity_out/`:

| File | For | Contents |
|---|---|---|
| `diag.txt` | **sharing / troubleshooting** | The DIAG card (also printed at the end of every run) |
| `run.log` | troubleshooting | Full timestamped log: phases, every warning, skipped, slow and failed files, repo2 candidates with scores, crash traceback |
| `parity_summary.md` | the LLM | Compact per-operation comparison and review queue |
| `parity_report.md` | you | Final report written by Copilot |
| `parity.json`, `contract.json`, `repo*_index.json`, `wsdl_cache/` | deep dives / re-runs | Full detail |

## Logs: what to share when something needs fixing

Every run, including failed runs and crashes, ends with a card like this in the terminal and in `parity_out/diag.txt`:

```
================================== SOAP-PARITY DIAG v1.1.0 ==================================
run    2026-11-19 20:13 | py 3.12.10 | Windows 11 | exit=0 | total 80.8s | peak mem 489 MB (main process) | jobs 8
input  mode=svc-code | contract=svc:QuoteService.svc | ops=2
       repo1=repo1 (auto from .svc) | repo2=repo2 | svcClass=QuoteService
phase  index-repo1 43.5s | contract-from-svc 0.0s | index-repo2 24.8s | analyze 6.7s | write 5.3s
repo1  seen 6162 | code 6008 conf 151 xml 0 orm 1 | skip: tests 0 files+1 dirs, gen 0, big 0, fail 0, walkErr 0
       classes 42019 | methods 102040 | integration hits 24016 | tables mapped 1500 | procs mapped 0
repo2  seen 3089 | code 3012 conf 76 xml 0 orm 0 | skip: tests 0 files+1 dirs, gen 0, big 0, fail 0, walkErr 0
       classes 21012 | methods 50957 | integration hits 12010 | tables mapped 1 | procs mapped 0 | nullable-ref-types ON
--------------------------------------------------------------------------------------------------------------
OPERATION              VERDICT          SCR | R1 ENTRY (slice files)     | R2 ENDPOINT (score, files)     | REQ m/f/x/u RESP m/f/x INT m/x RULE  REVIEW
GetQuote               PARTIAL         0.76 | QuoteService.cs:28 (4)     | QuotesController.cs: (0.85, 4) | 10/2/3/0    4/0/1     3/0     2/5   6
CancelOrder            NOT_IMPLEMENTED 0.00 | QuoteService.cs:70 (4)     | NONE                           | 0/0/2/0     0/0/2     0/3     0/0   3
legend: REQ/RESP match/fuzzy/missing/unresolved | INT match/missing-or-elsewhere | RULE matched/total
--------------------------------------------------------------------------------------------------------------
WARNINGS 1 (grouped by code, first example each; full list in run.log)
  W-ENTRY           x1    entry: no repo2 endpoint above --min-score 0.35 for CancelOrder
```

- **Share a screenshot of this card, or paste `diag.txt`.** It is usually enough to diagnose the run. When I need more, I'll ask for specific lines from `run.log`, for example `findstr /C:"candidate" parity_out\run.log`.
- Absolute repo paths are replaced with `<repo1>`, `<repo2>` and `<home>` (use `--no-redact` to turn this off). Relative file paths, class and operation names do appear, so check them before sharing outside the client.
- On a crash (exit 3) the card shows the phase, the file or operation being processed, and the last code frames (`soap_parity.py:<line> in <function>`).

How to read the card:

| Symptom on the card | Likely cause / fix |
|---|---|
| `R1 ENTRY NOT FOUND`, or slice files `(1)` | The entry method was not found, or DI/reflection hides the call path. Pass the `.svc` (`--svc`), or check `--repo1`. |
| `R2 ENDPOINT NONE` or a low score | repo2 has no matching endpoint, or it is outside `--repo2`. See the candidates in `run.log`. |
| Many `u` in `REQ m/f/x/u`, or `W-SVC ... not found in repo1 source` | DTOs are in a NuGet package or a DLL. Use the WSDL URL or file instead of the `.svc`. |
| `W-LIMIT ... skipped N file(s) over 1464 KB` | Huge generated files were skipped. Use `--max-file-kb 4000`. Big `*.designer.cs` files are always scanned for table and proc mappings. |
| `walkErr > 0` | Folders could not be listed (permissions, or paths longer than 260 chars). |
| `fail > 0` (`W-INDEX-FAIL`) | A file could not be parsed. The traceback is in `run.log`. |
| A phase takes many minutes | Narrow `--repo2` and `--repo1`, and use `-o`. Check `slowest:` on the card. |

## Large enterprise repos

- Source files are parsed in parallel (`--jobs`, default min(8, CPUs)). Measured on this machine: about 6,000 + 3,000 C# files, 42k classes and 100k methods took **81 s** with `--jobs 8` (261 s single-process). Peak memory was about 0.5 GB in the main process.
- Skipped automatically: `bin`, `obj`, `packages`, `node_modules`, `.vs`, test projects and test files (unless `--include-tests`), `*.g.cs`, `AssemblyInfo.cs`, `Resources/Settings.Designer.cs`, and source files over `--max-file-kb`.
- UTF-16 files (common in old Visual Studio projects) are decoded correctly.
- Recommended for very large repos: run once per operation (`-o`), point `--repo1` at the service's solution folder, and point `--repo2` at the likely project folder.

## What it detects

| Area | .NET | Java / others |
|---|---|---|
| SOAP entry (repo1) | WCF `[ServiceContract]/[OperationContract]` (interface → implementation), ASMX `[WebMethod]`, `OperationContract(Name/Action)`, `*Async` suffix | JAX-WS `@WebMethod`, Spring-WS `@PayloadRoot` |
| repo2 entry | ASP.NET Core controllers (`[Route("api/[controller]")]`, `[HttpPost]`), Minimal APIs (`MapPost`), WCF/CoreWCF, MediatR `Send` → `IRequestHandler.Handle` | Spring MVC, JAX-RS, Express, FastAPI/Flask, Go `HandleFunc` |
| Contract | DTO properties, records, `[DataMember(Name)]`, `[JsonPropertyName]`, `[XmlElement]` wire names, enums, collections, list wrappers (`ArrayOfX`) | fields, records, `@JsonProperty`, `@XmlElement` |
| DB | **LINQ to SQL** (`.dbml`, `*.designer.cs` `[Table]/[Function]`, `Table<T>`, query syntax, `SubmitChanges`, `ExecuteQuery`), EF Core / EF6 (`DbSet`, `ToTable`, `[Table]`, `.edmx`), Dapper, ADO.NET (`SqlCommand`, `CommandType.StoredProcedure`) | JDBC, `SimpleJdbcCall`, JPA/JPQL (entity → table), MyBatis mappers |
| Outbound | `HttpClient` (incl. typed clients registered with `AddHttpClient<>` + config), RestSharp, WCF client proxies (`ClientBase<>`) | RestTemplate, WebClient, Feign, JAX-WS ports, OkHttp |
| Messaging | Service Bus, MassTransit, RabbitMQ, MSMQ | JMS, Kafka, Rabbit |
| Config | `web.config` appSettings/connectionStrings/endpoints, `appsettings*.json`, `IConfiguration["A:B"]`, `GetSection`, `GetConnectionString` | `.properties`, `.yml`, `${...}` / `@Value` |
| Validation | DataAnnotations, FluentValidation (`RuleFor` chains mapped onto DTO fields), guard clauses, `required` modifier, nullable reference types (`<Nullable>enable`) | Bean Validation, guards |
| Business rules | conditions/calculations on the call path; constants are resolved (`TaxRate` → 0.08) and compared by value with the repo2 path | same |

## Review notes: what makes this kind of comparison go wrong, and how this setup avoids it

1. **The SOAP URL alone is not enough.** The WSDL only describes the contract. DB calls, outbound integrations, validations and rules live in repo1's source, so always pass `--repo1`. Without it, only contract comparison is possible.
2. **The WSDL is often unreachable from the client machine.** WCF with Windows/NTLM auth, VPN or proxies are common causes. The script fails fast with exit code 2 and a hint. The fix is to save `…svc?singleWsdl` from a browser (a single file with all schemas inlined) and pass `--wsdl file`, or omit `--wsdl` so the script uses the WSDL inside repo1. Imports that fail to load fall back to local `.xsd` copies in repo1 or `--schema-dir`, matched by file name or namespace.
3. **Name drift between repos** (`customerId` vs `custId`, `items/item` vs `LineItems`): the script uses token, abbreviation and containment matching plus wire-name attributes, and reports these as `FUZZY` for confirmation. Confirmed pairs go into a synonyms file so the next run is cleaner.
4. **Comparing whole repos gives false matches.** A table used elsewhere in repo2 does not prove this operation uses it. The script traces the call path from each entry point, covering DI interface → implementation, constructors and `@PostConstruct`, and MediatR handlers. It then compares only what is reachable and reports `FOUND_ELSEWHERE` separately.
5. **Generated code hides the data layer.** LINQ to SQL and EF6 put mappings in `*.designer.cs`, `.dbml` and `.edmx`. Those files are indexed, not skipped.
6. **A facade can look like a full implementation.** If repo2 just calls the legacy SOAP service, the DTOs match 100%. The summary has a `CHECK` section when repo2 references the legacy service address or contains SOAP client code.
7. **Type drift is silent.** Examples are `xs:decimal` → `double` for money, `dateTime` → `DateOnly`, and a repeating element mapped to a single value. These are flagged as `WARN`/`MISMATCH`.
8. **LLM hallucination and token overrun:** the prompt allows reading only the summary plus ±15 lines per review item, caps the queue at 25 items per operation, requires `file:line` for every claim, and has a "Not verified" section in the report.
9. **Big services:** run with `-o <Operation>` per operation (or in batches) to keep each summary small.

## Limitations (heuristic tool)

- Parsing is regex-based, not compiler-based. Reflection, dynamic dispatch, DI registrations by convention, and code generated at build time can break the call path. When the slice looks too small, the review queue says so and Copilot should search.
- Business-rule matching compares literals/constants. Equivalent logic written differently (`* 0.9` vs `- 10%`) shows as `NOT_FOUND`/`REVIEW` and needs the LLM or a human to judge.
- Stored procedure bodies and DB triggers are not analysed. Only their names are compared.
- WSDL 1.1 is fully supported. WSDL 2.0 support is basic. EDMX parsing is best effort.

## Flags

`--wsdl` (WSDL URL/file or `.svc` file/URL), `--svc`, `--repo1`, `--repo2`, `-o/--operation` (repeatable), `--out`, `--list-ops`, `--schema-dir`, `--synonyms`, `--insecure`, `--timeout`, `--include-tests`, `--max-depth` (call-path depth, default 8), `--min-score` (repo2 endpoint match threshold, default 0.35), `--max-rows`, `--max-review`, `--all-rows`, `--jobs` (parallel parsing, default min(8, CPUs)), `--max-file-kb` (default 1464), `--no-redact`.
Credentials: env vars `SOAP_PARITY_USER`/`SOAP_PARITY_PASSWORD` (Basic) or `SOAP_PARITY_HEADER="Authorization: Bearer …"`. Never put them on the command line.

## Self-test

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl samples/wsdl/quote.wsdl --repo1 samples/dotnet/repo1_l2s --repo2 samples/dotnet/repo2 --out parity_test
```

```bash
python .github/skills/soap-parity/soap_parity.py --wsdl samples/dotnet/repo1/Legacy.Quote/QuoteService.svc --repo2 samples/dotnet/repo2 --out parity_test_svc
```

Expected (both commands): `GetQuote` is **PARTIAL**. Missing: `country`, `discountAmount`, `channel` and `taxAmount`; `totalPrice` decimal→double is flagged, and the 8% tax rule is `NOT_FOUND`. `CancelOrder` is **NOT_IMPLEMENTED**, with the proc (`USP_CANCELORDER` in the LINQ to SQL sample, `PKG_ORDER.CANCEL_ORDER` in the `.svc` sample), the `ORDERS` table and the `audit-queue` missing.
