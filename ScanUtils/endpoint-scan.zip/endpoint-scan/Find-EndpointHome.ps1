<#
.SYNOPSIS
    Which repo HOSTS this service / endpoint?  (reverse of Find-HomeRepoUsage.ps1)

.DESCRIPTION
    Give it what you know and it finds the home repo in the inventory built by Build-UrlInventory.ps1 - nothing is cloned or scanned:

      WCF / SOAP   Order.svc    OrderService.svc    OrderService    IOrderService    http://host/Orders/Order.svc/basic
      REST         GET /api/v1/orders/5     /api/v1/orders/{id}     https://api.contoso.com/orders-api/api/v1/orders
                   OrdersController (a controller name returns every endpoint of it)

    -Query takes any mix (aliases: -Service, -Url, -Endpoint), -QueryFile takes one entry per line.
    The data comes from the per-repo files of the inventory (shards\*.exposed.csv: what every repo exposes), NOT from repos.csv
    (which only lists the repos); repos.csv is used to show each repo's URL / last commit and to know how much of the estate was harvested.

    How it matches
      SOAP without .svc  (a URL that does not end in .svc, or a contract / port / service name): matched against the SOAP services the
             harvest found in code / config / WSDL - ASMX, WCF mounted by ServiceRoute / ServiceHost / <service> config, Java JAX-WS, CXF,
             Spring-WS, Axis, web.xml mappings, WSDL files - by address, by the contract (port type) name and by host. Paste the WCF client
             line from a config file as the query and the contract is used too:  -Query '<endpoint address="https://h/rsax" contract="X.rootSoap" .../>'
      SOAP   the .svc file the repo hosts (High), the implementing class / interface name (Medium), a repo that only declares the contract
             - shared library or copy (Medium for an exact interface name, otherwise Low). Repos that call the service but whose host is not in the inventory are listed as leads.
      REST   the URL is matched segment by segment against every route of every controller / minimal API (a {id} in the route matches
             any value, GET/POST... is honoured when given). A leading gateway / virtual-directory prefix that is not part of the
             controller route (/orders-api/api/v1/orders) is tried and removed (Medium instead of High).
      -HostMapPath (Repo,Host) tells which host name belongs to which repo: a URL on a known host confirms the repo, a mismatch is flagged.

    Output: endpoint-home.csv in -OutputPath (one row per query x hosting repo) and a short summary on screen.

.EXAMPLE
    .\Find-EndpointHome.ps1 -InventoryPath D:\url-inventory -Query Order.svc,'GET /api/v1/orders/5'
.EXAMPLE
    .\Find-EndpointHome.ps1 -InventoryPath D:\url-inventory -QueryFile .\to-find.txt -HostMapPath .\hosts.csv
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$InventoryPath,
    [Alias('Service', 'Url', 'Endpoint', 'Name')][string[]]$Query = @(),
    [string]$QueryFile,
    [string]$HostMapPath,
    [string]$OutputPath = (Get-Location).Path,
    # also show Low-confidence matches (repos that only declare a contract, prefix-only route matches)
    [switch]$IncludeLow,
    # the URLs are SOAP services (do not try them as REST routes). Automatic when a repo's WCF client config calls the address or a contract is given.
    [Alias('Soap')][switch]$SoapOnly,
    [int]$MaxPerQuery = 15
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'EndpointScan.Common.ps1')
. (Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1')
function Split-List($s) { if ([string]::IsNullOrWhiteSpace($s)) { return @() }; return @($s -split ';' | Where-Object { $_ }) }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }
$rank = @{ High = 3; Medium = 2; Low = 1 }
function Lower-Conf([string]$c) { if ($c -eq 'High') { 'Medium' } elseif ($c -eq 'Medium') { 'Low' } else { 'Low' } }

# ---- inputs
$queries = New-Object System.Collections.Generic.List[object]      # @{ Raw; Contract; Binding }
function Get-XmlAttr([string]$tag, [string]$name) {
    $m = [regex]::Match($tag, '(?<![\w-])' + [regex]::Escape($name) + '\s*=\s*(?:"([^"]*)"|''([^'']*)'')', 'IgnoreCase')
    if ($m.Success) { if ($m.Groups[1].Success) { return $m.Groups[1].Value } else { return $m.Groups[2].Value } }
    return ''
}
function Add-QueryText([string]$text) {
    # a pasted WCF client line   <endpoint address="https://host/path" binding=".." contract="Ns.IService" name=".." />   gives the address AND the contract
    foreach ($t in [regex]::Matches($text, '<endpoint\b[^>]*>', 'Singleline')) {
        $a = Get-XmlAttr $t.Value 'address'
        if ($a) { $queries.Add([pscustomobject]@{ Raw = $a; Contract = (Get-XmlAttr $t.Value 'contract'); Binding = (Get-XmlAttr $t.Value 'binding') }) }
    }
    $text = [regex]::Replace($text, '<endpoint\b[^>]*>', '', 'Singleline')
    $text = [regex]::Replace($text, '(?m)^\s*#.*$', '')
    foreach ($part in ($text -split '[,;\r\n]')) { $x = $part.Trim(); if ($x -and $x -notmatch '^<') { $queries.Add([pscustomobject]@{ Raw = $x; Contract = ''; Binding = '' }) } }      # a comma list stays a list however the script was started
}
foreach ($q in $Query) { Add-QueryText $q }
if ($QueryFile) {
    if (-not (Test-Path -LiteralPath $QueryFile)) { throw "QueryFile not found: $QueryFile" }
    Add-QueryText (Get-Content -LiteralPath $QueryFile -Raw)
}
if ($queries.Count -eq 0) { throw 'Nothing to look up: pass -Query (service names, .svc files, URLs, "GET /api/...") and/or -QueryFile.' }
if (-not (Test-Path -LiteralPath $InventoryPath)) { throw "InventoryPath not found: $InventoryPath" }
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$shardDir = Join-Path $InventoryPath 'shards'; $reposFile = Join-Path $InventoryPath 'repos.csv'
if (-not (Test-Path $reposFile) -or -not (Test-Path $shardDir)) { throw "$InventoryPath is not an inventory folder (repos.csv / shards missing) - run Build-UrlInventory.ps1 first." }
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null; $OutputPath = (Resolve-Path -LiteralPath $OutputPath).Path

# ---- repos.csv: which repos are harvested, and their URL / last commit
$repoInfo = @{}; $okRepos = New-Object System.Collections.Generic.List[string]; $all = 0
foreach ($r in (Import-Csv $reposFile)) { if (-not $r.Repo) { continue }; $repoInfo[$r.Repo] = $r; if ($r.Status -in 'ok', 'skipped', 'failed', 'empty', 'missing') { $all++ }; if ($r.Status -eq 'ok') { $okRepos.Add($r.Repo) } }
$notDone = $all - $okRepos.Count

# ---- what every repo exposes (per-repo shards are the source of truth; header-only files are skipped without parsing)
$soap = New-Object System.Collections.Generic.List[object]; $rest = New-Object System.Collections.Generic.List[object]; $soapProv = New-Object System.Collections.Generic.List[object]; $deployRows = New-Object System.Collections.Generic.List[object]
foreach ($repo in $okRepos) {
    $f = Join-Path $shardDir ((Safe-Name $repo) + '.exposed.csv')
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $lines = [System.IO.File]::ReadAllLines($f)
    if ($lines.Length -le 1) { continue }
    foreach ($x in ($lines | ConvertFrom-Csv)) { if ($x.Kind -eq 'WCF') { $soap.Add($x) } elseif ($x.Kind -eq 'REST') { $rest.Add($x) } elseif ($x.Kind -eq 'SOAP') { $soapProv.Add($x) } elseif ($x.Kind -eq 'DEPLOY') { $deployRows.Add($x) } }
}
Write-Host ("Inventory: {0} of {1} repos harvested{2}; {3:N0} SOAP rows, {4:N0} non-.svc SOAP service records and {5:N0} REST routes to search." -f $okRepos.Count, $all, $(if ($notDone -gt 0) { " ($notDone not harvested yet - a repo that is not harvested cannot be found)" } else { '' }), $soap.Count, $soapProv.Count, $rest.Count)

# ---- SOAP index / REST index
function Get-Base([string]$s) { ($s -replace '(?i)\.svc$', '' -replace '(?i)\.cs$', '').ToLowerInvariant() }
$soapIdx = New-Object System.Collections.Generic.List[object]
foreach ($x in $soap) {
    $leaf = if ($x.SvcFile) { (($x.SvcFile -split '[\\/]')[-1]).ToLowerInvariant() } elseif ($x.Service) { $x.Service.ToLowerInvariant() } else { '' }
    $impl = @(Split-List $x.ImplClasses | ForEach-Object { ($_ -split '\.')[-1].ToLowerInvariant() })
    $soapIdx.Add([pscustomobject]@{ Row = $x; Leaf = $leaf; Contract = "$($x.Contract)".ToLowerInvariant(); Impl = $impl })
}
$shapeCache = @{}
$restIdx = @{}
foreach ($x in $rest) {
    if (-not $x.RouteNormalized -and $x.RouteNormalized -ne '') { continue }
    if (-not $shapeCache.ContainsKey($x.RouteNormalized)) { $shapeCache[$x.RouteNormalized] = New-RouteShape $x.RouteNormalized }
    $shape = $shapeCache[$x.RouteNormalized]
    $k = if ($shape.Key) { $shape.Key } else { '' }
    if (-not $restIdx.ContainsKey($k)) { $restIdx[$k] = New-Object System.Collections.Generic.List[object] }
    $restIdx[$k].Add([pscustomobject]@{ Row = $x; Shape = $shape })
}
$knownNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
foreach ($e in $soapIdx) { if ($e.Leaf) { [void]$knownNames.Add($e.Leaf) }; if ($e.Contract) { [void]$knownNames.Add($e.Row.Contract) } }
$restByController = @{}; $ctlNames = @{}
foreach ($x in $rest) { if ($x.Service) { $ctlNames[(($x.Service -replace '(?i)controller$', '')).ToLowerInvariant()] = $x.Service }; $c = (("$($x.Service)" -replace '(?i)controller$', '')).ToLowerInvariant(); if ($c) { if (-not $restByController.ContainsKey($c)) { $restByController[$c] = New-Object System.Collections.Generic.List[object] }; $restByController[$c].Add($x) } }

# ---- host -> repos
$hostRepos = @{}
if ($HostMapPath) {
    foreach ($r in (Import-Csv $HostMapPath)) {
        foreach ($h in ($r.Host -split ';')) { $h = ($h.Trim() -replace '^[a-z]+://', '' -replace '[/:].*$', '').ToLowerInvariant(); if ($h) { if (-not $hostRepos.ContainsKey($h)) { $hostRepos[$h] = New-Object System.Collections.Generic.List[string] }; $hostRepos[$h].Add($r.Repo) } }
    }
}


# ---- helpers for SOAP services that are not a *.svc file
$implContracts = @{}      # 'repo|implClass' -> WCF contracts that class implements (a service mounted by ServiceRoute has the class here, the contract elsewhere)
foreach ($x in $soap) { foreach ($ic in (Split-List $x.ImplClasses)) { $k = $x.Repo + '|' + (("$ic" -split '[.$]')[-1]).ToLowerInvariant(); if (-not $implContracts.ContainsKey($k)) { $implContracts[$k] = New-Object System.Collections.Generic.List[string] }; if ($x.Contract -and -not $implContracts[$k].Contains($x.Contract)) { $implContracts[$k].Add($x.Contract) } } }
$genericSeg = 'services', 'service', 'ws', 'webservice', 'webservices', 'soap', 'api', 'axis', 'cxf', 'wsdl', 'rest', 'i1', 'external', 'internal'
function Test-GenericSeg([string]$s) { return ($genericSeg -contains $s) -or ($s -match '^v\d+$') }
function Get-NameKey([string]$s) { return (("$s" -split '[.:/$]')[-1] -replace '[^A-Za-z0-9]', '').ToLowerInvariant() }          # 'FiBRS.Root.rootSoap' -> 'rootsoap'
function Get-NameCore([string]$s) { return ((Get-NameKey $s) -replace '(soap12|soap11|soap|porttype|port|binding|service|impl|endpoint)$', '') }   # 'rootsoap' -> 'root'
function Test-SegSeq($a, $b) { if ($a.Count -ne $b.Count) { return $false }; for ($i = 0; $i -lt $a.Count; $i++) { if ($a[$i] -ne $b[$i]) { return $false } }; return $true }
# one pass over the saved URL facts of every harvested repo for a set of tokens (host names / paths): who calls or mentions them
function Search-UsedShards([string[]]$tokens) {
    $res = New-Object System.Collections.Generic.List[object]
    $tokens = @($tokens | Where-Object { $_ } | Select-Object -Unique)
    if ($tokens.Count -eq 0) { return $res }
    $rx = New-Object System.Text.RegularExpressions.Regex(('(?i)' + ((@($tokens | Sort-Object { $_.Length } -Descending) | ForEach-Object { [regex]::Escape($_) }) -join '|')))
    foreach ($repo in $okRepos) {
        $f = Join-Path $shardDir ((Safe-Name $repo) + '.used.csv'); if (-not (Test-Path -LiteralPath $f)) { continue }
        $text = [System.IO.File]::ReadAllText($f)
        if (-not $rx.IsMatch($text)) { continue }
        $lines = $text -split "`r?`n"
        $hdr = ($lines[0] -replace '"', '') -split ','
        $hit = @($lines | Select-Object -Skip 1 | Where-Object { $_ -and $rx.IsMatch($_) })
        foreach ($u in ($hit | ConvertFrom-Csv -Header $hdr)) { $res.Add($u) }
    }
    return $res
}

# ---- REST: where a repo says it is mounted / reachable (path base, host) and name evidence
$deploy = $deployRows
$pathBases = @{}                  # repo -> @{ Segs; Route; File; Line; Framework }
$deployHosts = @{}                # host -> repos that declare it (ingress / route / values files)
foreach ($d in $deploy) {
    if ($d.Service -eq 'pathbase' -and $d.RouteNormalized) {
        if (-not $pathBases.ContainsKey($d.Repo)) { $pathBases[$d.Repo] = New-Object System.Collections.Generic.List[object] }
        $pathBases[$d.Repo].Add(@{ Segs = @($d.RouteNormalized -split '/' | Where-Object { $_ }); Route = $d.Route; File = $d.File; Line = $d.Line; Framework = $d.Framework })
    } elseif ($d.Service -eq 'host' -and $d.RouteNormalized) {
        if (-not $deployHosts.ContainsKey($d.RouteNormalized)) { $deployHosts[$d.RouteNormalized] = @{} }
        $deployHosts[$d.RouteNormalized][$d.Repo] = $d
    }
}
$repoBoostRepos = @{}; foreach ($h in $deployHosts.Values) { foreach ($r in $h.Keys) { $repoBoostRepos[$r] = 1 } }
foreach ($r in $okRepos) { $repoBoostRepos[$r] = 1 }
$envWords = 'saifg', 'rbc', 'sterbc', 'com', 'org', 'net', 'apps', 'ocp', 'mtls', 'uat', 'qa', 'dev', 'sit', 'int', 'ist', 'prod', 'prd', 'nonprod', 'apigw', 'gw', 'api', 'www', 'svc', 'internal', 'external', 'cluster', 'local', 'intranet', 'rest', 'service', 'services'
function Get-UrlTokens($q) {
    $t = New-Object System.Collections.Generic.HashSet[string]
    foreach ($label in ($q.Host -split '\.')) { foreach ($w in ($label -split '-')) { $n = ($w -replace '[^a-z0-9]', ''); if ($n.Length -ge 5 -and $envWords -notcontains $n -and $n -notmatch '^n\d{3}\w*$') { [void]$t.Add($n) } } }
    foreach ($seg in $q.Segs) {
        if (Test-GenericSeg $seg -or $seg -match '^\{') { continue }
        $n = ($seg -replace '[^a-z0-9]', ''); if ($n.Length -ge 5 -and $envWords -notcontains $n) { [void]$t.Add($n) }
        foreach ($w in ($seg -split '[-_.]')) { $n = ($w -replace '[^a-z0-9]', ''); if ($n.Length -ge 5 -and $envWords -notcontains $n) { [void]$t.Add($n) } }
    }
    return @($t)
}
function Get-RepoPathBase([string]$repo, $removed) {          # the repo declares exactly the prefix that was removed from the URL
    if (-not $pathBases.ContainsKey($repo)) { return $null }
    foreach ($pb in $pathBases[$repo]) { if ($pb.Segs.Count -eq $removed.Count -and (Test-SegSeq $pb.Segs @($removed | ForEach-Object { $_.ToLowerInvariant() }))) { return $pb } }
    return $null
}
$restByRepo = @{}
foreach ($x in $rest) { if (-not $restByRepo.ContainsKey($x.Repo)) { $restByRepo[$x.Repo] = New-Object System.Collections.Generic.List[object] }; $restByRepo[$x.Repo].Add($x) }
$boostCache = @{}
function Get-RepoBoost([string]$repo, $q, $tokens) {
    $ck = $repo + '|' + $q.Raw
    if ($boostCache.ContainsKey($ck)) { return $boostCache[$ck] }
    $pts = 0; $ev = New-Object System.Collections.Generic.List[string]
    if ($q.Host -and $deployHosts.ContainsKey($q.Host) -and $deployHosts[$q.Host].ContainsKey($repo)) {
        $d = $deployHosts[$q.Host][$repo]
        if ($deployHosts[$q.Host].Count -le 3) { $pts += 5; $ev.Add("host name '$($q.Host)' is declared by this repo ($($d.Framework): $($d.File):$($d.Line))") }
        else { $pts += 1; $ev.Add("host name is declared by this repo (but also by $($deployHosts[$q.Host].Count - 1) others: shared host)") }
    }
    $full = ($repo -replace '[^A-Za-z0-9]', '').ToLowerInvariant(); $core = ($full -replace '(service|api|app|web|svc|rest|core|webapi|server|backend|bff)+$', '')
    $nameBest = 0; $nameTok = ''
    foreach ($tk in $tokens) {
        if ($tk -eq $full -or $tk -eq $core) { $nameBest = 4; $nameTok = $tk; break }
        elseif ($full.Contains($tk) -or ($core.Length -ge 6 -and $tk.Contains($core))) { if ($nameBest -lt 3) { $nameBest = 3; $nameTok = $tk } }
    }
    if ($nameBest -gt 0) { $pts += $nameBest; $ev.Add("repo name '$repo' $(if ($nameBest -eq 4) { 'equals' } else { 'contains' }) '$nameTok' from the URL") }
    $res = @{ Pts = $pts; Ev = @($ev) }; $boostCache[$ck] = $res; return $res
}
function Get-ControllerEvidence([string]$controller, $tokens) {
    $c = ($controller -replace '(?i)controller$', '' -replace '[^A-Za-z0-9]', '').ToLowerInvariant()
    if ($c.Length -lt 5) { return $null }
    foreach ($tk in $tokens) { if ($tk -eq $c) { return "controller '$controller' is named like '$tk' in the URL" } }
    return $null
}

# ---- parse a query
function Read-Query([string]$raw) {
    $t = $raw.Trim(); $verb = ''
    if ($t -match '^(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+(.+)$') { $verb = $Matches[1].ToUpperInvariant(); $t = $Matches[2].Trim() }
    $hostName = ''; $path = $t
    if ($t -match '^[a-zA-Z][a-zA-Z0-9+.-]*://([^/\s?#]+)(/[^?#]*)?') { $hostName = ($Matches[1] -replace ':\d+$', '').ToLowerInvariant(); $path = $Matches[2] }
    $path = ($path -split '[?#]')[0]
    $isSvc = $t -match '(?i)\.svc(\b|$|[/?#])'
    $svcLeaf = ''; if ($isSvc) { $m = [regex]::Match($t, '(?i)([^/\\]+\.svc)(?=$|[/?#])'); if ($m.Success) { $svcLeaf = $m.Groups[1].Value.ToLowerInvariant() } else { $svcLeaf = (($t -split '[/\\]')[-1]).ToLowerInvariant() } }
    $pathLike = (-not $isSvc) -and ($path.Contains('/') -or $hostName -or $verb)
    $norm = [regex]::Replace($path, '\{\{[^}]*\}\}|\$?\{[^}]*\}|(?<=/):[A-Za-z_]\w*', '{}')
    $segs = @($norm.Trim('~', '/').ToLowerInvariant() -split '/' | Where-Object { $_ -ne '' })
    [pscustomobject]@{
        Raw = $raw; Verb = $verb; Host = $hostName; Segs = $segs; Trail = $norm.EndsWith('/')
        WantSoap = ($isSvc -or -not $pathLike); WantRest = ($pathLike -or -not $isSvc)
        SvcLeaf = $svcLeaf; NameKey = $(if (-not $isSvc -and -not $pathLike) { ((($t -replace '(?i)\.(asmx|wsdl|java|cs)$', '') -split '[.:/$]')[-1] -replace '[^A-Za-z0-9]', '').ToLowerInvariant() } else { '' }); Key = $(if (-not $isSvc -and -not $pathLike) { Get-Base $t } else { '' }); Kind = $(if ($isSvc) { 'SOAP (.svc)' } elseif ($pathLike) { 'REST (URL)' } else { 'name (SOAP or REST controller)' })
    }
}

$results = New-Object System.Collections.Generic.List[object]
$summary = New-Object System.Collections.Generic.List[object]
function New-Hit($q, $kind, $repo, $role, $service, $contract, $endpoint, $conf, $by, $file, $line, $notes) {
    $ri = $repoInfo[$repo]
    [pscustomobject][ordered]@{
        Query = $q.Raw; Kind = $kind; HomeRepo = $repo; Confidence = $conf; Role = $role; Service = $service; Contract = $contract; Endpoint = $endpoint
        MatchedBy = $by; File = $file; Line = $line; RepoUrl = $(if ($ri) { $ri.RepoUrl } else { '' }); LastCommit = $(if ($ri) { $ri.LastCommit } else { '' }); Notes = $notes
    }
}

# callers / mentions of every non-.svc URL, found in ONE pass over the saved URL facts
$parsed = @($queries | ForEach-Object { $x = Read-Query $_.Raw; $x | Add-Member -NotePropertyName Contract -NotePropertyValue $_.Contract -Force; $x | Add-Member -NotePropertyName Binding -NotePropertyValue $_.Binding -Force; $x })
$scanTokens = New-Object System.Collections.Generic.List[string]
foreach ($pq in $parsed) {
    if (-not $pq.SvcLeaf -and $pq.NameKey -and $pq.NameKey.Length -ge 4) { $tk = (($pq.Raw -replace '(?i)\.(asmx|wsdl|java|cs)$', '') -split '[.:/$]')[-1]; if ($tk.Length -ge 4) { $scanTokens.Add($tk) } }
    if (-not $pq.SvcLeaf -and $pq.Segs.Count -gt 0) { if ($pq.Host) { $scanTokens.Add($pq.Host) }; $scanTokens.Add('/' + ($pq.Segs -join '/')) } }
$usedHits = @(); if ($scanTokens.Count -gt 0) { Write-Host 'Looking for callers of the addresses in the saved URL facts ...'; $usedHits = @(Search-UsedShards $scanTokens.ToArray()) }

foreach ($q in $parsed) {
    $raw = $q.Raw
    $hits = New-Object System.Collections.Generic.List[object]
    $groupsWire = @{}

    # ---------------- SOAP
    if ($q.WantSoap) {
        $groups = @{}
        foreach ($e in $soapIdx) {
            $x = $e.Row; $type = 0; $by = ''
            # evidence weight: the .svc file itself (4) > exact interface name (3) > implementing class / I+name (2; 1 when the question was a .svc file)
            if ($q.SvcLeaf) {
                if ($e.Leaf -and ($e.Leaf -eq $q.SvcLeaf -or (Get-Base $e.Leaf) -eq (Get-Base $q.SvcLeaf))) { $type = 4; $by = ".svc file '$($e.Leaf)'" }
                elseif ($e.Impl -contains (Get-Base $q.SvcLeaf)) { $type = 1; $by = "class named '$(Get-Base $q.SvcLeaf)' (no .svc file of that name in this repo)" }
            } elseif ($q.Key) {
                if ($e.Leaf -and (Get-Base $e.Leaf) -eq $q.Key) { $type = 4; $by = ".svc file '$($e.Leaf)'" }
                elseif ($e.Contract -and $e.Contract -eq $q.Key) { $type = 3; $by = "contract '$($x.Contract)'" }
                elseif ($e.Impl -contains $q.Key) { $type = 2; $by = "implementing class '$($q.Key)'" }
                elseif ($e.Contract -and $e.Contract -eq ('i' + $q.Key)) { $type = 2; $by = "contract '$($x.Contract)'" }
            }
            if ($type -eq 0) { continue }
            $roleScore = switch ($x.Role) { 'Host' { 2 } 'Implementation' { 1 } default { 0 } }
            $k = $x.Repo + '|' + $x.Contract + '|' + $e.Leaf
            if (-not $groups.ContainsKey($k)) { $groups[$k] = @{ Repo = $x.Repo; Contract = $x.Contract; Leaf = $e.Leaf; Role = $x.Role; Type = $type; By = $by; Score = $type + $roleScore; File = $x.File; Line = $x.Line; Ops = New-Object System.Collections.Generic.List[string]; Wire = $x.WireNamespace } }
            $g = $groups[$k]
            if (($type + $roleScore) -gt $g.Score) { $g.Score = $type + $roleScore; $g.Role = $x.Role; $g.By = $by; $g.File = $x.File; $g.Line = $x.Line }
            if ($x.Operation -and $x.Operation -ne '*' -and -not $g.Ops.Contains($x.Operation)) { $g.Ops.Add($x.Operation) }
        }
        foreach ($g in $groups.Values) {
            $groupsWire[$g.Repo + '|' + $g.Contract] = $g.Wire
            $conf = if ($g.Score -ge 5) { 'High' } elseif ($g.Score -ge 3) { 'Medium' } else { 'Low' }
            $note = if ($g.Role -eq 'ContractOnly') { 'declares the contract only (shared library or copy) - not the host' } elseif ($g.Role -eq 'Implementation') { 'implements the contract; no .svc / host configuration found in this repo' } else { '' }
            if ($q.Host -and $hostRepos.ContainsKey($q.Host)) { if ($hostRepos[$q.Host] -contains $g.Repo) { $conf = 'High'; $note = (($note + ' host name belongs to this repo (hosts.csv)').Trim()) } else { $conf = Lower-Conf $conf; $note = (($note + " host '$($q.Host)' belongs to: $($hostRepos[$q.Host] -join ', ')").Trim()) } }
            $hits.Add((New-Hit $q 'SOAP' $g.Repo $g.Role $(if ($g.Leaf) { $g.Leaf } else { $g.Contract }) $g.Contract $(if ($g.Ops.Count) { ("{0} operation(s): {1}{2}" -f $g.Ops.Count, (($g.Ops | Select-Object -First 6) -join ', '), $(if ($g.Ops.Count -gt 6) { ', ...' } else { '' })) } else { '(operations are declared in the contract library, not in this repo)' }) $conf $g.By $g.File $g.Line $note))
        }
    }


    # ---------------- who CALLS this address (WCF client endpoints and other URL facts) - and the contract names they use
    $qPath = ($q.Segs -join '/')
    $callers = @{}; $soapCallers = @{}; $mentions = @{}; $wantContracts = New-Object System.Collections.Generic.List[string]
    if ($q.Contract) { $wantContracts.Add($q.Contract) }
    if (-not $q.SvcLeaf -and $qPath) {
        foreach ($u in $usedHits) {
            $up = (("$($u.UrlPath)" -replace '[?#].*$', '').Trim('/', '~')).ToLowerInvariant()
            $samePath = ($up -eq $qPath)
            $deployLike = ("$($u.File)" -match '(?i)(values|route|ingress|deploy|helm|chart|openshift|k8s|manifest|gateway|ocelot|yarp|swagger|openapi|\.ya?ml$)')
            if ($u.Kind -eq 'SoapClientEndpoint' -and $samePath) {
                $callers[$u.Repo] = 1; $soapCallers[$u.Repo] = 1
                $cm = [regex]::Match("$($u.Detail)", 'contract=([^;]+)'); if ($cm.Success -and -not $wantContracts.Contains($cm.Groups[1].Value)) { $wantContracts.Add($cm.Groups[1].Value) }
            } elseif ($samePath -and -not $deployLike -and (-not $q.Host -or $u.Host -eq $q.Host)) {
                $callers[$u.Repo] = 1      # the URL is in this repo's code / settings: a consumer
            } elseif ($samePath -or ($q.Host -and $u.Host -eq $q.Host -and $up.StartsWith($qPath))) {
                if (-not $mentions.ContainsKey($u.Repo)) { $mentions[$u.Repo] = $u.File }
            }
        }
        foreach ($k in @($mentions.Keys)) { if ($callers.ContainsKey($k)) { $mentions.Remove($k) } }
    }
    if (-not $q.SvcLeaf -and $q.NameKey -and $q.NameKey.Length -ge 4) {      # a bare contract / port-type name: repos whose WCF client config uses it are consumers
        foreach ($u in $usedHits) {
            if ($u.Kind -ne 'SoapClientEndpoint') { continue }
            $cm = [regex]::Match("$($u.Detail)", 'contract=([^;]+)')
            if ($cm.Success -and (Get-NameKey $cm.Groups[1].Value) -eq $q.NameKey) { $callers[$u.Repo] = 1 }
        }
    }
    $knownSoap = ($soapCallers.Count -gt 0) -or [bool]$q.Contract
    if ($SoapOnly -or $knownSoap) { $q.WantRest = $false }

    # ---------------- SOAP that is not a *.svc file: address / contract (port type) / service name  vs  what the harvest found in code, config and WSDL
    $provHits = New-Object System.Collections.Generic.List[object]
    if (-not $q.SvcLeaf -and ($qPath -or $q.NameKey -or $wantContracts.Count -gt 0)) {
        $wantKeys = @($wantContracts | ForEach-Object { @{ Key = (Get-NameKey $_); Core = (Get-NameCore $_); Orig = $_ } })
        $lastSeg = @($q.Segs | Where-Object { -not (Test-GenericSeg $_) } | Select-Object -Last 1)
        $cand = @{}
        foreach ($p in $soapProv) {
            $ev = New-Object System.Collections.Generic.List[string]; $score = 0
            $addr = @(); if ($p.RouteNormalized) { $addr = @($p.RouteNormalized -split '/' | Where-Object { $_ }) }
            $addrSpecific = @($addr | Where-Object { -not (Test-GenericSeg $_) }).Count -gt 0
            if ($q.Segs.Count -gt 0 -and $addr.Count -gt 0 -and $addrSpecific) {
                $n = $addr.Count; $c = $q.Segs.Count
                if (Test-SegSeq $addr $q.Segs) { $score += 7; $ev.Add('address equals the URL path') }
                elseif ($c -gt $n -and (Test-SegSeq @($q.Segs[0..($n - 1)]) $addr)) { $score += 4; $ev.Add("address '$($p.Route)' is the base path of the URL") }
                elseif ($c -gt $n -and (Test-SegSeq @($q.Segs[($c - $n)..($c - 1)]) $addr)) { if ($addr[-1] -like '*.asmx') { $score += 7; $ev.Add("ASMX file '$($addr[-1])' is the end of the URL path") } else { $score += 4; $ev.Add("address '$($p.Route)' matches the end of the URL path (gateway prefix in front)") } }
                elseif ($n -gt $c -and (Test-SegSeq @($addr[0..($c - 1)]) $q.Segs)) { $score += 1; $ev.Add("the URL is the base path of address '$($p.Route)'") }
                if ($q.Host -and "$($p.Route)" -match '^[a-z]+://([^/:]+)' -and $Matches[1].ToLowerInvariant() -eq $q.Host) { $score += 2; $ev.Add('address host equals') }
            }
            $implShort = (("$($p.ImplClasses)" -split '[.$]')[-1]); if (-not $implShort) { $implShort = $p.Service }
            $extra = @(); $ik = $p.Repo + '|' + "$implShort".ToLowerInvariant(); if ($implContracts.ContainsKey($ik)) { $extra = @($implContracts[$ik]) }
            $names = @((("$($p.Contract)" -split '\|') + $p.Service + $implShort + $extra) | Where-Object { $_ })
            $nameHit = $false
            foreach ($w in $wantKeys) {
                foreach ($nm in $names) {
                    $k = Get-NameKey $nm; $cr = Get-NameCore $nm
                    if ($k -and $k -eq $w.Key) { $score += 4; $ev.Add("contract / port name '$nm' equals the client's '$($w.Orig)'"); $nameHit = $true; break }
                    elseif ($cr.Length -ge 3 -and $w.Core.Length -ge 3 -and $cr -eq $w.Core) { $score += 3; $ev.Add("name '$nm' has the same core name as '$($w.Orig)'"); $nameHit = $true; break }
                    elseif ($cr.Length -ge 6 -and $w.Core.Length -ge 6 -and ($w.Core.Contains($cr) -or $cr.Contains($w.Core))) { $score += 2; $ev.Add("name '$nm' resembles '$($w.Orig)'"); $nameHit = $true; break }
                }
                if ($nameHit) { break }
            }
            if ($q.NameKey) {
                foreach ($nm in $names) { if ((Get-NameKey $nm) -eq $q.NameKey) { $score += 6; $ev.Add("name '$nm' equals '$($q.Raw)'"); $nameHit = $true; break } }
            }
            if (-not $nameHit -and $lastSeg.Count -gt 0 -and $lastSeg[0].Length -ge 4) {
                foreach ($nm in $names) { if ((Get-NameKey $nm) -eq ($lastSeg[0] -replace '[^a-z0-9]', '')) { $score += 3; $ev.Add("service name '$nm' equals '$($lastSeg[0])' in the URL"); break } }
            }
            if ($q.Host -and $hostRepos.ContainsKey($q.Host) -and $hostRepos[$q.Host] -contains $p.Repo) { $score += 4; $ev.Add('host name belongs to this repo (hosts.csv)') }
            if ($score -lt 2) { continue }
            $r = $p.Repo
            if (-not $cand.ContainsKey($r)) { $cand[$r] = @{ Best = $null; Score = -1; Ev = @(); Roles = @{}; BestScore = -1 } }
            $cr0 = $cand[$r]; $cr0.Roles[$p.Role] = 1
            if ($score -gt $cr0.BestScore) { $cr0.Best = $p; $cr0.BestScore = $score; $cr0.Ev = @($ev) }
        }
        foreach ($r in $cand.Keys) {
            $cr0 = $cand[$r]; $p = $cr0.Best; $score = $cr0.BestScore; $ev = @($cr0.Ev)
            if ($cr0.Roles.ContainsKey('Wsdl') -and $cr0.Roles.ContainsKey('Provider')) { $score += 2; $ev += 'code and WSDL in this repo agree' }
            $conf = if ($score -ge 9) { 'High' } elseif ($score -ge 5) { 'Medium' } else { 'Low' }
            $note = ''
            if ($p.Role -eq 'Wsdl' -and -not $cr0.Roles.ContainsKey('Provider')) {
                if ($conf -eq 'High') { $conf = 'Medium' }
                $note = 'a WSDL describes the service here (the provider''s own definition - or a copy kept by a consumer); no code that serves it was recognised'
            }
            if ($callers.ContainsKey($r)) { $conf = Lower-Conf $conf; $note = (($note + ' this repo also CALLS the address: the WSDL / contract is probably a copy of the provider''s').Trim()) }
            $provHits.Add((New-Hit $q 'SOAP' $r $(if ($p.Role -eq 'Provider') { 'Provider' } else { 'Wsdl' }) $p.Service $p.Contract $(if ($p.Route) { $p.Route } else { '(address is configured outside the code)' }) $conf ($ev -join '; ') $p.File $p.Line $note))
        }
        # .NET services hosted without a .svc (ServiceRoute / ServiceHost): the harvest already has their WCF contract - match it by the client's contract name
        foreach ($w in $wantKeys) {
            foreach ($e in $soapIdx) {
                if (-not $e.Contract) { continue }
                if ((Get-NameKey $e.Contract) -ne $w.Key -or -not $w.Key) { continue }
                if ($e.Row.Role -eq 'ContractOnly' -or $cand.ContainsKey($e.Row.Repo)) { continue }
                $provHits.Add((New-Hit $q 'SOAP' $e.Row.Repo $e.Row.Role $e.Leaf $e.Row.Contract '(WCF service without .svc)' $(if ($e.Row.Role -eq 'Host') { 'Medium' } else { 'Low' }) "WCF contract '$($e.Row.Contract)' equals the client's '$($w.Orig)'" $e.Row.File $e.Row.Line ''))
            }
        }
    }
    $already = @{}; foreach ($h in $hits) { if ($h.Kind -eq 'SOAP' -and $h.Confidence -in 'High', 'Medium') { $already[$h.HomeRepo] = 1 } }
    foreach ($h in $provHits) { if ($q.NameKey -and $already.ContainsKey($h.HomeRepo)) { continue }; $hits.Add($h) }

    # ---------------- REST: route match + where the repo says it is mounted (path base / host) + name evidence, added up as points
    if ($q.WantRest -and $q.Segs.Count -gt 0) {
        $tokens = Get-UrlTokens $q
        $cands = @{}                                           # repo|verb|route -> best candidate
        for ($strip = 0; $strip -le [Math]::Min(3, $q.Segs.Count - 1); $strip++) {
            $segs = if ($strip -eq 0) { $q.Segs } else { @($q.Segs[$strip..($q.Segs.Count - 1)]) }
            $keys = @(); if ($segs.Count -ge 2) { $keys += ($segs[0] + '/' + $segs[1]) }; $keys += $segs[0]; $keys += ''      # '' = routes that start with a parameter
            $removed = if ($strip -gt 0) { @($q.Segs[0..($strip - 1)]) } else { @() }
            $remSpecific = @($segs | Where-Object { -not (Test-GenericSeg $_) }).Count -gt 0
            foreach ($k in $keys) {
                if (-not $restIdx.ContainsKey($k)) { continue }
                foreach ($c in $restIdx[$k]) {
                    $lvl = Test-RouteMatch $c.Shape $segs ($q.Trail -and $strip -eq 0)
                    if (-not $lvl) { continue }
                    $x = $c.Row
                    if ($q.Verb -and $x.HttpVerb -ne $q.Verb -and $x.HttpVerb -ne 'ANY') { continue }
                    $pts = 0; $ev = New-Object System.Collections.Generic.List[string]
                    if ($lvl -eq 'Full') { $pts += 5; $ev.Add("route '$($x.Route)' (full match)"); if ($q.Verb) { $pts += 2 } }
                    elseif ($remSpecific) { $pts += 4; $ev.Add("the URL is the base path of route '$($x.Route)'") }
                    else { $pts += 1; $ev.Add("route '$($x.Route)' starts with the (generic) URL path") }
                    $sc = $c.Shape.StrongCount; if ($sc -ge 2) { $pts += 1 } elseif ($sc -eq 1) { $pts -= 1 } else { $pts -= 3 }
                    $hasPb = $false
                    if ($strip -gt 0) {
                        $pb = Get-RepoPathBase $x.Repo $removed
                        if ($pb) { $hasPb = $true; $pts += 5; $ev.Add("path base '$($pb.Route)' is declared by this repo ($($pb.Framework): $($pb.File):$($pb.Line))") }
                        else { $pts -= 1; $ev.Add("after removing the leading '$($removed -join '/')' (gateway / virtual-directory prefix)") }
                    }
                    $b = Get-RepoBoost $x.Repo $q $tokens
                    $pts += $b.Pts; foreach ($e in $b.Ev) { $ev.Add($e) }
                    $ct = Get-ControllerEvidence $x.Service $tokens; if ($ct) { $pts += 3; $ev.Add($ct) }
                    $ck = $x.Repo + '|' + $x.HttpVerb + '|' + $x.RouteNormalized
                    if (-not $cands.ContainsKey($ck) -or $pts -gt $cands[$ck].Pts) { $cands[$ck] = @{ Row = $x; Pts = $pts; Ev = @($ev); Lvl = $lvl; Strip = $strip; Pb = $hasPb } }
                }
            }
        }
        # a complete route match means the URL is a concrete endpoint (not a base path) - and the shortest prefix removal wins, unless a repo declares that prefix itself
        $fullStrong = @($cands.Values | Where-Object { $_.Lvl -eq 'Full' -and $_.Pts -ge 5 })
        $strip0Strong = @($fullStrong | Where-Object { $_.Strip -eq 0 })
        $byRepo = @{}
        foreach ($cd in $cands.Values) {
            if ($cd.Pts -lt 3) { continue }
            if ($fullStrong.Count -gt 0 -and $cd.Lvl -ne 'Full' -and -not $cd.Pb) { continue }
            if ($strip0Strong.Count -gt 0 -and $cd.Strip -gt 0 -and -not $cd.Pb) { continue }
            if (-not $byRepo.ContainsKey($cd.Row.Repo)) { $byRepo[$cd.Row.Repo] = New-Object System.Collections.Generic.List[object] }
            $byRepo[$cd.Row.Repo].Add($cd)
        }
        foreach ($repo in $byRepo.Keys) {
            $list = @($byRepo[$repo] | Sort-Object { - $_.Pts })
            $fullHits = @($list | Where-Object { $_.Lvl -eq 'Full' }); $baseHits = @($list | Where-Object { $_.Lvl -ne 'Full' })
            $emit = New-Object System.Collections.Generic.List[object]
            foreach ($cd in $fullHits) { $emit.Add(@{ Cd = $cd; Endpoint = ("{0} /{1}" -f $cd.Row.HttpVerb, $cd.Row.Route.TrimStart('/')) }) }
            if ($baseHits.Count -gt 0) {      # a base URL: one row per repo, not one per route underneath it
                $top = $baseHits[0]
                $sample = @($baseHits | Select-Object -First 4 | ForEach-Object { '{0} /{1}' -f $_.Row.HttpVerb, $_.Row.Route.TrimStart('/') })
                $emit.Add(@{ Cd = $top; Endpoint = ("{0} endpoint(s) under this base: {1}{2}" -f $baseHits.Count, ($sample -join '; '), $(if ($baseHits.Count -gt 4) { '; ...' } else { '' })) })
            }
            foreach ($em in $emit) {
                $cd = $em.Cd; $x = $cd.Row; $pts = $cd.Pts; $note = ''
                if ($x.Role -eq 'Library') { $note = 'controller is in a class library (not a web project) - hosted by the web project that references it' }
                if ($x.Flags -match 'UnresolvedRoute') { $note = (($note + ' route could not be fully resolved from the code').Trim()) }
                if ($q.Host -and $hostRepos.ContainsKey($q.Host)) { if ($hostRepos[$q.Host] -contains $x.Repo) { $pts += 4; $cd.Ev += 'host name belongs to this repo (hosts.csv)' } else { $pts -= 2; $note = (($note + " host '$($q.Host)' belongs to: $($hostRepos[$q.Host] -join ', ')").Trim()) } }
                $conf = if ($pts -ge 8) { 'High' } elseif ($pts -ge 5) { 'Medium' } elseif ($pts -ge 3) { 'Low' } else { '' }
                if (-not $conf) { continue }
                $hits.Add((New-Hit $q 'REST' $x.Repo $(if ($x.Role -eq 'Library') { 'Library' } else { 'Host' }) $x.Service '' $em.Endpoint $conf ($cd.Ev -join '; ') $x.File $x.Line $note))
            }
        }
        # repos with no route that matches but strong evidence of their own (path base + name / host): the service may mount its routes in a way the scan cannot see
        foreach ($repo in (@($repoBoostRepos.Keys) + @($pathBases.Keys) | Select-Object -Unique)) {
            if ($byRepo.ContainsKey($repo)) { continue }
            $b = Get-RepoBoost $repo $q $tokens
            $pbHit = $null; if ($pathBases.ContainsKey($repo)) { foreach ($pbs in $pathBases[$repo]) { if ($pbs.Segs.Count -gt 0 -and $q.Segs.Count -ge $pbs.Segs.Count -and (Test-SegSeq @($q.Segs[0..($pbs.Segs.Count - 1)]) $pbs.Segs) -and (@($pbs.Segs | Where-Object { -not (Test-GenericSeg $_) }).Count -gt 0)) { $pbHit = $pbs } } }
            $pts = $b.Pts; $ev = @($b.Ev)
            if ($pbHit) { $pts += 5; $ev += "path base '$($pbHit.Route)' is declared by this repo ($($pbHit.Framework): $($pbHit.File):$($pbHit.Line))" }
            if ($pts -lt 5 -or ($b.Pts -eq 0 -and -not $pbHit)) { continue }
            $conf = if ($pts -ge 8) { 'High' } elseif ($pts -ge 5) { 'Medium' } else { 'Low' }
            $endpointText = '(no route of this repo matched - see MatchedBy)'; $noteText = 'the repo declares where it is mounted / reachable, but its routes did not match the rest of the URL'; $routeFile = ''; $routeLine = ''
            if ($pbHit -and $restByRepo.ContainsKey($repo)) {
                $rem = @(); if ($q.Segs.Count -gt $pbHit.Segs.Count) { $rem = @($q.Segs[$pbHit.Segs.Count..($q.Segs.Count - 1)]) }
                $under = New-Object System.Collections.Generic.List[object]
                foreach ($rx in $restByRepo[$repo]) {
                    $rs = @($rx.RouteNormalized -split '/' | Where-Object { $_ }); $okp = ($rs.Count -ge $rem.Count)
                    for ($i = 0; $okp -and $i -lt $rem.Count; $i++) { if ($rs[$i] -ne '{}' -and $rs[$i].ToLowerInvariant() -ne $rem[$i].ToLowerInvariant()) { $okp = $false } }
                    if ($okp) { $under.Add($rx) }
                }
                if ($under.Count -gt 0) {
                    $sample = @($under | Select-Object -First 4 | ForEach-Object { '{0} /{1}' -f $_.HttpVerb, $_.Route.TrimStart('/') })
                    $endpointText = ("{0} endpoint(s) under this base (after the path base '{1}'): {2}{3}" -f $under.Count, $pbHit.Route, ($sample -join '; '), $(if ($under.Count -gt 4) { '; ...' } else { '' }))
                    $noteText = ''; $routeFile = $under[0].File; $routeLine = $under[0].Line
                    $pts += 1; if ($pts -ge 5 -and $conf -eq 'Low') { $conf = 'Medium' }
                }
            }
            $hits.Add((New-Hit $q 'REST' $repo 'Host' '' '' $endpointText $conf ($ev -join '; ') $(if ($routeFile) { $routeFile } elseif ($pbHit) { $pbHit.File } else { '' }) $(if ($routeLine) { $routeLine } elseif ($pbHit) { $pbHit.Line } else { '' }) $noteText))
        }
    }
    # a bare name can also be a controller: list its endpoints (one row per repo)
    if ($q.Key -and $q.WantRest) {
        $c = ($q.Key -replace 'controller$', '')
        if ($restByController.ContainsKey($c)) {
            foreach ($g in ($restByController[$c] | Group-Object Repo)) {
                $r0 = $g.Group[0]
                $hits.Add((New-Hit $q 'REST' $g.Name $(if ($r0.Role -eq 'Library') { 'Library' } else { 'Host' }) $r0.Service '' ("{0} endpoint(s): {1}" -f $g.Count, ((@($g.Group | Select-Object -First 4 | ForEach-Object { '{0} /{1}' -f $_.HttpVerb, $_.Route.TrimStart('/') })) -join '; ') + $(if ($g.Count -gt 4) { '; ...' } else { '' })) 'High' "controller '$($r0.Service)'" $r0.File $r0.Line $(if ($r0.Role -eq 'Library') { 'controller is in a class library (not a web project)' } else { '' })))
            }
        }
    }

    # ---------------- rank, mark duplicates, keep the best
    $ranked = @($hits | Sort-Object @{ e = { - $rank[$_.Confidence] } }, @{ e = { if ($_.Role -eq 'Host') { 0 } elseif ($_.Role -eq 'Implementation') { 1 } else { 2 } } }, @{ e = { $_.LastCommit }; Descending = $true })
    $shown = @($ranked | Where-Object { $IncludeLow -or $rank[$_.Confidence] -ge 2 })
    $hiddenLow = $ranked.Count - $shown.Count
    $wires = @($groupsWire.Values | Where-Object { $_ } | Select-Object -Unique)
    if ($wires.Count -gt 1) { foreach ($h in $shown) { if ($h.Kind -eq 'SOAP' -and $groupsWire.ContainsKey($h.HomeRepo + '|' + $h.Contract)) { $h.Notes = (("different services share this name - wire namespace '" + $groupsWire[$h.HomeRepo + '|' + $h.Contract] + "'. " + $h.Notes)).Trim() } } }
    $repoSet = @($shown | ForEach-Object { $_.HomeRepo } | Select-Object -Unique)
    if ($repoSet.Count -gt 1) { foreach ($h in $shown) { $h.Notes = ((("also in: " + (($repoSet | Where-Object { $_ -ne $h.HomeRepo }) -join ', ') + ' ' + $h.Notes)).Trim()) } }
    foreach ($h in ($shown | Select-Object -First $MaxPerQuery)) { $results.Add($h) }

    # ---------------- leads when nothing hosts it: who CALLS this .svc (from the saved URL facts)
    $leadText = ''
    if ($shown.Count -eq 0 -and $q.SvcLeaf) {
        $callers = @{}; $hostsSeen = @{}
        foreach ($repo in $okRepos) {
            $f = Join-Path $shardDir ((Safe-Name $repo) + '.used.csv'); if (-not (Test-Path -LiteralPath $f)) { continue }
            $lines = [System.IO.File]::ReadAllLines($f); if ($lines.Length -le 1) { continue }
            $hit = @($lines | Where-Object { $_.IndexOf($q.SvcLeaf, [StringComparison]::OrdinalIgnoreCase) -ge 0 })
            if ($hit.Count -eq 0) { continue }
            foreach ($u in ($hit | ConvertFrom-Csv -Header ($lines[0] -replace '"', '' -split ','))) { if ($u.Value -match [regex]::Escape($q.SvcLeaf)) { $callers[$repo] = 1; if ($u.Host) { $hostsSeen[$u.Host] = 1 } } }
        }
        if ($callers.Count -gt 0) {
            $leadText = ("no repo in the inventory hosts it, but {0} repo(s) call it: {1}; host name(s) used: {2}" -f $callers.Count, ((@($callers.Keys | Sort-Object | Select-Object -First 8)) -join ', '), $(if ($hostsSeen.Count) { (@($hostsSeen.Keys) -join ', ') } else { '(relative addresses)' }))
            $results.Add((New-Hit $q 'SOAP' '(not found)' '' $q.SvcLeaf '' '' 'Low' 'references only' '' '' $leadText))
        }
    }
    if ($shown.Count -eq 0 -and -not $q.SvcLeaf -and ($callers.Count -gt 0 -or $mentions.Count -gt 0)) {
        $parts = @()
        if ($mentions.Count -gt 0) { $parts += ("{0} repo(s) mention the address / host in configuration (possible host deployment config): {1}" -f $mentions.Count, ((@($mentions.Keys | Sort-Object | Select-Object -First 6 | ForEach-Object { "$_ ($($mentions[$_]))" })) -join ', ')) }
        $leadText = ('no repo in the inventory declares a service for it' + $(if ($parts.Count) { '; ' + ($parts -join '; ') } else { '' }))
        $results.Add((New-Hit $q 'SOAP' '(not found)' '' '' ($wantContracts -join ', ') $q.Raw 'Low' 'references only' '' '' $leadText))
    }
    $calledBy = ''; if ($callers.Count -gt 0) { $calledBy = ("called by {0} repo(s): {1}{2}" -f $callers.Count, ((@($callers.Keys | Sort-Object | Select-Object -First 6)) -join ', '), $(if ($wantContracts.Count) { "  (contract: " + (($wantContracts | Select-Object -First 3) -join ', ') + ')' } else { '' })) }
    $suggest = ''
    if ($shown.Count -eq 0 -and -not $leadText) {
        $key = if ($q.SvcLeaf) { Get-Base $q.SvcLeaf } else { $q.Key }
        if ($key -and $key.Length -ge 3) {
            $names = @($knownNames | Where-Object { $n = (Get-Base $_).TrimStart('i'); $n.Length -ge 3 -and ($n.Contains($key.TrimStart('i')) -or $key.TrimStart('i').Contains($n)) } | Select-Object -First 6)
            $ctl = @($restByController.Keys | Where-Object { $_.Contains($key) -or ($_.Length -ge 3 -and $key.Contains($_)) } | Select-Object -First 3 | ForEach-Object { $ctlNames[$_] })
            $all = @($names + $ctl | Select-Object -Unique); if ($all.Count -gt 0) { $suggest = 'did you mean: ' + ($all -join ', ') + '?' }
        }
    }
    $summary.Add([pscustomobject]@{ Query = $raw; Kind = $q.Kind; Shown = $shown.Count; Hidden = $hiddenLow; Top = ($shown | Select-Object -First 3); Lead = $leadText; Suggest = $suggest; CalledBy = $calledBy })
}

# ---- output: one file, short summary
$cols = 'Query', 'Kind', 'HomeRepo', 'Confidence', 'Role', 'Service', 'Contract', 'Endpoint', 'MatchedBy', 'File', 'Line', 'RepoUrl', 'LastCommit', 'Notes'
$outFile = Join-Path $OutputPath 'endpoint-home.csv'
if ($results.Count -gt 0) { $results.ToArray() | Select-Object $cols | Export-Csv -LiteralPath $outFile -NoTypeInformation -Encoding UTF8 }
else { Set-Content -LiteralPath $outFile -Value (($cols | ForEach-Object { '"' + $_ + '"' }) -join ',') -Encoding UTF8 }

Write-Host ''
foreach ($s in $summary) {
    if ($s.Shown -gt 0) {
        $t = $s.Top[0]
        $more = if ($s.Shown -gt 1) { "  (+{0} more)" -f ($s.Shown - 1) } else { '' }
        Write-Host ("  {0}" -f $s.Query) -ForegroundColor White
        foreach ($h in $s.Top) { Write-Host ("      -> {0,-32} {1,-6} {2,-14} {3}  [{4}]" -f $h.HomeRepo, $h.Confidence, $h.Role, $h.Endpoint, $h.MatchedBy) -ForegroundColor Green }
        if ($s.CalledBy) { Write-Host ("      {0}" -f $s.CalledBy) -ForegroundColor DarkGray }
        if ($s.Shown -gt 3) { Write-Host ("      ... {0} more in the file" -f ($s.Shown - 3)) -ForegroundColor DarkGray }
        if ($s.Hidden -gt 0) { Write-Host ("      ({0} low-confidence match(es) hidden - use -IncludeLow)" -f $s.Hidden) -ForegroundColor DarkGray }
    } else {
        Write-Host ("  {0}" -f $s.Query) -ForegroundColor White
        if ($s.Lead) { Write-Host ("      -> NOT HOSTED in the inventory: {0}" -f $s.Lead) -ForegroundColor Yellow }
        elseif ($s.Suggest) { Write-Host ("      -> not found; {0}" -f $s.Suggest) -ForegroundColor Yellow }
        else { Write-Host ("      -> not found{0}{1}" -f $(if ($s.Hidden -gt 0) { " (only $($s.Hidden) low-confidence match(es): use -IncludeLow)" } else { '' }), $(if ($notDone -gt 0) { "; $notDone repo(s) are not harvested yet, the host may be one of them" } else { '' })) -ForegroundColor Yellow }
    }
}
Write-Host ''
Write-Host "  wrote $outFile"
