<#
.SYNOPSIS
    Build a persistent inventory of the URLs / endpoints every repo USES and EXPOSES - in batches, so thousands of
    repos never have to be on disk at the same time.

.DESCRIPTION
    Loop (repeat until every repo is done):
        1. take the next N repos that are not in the inventory yet            (-BatchSize, default 500)
        2. clone them: shallow, single branch, and ONLY source/config files   (partial + sparse clone - binaries,
           node_modules, bin/obj, images, packages are never downloaded)
        3. harvest facts from them
        4. save the facts (one small file set per repo) + a line in repos.csv
        5. DELETE the clones                                                 (free space for the next batch)
    It is resumable and timeout-safe:
      * every repo that already has an entry in repos.csv is SKIPPED (not cloned again); -RetryFailed retries the failed ones
      * the other way round too: a repo marked 'ok' whose saved results are missing (deleted / never written) is detected and harvested again
      * clones left on disk by an interrupted run are CHECKED (git status) and REUSED instead of being cloned again; incomplete ones are replaced
      * every file is written to a temporary file and renamed into place, so stopping the script at any moment cannot leave a half-written CSV
      * progress is saved after every small group of repos (-CheckpointSize, default 25), so an interruption loses at most that group
      * repos whose results were saved but never reached repos.csv (crash / killed session) are re-adopted from the saved files, not re-cloned
      * every git operation has a timeout (-CloneTimeoutMinutes) and stalled transfers abort by themselves
      * -MaxRunMinutes stops cleanly before a session / job time limit; run the same command again to continue
    Re-running a repo (-Refresh) replaces its facts (no duplicates).
    A running log (build-inventory.log in the inventory folder) records every run: parameters, every repo's outcome, failures with the reason,
    skipped forks/archived repos, warnings and the final summary.
    Only one run at a time can use an inventory folder (a lock file prevents two runs from overwriting each other's progress).

    The inventory folder contains
        repos.csv              one row per repo: url, branch, last commit, scan time, status, counts
        urls-used.csv          what each repo calls:   Repo | Url | Kind | Host | UrlPath | Verb | Detail | File | Line | ...
                               (XML + JSON config URLs, WCF <client> endpoints, *.svc references, URLs/routes in code and
                                frontend files, ChannelFactory<T>/ClientBase<T> types)
        endpoints-exposed.csv  what each repo exposes: SOAP contracts/operations/.svc and REST controller routes
        shards\                the per-repo source files these are built from (used by Find-HomeRepoUsage.ps1)
    The two big CSVs are re-generated at the end of every run.

    Works with GitHub (github.com / GitHub Enterprise Server) and Azure DevOps (dev.azure.com, *.visualstudio.com, Azure DevOps Server).
    -FromFolder harvests repos that are ALREADY cloned (no cloning, no deleting), in batches.

.EXAMPLE
    $env:GITHUB_TOKEN = '<token>'
    .\Build-UrlInventory.ps1 -BaseUrl https://github.com/contoso -InventoryPath D:\url-inventory -WorkPath D:\work
.EXAMPLE
    # Azure DevOps project, 300 repos per batch, keep at least 10 GB free
    $env:AZURE_DEVOPS_PAT = '<pat>'
    .\Build-UrlInventory.ps1 -BaseUrl https://dev.azure.com/contoso/MyProject -InventoryPath D:\url-inventory -BatchSize 300 -MinFreeGB 10
.EXAMPLE
    .\Build-UrlInventory.ps1 -FromFolder C:\Proj -InventoryPath D:\url-inventory -BatchSize 100
#>
[CmdletBinding()]
param(
    [string]$BaseUrl,
    [string]$FromFolder,
    [Parameter(Mandatory)][string]$InventoryPath,
    [string]$WorkPath = (Join-Path ([System.IO.Path]::GetTempPath()) 'url-inventory-work'),
    # Repos per progress batch (only groups the output and -MaxBatchGB); what is on disk at any time is one -CheckpointSize group
    [int]$BatchSize = 500,
    # Clone + harvest + save + delete this many repos at a time. Smaller = less disk and less lost work after an interruption.
    [int]$CheckpointSize = 25,
    # Stop cleanly after this many minutes (0 = no limit). Re-run the same command to continue.
    [double]$MaxRunMinutes = 0,
    # Give up on a single clone/checkout after this many minutes
    [double]$CloneTimeoutMinutes = 15,
    # Repos that already have a 'failed' entry in repos.csv are skipped by default; this retries them
    [switch]$RetryFailed,
    # Do not rebuild urls-used.csv / endpoints-exposed.csv at the end (do it later with -MergeOnly)
    [switch]$NoMerge,
    # Also start a new batch when the API-reported (full, un-sparsed) size of the batch exceeds this many GB. 0 = off.
    [double]$MaxBatchGB = 0,
    # Never let the work drive drop below this; cloning stops early (the rest waits for the next batch)
    [double]$MinFreeGB = 5,
    [string]$Token,
    [ValidateSet('Auto', 'GitHub', 'AzureDevOps')][string]$Provider = 'Auto',
    [string]$ApiBase,
    [string[]]$Include = @('*'),
    [string[]]$Exclude = @(),
    [switch]$IncludeArchived,
    [switch]$IncludeForks,
    # Repos cloned at the same time
    [int]$Parallel = 4,
    # Repos whose URLs are collected at the same time (CPU bound: default = number of cores, at most 6)
    [int]$HarvestParallel = [Math]::Min([Environment]::ProcessorCount, 6),
    # Stop collecting URLs of ONE repo after this many minutes (what was found is kept; the repo is noted in the log and repos.csv)
    [double]$MaxRepoMinutes = 10,
    # Repos larger than this (size reported by the server, MB) are cloned LAST, each on its own with a longer time limit, so that
    # one huge repo never holds up a group of normal ones. (A huge repo whose clone is already on disk is not deferred.)
    [double]$LargeRepoMB = 2048,
    [double]$LargeCloneTimeoutMinutes = 90,
    # Only process the first N pending repos (testing)
    [int]$Limit = 0,
    # Re-harvest repos already in the inventory (all, or those scanned more than N days ago)
    [switch]$Refresh,
    # Re-harvest only the repos that were scanned by an OLDER scanner AND show frontend code (ts / tsx / js / jsx / vue / html ...) in their saved results.
    # The frontend scanner was improved (short API paths, baseURL, verbs on later lines ...); everything else in the inventory is left alone.
    [switch]$RefreshFrontend,
    # What a PROVIDER repo says about itself is only found by the improved scanner: SOAP services that are not a *.svc file (WSDL, ASMX, WCF mounted by
    # ServiceRoute / base address, Java JAX-WS / CXF / Spring-WS / Axis) and where a service is mounted / reachable (UsePathBase, PathBase settings,
    # ingress paths, route / ingress host names). -RefreshProviders re-harvests the repos scanned BEFORE the update that are likely to host something
    # (a WCF or REST service, or a WSDL / ASMX / web.xml / pom.xml / helm / route / ingress file in their saved results); -RefreshProvidersAll
    # re-harvests every older repo (the saved results cannot tell which Java repos have @WebService classes). Repos harvested since the update, and
    # everything else in the inventory, are left alone.   (older names: -RefreshSoap, -RefreshSoapAll)
    [Alias('RefreshSoap')][switch]$RefreshProviders,
    [Alias('RefreshSoapAll')][switch]$RefreshProvidersAll,
    [int]$RefreshOlderThanDays = 0,
    [switch]$KeepClones,
    [switch]$IncludeTests,
    # Only rebuild urls-used.csv / endpoints-exposed.csv from the shards
    [switch]$MergeOnly,
    # While waiting for clones, print a 'still working' line this often (seconds)
    [int]$HeartbeatSeconds = 30,
    # Running log (default: <InventoryPath>\build-inventory.log, appended to on every run; the token is never written)
    [string]$LogPath
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'EndpointScan.Common.ps1')
. (Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1')
function Split-List($s) { if ([string]::IsNullOrWhiteSpace($s)) { return @() }; return @($s -split ';' | Where-Object { $_ }) }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }

New-Item -ItemType Directory -Force -Path $InventoryPath | Out-Null
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$logFile = if ($LogPath) { $LogPath } else { Join-Path $InventoryPath 'build-inventory.log' }
# prints to the console AND appends a time-stamped line to the log file (-FileOnly: log only)
function Log {
    param([Parameter(Position = 0)][string]$Message = '', [string]$ForegroundColor = '', [switch]$FileOnly)
    if ($Message.Trim() -ne '') { try { Add-Content -LiteralPath $logFile -Value ('{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $Message.TrimStart("`n")) -Encoding UTF8 -ErrorAction Stop } catch { } }
    if ($FileOnly) { return }
    if ($ForegroundColor) { Microsoft.PowerShell.Utility\Write-Host $Message -ForegroundColor $ForegroundColor } else { Microsoft.PowerShell.Utility\Write-Host $Message }
}
$shardDir = Join-Path $InventoryPath 'shards'
New-Item -ItemType Directory -Force -Path $shardDir | Out-Null
$reposFile = Join-Path $InventoryPath 'repos.csv'
$excludeDir = @('bin', 'obj', 'node_modules', '.git', '.vs', '.idea', 'packages', 'TestResults', 'artifacts', 'dist', '.next', '.angular', 'coverage', 'bower_components')

# ------------------------------------------------------------------------------------------------
# repos.csv  (state of the inventory)
# ------------------------------------------------------------------------------------------------
$repoCols = 'Repo', 'RepoUrl', 'Provider', 'DefaultBranch', 'LastCommit', 'Sha', 'ScannedAt', 'Batch', 'Status', 'Message', 'ExposedRows', 'UsedRows', 'ApiSizeMB'
$state = @{}
if (Test-Path -LiteralPath $reposFile) {
    $damagedRows = 0
    try {
        foreach ($r in (Import-Csv -LiteralPath $reposFile -ErrorAction Stop)) {
            # a row must have a repo name and a known status; anything else is a damaged line (cut off by a full disk, hand-edited, ...) and is ignored:
            # the repo is then re-adopted from its saved results, or done again
            if ($r.Repo -and $r.Status -in 'ok', 'empty', 'failed', 'skipped', 'missing') { $state[$r.Repo] = $r } else { $damagedRows++ }
        }
        if ($damagedRows -gt 0) { Log ("WARNING: {0} damaged line(s) in repos.csv were ignored; the affected repos are re-adopted from their saved results or done again." -f $damagedRows) -ForegroundColor Yellow }
    }
    catch {
        # cannot happen through this script (files are replaced atomically) but a manual edit / disk problem could: keep the broken file, rebuild from the saved results
        $bad = Join-Path $InventoryPath ('repos.corrupt-{0:yyyyMMdd-HHmmss}.csv' -f (Get-Date)); $state = @{}
        try { Move-Item -LiteralPath $reposFile -Destination $bad -Force } catch { }
        Log ("WARNING: repos.csv could not be read ({0}). It was kept as {1}; the list is rebuilt from the saved per-repo results." -f $_.Exception.Message, $bad) -ForegroundColor Yellow
    }
}
function Save-State {
    $tmp = "$reposFile.tmp"
    @($state.Values | Sort-Object Repo | Select-Object $repoCols) | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
    $tries = if ($script:stateWarned) { 1 } else { 5 }      # once we know the file is locked, do not wait again at every checkpoint
    for ($i = 1; $i -le $tries; $i++) {
        try { Move-Item -LiteralPath $tmp -Destination $reposFile -Force -ErrorAction Stop; $script:stateWarned = $false; return } catch { if ($i -lt $tries) { Start-Sleep -Seconds 2 } }
    }
    # repos.csv is locked (typically: it is open in Excel). Never abort the run for that - nothing is lost, the per-repo files are the source of truth.
    $alt = Join-Path $InventoryPath 'repos.unsaved.csv'
    try { Move-Item -LiteralPath $tmp -Destination $alt -Force -ErrorAction Stop } catch { }
    if (-not $script:stateWarned) { Log ("WARNING: repos.csv is locked by another program (is it open in Excel?). Progress is NOT lost: it is kept in the per-repo files and in repos.unsaved.csv, and repos.csv is updated as soon as you close it. Please close the file.") -ForegroundColor Yellow; $script:stateWarned = $true }
}

# ------------------------------------------------------------------------------------------------
# merged, human-friendly CSVs (rebuilt from the shards)
# ------------------------------------------------------------------------------------------------
function ConvertTo-CsvLine($vals) {
    ($vals | ForEach-Object { $s = [string]$_; '"' + $s.Replace('"', '""') + '"' }) -join ','
}
function Merge-Inventory {
    Log 'Rebuilding urls-used.csv and endpoints-exposed.csv ...'
    $meta = @{}; foreach ($r in $state.Values) { $meta[$r.Repo] = $r }
    $enc = New-Object System.Text.UTF8Encoding($true)
    $defs = @(
        @{ Suffix = 'used'; File = 'urls-used.csv'
           Cols = 'Repo', 'Url', 'Kind', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count', 'RepoLastCommit', 'ScannedAt'
           Map = { param($r, $m) @($r.Repo, $r.Value, $r.Kind, $r.Host, $r.UrlPath, $r.Verb, $r.Detail, $r.File, $r.Line, $r.Count, $m.LastCommit, $m.ScannedAt) } },
        @{ Suffix = 'exposed'; File = 'endpoints-exposed.csv'
           Cols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'Operation', 'HttpVerb', 'Route', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'ImplClasses', 'Flags', 'ProjectNames', 'RepoLastCommit'
           Map = { param($r, $m) @($r.Repo, $r.Kind, $r.Role, $r.Service, $r.Contract, $r.Operation, $r.HttpVerb, $r.Route, $r.SoapAction, $r.WireNamespace, $r.SvcFile, $r.File, $r.Line, $r.ImplClasses, $r.Flags, $r.ProjectNames, $m.LastCommit) } }
    )
    foreach ($d in $defs) {
        $tmp = Join-Path $InventoryPath ($d.File + '.tmp')
        $w = New-Object System.IO.StreamWriter($tmp, $false, $enc)
        try {
            $w.WriteLine((ConvertTo-CsvLine $d.Cols))
            $rows = 0
            foreach ($f in (Get-ChildItem -LiteralPath $shardDir -Filter ('*.' + $d.Suffix + '.csv') | Sort-Object Name)) {
                foreach ($r in (Import-Csv -LiteralPath $f.FullName)) {
                    $m = $meta[$r.Repo]; if (-not $m) { $m = [pscustomobject]@{ LastCommit = ''; ScannedAt = '' } }
                    $w.WriteLine((ConvertTo-CsvLine (& $d.Map $r $m))); $rows++
                }
            }
        } finally { $w.Dispose() }
        try { Move-Item -LiteralPath $tmp -Destination (Join-Path $InventoryPath $d.File) -Force -ErrorAction Stop }
        catch { $alt = Join-Path $InventoryPath ($d.File -replace '\.csv$', '.new.csv'); Move-Item -LiteralPath $tmp -Destination $alt -Force; Log "WARNING: $($d.File) is locked (open in Excel?) - the new version was written to $alt" -ForegroundColor Yellow }
        Log ("  {0}: {1:N0} rows" -f $d.File, $rows)
    }
}
# Repos whose shards were completely written but that never made it into repos.csv (crash / killed session): adopt them instead of cloning again
function Restore-FromShards {
    $known = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($r in $state.Values) { [void]$known.Add((Safe-Name $r.Repo)) }
    $n = 0
    foreach ($f in (Get-ChildItem -LiteralPath $shardDir -Filter '*.used.csv' -ErrorAction SilentlyContinue)) {
        $base = $f.Name -replace '\.used\.csv$', ''
        if ($known.Contains($base)) { continue }
        if (-not (Test-Path -LiteralPath (Join-Path $shardDir "$base.exposed.csv")) -or -not (Test-Path -LiteralPath (Join-Path $shardDir "$base.refs.csv"))) { continue }   # incomplete set
        $name = $base
        foreach ($suffix in 'used', 'exposed', 'refs') {
            $first = @(Get-Content -LiteralPath (Join-Path $shardDir "$base.$suffix.csv") -TotalCount 2 | ConvertFrom-Csv)
            if ($first.Count -gt 0 -and $first[0].Repo) { $name = $first[0].Repo; break }
        }
        if ($state.ContainsKey($name)) { continue }
        $state[$name] = [pscustomobject]@{ Repo = $name; RepoUrl = ''; Provider = ''; DefaultBranch = ''; LastCommit = ''; Sha = ''; ScannedAt = $f.LastWriteTime.ToString('s'); Batch = 0; Status = 'ok'; Message = 'recovered from saved files'; ExposedRows = ''; UsedRows = ''; ApiSizeMB = '' }
        $n++
    }
    if ($n -gt 0) { Log ("Recovered {0} repo(s) whose results were saved but not recorded in repos.csv (an earlier run was interrupted) - they will not be cloned again." -f $n) -ForegroundColor Yellow; Save-State }
}
# The other direction of Restore-FromShards: a repo that has an 'ok' row but whose saved results are gone (deleted, never written) must be harvested again
function Mark-MissingResults {
    $have = @{}
    foreach ($f in [System.IO.Directory]::GetFiles($shardDir, '*.csv')) {
        $n = [System.IO.Path]::GetFileName($f)
        if ($n -match '^(.+)\.(exposed|used|refs)\.csv$') { $b = $Matches[1]; $have[$b] = 1 + [int]$have[$b] }
    }
    $n = 0; $names = @()
    foreach ($r in $state.Values) {
        if ($r.Status -eq 'ok' -and $have[(Safe-Name $r.Repo)] -ne 3) { $r.Status = 'missing'; $r.Message = 'saved results not found - will be harvested again'; $n++; $names += $r.Repo }
    }
    if ($n -gt 0) { Log ("{0} repo(s) have an entry in repos.csv but their saved results are missing - they will be harvested again: {1}" -f $n, (($names | Select-Object -First 10) -join ', ') + $(if ($n -gt 10) { ', ...' } else { '' })) -ForegroundColor Yellow; Save-State }
}

# only one run at a time may use an inventory folder (two runs would overwrite each other's repos.csv)
$lockFile = Join-Path $InventoryPath '.build.lock'
$lockHeld = $false
if (-not $MergeOnly) {
    if (Test-Path -LiteralPath $lockFile) {
        $info = (Get-Content -LiteralPath $lockFile -ErrorAction SilentlyContinue | Select-Object -First 1)
        $lockPid = 0; if ($info -match '^(\d+)') { $lockPid = [int]$Matches[1] }
        $alive = $lockPid -gt 0 -and $lockPid -ne $PID -and [bool](Get-Process -Id $lockPid -ErrorAction SilentlyContinue)
        if ($alive) { throw "Another Build-UrlInventory run is already using $InventoryPath ($info). Two runs would overwrite each other's progress - wait for it or stop it first. (If you are sure it is dead, delete $lockFile.)" }
    }
    Set-Content -LiteralPath $lockFile -Value ("{0} started {1:s}" -f $PID, (Get-Date))
    $lockHeld = $true
}
try {
# temporary files of a write that was interrupted (never part of the data)
foreach ($d in @($InventoryPath, $shardDir)) { Get-ChildItem -LiteralPath $d -Filter '*.tmp' -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue }
$scannerMarker = Join-Path $InventoryPath 'frontend-scanner.marker'
if (-not (Test-Path -LiteralPath $scannerMarker)) { Set-Content -LiteralPath $scannerMarker -Value (Get-Date).ToString('s') -Encoding ASCII }
$scannerSince = [datetime]::Parse((Get-Content -LiteralPath $scannerMarker -TotalCount 1), [Globalization.CultureInfo]::InvariantCulture)
$soapMarker = Join-Path $InventoryPath 'provider-scanner.marker'
if (-not (Test-Path -LiteralPath $soapMarker)) { Set-Content -LiteralPath $soapMarker -Value (Get-Date).ToString('s') -Encoding ASCII }
$soapSince = [datetime]::Parse((Get-Content -LiteralPath $soapMarker -TotalCount 1), [Globalization.CultureInfo]::InvariantCulture)
$bound = (($PSBoundParameters.Keys | Where-Object { $_ -ne 'Token' } | Sort-Object | ForEach-Object { "$_=$($PSBoundParameters[$_])" }) -join ' ')
Log ("Log file: $logFile   (Ctrl+C is safe: run the same command again to continue)")
Log -FileOnly ("==== run started | PowerShell $($PSVersionTable.PSVersion) | $(& git --version 2>$null) | $bound")

Restore-FromShards
Mark-MissingResults

if ($MergeOnly) { Merge-Inventory; return }

if (-not $BaseUrl -and -not $FromFolder) { throw 'Pass -BaseUrl (org / project URL) or -FromFolder (folder with existing clones).' }

# ------------------------------------------------------------------------------------------------
# helpers: API, repo listing
# ------------------------------------------------------------------------------------------------
function Invoke-Api([string]$url, [hashtable]$headers) {
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        try { return (Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 300 -ErrorAction Stop) }
        catch {
            $code = 0; if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
            if ($code -eq 404) { return $null }
            if ($code -in 401, 203) { throw "The server rejected the credentials (HTTP $code) - check the token / PAT and its permissions." }
            if ($code -in 403, 429 -and $attempt -lt 4) { Log '  API rate limit, waiting 60 s ...'; Start-Sleep -Seconds 60; continue }
            if (($code -ge 500 -or $code -eq 0) -and $attempt -lt 4) { Start-Sleep -Seconds (2 * $attempt); continue }
            throw
        }
    }
}

function Get-RemoteRepos {
    $u = [uri]$BaseUrl
    $prov = $Provider
    if ($prov -eq 'Auto') { $prov = if ($u.Host -match '(?i)^dev\.azure\.com$|\.visualstudio\.com$|/_git/|/tfs/') { 'AzureDevOps' } elseif ($u.AbsolutePath -match '(?i)/_apis|/tfs/') { 'AzureDevOps' } else { 'GitHub' } }
    $list = New-Object System.Collections.Generic.List[object]
    if ($prov -eq 'GitHub') {
        $script:Token = if ($Token) { $Token } else { $env:GITHUB_TOKEN }
        $org = ($u.AbsolutePath.Trim('/') -split '/')[0]
        if (-not $org) { throw "Could not read an org/user from '$BaseUrl'." }
        $api = if ($ApiBase) { $ApiBase.TrimEnd('/') } elseif ($u.Host -eq 'github.com') { 'https://api.github.com' } else { "$($u.Scheme)://$($u.Host)/api/v3" }
        $h = @{ Accept = 'application/vnd.github+json'; 'User-Agent' = 'endpoint-scan'; 'X-GitHub-Api-Version' = '2022-11-28' }
        if ($script:Token) { $h.Authorization = "Bearer $($script:Token)" }
        $kind = if ($null -eq (Invoke-Api "$api/orgs/$org" $h)) { 'users' } else { 'orgs' }
        $page = 1
        while ($true) {
            $items = @(Invoke-Api "$api/$kind/$org/repos?per_page=100&page=$page&type=all" $h)
            if ($items.Count -eq 0 -or $null -eq $items[0]) { break }
            foreach ($x in $items) { $list.Add([pscustomobject]@{ Name = $x.name; CloneUrl = $x.clone_url; Branch = $x.default_branch; SizeMB = [math]::Round($x.size / 1024.0, 1); Archived = [bool]$x.archived; Fork = [bool]$x.fork; Private = [bool]$x.private }) }
            if ($items.Count -lt 100) { break }; $page++
        }
        $script:ProviderUsed = 'GitHub'; $script:CloneHost = "$($u.Scheme)://$($u.Host)/"
        $script:AuthHeaderValue = if ($script:Token) { 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("x-access-token:$($script:Token)")) } else { '' }
    } else {
        $script:Token = if ($Token) { $Token } elseif ($env:AZURE_DEVOPS_PAT) { $env:AZURE_DEVOPS_PAT } else { $env:SYSTEM_ACCESSTOKEN }
        if (-not $script:Token) { throw 'Azure DevOps needs a PAT (Code: Read): pass -Token or set $env:AZURE_DEVOPS_PAT.' }
        $basic = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(":$($script:Token)"))
        $h = @{ Authorization = $basic; Accept = 'application/json'; 'User-Agent' = 'endpoint-scan' }
        $root = if ($ApiBase) { $ApiBase.TrimEnd('/') } else { $BaseUrl.TrimEnd('/') -replace '/_git/.*$', '' }
        $r = Invoke-Api "$root/_apis/git/repositories?api-version=7.1" $h
        if ($null -eq $r -or $null -eq $r.value) { throw "No repositories returned from $root/_apis/git/repositories - check the URL (org or org/project) and the PAT." }
        $names = @{}; foreach ($x in $r.value) { $names[$x.name] = 1 + [int]$names[$x.name] }
        foreach ($x in $r.value) {
            $nm = if ($names[$x.name] -gt 1 -and $x.project) { "$($x.project.name).$($x.name)" } else { $x.name }
            $br = ("$($x.defaultBranch)" -replace '^refs/heads/', '')
            $list.Add([pscustomobject]@{ Name = $nm; CloneUrl = $x.remoteUrl; Branch = $br; SizeMB = [math]::Round(([double]$x.size) / 1MB, 1); Archived = [bool]$x.isDisabled; Fork = [bool]$x.isFork; Private = $true })
        }
        $script:ProviderUsed = 'AzureDevOps'; $script:CloneHost = "$(([uri]$list[0].CloneUrl).Scheme)://$(([uri]$list[0].CloneUrl).Host)/"
        $script:AuthHeaderValue = $basic
    }
    return $list
}

# ------------------------------------------------------------------------------------------------
# clone worker: shallow + partial + sparse (deny-list of junk directories and binary extensions)
# ------------------------------------------------------------------------------------------------
$junkDirs = 'bin', 'obj', 'node_modules', 'packages', '.vs', 'dist', 'bower_components', 'TestResults', '.next', '.angular', 'coverage'
$junkExt = 'dll exe pdb zip 7z rar gz tgz tar nupkg msi iso bin dat db sqlite mdf ldf bak png jpg jpeg gif bmp ico tif tiff pdf doc docx xls xlsx ppt pptx mp3 mp4 avi mov wav woff woff2 ttf eot otf jar war class so dylib lib o snk pfx cer p12 psd ai dwg sav pkg apk ipa swf flv mkv wmv ogg webm webp heic svgz'.Split(' ')
$sparseLines = @('/*') + @($junkDirs | ForEach-Object { "!$_/" }) + @($junkExt | ForEach-Object { "!*.$_" })

$workerText = @'
param($r, $dest, $patterns, $timeoutSec)
$res = [ordered]@{ Name = $r.Name; Status = ''; Detail = ''; Seconds = 0; Reused = $false }
$sw = [System.Diagnostics.Stopwatch]::StartNew()
function Last-Line($o) {
    $l = @($o -split "`n" | ForEach-Object { "$_".Trim() } | Where-Object { $_ })
    $f = @($l | Where-Object { $_ -match '^(fatal|error|remote):' })
    if ($f.Count) { return ($f[0] -replace '^(fatal|error|remote):\s*', '') }
    if ($l.Count) { return $l[-1] } else { return '' }
}
# runs git with a hard time limit; the whole process tree is killed on timeout
function Invoke-GitTimed([string[]]$gitArgs, [int]$limit) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'git'
    $psi.Arguments = (($gitArgs | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join ' ')
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEndAsync(); $se = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($limit * 1000)) {
        try { if ($PSVersionTable.PSVersion.Major -ge 7) { $p.Kill($true) } else { & taskkill /PID $p.Id /T /F 2>&1 | Out-Null } } catch { }
        return @{ Code = -1; Out = "timed out after $limit s"; TimedOut = $true }
    }
    $p.WaitForExit()
    return @{ Code = $p.ExitCode; Out = ($so.Result + "`n" + $se.Result); StdOut = $so.Result; TimedOut = $false }
}
# Is the folder a COMPLETE clone of this repo left by an earlier (interrupted) run?  A killed clone / checkout always shows up as a
# missing HEAD, an index.lock, a different remote, or files that git status reports as deleted.
function Test-ReusableClone([string]$dest, [string]$url, [int]$limit) {
    if (-not (Test-Path -LiteralPath (Join-Path $dest '.git'))) { return $false }
    if (Test-Path -LiteralPath (Join-Path $dest '.git/index.lock')) { return $false }
    & git -C $dest rev-parse --verify --quiet HEAD 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { return $false }
    if ("$(& git -C $dest config --get remote.origin.url 2>$null)".Trim() -ne $url) { return $false }
    if ("$(& git -C $dest config --get core.sparseCheckout 2>$null)".Trim() -ne 'true') { return $false }
    $g = Invoke-GitTimed @('-C', $dest, '--no-optional-locks', 'status', '--porcelain', '--untracked-files=no') $limit
    return ($g.Code -eq 0 -and -not $g.TimedOut -and -not ("$($g.StdOut)".Trim()))
}
try {
    if (Test-ReusableClone $dest $r.CloneUrl 300) { $res.Status = 'cloned'; $res.Detail = 'reused existing clone'; $res.Reused = $true; $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
    $ok = $false; $out = ''; $timedOut = 0
    foreach ($filter in @('--filter=blob:none', '')) {
        $a = @('-c', 'core.longpaths=true', '-c', 'credential.helper=', 'clone', '--quiet', '--no-tags', '--no-checkout', '--depth', '1')   # credential.helper= : no Git Credential Manager window can block the clone (auth is the header we pass)
        if ($filter) { $a += $filter }
        $a += @($r.CloneUrl, $dest)
        for ($try = 1; $try -le 3; $try++) {
            $g = Invoke-GitTimed $a $timeoutSec
            if ($g.Code -eq 0) { $ok = $true; break }
            $out = $g.Out
            if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
            if ($g.TimedOut) { $timedOut++; if ($timedOut -ge 2) { break } }           # one retry after a timeout, then give up on this repo
            elseif ($out -match 'not found|Authentication failed|could not read Username|Repository not found|403|does not appear') { break }
            Start-Sleep -Seconds (3 * $try)
        }
        if ($ok -or $timedOut -ge 2) { break }
    }
    if (-not $ok) { $res.Status = 'failed'; $res.Detail = $(if ($timedOut -ge 2) { "git did not finish within the time limit ($([math]::Round($timeoutSec / 60.0, 1)) min), tried twice" } else { Last-Line $out }); $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    & git -C $dest rev-parse --verify --quiet HEAD 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { $res.Status = 'empty'; $res.Detail = 'repository has no commits'; $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    & git -C $dest config core.sparseCheckout true 2>&1 | Out-Null
    $info = Join-Path $dest '.git/info'
    New-Item -ItemType Directory -Force -Path $info | Out-Null
    [System.IO.File]::WriteAllLines((Join-Path $info 'sparse-checkout'), [string[]]$patterns)
    $g = Invoke-GitTimed @('-C', $dest, 'checkout', '--quiet') $timeoutSec
    if ($g.Code -ne 0) { $res.Status = 'failed'; $res.Detail = 'checkout: ' + $(if ($g.TimedOut) { $g.Out } else { Last-Line $g.Out }); $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    $res.Status = 'cloned'
} catch { $res.Status = 'failed'; $res.Detail = $_.Exception.Message }
$res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1)
[pscustomobject]$res
'@

# ---- worker pool: runs on Windows PowerShell 5.1 AND PowerShell 7 (ForEach-Object -Parallel is PowerShell 7 only) ---------------------
# Workers are runspaces that take items from a shared queue, push result objects to a shared result queue and publish what they are
# working on in a shared status table (the main loop prints it as a heartbeat).
function Start-WorkerPool {
    param([object[]]$Items, [string]$WorkerText, [object[]]$WorkerArgs, [int]$Count)
    $queue = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
    foreach ($i in $Items) { $queue.Enqueue($i) }
    $results = New-Object 'System.Collections.Concurrent.ConcurrentQueue[object]'
    $status = New-Object 'System.Collections.Concurrent.ConcurrentDictionary[string,string]'
    $n = [Math]::Max(1, [Math]::Min($Count, @($Items).Count))
    $pool = [runspacefactory]::CreateRunspacePool(1, $n)
    $pool.Open()
    $workers = New-Object System.Collections.Generic.List[object]
    for ($w = 1; $w -le $n; $w++) {
        $ps = [powershell]::Create()
        $ps.RunspacePool = $pool
        [void]$ps.AddScript($WorkerText)
        [void]$ps.AddArgument($queue); [void]$ps.AddArgument($results); [void]$ps.AddArgument($status); [void]$ps.AddArgument("w$w")
        foreach ($a in $WorkerArgs) { [void]$ps.AddArgument($a) }
        $workers.Add([pscustomobject]@{ Ps = $ps; Handle = $ps.BeginInvoke() })
    }
    return [pscustomobject]@{ Pool = $pool; Workers = $workers; Queue = $queue; Results = $results; Status = $status }
}
function Receive-WorkerResults($wp) {
    $list = New-Object System.Collections.Generic.List[object]
    $x = $null
    while ($wp.Results.TryDequeue([ref]$x)) { $list.Add($x); $x = $null }
    return $list
}
function Test-WorkerPoolRunning($wp) { foreach ($w in $wp.Workers) { if (-not $w.Handle.IsCompleted) { return $true } }; return $false }
function Stop-WorkerPool($wp) {
    foreach ($w in $wp.Workers) { try { if (-not $w.Handle.IsCompleted) { $w.Ps.Stop() } } catch { }; try { $w.Ps.Dispose() } catch { } }
    try { $wp.Pool.Close(); $wp.Pool.Dispose() } catch { }
}
# what the workers are doing right now, longest-running first:  "repo (3.2 min: details)"
function Get-WorkerActivity($wp, [int]$max = 4) {
    $rows = foreach ($v in @($wp.Status.Values)) {
        $p = $v -split '\|', 3
        $mins = ([DateTime]::UtcNow - [DateTime]::new([long]$p[1], [DateTimeKind]::Utc)).TotalMinutes
        [pscustomobject]@{ Mins = $mins; Text = ('{0} ({1:N1} min{2})' -f $p[0], $mins, $(if ($p.Count -gt 2 -and $p[2]) { ': ' + $p[2] } else { '' })) }
    }
    return (@($rows | Sort-Object Mins -Descending | Select-Object -First $max | ForEach-Object { $_.Text }) -join '; ')
}

$cloneWorkerText = @'
param($queue, $results, $status, $id, $workerText, $batchRoot, $patterns, $timeoutSec)
$w = [scriptblock]::Create($workerText)
$r = $null
while ($queue.TryDequeue([ref]$r)) {
    $status[$id] = $r.Name + '|' + [DateTime]::UtcNow.Ticks + '|cloning'
    try { $o = & $w $r (Join-Path $batchRoot $r.Name) $patterns $timeoutSec }
    catch { $o = [pscustomobject]@{ Name = $r.Name; Status = 'failed'; Detail = $_.Exception.Message; Seconds = 0 } }
    [void]$results.Enqueue($o)
    $gone = $null; [void]$status.TryRemove($id, [ref]$gone)
    $r = $null
}
'@

$factsWorkerText = @'
param($queue, $results, $status, $id, $commonPath, $factsPath, $inclTests, $excludeDirs, $maxMin, $progressSec)
. $commonPath
. $factsPath
$r = $null
while ($queue.TryDequeue([ref]$r)) {
    $name = $r.Name; $ticks = [DateTime]::UtcNow.Ticks
    $status[$id] = "$name|$ticks|starting"
    $cb = { param($done, $total, $file, $facts) $status[$id] = ('{0}|{1}|{2:N0} of {3:N0} files, {4:N0} facts, now: {5}' -f $name, $ticks, $done, $total, $facts, $file) }.GetNewClosure()
    $stats = @{}; $t0 = [System.Diagnostics.Stopwatch]::StartNew(); $err = ''; $facts = @()
    try { $facts = @(Get-RepoUsedFacts -RepoDir $r.Dir -RepoName $name -ExcludeDir $excludeDirs -IncludeTests:$inclTests -Stats $stats -MaxMinutes $maxMin -OnProgress $cb -ProgressSeconds $progressSec) }
    catch { $err = $_.Exception.Message }
    [void]$results.Enqueue([pscustomobject]@{ Name = $name; Facts = $facts; Files = $stats.Files; TotalFiles = $stats.TotalFiles; Maxed = $stats.MaxedOut; TimedOut = $stats.TimedOut; Skipped = $stats.Skipped; Seconds = [math]::Round($t0.Elapsed.TotalSeconds, 1); Error = $err })
    $gone = $null; [void]$status.TryRemove($id, [ref]$gone)
    $r = $null
}
'@

function Get-FreeGB([string]$path) {
    try { $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $path).Path); return ((New-Object System.IO.DriveInfo($root)).AvailableFreeSpace / 1GB) } catch { return 1e6 }
}

function Remove-Tree([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    # cmd's rd is several times faster than Remove-Item for trees with 100,000+ files (and removes git's read-only pack files)
    if ($env:OS -eq 'Windows_NT') { & cmd.exe /c rd /s /q ('"' + $path + '"') 2>&1 | Out-Null; if (-not (Test-Path -LiteralPath $path)) { return } }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    try { Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Attributes = 'Normal' } catch { } } } catch { }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    if ($env:OS -eq 'Windows_NT') { & cmd.exe /c rd /s /q ('"' + $path + '"') 2>&1 | Out-Null }
    if (Test-Path -LiteralPath $path) { Write-Warning "Could not fully delete $path - delete it manually." }
}

# ---- background deletion: a clone folder is renamed into <WorkPath>\trash (instant) and deleted by a separate process while the run goes on.
#      Deleting a repo with 100,000+ files can take minutes on Windows; the run does not wait for it.
$script:cleaners = New-Object System.Collections.Generic.List[object]
function Start-DeleteProcess([string]$path) {
    try {
        if ($env:OS -eq 'Windows_NT') { $p = Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', 'rd', '/s', '/q', ('"' + $path + '"')) -WindowStyle Hidden -PassThru }
        else { $p = Start-Process -FilePath 'rm' -ArgumentList @('-rf', $path) -PassThru }
        $script:cleaners.Add([pscustomobject]@{ Proc = $p; Path = $path })
    } catch { Remove-Tree $path }
}
function Start-BackgroundDelete([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    New-Item -ItemType Directory -Force -Path $trashRoot | Out-Null
    $dest = Join-Path $trashRoot ([guid]::NewGuid().ToString('N'))
    try { Move-Item -LiteralPath $path -Destination $dest -ErrorAction Stop } catch { Remove-Tree $path; return }   # cannot rename (a file is open): delete it the slow way
    Start-DeleteProcess $dest
}
function Wait-BackgroundDeletes([string]$why) {
    $running = @($script:cleaners | Where-Object { -not $_.Proc.HasExited })
    if ($running.Count -gt 0) { Log ("  waiting for {0} background deletion(s) of old clones to finish {1} ..." -f $running.Count, $why); foreach ($c in $running) { $c.Proc.WaitForExit() } }
    $script:cleaners.Clear()
    if (Test-Path -LiteralPath $trashRoot) {
        foreach ($d in (Get-ChildItem -LiteralPath $trashRoot -Force -ErrorAction SilentlyContinue)) { Remove-Tree $d.FullName }   # whatever a deletion process left behind
        if (-not (Get-ChildItem -LiteralPath $trashRoot -Force -ErrorAction SilentlyContinue)) { Remove-Item -LiteralPath $trashRoot -Force -ErrorAction SilentlyContinue }
    }
}

# ------------------------------------------------------------------------------------------------
# harvest one batch folder -> shards
# ------------------------------------------------------------------------------------------------
function Write-ShardTmp($repo, [string]$suffix, $rows, [string[]]$cols) {
    $base = Join-Path $shardDir ((Safe-Name $repo) + ".$suffix.csv")
    $arr = @($rows)
    if ($arr.Count -gt 0) { $arr | Select-Object $cols | Export-Csv -LiteralPath "$base.tmp" -NoTypeInformation -Encoding UTF8 }
    else { Set-Content -LiteralPath "$base.tmp" -Value (($cols | ForEach-Object { '"' + $_ + '"' }) -join ',') -Encoding UTF8 }
    return $base
}
# the three files of a repo are renamed into place back to back (refs last: its presence means the set is complete)
function Write-ShardSet($repo, $exposedRows, $usedRows, $refRows) {
    $e = Write-ShardTmp $repo 'exposed' $exposedRows $exposedCols
    $u = Write-ShardTmp $repo 'used' $usedRows $usedCols
    $r = Write-ShardTmp $repo 'refs' $refRows @('Repo', 'RefType', 'RefName')
    foreach ($b in @($e, $u, $r)) { Move-Item -LiteralPath "$b.tmp" -Destination $b -Force }
}

$exposedCols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'ClrNamespace', 'Operation', 'HttpVerb', 'Route', 'RouteNormalized', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'Framework', 'ProjectNames', 'ImplClasses', 'Flags'
$usedCols = 'Repo', 'Kind', 'Value', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count'

function Invoke-Harvest($batchDir, $batchRepos, [int]$batchNo) {
    $n = $batchRepos.Count
    $swAll = [System.Diagnostics.Stopwatch]::StartNew()

    # ---- stage 1/3: code structure (SOAP contracts, REST controllers, hosting evidence, references) - one engine run over the group
    Log ("  harvest 1/3: SOAP contracts, REST controllers, hosting and references of {0} repos ..." -f $n)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $tmpOut = Join-Path $WorkPath ('engine-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    $ip = @{ RootPath = $batchDir; OutputPath = $tmpOut; SkipGit = $true; Chatty = $true; OnlyRepo = @($batchRepos | ForEach-Object { $_.Name }) }
    if ($IncludeTests) { $ip.IncludeTests = $true }
    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    try {
        & (Join-Path $PSScriptRoot 'Get-EndpointInventory.ps1') @ip 6>&1 3>$null | ForEach-Object {
            if ($_ -is [System.Management.Automation.InformationRecord]) {
                $t = "$($_.MessageData)"
                if ($t.StartsWith('    ')) { if ($t -match 'still scanning') { Log ('  ' + $t.TrimEnd()) } else { Log -FileOnly ('  ' + $t.TrimEnd()) } }   # per-repo detail goes to the log file, long waits to the console
            }
        }
    } finally { $ProgressPreference = $old }
    Log ("  harvest 1/3 done ({0:N1} s)" -f $sw.Elapsed.TotalSeconds)
    $inv = @(); $clu = @{}; $refs = @()
    if (Test-Path (Join-Path $tmpOut 'endpoint-inventory.csv')) { $inv = @(Import-Csv (Join-Path $tmpOut 'endpoint-inventory.csv')) }
    if (Test-Path (Join-Path $tmpOut 'endpoint-clusters.csv')) { foreach ($c in (Import-Csv (Join-Path $tmpOut 'endpoint-clusters.csv'))) { $clu[$c.ClusterId] = $c } }
    if (Test-Path (Join-Path $tmpOut 'repo-references.csv')) { $refs = @(Import-Csv (Join-Path $tmpOut 'repo-references.csv')) }
    $invBy = @{}; foreach ($r in $inv) { if (-not $invBy.ContainsKey($r.Repo)) { $invBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $invBy[$r.Repo].Add($r) }
    $refBy = @{}; foreach ($r in $refs) { if (-not $refBy.ContainsKey($r.Repo)) { $refBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $refBy[$r.Repo].Add($r) }

    # ---- stage 2/3: URLs / routes each repo uses (config, code, frontend). The slow part: runs several repos at the same time
    Log ("  harvest 2/3: collecting the URLs used by {0} repos (config files, code, frontend) ..." -f $n)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $jobRepos = @($batchRepos | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Dir = $(if ($_.Dir) { $_.Dir } else { Join-Path $batchDir $_.Name }) } })
    $factsBy = @{}
    $fc = @{ done = 0; facts = 0 }
    $repoNotes = @{}
    $handleFacts = {
        param($x)
        $fc.done++; $fc.facts += @($x.Facts).Count
        $factsBy[$x.Name] = $x.Facts
        $note = ''
        if ($x.TimedOut) { $note = ("URL scan stopped after {0} min: {1:N0} of {2:N0} files read (raise -MaxRepoMinutes to read more)" -f $MaxRepoMinutes, $x.Files, $x.TotalFiles) }
        elseif ($x.Maxed) { $note = 'very large repo: URL facts capped' }
        $repoNotes[$x.Name] = $note
        $line = ("    [{0,3}/{1}] {2}: {3:N0} of {4:N0} files read, {5:N0} URL facts  ({6} s){7}" -f $fc.done, $n, $x.Name, $x.Files, $x.TotalFiles, @($x.Facts).Count, $x.Seconds, $(if ($note) { '  *** ' + $note } else { '' }))
        if ($note) { Log $line -ForegroundColor Yellow } else { Log $line }
        if ($x.Error) { Log ("WARNING: reading the URLs of {0} failed: {1}" -f $x.Name, $x.Error) -ForegroundColor Yellow }
        Write-Progress -Activity ("Collecting URLs (batch {0})" -f $batchNo) -Status ("{0} / {1} repos - last: {2}" -f $fc.done, $n, $x.Name) -PercentComplete (100 * $fc.done / [Math]::Max(1, $n))
    }
    if ($HarvestParallel -gt 1 -and $jobRepos.Count -gt 1) {
        $commonPath = Join-Path $PSScriptRoot 'EndpointScan.Common.ps1'; $factsPath = Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1'
        $wp = Start-WorkerPool -Items $jobRepos -WorkerText $factsWorkerText -WorkerArgs @($commonPath, $factsPath, [bool]$IncludeTests, $excludeDir, $MaxRepoMinutes, $HeartbeatSeconds) -Count $HarvestParallel
        $lastBeat = Get-Date
        try {
            while ($true) {
                foreach ($x in (Receive-WorkerResults $wp)) { & $handleFacts $x }
                if (-not (Test-WorkerPoolRunning $wp)) { foreach ($x in (Receive-WorkerResults $wp)) { & $handleFacts $x }; break }
                if (((Get-Date) - $lastBeat).TotalSeconds -ge $HeartbeatSeconds) {
                    Log ("  ... still collecting URLs: {0}/{1} repos finished, {2:N1} min so far. Running: {3}" -f $fc.done, $n, $sw.Elapsed.TotalMinutes, (Get-WorkerActivity $wp))
                    $lastBeat = Get-Date
                }
                Start-Sleep -Milliseconds 300
            }
        } finally { Stop-WorkerPool $wp }
    } else {
        foreach ($jr in $jobRepos) {
            $stats = @{}; $t0 = [System.Diagnostics.Stopwatch]::StartNew(); $repoName = $jr.Name
            $cb = { param($done, $total, $file, $facts) Log ("  ... {0}: {1:N0} of {2:N0} files, {3:N0} facts so far, now: {4}" -f $repoName, $done, $total, $facts, $file) }.GetNewClosure()
            Log ("    [{0,3}/{1}] collecting URLs of {2} ..." -f ($fc.done + 1), $n, $jr.Name)
            $facts = @(Get-RepoUsedFacts -RepoDir $jr.Dir -RepoName $jr.Name -ExcludeDir $excludeDir -IncludeTests:$IncludeTests -Stats $stats -MaxMinutes $MaxRepoMinutes -OnProgress $cb -ProgressSeconds $HeartbeatSeconds)
            & $handleFacts ([pscustomobject]@{ Name = $jr.Name; Facts = $facts; Files = $stats.Files; TotalFiles = $stats.TotalFiles; Maxed = $stats.MaxedOut; TimedOut = $stats.TimedOut; Skipped = $stats.Skipped; Seconds = [math]::Round($t0.Elapsed.TotalSeconds, 1); Error = '' })
        }
    }
    Write-Progress -Activity ("Collecting URLs (batch {0})" -f $batchNo) -Completed
    Log ("  harvest 2/3 done ({0:N1} s, {1:N0} URL facts)" -f $sw.Elapsed.TotalSeconds, $fc.facts)

    # ---- stage 3/3: write the saved results (one small file set per repo)
    Log ("  harvest 3/3: saving results of {0} repos ..." -f $n)
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    foreach ($br in $batchRepos) {
        $name = $br.Name
        $exposed = New-Object System.Collections.Generic.List[object]
        $proxyAgg = @{}
        if ($invBy.ContainsKey($name)) {
            foreach ($r in $invBy[$name]) {
                $c = $clu[$r.ClusterId]
                if ($r.Role -eq 'ProxyClient') {
                    $k = $r.File + '|' + $r.ContractOrController
                    if (-not $proxyAgg.ContainsKey($k)) { $proxyAgg[$k] = @{ Row = $r; Ops = (New-Object System.Collections.Generic.List[string]) } }
                    if ($r.Operation -and $r.Operation -ne '*' -and -not $proxyAgg[$k].Ops.Contains($r.Operation)) { $proxyAgg[$k].Ops.Add($r.Operation) }
                    continue
                }
                $svc = ''; $svcFile = ''
                if ($r.Kind -eq 'WCF') { $leaf = @(Split-List $c.SvcFiles | Select-Object -First 1)[0]; if ($leaf -and $r.Role -in 'Host', 'Implementation') { $svcFile = $leaf; $svc = ($leaf -split '[\\/]')[-1] } }
                else { $svc = $r.ContractOrController }
                $exposed.Add([pscustomobject]@{
                    Repo = $name; Kind = $r.Kind; Role = $r.Role; Service = $svc; Contract = $(if ($r.Kind -eq 'WCF') { $r.ContractOrController } else { '' }); ClrNamespace = $r.ClrNamespace
                    Operation = $r.Operation; HttpVerb = $r.HttpVerb; Route = $r.Route; RouteNormalized = $r.RouteNormalized
                    SoapAction = $r.SoapAction; WireNamespace = $r.WireNamespace; SvcFile = $svcFile; File = $r.File; Line = $r.Line; Framework = $r.Framework
                    ProjectNames = $r.ProjectNames; ImplClasses = $r.ImplClasses; Flags = $r.Flags
                })
            }
        }
        $used = New-Object System.Collections.Generic.List[object]
        foreach ($pa in $proxyAgg.Values) {
            $r = $pa.Row
            $used.Add([pscustomobject][ordered]@{ Repo = $name; Kind = 'SoapProxy'; Value = $r.ContractOrController; Host = ''; UrlPath = ''; Verb = ''
                Detail = ('wire=' + $r.WireNamespace + ';ops=' + ($pa.Ops -join ',') + ';generated=' + $r.IsGenerated); File = $r.File; Line = $r.Line; Count = 1 })
        }
        if ($factsBy.ContainsKey($name)) { foreach ($f in $factsBy[$name]) { if ($f.Kind -eq 'SoapProvider') { $exposed.Add((ConvertTo-SoapExposedRow $f)) } elseif ($f.Kind -eq 'DeployHint') { $exposed.Add((ConvertTo-DeployExposedRow $f)) } else { $used.Add($f) } } }      # non-.svc SOAP services are 'exposed', not 'used'
        else { Log ("WARNING: no URL facts were returned for {0} (the worker failed) - its calls may be missing; use -Refresh for this repo to redo it" -f $name) -ForegroundColor Yellow }
        $refRows = @(); if ($refBy.ContainsKey($name)) { $refRows = $refBy[$name] | ForEach-Object { [pscustomobject]@{ Repo = $name; RefType = $_.RefType; RefName = $_.RefName } } }

        Write-ShardSet $name $exposed.ToArray() $used.ToArray() $refRows
        $br | Add-Member -NotePropertyName ExposedRows -NotePropertyValue $exposed.Count -Force
        $br | Add-Member -NotePropertyName UsedRows -NotePropertyValue $used.Count -Force
        $br | Add-Member -NotePropertyName HarvestNote -NotePropertyValue $(if ($repoNotes.ContainsKey($name)) { $repoNotes[$name] } else { '' }) -Force
    }
    Remove-Item -LiteralPath $tmpOut -Recurse -Force -ErrorAction SilentlyContinue
    Log ("  harvest 3/3 done ({0:N1} s); harvesting this group took {1:N1} s in total" -f $sw.Elapsed.TotalSeconds, $swAll.Elapsed.TotalSeconds)
}

function Get-RepoGitInfo([string]$dir) {
    $i = @{ Url = ''; Branch = ''; LastCommit = ''; Sha = '' }
    try {
        $url = (& git -C $dir config --get remote.origin.url 2>$null)
        if ($url) { $i.Url = ($url -replace '://[^/@]+@', '://') }
        $i.Branch = (& git -C $dir rev-parse --abbrev-ref HEAD 2>$null)
        $i.LastCommit = (& git -C $dir log -1 --format=%cI 2>$null)
        $i.Sha = (& git -C $dir rev-parse HEAD 2>$null)
    } catch { }
    return $i
}

# ------------------------------------------------------------------------------------------------
# main
# ------------------------------------------------------------------------------------------------
New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null
$WorkPath = (Resolve-Path -LiteralPath $WorkPath).Path
$batchRoot = Join-Path $WorkPath 'batch'
$trashRoot = Join-Path $WorkPath 'trash'
if (-not $FromFolder -and (Test-Path -LiteralPath $trashRoot)) { foreach ($d in (Get-ChildItem -LiteralPath $trashRoot -Force -ErrorAction SilentlyContinue)) { Start-DeleteProcess $d.FullName } }
# --- the list of repos to process
$all = New-Object System.Collections.Generic.List[object]
if ($FromFolder) {
    foreach ($d in (Find-Repos -Root $FromFolder -ExcludeDir $excludeDir -ExcludeRepo @())) { $all.Add([pscustomobject]@{ Name = (Split-Path $d -Leaf); CloneUrl = ''; Branch = ''; SizeMB = 0; Archived = $false; Fork = $false; Private = $false; Dir = $d }) }
    $script:ProviderUsed = 'Folder'
} else {
    Log "Listing repositories of $BaseUrl ..."
    foreach ($r in (Get-RemoteRepos)) { $all.Add($r) }
}
# repos that are in repos.csv without a URL (re-adopted from saved files after an interrupted run): fill it in from the server's list
$filled = 0
foreach ($r in $all) {
    $st = $state[$r.Name]
    if ($st -and -not $st.RepoUrl -and $r.CloneUrl) {
        $st.RepoUrl = ($r.CloneUrl -replace '://[^/@]+@', '://'); $filled++
        if (-not $st.Provider) { $st.Provider = $script:ProviderUsed }
        if (-not $st.DefaultBranch) { $st.DefaultBranch = $r.Branch }
        if (-not $st.ApiSizeMB) { $st.ApiSizeMB = $r.SizeMB }
    }
}
if ($filled -gt 0) { Log ("Filled in the missing repository URL / branch of {0} repos in repos.csv." -f $filled); Save-State }

$skippedA = 0; $skippedF = 0; $skippedI = 0
$skipNames = @{ archived = (New-Object System.Collections.Generic.List[string]); fork = (New-Object System.Collections.Generic.List[string]) }
$newSkipped = 0
function Set-SkippedRow($r, [string]$why) {
    $skipNames[$why].Add($r.Name)
    if (-not $state.ContainsKey($r.Name)) {      # recorded so repos.csv accounts for every repo of the server; 'skipped' rows are never treated as done
        $state[$r.Name] = [pscustomobject]@{ Repo = $r.Name; RepoUrl = $(if ($r.CloneUrl) { ($r.CloneUrl -replace '://[^/@]+@', '://') } else { '' }); Provider = $script:ProviderUsed; DefaultBranch = $r.Branch; LastCommit = ''; Sha = ''; ScannedAt = ''; Batch = ''; Status = 'skipped'; Message = $(if ($why -eq 'fork') { 'fork (use -IncludeForks)' } else { 'archived/disabled (use -IncludeArchived)' }); ExposedRows = ''; UsedRows = ''; ApiSizeMB = $r.SizeMB }
        $script:newSkipped++
    }
}
$wanted = New-Object System.Collections.Generic.List[object]
foreach ($r in ($all | Sort-Object Name)) {
    if (-not $IncludeArchived -and $r.Archived) { $skippedA++; Set-SkippedRow $r 'archived'; continue }
    if (-not $IncludeForks -and $r.Fork) { $skippedF++; Set-SkippedRow $r 'fork'; continue }
    $ok = $false; foreach ($p in $Include) { if ($r.Name -like $p) { $ok = $true; break } }
    foreach ($p in $Exclude) { if ($r.Name -like $p) { $ok = $false; break } }
    if (-not $ok) { $skippedI++; continue }
    $wanted.Add($r)
}
if ($skipNames.archived.Count) { Log -FileOnly ('skipped (archived/disabled): ' + ($skipNames.archived -join ', ')) }
if ($skipNames.fork.Count) { Log -FileOnly ('skipped (forks): ' + ($skipNames.fork -join ', ')) }
if ($newSkipped -gt 0) { Save-State }
$pending = New-Object System.Collections.Generic.List[object]
$nOk = 0; $nFailed = 0; $nRefresh = 0; $nMissing = 0
$frontendRedo = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
$soapRedo = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
if ($RefreshProviders -or $RefreshProvidersAll) {
    $soapUsedRx = New-Object System.Text.RegularExpressions.Regex('\.(wsdl|asmx|java|wsdd)"|(^|[\\/])(web|services)\.xml"|(^|[\\/])pom\.xml"|jaxws|"ServiceUrl"|(values|route|ingress|deploy|helm|chart|openshift)[^"]*\.ya?ml"', 'IgnoreCase')
    $checkedS = 0
    foreach ($r in $wanted) {
        $st = $state[$r.Name]
        if (-not $st -or $st.Status -ne 'ok') { continue }
        if ($st.ScannedAt) { try { if ([datetime]::Parse($st.ScannedAt, [Globalization.CultureInfo]::InvariantCulture) -ge $soapSince) { continue } } catch { } }      # already harvested by the improved scanner
        $checkedS++
        if ($RefreshProvidersAll) { [void]$soapRedo.Add($r.Name); continue }
        $ef = Join-Path $shardDir ((Safe-Name $r.Name) + '.exposed.csv'); $uf = Join-Path $shardDir ((Safe-Name $r.Name) + '.used.csv')
        $likely = $false
        if (Test-Path -LiteralPath $ef) { $et = [System.IO.File]::ReadAllText($ef); if ($et.Contains('"WCF"') -or $et.Contains('"REST"')) { $likely = $true } }            # a .NET service repo: may mount it with ServiceRoute / UsePathBase / a base address
        if (-not $likely -and (Test-Path -LiteralPath $uf)) { if ($soapUsedRx.IsMatch([System.IO.File]::ReadAllText($uf))) { $likely = $true } }      # WSDL / ASMX / web.xml / pom.xml / .svc references
        if ($likely) { [void]$soapRedo.Add($r.Name) }
    }
    if ($RefreshProvidersAll) { Log ("-RefreshProvidersAll: {0} repo(s) scanned before the provider-scanner update are done again." -f $soapRedo.Count) -ForegroundColor Cyan }
    else { Log ("-RefreshProviders: {0} repo(s) scanned before the provider-scanner update and likely to host a service are done again; {1} older repo(s) show no sign of it in their saved results (use -RefreshProvidersAll to include them)." -f $soapRedo.Count, ($checkedS - $soapRedo.Count)) -ForegroundColor Cyan }
}
if ($RefreshFrontend) {
    $feRx = New-Object System.Text.RegularExpressions.Regex('\.(ts|tsx|js|jsx|mjs|cjs|vue|svelte|html?|cshtml|razor)"|\.env[.\w]*"', 'IgnoreCase')
    $checked = 0
    foreach ($r in $wanted) {
        $st = $state[$r.Name]
        if (-not $st -or $st.Status -ne 'ok') { continue }
        if ($st.ScannedAt) { try { if ([datetime]::Parse($st.ScannedAt, [Globalization.CultureInfo]::InvariantCulture) -ge $scannerSince) { continue } } catch { } }      # already harvested by the improved scanner
        $checked++
        $uf = Join-Path $shardDir ((Safe-Name $r.Name) + '.used.csv')
        if (-not (Test-Path -LiteralPath $uf)) { continue }
        if ($feRx.IsMatch([System.IO.File]::ReadAllText($uf))) { [void]$frontendRedo.Add($r.Name) }
    }
    Log ("-RefreshFrontend: {0} repo(s) with frontend code were harvested by an older scanner and are done again; {1} older repo(s) without frontend code and everything harvested since the update are left alone." -f $frontendRedo.Count, ($checked - $frontendRedo.Count)) -ForegroundColor Cyan
}
foreach ($r in $wanted) {
    $st = $state[$r.Name]
    $done = ($null -ne $st) -and ($st.Status -notin 'skipped', 'missing')   # ANY entry in repos.csv means: do not clone it again ('skipped' = fork/archived note, 'missing' = results gone: redo) ...
    if ($st -and $st.Status -eq 'failed') { $nFailed++; if ($RetryFailed) { $done = $false } }      # ... unless it failed and -RetryFailed was given
    elseif ($st -and $st.Status -notin 'skipped', 'missing') { $nOk++ }
    if ($st -and $st.Status -eq 'missing') { $nMissing++ }
    if ($done -and $st.Status -in 'ok', 'empty' -and ($Refresh -or $frontendRedo.Contains($r.Name) -or $soapRedo.Contains($r.Name) -or ($RefreshOlderThanDays -gt 0 -and $st.ScannedAt -and ([datetime]::Parse($st.ScannedAt, [Globalization.CultureInfo]::InvariantCulture) -lt (Get-Date).AddDays(-$RefreshOlderThanDays))))) { $done = $false; $nRefresh++ }
    if (-not $done) { $pending.Add($r) }
}
$alreadyDone = $wanted.Count - $pending.Count
if ($Limit -gt 0 -and $pending.Count -gt $Limit) { $pending = New-Object System.Collections.Generic.List[object] (, @($pending | Select-Object -First $Limit)) }
$skipText = @(); if ($skippedA) { $skipText += "$skippedA archived/disabled" }; if ($skippedF) { $skipText += "$skippedF forks" }; if ($skippedI) { $skipText += "$skippedI by filter" }
Log ("{0} repos listed, {1} in scope{2}." -f $all.Count, $wanted.Count, $(if ($skipText) { " (skipped: $($skipText -join ', '))" } else { '' }))
Log ("{0} already have an entry in repos.csv ({1} ok/empty, {2} failed{3}) and are not cloned again; {4} to do." -f ($nOk + $nFailed), $nOk, $nFailed, $(if ($nFailed -and -not $RetryFailed) { ' - add -RetryFailed to retry them' } else { '' }), $pending.Count)
# ---- clones left on disk by an interrupted run: keep those of repos that are still to do (the clone worker verifies them with git status
#      and REUSES them instead of cloning again - a 4 GB repo is not downloaded twice); everything else is deleted
$existingClones = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
if (-not $FromFolder -and (Test-Path -LiteralPath $batchRoot)) {
    $pendingNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($r in $pending) { [void]$pendingNames.Add($r.Name) }
    $drop = New-Object System.Collections.Generic.List[object]
    foreach ($d in (Get-ChildItem -LiteralPath $batchRoot -Force -ErrorAction SilentlyContinue)) {
        if ($d.PSIsContainer -and $pendingNames.Contains($d.Name)) { [void]$existingClones.Add($d.Name) } else { $drop.Add($d) }
    }
    if ($existingClones.Count -gt 0) { Log ("Found {0} clone(s) of unfinished repos left by an interrupted run - they are checked and reused, not cloned again: {1}" -f $existingClones.Count, ((@($existingClones | Select-Object -First 8) -join ', ') + $(if ($existingClones.Count -gt 8) { ', ...' } else { '' }))) -ForegroundColor Green }
    if ($drop.Count -gt 0) {
        $mb = [math]::Round(((Get-ChildItem -LiteralPath $batchRoot -Recurse -File -Force -ErrorAction SilentlyContinue | Where-Object { $n = $_.FullName; @($drop | Where-Object { $n.StartsWith($_.FullName) }).Count -gt 0 } | Measure-Object Length -Sum).Sum) / 1MB, 0)
        Log ("Removing {0} leftover folder(s) ({1:N0} MB) that are not needed any more from {2} ..." -f $drop.Count, $mb, $batchRoot) -ForegroundColor Yellow
        foreach ($d in $drop) { if ($d.PSIsContainer) { Start-BackgroundDelete $d.FullName } else { Remove-Item -LiteralPath $d.FullName -Force -ErrorAction SilentlyContinue } }
    }
}
# very large repos go last and alone (unless their clone is already on disk)
$normal = New-Object System.Collections.Generic.List[object]; $large = New-Object System.Collections.Generic.List[object]
foreach ($r in $pending) {
    $isLarge = ($LargeRepoMB -gt 0) -and ([double]$r.SizeMB -gt $LargeRepoMB) -and -not $existingClones.Contains($r.Name)
    $r | Add-Member -NotePropertyName IsLarge -NotePropertyValue $isLarge -Force
    if ($isLarge) { $large.Add($r) } else { $normal.Add($r) }
}
if ($large.Count -gt 0) {
    $pending = New-Object System.Collections.Generic.List[object]
    foreach ($r in $normal) { $pending.Add($r) }
    foreach ($r in ($large | Sort-Object { [double]$_.SizeMB })) { $pending.Add($r) }
    Log ("{0} very large repo(s) (> {1:N0} MB) are processed last, each on its own with a {2:N0} min clone limit: {3}" -f $large.Count, $LargeRepoMB, $LargeCloneTimeoutMinutes, ((@($large | ForEach-Object { '{0} ({1:N0} MB)' -f $_.Name, $_.SizeMB }) -join ', ')))
}
if ($nMissing -gt 0) { Log ("{0} of the pending repos have an entry but no saved results (see above) and are included in the {1} to do." -f $nMissing, $pending.Count) }
if ($pending.Count -eq 0) { if (-not $NoMerge) { Merge-Inventory }; return }

# --- auth for git (environment only; nothing is written to .git/config or the command line)
$saved = @{}
foreach ($n in 'GCM_INTERACTIVE', 'GIT_TERMINAL_PROMPT', 'GIT_LFS_SKIP_SMUDGE', 'GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0', 'GIT_CONFIG_VALUE_0', 'GIT_HTTP_LOW_SPEED_LIMIT', 'GIT_HTTP_LOW_SPEED_TIME') { $saved[$n] = [Environment]::GetEnvironmentVariable($n) }
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_LFS_SKIP_SMUDGE = '1'; $env:GCM_INTERACTIVE = 'never'
$env:GIT_HTTP_LOW_SPEED_LIMIT = '1000'; $env:GIT_HTTP_LOW_SPEED_TIME = '120'      # a transfer slower than 1 KB/s for 2 minutes is aborted instead of hanging
if (-not $FromFolder -and $script:AuthHeaderValue) {
    $env:GIT_CONFIG_COUNT = '1'
    $env:GIT_CONFIG_KEY_0 = "http.$($script:CloneHost).extraheader"
    $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: $($script:AuthHeaderValue)"
}

$batchNo = 0; $totalDone = $alreadyDone; $totalFailed = 0; $stopped = ''
$startTime = Get-Date
$cloneTimeoutSec = [int][Math]::Max(5, $CloneTimeoutMinutes * 60)
$queue = New-Object System.Collections.Generic.Queue[object]
foreach ($r in $pending) { $queue.Enqueue($r) }
$estBatches = [math]::Ceiling($pending.Count / [double]$BatchSize)
$wave = [Math]::Max(1, [Math]::Min($CheckpointSize, $BatchSize))
New-Item -ItemType Directory -Force -Path $batchRoot | Out-Null
try {
    :outer while ($queue.Count -gt 0) {
        $batchNo++
        $batch = New-Object System.Collections.Generic.List[object]; $gb = 0.0
        while ($queue.Count -gt 0 -and $batch.Count -lt $BatchSize) {
            $next = $queue.Peek()
            if ($MaxBatchGB -gt 0 -and $batch.Count -gt 0 -and ($gb + $next.SizeMB / 1024.0) -gt $MaxBatchGB) { break }
            $batch.Add($queue.Dequeue()); $gb += $next.SizeMB / 1024.0
        }
        Log ("`n[batch {0}/~{1}] {2} repos" -f $batchNo, $estBatches, $batch.Count) -ForegroundColor Cyan

        $groups = New-Object System.Collections.Generic.List[object]
        $cur = New-Object System.Collections.Generic.List[object]
        foreach ($r in $batch) {
            if ($r.IsLarge) { if ($cur.Count -gt 0) { $groups.Add($cur.ToArray()); $cur = New-Object System.Collections.Generic.List[object] }; $groups.Add(@($r)) }
            else { $cur.Add($r); if ($cur.Count -ge $wave) { $groups.Add($cur.ToArray()); $cur = New-Object System.Collections.Generic.List[object] } }
        }
        if ($cur.Count -gt 0) { $groups.Add($cur.ToArray()) }
        for ($groupNo = 0; $groupNo -lt $groups.Count; $groupNo++) {
            if ($MaxRunMinutes -gt 0 -and ((Get-Date) - $startTime).TotalMinutes -ge $MaxRunMinutes) { $stopped = "time budget of $MaxRunMinutes min reached"; break outer }
            $chunk = @($groups[$groupNo])
            $isLargeGroup = [bool]$chunk[0].IsLarge
            $groupTimeoutSec = if ($isLargeGroup) { [int]([Math]::Max($cloneTimeoutSec, $LargeCloneTimeoutMinutes * 60)) } else { $cloneTimeoutSec }
            $now = (Get-Date).ToString('s')
            $cloned = New-Object System.Collections.Generic.List[object]
            $nBad = 0

            if ($FromFolder) {
                foreach ($r in $chunk) { $cloned.Add($r) }          # repos are scanned in place; nothing is cloned or deleted
                $workDir = $FromFolder
            } else {
                $workDir = $batchRoot
                if ((Get-FreeGB $batchRoot) -lt $MinFreeGB) { Wait-BackgroundDeletes 'to free disk space' }
                if ((Get-FreeGB $batchRoot) -lt $MinFreeGB) {
                    throw ("Free space on the work drive is below -MinFreeGB ({0} GB). Free some space, lower -MinFreeGB, lower -CheckpointSize, or point -WorkPath at a bigger drive. Nothing is lost: run the same command again to continue." -f $MinFreeGB)
                }
                if ($isLargeGroup) { Log ("  very large repo ({0:N0} MB): {1} - cloned on its own, clone limit {2:N0} min" -f $chunk[0].SizeMB, $chunk[0].Name, ($groupTimeoutSec / 60)) -ForegroundColor Cyan }
                Log ("  cloning {0} repos ({1} at a time) ..." -f $chunk.Count, $(if ($PSVersionTable.PSVersion.Major -ge 7) { $Parallel } else { 1 }))
                $ctr = @{ bad = 0; done = 0 }
                $handleResult = {
                    param($x)
                    $ctr.done++
                    $br = $chunk | Where-Object { $_.Name -eq $x.Name } | Select-Object -First 1
                    if ($x.Status -eq 'cloned') {
                        $cloned.Add($br)
                        if ($x.Reused) { Log ("  [{0,3}/{1}] reused   {2}  (complete clone from the interrupted run - not cloned again, checked in {3} s)" -f $ctr.done, $chunk.Count, $x.Name, $x.Seconds) -ForegroundColor Green }
                        else { Log ("  [{0,3}/{1}] cloned   {2}  ({3} s)" -f $ctr.done, $chunk.Count, $x.Name, $x.Seconds) }
                    }
                    else {
                        $st = if ($x.Status -eq 'empty') { 'empty' } else { 'failed' }
                        $state[$x.Name] = [pscustomobject]@{ Repo = $x.Name; RepoUrl = $br.CloneUrl; Provider = $script:ProviderUsed; DefaultBranch = $br.Branch; LastCommit = ''; Sha = ''; ScannedAt = $now; Batch = $batchNo; Status = $st; Message = $x.Detail; ExposedRows = 0; UsedRows = 0; ApiSizeMB = $br.SizeMB }
                        if ($st -eq 'failed') { $ctr.bad++; Log ("  [{0,3}/{1}] FAILED   {2}: {3}  ({4} s)" -f $ctr.done, $chunk.Count, $x.Name, $x.Detail, $x.Seconds) -ForegroundColor Yellow }
                        else { Log ("  [{0,3}/{1}] empty    {2}  ({3})" -f $ctr.done, $chunk.Count, $x.Name, $x.Detail) }
                    }
                    Write-Progress -Activity ("Cloning ({0}/{1} repos done overall)" -f $totalDone, $wanted.Count) -Status ("{0} / {1} of this group - last: {2}" -f $ctr.done, $chunk.Count, $x.Name) -PercentComplete (100 * $ctr.done / $chunk.Count)
                }
                $groupStart = Get-Date
                if ($Parallel -gt 1 -and $chunk.Count -gt 1) {
                    $wp = Start-WorkerPool -Items $chunk -WorkerText $cloneWorkerText -WorkerArgs @($workerText, $batchRoot, $sparseLines, $groupTimeoutSec) -Count $Parallel
                    $lastBeat = Get-Date
                    try {
                        while ($true) {
                            foreach ($x in (Receive-WorkerResults $wp)) { & $handleResult $x }
                            if (-not (Test-WorkerPoolRunning $wp)) { foreach ($x in (Receive-WorkerResults $wp)) { & $handleResult $x }; break }
                            if (((Get-Date) - $lastBeat).TotalSeconds -ge $HeartbeatSeconds) {
                                Log ("  ... still cloning: {0}/{1} of this group finished, {2:N1} min in this group. Running: {3}" -f $ctr.done, $chunk.Count, ((Get-Date) - $groupStart).TotalMinutes, (Get-WorkerActivity $wp))
                                $lastBeat = Get-Date
                            }
                            Start-Sleep -Milliseconds 300
                        }
                    } finally { Stop-WorkerPool $wp }
                } else {
                    $w = [scriptblock]::Create($workerText)
                    foreach ($r in $chunk) {
                        Log ("  [{0,3}/{1}] cloning  {2} ..." -f ($ctr.done + 1), $chunk.Count, $r.Name)
                        & $handleResult (& $w $r (Join-Path $batchRoot $r.Name) $sparseLines $groupTimeoutSec)
                    }
                }
                Write-Progress -Activity 'Cloning' -Completed
                $nBad = $ctr.bad; $totalFailed += $nBad
            }

            if ($cloned.Count -gt 0) {
                Invoke-Harvest $workDir $cloned $batchNo
                foreach ($br in $cloned) {
                    $dir = if ($FromFolder) { $br.Dir } else { Join-Path $workDir $br.Name }
                    $gi = Get-RepoGitInfo $dir
                    $state[$br.Name] = [pscustomobject]@{ Repo = $br.Name; RepoUrl = $(if ($br.CloneUrl) { ($br.CloneUrl -replace '://[^/@]+@', '://') } else { $gi.Url }); Provider = $script:ProviderUsed; DefaultBranch = $(if ($gi.Branch) { $gi.Branch } else { $br.Branch })
                        LastCommit = $gi.LastCommit; Sha = $gi.Sha; ScannedAt = $now; Batch = $batchNo; Status = 'ok'; Message = $br.HarvestNote; ExposedRows = $br.ExposedRows; UsedRows = $br.UsedRows; ApiSizeMB = $br.SizeMB }
                    Log -FileOnly ("ok       {0}  (calls {1}, exposes {2})" -f $br.Name, $br.UsedRows, $br.ExposedRows)
                }
            }
            Save-State                                                    # checkpoint: everything in this group is now recorded
            if (-not $FromFolder -and -not $KeepClones) { foreach ($r in $chunk) { Start-BackgroundDelete (Join-Path $batchRoot $r.Name) } }      # instant: the deletion runs in a separate process
            $totalDone += $chunk.Count
            $mins = ((Get-Date) - $startTime).TotalMinutes
$doneNow = $totalDone - $alreadyDone
            $eta = ''
            if ($doneNow -gt 0 -and $totalDone -lt $wanted.Count) { $left = ($wanted.Count - $totalDone) * ($mins / $doneNow); $eta = if ($left -ge 90) { "  ~{0:N1} h left at this pace" -f ($left / 60) } else { "  ~{0:N0} min left at this pace" -f $left } }
            Log ("  saved: {0}/{1} repos done (+{2}{3}), {4:N0} min elapsed{5}" -f $totalDone, $wanted.Count, $chunk.Count, $(if ($nBad) { ", $nBad failed" } else { '' }), $mins, $eta)
        }
    }
} finally {
    foreach ($n in $saved.Keys) { [Environment]::SetEnvironmentVariable($n, $saved[$n]) }
    Save-State
    if (-not $FromFolder -and -not $KeepClones) { Start-BackgroundDelete $batchRoot }
    Wait-BackgroundDeletes 'before the run ends'
}
$left = @($wanted | Where-Object { -not $state.ContainsKey($_.Name) }).Count
$ok = @($state.Values | Where-Object { $_.Status -in 'ok', 'empty' }).Count
$bad = @($state.Values | Where-Object Status -eq 'failed').Count
if ($stopped -or $left -gt 0) {
    Log ''
    Log ("Stopped: {0}. {1} repos done, {2} still to do. Run the SAME command again to continue; repos already in repos.csv are not cloned again." -f $(if ($stopped) { $stopped } else { 'not all repos were processed' }), $ok, $left) -ForegroundColor Yellow
    Log "(urls-used.csv / endpoints-exposed.csv are rebuilt when everything is done, or at any time with -MergeOnly; Find-HomeRepoUsage.ps1 reads the saved files directly.)"
} else {
    if (-not $NoMerge) { Merge-Inventory }
    Log ''
    Log ("Inventory: {0} repos OK, {1} failed{2}  ->  {3}" -f $ok, $bad, $(if ($bad) { ' (add -RetryFailed to retry them)' } else { '' }), $InventoryPath) -ForegroundColor $(if ($bad) { 'Yellow' } else { 'Green' })
}
} catch {
    Log ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    throw
} finally {
    if ($lockHeld) { Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue }
    Log -FileOnly '==== run ended'
}
