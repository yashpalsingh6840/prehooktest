<#
.SYNOPSIS
    Build a persistent inventory of the URLs / endpoints every repo USES and EXPOSES - in batches, so thousands of
    repos never have to be on disk at the same time.

.DESCRIPTION
    Loop (repeat until every repo is done):
        1. take the next N repos that are not in the inventory yet            (-BatchSize, default 500)
        2. clone them: shallow, single branch, and ONLY source/config files   (partial + sparse clone - binaries,
           node_modules, bin/obj, images, packages are never downloaded)
        3. harvest facts from them
        4. save the facts (one small file set per repo) + a line in repos.csv
        5. DELETE the clones                                                 (free space for the next batch)
    It is resumable and timeout-safe:
      * every repo that already has an entry in repos.csv is SKIPPED (not cloned again); -RetryFailed retries the failed ones
      * the other way round too: a repo marked 'ok' whose saved results are missing (deleted / never written) is detected and harvested again
      * progress is saved after every small group of repos (-CheckpointSize, default 25), so an interruption loses at most that group
      * repos whose results were saved but never reached repos.csv (crash / killed session) are re-adopted from the saved files, not re-cloned
      * every git operation has a timeout (-CloneTimeoutMinutes) and stalled transfers abort by themselves
      * -MaxRunMinutes stops cleanly before a session / job time limit; run the same command again to continue
    Re-running a repo (-Refresh) replaces its facts (no duplicates).
    A running log (build-inventory.log in the inventory folder) records every run: parameters, every repo's outcome, failures with the reason,
    skipped forks/archived repos, warnings and the final summary.
    Only one run at a time can use an inventory folder (a lock file prevents two runs from overwriting each other's progress).

    The inventory folder contains
        repos.csv              one row per repo: url, branch, last commit, scan time, status, counts
        urls-used.csv          what each repo calls:   Repo | Url | Kind | Host | UrlPath | Verb | Detail | File | Line | ...
                               (XML + JSON config URLs, WCF <client> endpoints, *.svc references, URLs/routes in code and
                                frontend files, ChannelFactory<T>/ClientBase<T> types)
        endpoints-exposed.csv  what each repo exposes: SOAP contracts/operations/.svc and REST controller routes
        shards\                the per-repo source files these are built from (used by Find-HomeRepoUsage.ps1)
    The two big CSVs are re-generated at the end of every run.

    Works with GitHub (github.com / GitHub Enterprise Server) and Azure DevOps (dev.azure.com, *.visualstudio.com, Azure DevOps Server).
    -FromFolder harvests repos that are ALREADY cloned (no cloning, no deleting), in batches.

.EXAMPLE
    $env:GITHUB_TOKEN = '<token>'
    .\Build-UrlInventory.ps1 -BaseUrl https://github.com/contoso -InventoryPath D:\url-inventory -WorkPath D:\work
.EXAMPLE
    # Azure DevOps project, 300 repos per batch, keep at least 10 GB free
    $env:AZURE_DEVOPS_PAT = '<pat>'
    .\Build-UrlInventory.ps1 -BaseUrl https://dev.azure.com/contoso/MyProject -InventoryPath D:\url-inventory -BatchSize 300 -MinFreeGB 10
.EXAMPLE
    .\Build-UrlInventory.ps1 -FromFolder C:\Proj -InventoryPath D:\url-inventory -BatchSize 100
#>
[CmdletBinding()]
param(
    [string]$BaseUrl,
    [string]$FromFolder,
    [Parameter(Mandatory)][string]$InventoryPath,
    [string]$WorkPath = (Join-Path ([System.IO.Path]::GetTempPath()) 'url-inventory-work'),
    # Repos per progress batch (only groups the output and -MaxBatchGB); what is on disk at any time is one -CheckpointSize group
    [int]$BatchSize = 500,
    # Clone + harvest + save + delete this many repos at a time. Smaller = less disk and less lost work after an interruption.
    [int]$CheckpointSize = 25,
    # Stop cleanly after this many minutes (0 = no limit). Re-run the same command to continue.
    [double]$MaxRunMinutes = 0,
    # Give up on a single clone/checkout after this many minutes
    [double]$CloneTimeoutMinutes = 15,
    # Repos that already have a 'failed' entry in repos.csv are skipped by default; this retries them
    [switch]$RetryFailed,
    # Do not rebuild urls-used.csv / endpoints-exposed.csv at the end (do it later with -MergeOnly)
    [switch]$NoMerge,
    # Also start a new batch when the API-reported (full, un-sparsed) size of the batch exceeds this many GB. 0 = off.
    [double]$MaxBatchGB = 0,
    # Never let the work drive drop below this; cloning stops early (the rest waits for the next batch)
    [double]$MinFreeGB = 5,
    [string]$Token,
    [ValidateSet('Auto', 'GitHub', 'AzureDevOps')][string]$Provider = 'Auto',
    [string]$ApiBase,
    [string[]]$Include = @('*'),
    [string[]]$Exclude = @(),
    [switch]$IncludeArchived,
    [switch]$IncludeForks,
    [int]$Parallel = 4,
    # Only process the first N pending repos (testing)
    [int]$Limit = 0,
    # Re-harvest repos already in the inventory (all, or those scanned more than N days ago)
    [switch]$Refresh,
    [int]$RefreshOlderThanDays = 0,
    [switch]$KeepClones,
    [switch]$IncludeTests,
    # Only rebuild urls-used.csv / endpoints-exposed.csv from the shards
    [switch]$MergeOnly,
    # While waiting for clones, print a 'still working' line this often (seconds)
    [int]$HeartbeatSeconds = 30,
    # Running log (default: <InventoryPath>\build-inventory.log, appended to on every run; the token is never written)
    [string]$LogPath
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'EndpointScan.Common.ps1')
. (Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1')
function Split-List($s) { if ([string]::IsNullOrWhiteSpace($s)) { return @() }; return @($s -split ';' | Where-Object { $_ }) }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }

New-Item -ItemType Directory -Force -Path $InventoryPath | Out-Null
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$logFile = if ($LogPath) { $LogPath } else { Join-Path $InventoryPath 'build-inventory.log' }
# prints to the console AND appends a time-stamped line to the log file (-FileOnly: log only)
function Log {
    param([Parameter(Position = 0)][string]$Message = '', [string]$ForegroundColor = '', [switch]$FileOnly)
    if ($Message.Trim() -ne '') { try { Add-Content -LiteralPath $logFile -Value ('{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $Message.TrimStart("`n")) -Encoding UTF8 -ErrorAction Stop } catch { } }
    if ($FileOnly) { return }
    if ($ForegroundColor) { Microsoft.PowerShell.Utility\Write-Host $Message -ForegroundColor $ForegroundColor } else { Microsoft.PowerShell.Utility\Write-Host $Message }
}
$shardDir = Join-Path $InventoryPath 'shards'
New-Item -ItemType Directory -Force -Path $shardDir | Out-Null
$reposFile = Join-Path $InventoryPath 'repos.csv'
$excludeDir = @('bin', 'obj', 'node_modules', '.git', '.vs', '.idea', 'packages', 'TestResults', 'artifacts', 'dist', '.next', '.angular', 'coverage', 'bower_components')

# ------------------------------------------------------------------------------------------------
# repos.csv  (state of the inventory)
# ------------------------------------------------------------------------------------------------
$repoCols = 'Repo', 'RepoUrl', 'Provider', 'DefaultBranch', 'LastCommit', 'Sha', 'ScannedAt', 'Batch', 'Status', 'Message', 'ExposedRows', 'UsedRows', 'ApiSizeMB'
$state = @{}
if (Test-Path -LiteralPath $reposFile) { foreach ($r in (Import-Csv -LiteralPath $reposFile)) { $state[$r.Repo] = $r } }
function Save-State {
    $tmp = "$reposFile.tmp"
    @($state.Values | Sort-Object Repo | Select-Object $repoCols) | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
    $tries = if ($script:stateWarned) { 1 } else { 5 }      # once we know the file is locked, do not wait again at every checkpoint
    for ($i = 1; $i -le $tries; $i++) {
        try { Move-Item -LiteralPath $tmp -Destination $reposFile -Force -ErrorAction Stop; $script:stateWarned = $false; return } catch { if ($i -lt $tries) { Start-Sleep -Seconds 2 } }
    }
    # repos.csv is locked (typically: it is open in Excel). Never abort the run for that - nothing is lost, the per-repo files are the source of truth.
    $alt = Join-Path $InventoryPath 'repos.unsaved.csv'
    try { Move-Item -LiteralPath $tmp -Destination $alt -Force -ErrorAction Stop } catch { }
    if (-not $script:stateWarned) { Log ("WARNING: repos.csv is locked by another program (is it open in Excel?). Progress is NOT lost: it is kept in the per-repo files and in repos.unsaved.csv, and repos.csv is updated as soon as you close it. Please close the file.") -ForegroundColor Yellow; $script:stateWarned = $true }
}

# ------------------------------------------------------------------------------------------------
# merged, human-friendly CSVs (rebuilt from the shards)
# ------------------------------------------------------------------------------------------------
function ConvertTo-CsvLine($vals) {
    ($vals | ForEach-Object { $s = [string]$_; '"' + $s.Replace('"', '""') + '"' }) -join ','
}
function Merge-Inventory {
    Log 'Rebuilding urls-used.csv and endpoints-exposed.csv ...'
    $meta = @{}; foreach ($r in $state.Values) { $meta[$r.Repo] = $r }
    $enc = New-Object System.Text.UTF8Encoding($true)
    $defs = @(
        @{ Suffix = 'used'; File = 'urls-used.csv'
           Cols = 'Repo', 'Url', 'Kind', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count', 'RepoLastCommit', 'ScannedAt'
           Map = { param($r, $m) @($r.Repo, $r.Value, $r.Kind, $r.Host, $r.UrlPath, $r.Verb, $r.Detail, $r.File, $r.Line, $r.Count, $m.LastCommit, $m.ScannedAt) } },
        @{ Suffix = 'exposed'; File = 'endpoints-exposed.csv'
           Cols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'Operation', 'HttpVerb', 'Route', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'ImplClasses', 'Flags', 'ProjectNames', 'RepoLastCommit'
           Map = { param($r, $m) @($r.Repo, $r.Kind, $r.Role, $r.Service, $r.Contract, $r.Operation, $r.HttpVerb, $r.Route, $r.SoapAction, $r.WireNamespace, $r.SvcFile, $r.File, $r.Line, $r.ImplClasses, $r.Flags, $r.ProjectNames, $m.LastCommit) } }
    )
    foreach ($d in $defs) {
        $tmp = Join-Path $InventoryPath ($d.File + '.tmp')
        $w = New-Object System.IO.StreamWriter($tmp, $false, $enc)
        try {
            $w.WriteLine((ConvertTo-CsvLine $d.Cols))
            $rows = 0
            foreach ($f in (Get-ChildItem -LiteralPath $shardDir -Filter ('*.' + $d.Suffix + '.csv') | Sort-Object Name)) {
                foreach ($r in (Import-Csv -LiteralPath $f.FullName)) {
                    $m = $meta[$r.Repo]; if (-not $m) { $m = [pscustomobject]@{ LastCommit = ''; ScannedAt = '' } }
                    $w.WriteLine((ConvertTo-CsvLine (& $d.Map $r $m))); $rows++
                }
            }
        } finally { $w.Dispose() }
        try { Move-Item -LiteralPath $tmp -Destination (Join-Path $InventoryPath $d.File) -Force -ErrorAction Stop }
        catch { $alt = Join-Path $InventoryPath ($d.File -replace '\.csv$', '.new.csv'); Move-Item -LiteralPath $tmp -Destination $alt -Force; Log "WARNING: $($d.File) is locked (open in Excel?) - the new version was written to $alt" -ForegroundColor Yellow }
        Log ("  {0}: {1:N0} rows" -f $d.File, $rows)
    }
}
# Repos whose shards were completely written but that never made it into repos.csv (crash / killed session): adopt them instead of cloning again
function Restore-FromShards {
    $known = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($r in $state.Values) { [void]$known.Add((Safe-Name $r.Repo)) }
    $n = 0
    foreach ($f in (Get-ChildItem -LiteralPath $shardDir -Filter '*.used.csv' -ErrorAction SilentlyContinue)) {
        $base = $f.Name -replace '\.used\.csv$', ''
        if ($known.Contains($base)) { continue }
        if (-not (Test-Path -LiteralPath (Join-Path $shardDir "$base.exposed.csv")) -or -not (Test-Path -LiteralPath (Join-Path $shardDir "$base.refs.csv"))) { continue }   # incomplete set
        $name = $base
        foreach ($suffix in 'used', 'exposed', 'refs') {
            $first = @(Get-Content -LiteralPath (Join-Path $shardDir "$base.$suffix.csv") -TotalCount 2 | ConvertFrom-Csv)
            if ($first.Count -gt 0 -and $first[0].Repo) { $name = $first[0].Repo; break }
        }
        if ($state.ContainsKey($name)) { continue }
        $state[$name] = [pscustomobject]@{ Repo = $name; RepoUrl = ''; Provider = ''; DefaultBranch = ''; LastCommit = ''; Sha = ''; ScannedAt = $f.LastWriteTime.ToString('s'); Batch = 0; Status = 'ok'; Message = 'recovered from saved files'; ExposedRows = ''; UsedRows = ''; ApiSizeMB = '' }
        $n++
    }
    if ($n -gt 0) { Log ("Recovered {0} repo(s) whose results were saved but not recorded in repos.csv (an earlier run was interrupted) - they will not be cloned again." -f $n) -ForegroundColor Yellow; Save-State }
}
# The other direction of Restore-FromShards: a repo that has an 'ok' row but whose saved results are gone (deleted, never written) must be harvested again
function Mark-MissingResults {
    $have = @{}
    foreach ($f in [System.IO.Directory]::GetFiles($shardDir, '*.csv')) {
        $n = [System.IO.Path]::GetFileName($f)
        if ($n -match '^(.+)\.(exposed|used|refs)\.csv$') { $b = $Matches[1]; $have[$b] = 1 + [int]$have[$b] }
    }
    $n = 0; $names = @()
    foreach ($r in $state.Values) {
        if ($r.Status -eq 'ok' -and $have[(Safe-Name $r.Repo)] -ne 3) { $r.Status = 'missing'; $r.Message = 'saved results not found - will be harvested again'; $n++; $names += $r.Repo }
    }
    if ($n -gt 0) { Log ("{0} repo(s) have an entry in repos.csv but their saved results are missing - they will be harvested again: {1}" -f $n, (($names | Select-Object -First 10) -join ', ') + $(if ($n -gt 10) { ', ...' } else { '' })) -ForegroundColor Yellow; Save-State }
}

# only one run at a time may use an inventory folder (two runs would overwrite each other's repos.csv)
$lockFile = Join-Path $InventoryPath '.build.lock'
$lockHeld = $false
if (-not $MergeOnly) {
    if (Test-Path -LiteralPath $lockFile) {
        $info = (Get-Content -LiteralPath $lockFile -ErrorAction SilentlyContinue | Select-Object -First 1)
        $lockPid = 0; if ($info -match '^(\d+)') { $lockPid = [int]$Matches[1] }
        $alive = $lockPid -gt 0 -and $lockPid -ne $PID -and [bool](Get-Process -Id $lockPid -ErrorAction SilentlyContinue)
        if ($alive) { throw "Another Build-UrlInventory run is already using $InventoryPath ($info). Two runs would overwrite each other's progress - wait for it or stop it first. (If you are sure it is dead, delete $lockFile.)" }
    }
    Set-Content -LiteralPath $lockFile -Value ("{0} started {1:s}" -f $PID, (Get-Date))
    $lockHeld = $true
}
try {
$bound = (($PSBoundParameters.Keys | Where-Object { $_ -ne 'Token' } | Sort-Object | ForEach-Object { "$_=$($PSBoundParameters[$_])" }) -join ' ')
Log ("Log file: $logFile   (Ctrl+C is safe: run the same command again to continue)")
Log -FileOnly ("==== run started | PowerShell $($PSVersionTable.PSVersion) | $(& git --version 2>$null) | $bound")

Restore-FromShards
Mark-MissingResults

if ($MergeOnly) { Merge-Inventory; return }

if (-not $BaseUrl -and -not $FromFolder) { throw 'Pass -BaseUrl (org / project URL) or -FromFolder (folder with existing clones).' }

# ------------------------------------------------------------------------------------------------
# helpers: API, repo listing
# ------------------------------------------------------------------------------------------------
function Invoke-Api([string]$url, [hashtable]$headers) {
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        try { return (Invoke-RestMethod -Uri $url -Headers $headers -Method Get -TimeoutSec 300 -ErrorAction Stop) }
        catch {
            $code = 0; if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
            if ($code -eq 404) { return $null }
            if ($code -in 401, 203) { throw "The server rejected the credentials (HTTP $code) - check the token / PAT and its permissions." }
            if ($code -in 403, 429 -and $attempt -lt 4) { Log '  API rate limit, waiting 60 s ...'; Start-Sleep -Seconds 60; continue }
            if (($code -ge 500 -or $code -eq 0) -and $attempt -lt 4) { Start-Sleep -Seconds (2 * $attempt); continue }
            throw
        }
    }
}

function Get-RemoteRepos {
    $u = [uri]$BaseUrl
    $prov = $Provider
    if ($prov -eq 'Auto') { $prov = if ($u.Host -match '(?i)^dev\.azure\.com$|\.visualstudio\.com$|/_git/|/tfs/') { 'AzureDevOps' } elseif ($u.AbsolutePath -match '(?i)/_apis|/tfs/') { 'AzureDevOps' } else { 'GitHub' } }
    $list = New-Object System.Collections.Generic.List[object]
    if ($prov -eq 'GitHub') {
        $script:Token = if ($Token) { $Token } else { $env:GITHUB_TOKEN }
        $org = ($u.AbsolutePath.Trim('/') -split '/')[0]
        if (-not $org) { throw "Could not read an org/user from '$BaseUrl'." }
        $api = if ($ApiBase) { $ApiBase.TrimEnd('/') } elseif ($u.Host -eq 'github.com') { 'https://api.github.com' } else { "$($u.Scheme)://$($u.Host)/api/v3" }
        $h = @{ Accept = 'application/vnd.github+json'; 'User-Agent' = 'endpoint-scan'; 'X-GitHub-Api-Version' = '2022-11-28' }
        if ($script:Token) { $h.Authorization = "Bearer $($script:Token)" }
        $kind = if ($null -eq (Invoke-Api "$api/orgs/$org" $h)) { 'users' } else { 'orgs' }
        $page = 1
        while ($true) {
            $items = @(Invoke-Api "$api/$kind/$org/repos?per_page=100&page=$page&type=all" $h)
            if ($items.Count -eq 0 -or $null -eq $items[0]) { break }
            foreach ($x in $items) { $list.Add([pscustomobject]@{ Name = $x.name; CloneUrl = $x.clone_url; Branch = $x.default_branch; SizeMB = [math]::Round($x.size / 1024.0, 1); Archived = [bool]$x.archived; Fork = [bool]$x.fork; Private = [bool]$x.private }) }
            if ($items.Count -lt 100) { break }; $page++
        }
        $script:ProviderUsed = 'GitHub'; $script:CloneHost = "$($u.Scheme)://$($u.Host)/"
        $script:AuthHeaderValue = if ($script:Token) { 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("x-access-token:$($script:Token)")) } else { '' }
    } else {
        $script:Token = if ($Token) { $Token } elseif ($env:AZURE_DEVOPS_PAT) { $env:AZURE_DEVOPS_PAT } else { $env:SYSTEM_ACCESSTOKEN }
        if (-not $script:Token) { throw 'Azure DevOps needs a PAT (Code: Read): pass -Token or set $env:AZURE_DEVOPS_PAT.' }
        $basic = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(":$($script:Token)"))
        $h = @{ Authorization = $basic; Accept = 'application/json'; 'User-Agent' = 'endpoint-scan' }
        $root = if ($ApiBase) { $ApiBase.TrimEnd('/') } else { $BaseUrl.TrimEnd('/') -replace '/_git/.*$', '' }
        $r = Invoke-Api "$root/_apis/git/repositories?api-version=7.1" $h
        if ($null -eq $r -or $null -eq $r.value) { throw "No repositories returned from $root/_apis/git/repositories - check the URL (org or org/project) and the PAT." }
        $names = @{}; foreach ($x in $r.value) { $names[$x.name] = 1 + [int]$names[$x.name] }
        foreach ($x in $r.value) {
            $nm = if ($names[$x.name] -gt 1 -and $x.project) { "$($x.project.name).$($x.name)" } else { $x.name }
            $br = ("$($x.defaultBranch)" -replace '^refs/heads/', '')
            $list.Add([pscustomobject]@{ Name = $nm; CloneUrl = $x.remoteUrl; Branch = $br; SizeMB = [math]::Round(([double]$x.size) / 1MB, 1); Archived = [bool]$x.isDisabled; Fork = [bool]$x.isFork; Private = $true })
        }
        $script:ProviderUsed = 'AzureDevOps'; $script:CloneHost = "$(([uri]$list[0].CloneUrl).Scheme)://$(([uri]$list[0].CloneUrl).Host)/"
        $script:AuthHeaderValue = $basic
    }
    return $list
}

# ------------------------------------------------------------------------------------------------
# clone worker: shallow + partial + sparse (deny-list of junk directories and binary extensions)
# ------------------------------------------------------------------------------------------------
$junkDirs = 'bin', 'obj', 'node_modules', 'packages', '.vs', 'dist', 'bower_components', 'TestResults', '.next', '.angular', 'coverage'
$junkExt = 'dll exe pdb zip 7z rar gz tgz tar nupkg msi iso bin dat db sqlite mdf ldf bak png jpg jpeg gif bmp ico tif tiff pdf doc docx xls xlsx ppt pptx mp3 mp4 avi mov wav woff woff2 ttf eot otf jar war class so dylib lib o snk pfx cer p12 psd ai dwg sav pkg apk ipa swf flv mkv wmv ogg webm webp heic svgz'.Split(' ')
$sparseLines = @('/*') + @($junkDirs | ForEach-Object { "!$_/" }) + @($junkExt | ForEach-Object { "!*.$_" })

$workerText = @'
param($r, $dest, $patterns, $timeoutSec)
$res = [ordered]@{ Name = $r.Name; Status = ''; Detail = ''; Seconds = 0 }
$sw = [System.Diagnostics.Stopwatch]::StartNew()
function Last-Line($o) {
    $l = @($o -split "`n" | ForEach-Object { "$_".Trim() } | Where-Object { $_ })
    $f = @($l | Where-Object { $_ -match '^(fatal|error|remote):' })
    if ($f.Count) { return ($f[0] -replace '^(fatal|error|remote):\s*', '') }
    if ($l.Count) { return $l[-1] } else { return '' }
}
# runs git with a hard time limit; the whole process tree is killed on timeout
function Invoke-GitTimed([string[]]$gitArgs, [int]$limit) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'git'
    $psi.Arguments = (($gitArgs | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join ' ')
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $so = $p.StandardOutput.ReadToEndAsync(); $se = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($limit * 1000)) {
        try { if ($PSVersionTable.PSVersion.Major -ge 7) { $p.Kill($true) } else { & taskkill /PID $p.Id /T /F 2>&1 | Out-Null } } catch { }
        return @{ Code = -1; Out = "timed out after $limit s"; TimedOut = $true }
    }
    $p.WaitForExit()
    return @{ Code = $p.ExitCode; Out = ($so.Result + "`n" + $se.Result); TimedOut = $false }
}
try {
    if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
    $ok = $false; $out = ''; $timedOut = 0
    foreach ($filter in @('--filter=blob:none', '')) {
        $a = @('-c', 'core.longpaths=true', '-c', 'credential.helper=', 'clone', '--quiet', '--no-tags', '--no-checkout', '--depth', '1')   # credential.helper= : no Git Credential Manager window can block the clone (auth is the header we pass)
        if ($filter) { $a += $filter }
        $a += @($r.CloneUrl, $dest)
        for ($try = 1; $try -le 3; $try++) {
            $g = Invoke-GitTimed $a $timeoutSec
            if ($g.Code -eq 0) { $ok = $true; break }
            $out = $g.Out
            if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
            if ($g.TimedOut) { $timedOut++; if ($timedOut -ge 2) { break } }           # one retry after a timeout, then give up on this repo
            elseif ($out -match 'not found|Authentication failed|could not read Username|Repository not found|403|does not appear') { break }
            Start-Sleep -Seconds (3 * $try)
        }
        if ($ok -or $timedOut -ge 2) { break }
    }
    if (-not $ok) { $res.Status = 'failed'; $res.Detail = $(if ($timedOut -ge 2) { "git did not finish within the time limit ($([math]::Round($timeoutSec / 60.0, 1)) min), tried twice" } else { Last-Line $out }); $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    & git -C $dest rev-parse --verify --quiet HEAD 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { $res.Status = 'empty'; $res.Detail = 'repository has no commits'; $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    & git -C $dest config core.sparseCheckout true 2>&1 | Out-Null
    $info = Join-Path $dest '.git/info'
    New-Item -ItemType Directory -Force -Path $info | Out-Null
    [System.IO.File]::WriteAllLines((Join-Path $info 'sparse-checkout'), [string[]]$patterns)
    $g = Invoke-GitTimed @('-C', $dest, 'checkout', '--quiet') $timeoutSec
    if ($g.Code -ne 0) { $res.Status = 'failed'; $res.Detail = 'checkout: ' + $(if ($g.TimedOut) { $g.Out } else { Last-Line $g.Out }); $res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1); return [pscustomobject]$res }
    $res.Status = 'cloned'
} catch { $res.Status = 'failed'; $res.Detail = $_.Exception.Message }
$res.Seconds = [math]::Round($sw.Elapsed.TotalSeconds, 1)
[pscustomobject]$res
'@

function Get-FreeGB([string]$path) {
    try { $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $path).Path); return ((New-Object System.IO.DriveInfo($root)).AvailableFreeSpace / 1GB) } catch { return 1e6 }
}

function Remove-Tree([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    try { Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Attributes = 'Normal' } catch { } } } catch { }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    if ($env:OS -eq 'Windows_NT') { & cmd.exe /c rd /s /q ('"' + $path + '"') 2>&1 | Out-Null }
    if (Test-Path -LiteralPath $path) { Write-Warning "Could not fully delete $path - delete it manually." }
}

# ------------------------------------------------------------------------------------------------
# harvest one batch folder -> shards
# ------------------------------------------------------------------------------------------------
function Write-Shard($repo, [string]$suffix, $rows, [string[]]$cols) {
    $base = Join-Path $shardDir ((Safe-Name $repo) + ".$suffix.csv")
    $arr = @($rows)
    if ($arr.Count -gt 0) { $arr | Select-Object $cols | Export-Csv -LiteralPath "$base.tmp" -NoTypeInformation -Encoding UTF8 }
    else { Set-Content -LiteralPath "$base.tmp" -Value (($cols | ForEach-Object { '"' + $_ + '"' }) -join ',') -Encoding UTF8 }
    Move-Item -LiteralPath "$base.tmp" -Destination $base -Force
}

$exposedCols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'ClrNamespace', 'Operation', 'HttpVerb', 'Route', 'RouteNormalized', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'Framework', 'ProjectNames', 'ImplClasses', 'Flags'
$usedCols = 'Repo', 'Kind', 'Value', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count'

function Invoke-Harvest($batchDir, $batchRepos, [int]$batchNo) {
    $tmpOut = Join-Path $WorkPath ('engine-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    $ip = @{ RootPath = $batchDir; OutputPath = $tmpOut; SkipGit = $true; OnlyRepo = @($batchRepos | ForEach-Object { $_.Name }) }
    if ($IncludeTests) { $ip.IncludeTests = $true }
    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    try { & (Join-Path $PSScriptRoot 'Get-EndpointInventory.ps1') @ip 6>$null 3>$null | Out-Null } finally { $ProgressPreference = $old }
    $inv = @(); $clu = @{}; $refs = @()
    if (Test-Path (Join-Path $tmpOut 'endpoint-inventory.csv')) { $inv = @(Import-Csv (Join-Path $tmpOut 'endpoint-inventory.csv')) }
    if (Test-Path (Join-Path $tmpOut 'endpoint-clusters.csv')) { foreach ($c in (Import-Csv (Join-Path $tmpOut 'endpoint-clusters.csv'))) { $clu[$c.ClusterId] = $c } }
    if (Test-Path (Join-Path $tmpOut 'repo-references.csv')) { $refs = @(Import-Csv (Join-Path $tmpOut 'repo-references.csv')) }
    $invBy = @{}; foreach ($r in $inv) { if (-not $invBy.ContainsKey($r.Repo)) { $invBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $invBy[$r.Repo].Add($r) }
    $refBy = @{}; foreach ($r in $refs) { if (-not $refBy.ContainsKey($r.Repo)) { $refBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $refBy[$r.Repo].Add($r) }

    foreach ($br in $batchRepos) {
        $name = $br.Name
        $dir = Join-Path $batchDir $name
        $exposed = New-Object System.Collections.Generic.List[object]
        $proxyAgg = @{}
        if ($invBy.ContainsKey($name)) {
            foreach ($r in $invBy[$name]) {
                $c = $clu[$r.ClusterId]
                if ($r.Role -eq 'ProxyClient') {
                    $k = $r.File + '|' + $r.ContractOrController
                    if (-not $proxyAgg.ContainsKey($k)) { $proxyAgg[$k] = @{ Row = $r; Ops = (New-Object System.Collections.Generic.List[string]) } }
                    if ($r.Operation -and $r.Operation -ne '*' -and -not $proxyAgg[$k].Ops.Contains($r.Operation)) { $proxyAgg[$k].Ops.Add($r.Operation) }
                    continue
                }
                $svc = ''; $svcFile = ''
                if ($r.Kind -eq 'WCF') { $leaf = @(Split-List $c.SvcFiles | Select-Object -First 1)[0]; if ($leaf -and $r.Role -in 'Host', 'Implementation') { $svcFile = $leaf; $svc = ($leaf -split '[\\/]')[-1] } }
                else { $svc = $r.ContractOrController }
                $exposed.Add([pscustomobject]@{
                    Repo = $name; Kind = $r.Kind; Role = $r.Role; Service = $svc; Contract = $(if ($r.Kind -eq 'WCF') { $r.ContractOrController } else { '' }); ClrNamespace = $r.ClrNamespace
                    Operation = $(if ($r.Kind -eq 'WCF') { $r.Operation } else { $r.Operation }); HttpVerb = $r.HttpVerb; Route = $r.Route; RouteNormalized = $r.RouteNormalized
                    SoapAction = $r.SoapAction; WireNamespace = $r.WireNamespace; SvcFile = $svcFile; File = $r.File; Line = $r.Line; Framework = $r.Framework
                    ProjectNames = $r.ProjectNames; ImplClasses = $r.ImplClasses; Flags = $r.Flags
                })
            }
        }
        $used = New-Object System.Collections.Generic.List[object]
        foreach ($pa in $proxyAgg.Values) {
            $r = $pa.Row
            $used.Add([pscustomobject][ordered]@{ Repo = $name; Kind = 'SoapProxy'; Value = $r.ContractOrController; Host = ''; UrlPath = ''; Verb = ''
                Detail = ('wire=' + $r.WireNamespace + ';ops=' + ($pa.Ops -join ',') + ';generated=' + $r.IsGenerated); File = $r.File; Line = $r.Line; Count = 1 })
        }
        foreach ($f in (Get-RepoUsedFacts -RepoDir $dir -RepoName $name -ExcludeDir $excludeDir -IncludeTests:$IncludeTests)) { $used.Add($f) }
        $refRows = @(); if ($refBy.ContainsKey($name)) { $refRows = $refBy[$name] | ForEach-Object { [pscustomobject]@{ Repo = $name; RefType = $_.RefType; RefName = $_.RefName } } }

        Write-Shard $name 'exposed' $exposed.ToArray() $exposedCols
        Write-Shard $name 'used' $used.ToArray() $usedCols
        Write-Shard $name 'refs' $refRows @('Repo', 'RefType', 'RefName')
        $br | Add-Member -NotePropertyName ExposedRows -NotePropertyValue $exposed.Count -Force
        $br | Add-Member -NotePropertyName UsedRows -NotePropertyValue $used.Count -Force
    }
    Remove-Item -LiteralPath $tmpOut -Recurse -Force -ErrorAction SilentlyContinue
}

function Get-RepoGitInfo([string]$dir) {
    $i = @{ Url = ''; Branch = ''; LastCommit = ''; Sha = '' }
    try {
        $url = (& git -C $dir config --get remote.origin.url 2>$null)
        if ($url) { $i.Url = ($url -replace '://[^/@]+@', '://') }
        $i.Branch = (& git -C $dir rev-parse --abbrev-ref HEAD 2>$null)
        $i.LastCommit = (& git -C $dir log -1 --format=%cI 2>$null)
        $i.Sha = (& git -C $dir rev-parse HEAD 2>$null)
    } catch { }
    return $i
}

# ------------------------------------------------------------------------------------------------
# main
# ------------------------------------------------------------------------------------------------
New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null
$WorkPath = (Resolve-Path -LiteralPath $WorkPath).Path
$batchRoot = Join-Path $WorkPath 'batch'

# --- the list of repos to process
$all = New-Object System.Collections.Generic.List[object]
if ($FromFolder) {
    foreach ($d in (Find-Repos -Root $FromFolder -ExcludeDir $excludeDir -ExcludeRepo @())) { $all.Add([pscustomobject]@{ Name = (Split-Path $d -Leaf); CloneUrl = ''; Branch = ''; SizeMB = 0; Archived = $false; Fork = $false; Private = $false; Dir = $d }) }
    $script:ProviderUsed = 'Folder'
} else {
    Log "Listing repositories of $BaseUrl ..."
    foreach ($r in (Get-RemoteRepos)) { $all.Add($r) }
}
# repos that are in repos.csv without a URL (re-adopted from saved files after an interrupted run): fill it in from the server's list
$filled = 0
foreach ($r in $all) {
    $st = $state[$r.Name]
    if ($st -and -not $st.RepoUrl -and $r.CloneUrl) {
        $st.RepoUrl = ($r.CloneUrl -replace '://[^/@]+@', '://'); $filled++
        if (-not $st.Provider) { $st.Provider = $script:ProviderUsed }
        if (-not $st.DefaultBranch) { $st.DefaultBranch = $r.Branch }
        if (-not $st.ApiSizeMB) { $st.ApiSizeMB = $r.SizeMB }
    }
}
if ($filled -gt 0) { Log ("Filled in the missing repository URL / branch of {0} repos in repos.csv." -f $filled); Save-State }

$skippedA = 0; $skippedF = 0; $skippedI = 0
$skipNames = @{ archived = (New-Object System.Collections.Generic.List[string]); fork = (New-Object System.Collections.Generic.List[string]) }
$newSkipped = 0
function Set-SkippedRow($r, [string]$why) {
    $skipNames[$why].Add($r.Name)
    if (-not $state.ContainsKey($r.Name)) {      # recorded so repos.csv accounts for every repo of the server; 'skipped' rows are never treated as done
        $state[$r.Name] = [pscustomobject]@{ Repo = $r.Name; RepoUrl = $(if ($r.CloneUrl) { ($r.CloneUrl -replace '://[^/@]+@', '://') } else { '' }); Provider = $script:ProviderUsed; DefaultBranch = $r.Branch; LastCommit = ''; Sha = ''; ScannedAt = ''; Batch = ''; Status = 'skipped'; Message = $(if ($why -eq 'fork') { 'fork (use -IncludeForks)' } else { 'archived/disabled (use -IncludeArchived)' }); ExposedRows = ''; UsedRows = ''; ApiSizeMB = $r.SizeMB }
        $script:newSkipped++
    }
}
$wanted = New-Object System.Collections.Generic.List[object]
foreach ($r in ($all | Sort-Object Name)) {
    if (-not $IncludeArchived -and $r.Archived) { $skippedA++; Set-SkippedRow $r 'archived'; continue }
    if (-not $IncludeForks -and $r.Fork) { $skippedF++; Set-SkippedRow $r 'fork'; continue }
    $ok = $false; foreach ($p in $Include) { if ($r.Name -like $p) { $ok = $true; break } }
    foreach ($p in $Exclude) { if ($r.Name -like $p) { $ok = $false; break } }
    if (-not $ok) { $skippedI++; continue }
    $wanted.Add($r)
}
if ($skipNames.archived.Count) { Log -FileOnly ('skipped (archived/disabled): ' + ($skipNames.archived -join ', ')) }
if ($skipNames.fork.Count) { Log -FileOnly ('skipped (forks): ' + ($skipNames.fork -join ', ')) }
if ($newSkipped -gt 0) { Save-State }
$pending = New-Object System.Collections.Generic.List[object]
$nOk = 0; $nFailed = 0; $nRefresh = 0; $nMissing = 0
foreach ($r in $wanted) {
    $st = $state[$r.Name]
    $done = ($null -ne $st) -and ($st.Status -notin 'skipped', 'missing')   # ANY entry in repos.csv means: do not clone it again ('skipped' = fork/archived note, 'missing' = results gone: redo) ...
    if ($st -and $st.Status -eq 'failed') { $nFailed++; if ($RetryFailed) { $done = $false } }      # ... unless it failed and -RetryFailed was given
    elseif ($st -and $st.Status -notin 'skipped', 'missing') { $nOk++ }
    if ($st -and $st.Status -eq 'missing') { $nMissing++ }
    if ($done -and $st.Status -in 'ok', 'empty' -and ($Refresh -or ($RefreshOlderThanDays -gt 0 -and $st.ScannedAt -and ([datetime]::Parse($st.ScannedAt, [Globalization.CultureInfo]::InvariantCulture) -lt (Get-Date).AddDays(-$RefreshOlderThanDays))))) { $done = $false; $nRefresh++ }
    if (-not $done) { $pending.Add($r) }
}
$alreadyDone = $wanted.Count - $pending.Count
if ($Limit -gt 0 -and $pending.Count -gt $Limit) { $pending = New-Object System.Collections.Generic.List[object] (, @($pending | Select-Object -First $Limit)) }
$skipText = @(); if ($skippedA) { $skipText += "$skippedA archived/disabled" }; if ($skippedF) { $skipText += "$skippedF forks" }; if ($skippedI) { $skipText += "$skippedI by filter" }
Log ("{0} repos listed, {1} in scope{2}." -f $all.Count, $wanted.Count, $(if ($skipText) { " (skipped: $($skipText -join ', '))" } else { '' }))
Log ("{0} already have an entry in repos.csv ({1} ok/empty, {2} failed{3}) and are not cloned again; {4} to do." -f ($nOk + $nFailed), $nOk, $nFailed, $(if ($nFailed -and -not $RetryFailed) { ' - add -RetryFailed to retry them' } else { '' }), $pending.Count)
if ($nMissing -gt 0) { Log ("{0} of the pending repos have an entry but no saved results (see above) and are included in the {1} to do." -f $nMissing, $pending.Count) }
if ($pending.Count -eq 0) { if (-not $NoMerge) { Merge-Inventory }; return }

# --- auth for git (environment only; nothing is written to .git/config or the command line)
$saved = @{}
foreach ($n in 'GCM_INTERACTIVE', 'GIT_TERMINAL_PROMPT', 'GIT_LFS_SKIP_SMUDGE', 'GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0', 'GIT_CONFIG_VALUE_0', 'GIT_HTTP_LOW_SPEED_LIMIT', 'GIT_HTTP_LOW_SPEED_TIME') { $saved[$n] = [Environment]::GetEnvironmentVariable($n) }
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_LFS_SKIP_SMUDGE = '1'; $env:GCM_INTERACTIVE = 'never'
$env:GIT_HTTP_LOW_SPEED_LIMIT = '1000'; $env:GIT_HTTP_LOW_SPEED_TIME = '120'      # a transfer slower than 1 KB/s for 2 minutes is aborted instead of hanging
if (-not $FromFolder -and $script:AuthHeaderValue) {
    $env:GIT_CONFIG_COUNT = '1'
    $env:GIT_CONFIG_KEY_0 = "http.$($script:CloneHost).extraheader"
    $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: $($script:AuthHeaderValue)"
}

$batchNo = 0; $totalDone = $alreadyDone; $totalFailed = 0; $stopped = ''
$startTime = Get-Date
$cloneTimeoutSec = [int][Math]::Max(5, $CloneTimeoutMinutes * 60)
$queue = New-Object System.Collections.Generic.Queue[object]
foreach ($r in $pending) { $queue.Enqueue($r) }
$estBatches = [math]::Ceiling($pending.Count / [double]$BatchSize)
$wave = [Math]::Max(1, [Math]::Min($CheckpointSize, $BatchSize))
New-Item -ItemType Directory -Force -Path $batchRoot | Out-Null
try {
    :outer while ($queue.Count -gt 0) {
        $batchNo++
        $batch = New-Object System.Collections.Generic.List[object]; $gb = 0.0
        while ($queue.Count -gt 0 -and $batch.Count -lt $BatchSize) {
            $next = $queue.Peek()
            if ($MaxBatchGB -gt 0 -and $batch.Count -gt 0 -and ($gb + $next.SizeMB / 1024.0) -gt $MaxBatchGB) { break }
            $batch.Add($queue.Dequeue()); $gb += $next.SizeMB / 1024.0
        }
        Log ("`n[batch {0}/~{1}] {2} repos" -f $batchNo, $estBatches, $batch.Count) -ForegroundColor Cyan

        for ($wi = 0; $wi -lt $batch.Count; $wi += $wave) {
            if ($MaxRunMinutes -gt 0 -and ((Get-Date) - $startTime).TotalMinutes -ge $MaxRunMinutes) { $stopped = "time budget of $MaxRunMinutes min reached"; break outer }
            $chunk = @($batch[$wi..([Math]::Min($wi + $wave, $batch.Count) - 1)])
            $now = (Get-Date).ToString('s')
            $cloned = New-Object System.Collections.Generic.List[object]
            $nBad = 0

            if ($FromFolder) {
                foreach ($r in $chunk) { $cloned.Add($r) }          # repos are scanned in place; nothing is cloned or deleted
                $workDir = $FromFolder
            } else {
                $workDir = $batchRoot
                if ((Get-FreeGB $batchRoot) -lt $MinFreeGB) {
                    throw ("Free space on the work drive is below -MinFreeGB ({0} GB). Free some space, lower -MinFreeGB, lower -CheckpointSize, or point -WorkPath at a bigger drive. Nothing is lost: run the same command again to continue." -f $MinFreeGB)
                }
                Log ("  cloning {0} repos ({1} at a time) ..." -f $chunk.Count, $(if ($PSVersionTable.PSVersion.Major -ge 7) { $Parallel } else { 1 }))
                $ctr = @{ bad = 0; done = 0 }
                $handleResult = {
                    param($x)
                    $ctr.done++
                    $br = $chunk | Where-Object { $_.Name -eq $x.Name } | Select-Object -First 1
                    if ($x.Status -eq 'cloned') { $cloned.Add($br); Log ("  [{0,3}/{1}] cloned   {2}  ({3} s)" -f $ctr.done, $chunk.Count, $x.Name, $x.Seconds) }
                    else {
                        $st = if ($x.Status -eq 'empty') { 'empty' } else { 'failed' }
                        $state[$x.Name] = [pscustomobject]@{ Repo = $x.Name; RepoUrl = $br.CloneUrl; Provider = $script:ProviderUsed; DefaultBranch = $br.Branch; LastCommit = ''; Sha = ''; ScannedAt = $now; Batch = $batchNo; Status = $st; Message = $x.Detail; ExposedRows = 0; UsedRows = 0; ApiSizeMB = $br.SizeMB }
                        if ($st -eq 'failed') { $ctr.bad++; Log ("  [{0,3}/{1}] FAILED   {2}: {3}  ({4} s)" -f $ctr.done, $chunk.Count, $x.Name, $x.Detail, $x.Seconds) -ForegroundColor Yellow }
                        else { Log ("  [{0,3}/{1}] empty    {2}  ({3})" -f $ctr.done, $chunk.Count, $x.Name, $x.Detail) }
                    }
                    Write-Progress -Activity ("Cloning ({0}/{1} repos done overall)" -f $totalDone, $wanted.Count) -Status ("{0} / {1} of this group - last: {2}" -f $ctr.done, $chunk.Count, $x.Name) -PercentComplete (100 * $ctr.done / $chunk.Count)
                }
                $groupStart = Get-Date
                if ($PSVersionTable.PSVersion.Major -ge 7 -and $Parallel -gt 1) {
                    # run as a job so this loop can print results as they arrive and a heartbeat while it waits
                    $job = $chunk | ForEach-Object -ThrottleLimit $Parallel -Parallel {
                        $w = [scriptblock]::Create($using:workerText)
                        & $w $_ (Join-Path $using:batchRoot $_.Name) $using:sparseLines $using:cloneTimeoutSec
                    } -AsJob
                    $lastBeat = Get-Date
                    try {
                        while ($true) {
                            foreach ($x in @(Receive-Job -Job $job -ErrorAction SilentlyContinue)) { & $handleResult $x }
                            if ($job.State -notin 'Running', 'NotStarted') { foreach ($x in @(Receive-Job -Job $job -ErrorAction SilentlyContinue)) { & $handleResult $x }; break }
                            if (((Get-Date) - $lastBeat).TotalSeconds -ge $HeartbeatSeconds) {
                                Log ("  ... still cloning: {0}/{1} of this group finished, {2:N1} min in this group (a single clone is cut off after {3} min)" -f $ctr.done, $chunk.Count, ((Get-Date) - $groupStart).TotalMinutes, $CloneTimeoutMinutes)
                                $lastBeat = Get-Date
                            }
                            Start-Sleep -Milliseconds 500
                        }
                    } finally { Remove-Job -Job $job -Force -ErrorAction SilentlyContinue }
                } else {
                    $w = [scriptblock]::Create($workerText)
                    foreach ($r in $chunk) {
                        Log ("  [{0,3}/{1}] cloning  {2} ..." -f ($ctr.done + 1), $chunk.Count, $r.Name)
                        & $handleResult (& $w $r (Join-Path $batchRoot $r.Name) $sparseLines $cloneTimeoutSec)
                    }
                }
                Write-Progress -Activity 'Cloning' -Completed
                $nBad = $ctr.bad; $totalFailed += $nBad
            }

            if ($cloned.Count -gt 0) {
                Log ('  harvesting {0} repos ...' -f $cloned.Count)
                Invoke-Harvest $workDir $cloned $batchNo
                foreach ($br in $cloned) {
                    $dir = if ($FromFolder) { $br.Dir } else { Join-Path $workDir $br.Name }
                    $gi = Get-RepoGitInfo $dir
                    $state[$br.Name] = [pscustomobject]@{ Repo = $br.Name; RepoUrl = $(if ($br.CloneUrl) { ($br.CloneUrl -replace '://[^/@]+@', '://') } else { $gi.Url }); Provider = $script:ProviderUsed; DefaultBranch = $(if ($gi.Branch) { $gi.Branch } else { $br.Branch })
                        LastCommit = $gi.LastCommit; Sha = $gi.Sha; ScannedAt = $now; Batch = $batchNo; Status = 'ok'; Message = ''; ExposedRows = $br.ExposedRows; UsedRows = $br.UsedRows; ApiSizeMB = $br.SizeMB }
                    Log -FileOnly ("ok       {0}  (calls {1}, exposes {2})" -f $br.Name, $br.UsedRows, $br.ExposedRows)
                }
            }
            Save-State                                                    # checkpoint: everything in this group is now recorded
            if (-not $FromFolder -and -not $KeepClones) { foreach ($r in $chunk) { Remove-Tree (Join-Path $batchRoot $r.Name) } }
            $totalDone += $chunk.Count
            $mins = ((Get-Date) - $startTime).TotalMinutes
$doneNow = $totalDone - $alreadyDone
            $eta = ''
            if ($doneNow -gt 0 -and $totalDone -lt $wanted.Count) { $left = ($wanted.Count - $totalDone) * ($mins / $doneNow); $eta = if ($left -ge 90) { "  ~{0:N1} h left at this pace" -f ($left / 60) } else { "  ~{0:N0} min left at this pace" -f $left } }
            Log ("  saved: {0}/{1} repos done (+{2}{3}), {4:N0} min elapsed{5}" -f $totalDone, $wanted.Count, $chunk.Count, $(if ($nBad) { ", $nBad failed" } else { '' }), $mins, $eta)
        }
    }
} finally {
    foreach ($n in $saved.Keys) { [Environment]::SetEnvironmentVariable($n, $saved[$n]) }
    Save-State
    if (-not $FromFolder -and -not $KeepClones) { Remove-Tree $batchRoot }
}
$left = @($wanted | Where-Object { -not $state.ContainsKey($_.Name) }).Count
$ok = @($state.Values | Where-Object { $_.Status -in 'ok', 'empty' }).Count
$bad = @($state.Values | Where-Object Status -eq 'failed').Count
if ($stopped -or $left -gt 0) {
    Log ''
    Log ("Stopped: {0}. {1} repos done, {2} still to do. Run the SAME command again to continue; repos already in repos.csv are not cloned again." -f $(if ($stopped) { $stopped } else { 'not all repos were processed' }), $ok, $left) -ForegroundColor Yellow
    Log "(urls-used.csv / endpoints-exposed.csv are rebuilt when everything is done, or at any time with -MergeOnly; Find-HomeRepoUsage.ps1 reads the saved files directly.)"
} else {
    if (-not $NoMerge) { Merge-Inventory }
    Log ''
    Log ("Inventory: {0} repos OK, {1} failed{2}  ->  {3}" -f $ok, $bad, $(if ($bad) { ' (add -RetryFailed to retry them)' } else { '' }), $InventoryPath) -ForegroundColor $(if ($bad) { 'Yellow' } else { 'Green' })
}
} catch {
    Log ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    throw
} finally {
    if ($lockHeld) { Remove-Item -LiteralPath $lockFile -Force -ErrorAction SilentlyContinue }
    Log -FileOnly '==== run ended'
}
