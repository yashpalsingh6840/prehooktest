<#
.SYNOPSIS
    Build a persistent inventory of the URLs / endpoints every repo USES and EXPOSES - in batches, so thousands of
    repos never have to be on disk at the same time.

.DESCRIPTION
    Loop (repeat until every repo is done):
        1. take the next N repos that are not in the inventory yet            (-BatchSize, default 500)
        2. clone them: shallow, single branch, and ONLY source/config files   (partial + sparse clone - binaries,
           node_modules, bin/obj, images, packages are never downloaded)
        3. harvest facts from them
        4. save the facts (one small file set per repo) + a line in repos.csv
        5. DELETE the clones                                                 (free space for the next batch)
    It is resumable: re-run the same command after an interruption and it continues with the repos that are missing.
    Re-running a repo replaces its facts (no duplicates).

    The inventory folder contains
        repos.csv              one row per repo: url, branch, last commit, scan time, status, counts
        urls-used.csv          what each repo calls:   Repo | Url | Kind | Host | UrlPath | Verb | Detail | File | Line | ...
                               (XML + JSON config URLs, WCF <client> endpoints, *.svc references, URLs/routes in code and
                                frontend files, ChannelFactory<T>/ClientBase<T> types)
        endpoints-exposed.csv  what each repo exposes: SOAP contracts/operations/.svc and REST controller routes
        shards\                the per-repo source files these are built from (used by Find-HomeRepoUsage.ps1)
    The two big CSVs are re-generated at the end of every run.

    Works with GitHub (github.com / GitHub Enterprise Server) and Azure DevOps (dev.azure.com, *.visualstudio.com, Azure DevOps Server).
    -FromFolder harvests repos that are ALREADY cloned (no cloning, no deleting), in batches.

.EXAMPLE
    $env:GITHUB_TOKEN = '<token>'
    .\Build-UrlInventory.ps1 -BaseUrl https://github.com/contoso -InventoryPath D:\url-inventory -WorkPath D:\work
.EXAMPLE
    # Azure DevOps project, 300 repos per batch, keep at least 10 GB free
    $env:AZURE_DEVOPS_PAT = '<pat>'
    .\Build-UrlInventory.ps1 -BaseUrl https://dev.azure.com/contoso/MyProject -InventoryPath D:\url-inventory -BatchSize 300 -MinFreeGB 10
.EXAMPLE
    .\Build-UrlInventory.ps1 -FromFolder C:\Proj -InventoryPath D:\url-inventory -BatchSize 100
#>
[CmdletBinding()]
param(
    [string]$BaseUrl,
    [string]$FromFolder,
    [Parameter(Mandatory)][string]$InventoryPath,
    [string]$WorkPath = (Join-Path ([System.IO.Path]::GetTempPath()) 'url-inventory-work'),
    [int]$BatchSize = 500,
    # Also start a new batch when the API-reported (full, un-sparsed) size of the batch exceeds this many GB. 0 = off.
    [double]$MaxBatchGB = 0,
    # Never let the work drive drop below this; cloning stops early (the rest waits for the next batch)
    [double]$MinFreeGB = 5,
    [string]$Token,
    [ValidateSet('Auto', 'GitHub', 'AzureDevOps')][string]$Provider = 'Auto',
    [string]$ApiBase,
    [string[]]$Include = @('*'),
    [string[]]$Exclude = @(),
    [switch]$IncludeArchived,
    [switch]$IncludeForks,
    [int]$Parallel = 4,
    # Only process the first N pending repos (testing)
    [int]$Limit = 0,
    # Re-harvest repos already in the inventory (all, or those scanned more than N days ago)
    [switch]$Refresh,
    [int]$RefreshOlderThanDays = 0,
    [switch]$KeepClones,
    [switch]$IncludeTests,
    # Only rebuild urls-used.csv / endpoints-exposed.csv from the shards
    [switch]$MergeOnly
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'EndpointScan.Common.ps1')
. (Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1')
function Split-List($s) { if ([string]::IsNullOrWhiteSpace($s)) { return @() }; return @($s -split ';' | Where-Object { $_ }) }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }

New-Item -ItemType Directory -Force -Path $InventoryPath | Out-Null
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$shardDir = Join-Path $InventoryPath 'shards'
New-Item -ItemType Directory -Force -Path $shardDir | Out-Null
$reposFile = Join-Path $InventoryPath 'repos.csv'
$excludeDir = @('bin', 'obj', 'node_modules', '.git', '.vs', '.idea', 'packages', 'TestResults', 'artifacts', 'dist', '.next', '.angular', 'coverage', 'bower_components')

# ------------------------------------------------------------------------------------------------
# repos.csv  (state of the inventory)
# ------------------------------------------------------------------------------------------------
$repoCols = 'Repo', 'RepoUrl', 'Provider', 'DefaultBranch', 'LastCommit', 'Sha', 'ScannedAt', 'Batch', 'Status', 'Message', 'ExposedRows', 'UsedRows', 'ApiSizeMB'
$state = @{}
if (Test-Path -LiteralPath $reposFile) { foreach ($r in (Import-Csv -LiteralPath $reposFile)) { $state[$r.Repo] = $r } }
function Save-State {
    $tmp = "$reposFile.tmp"
    @($state.Values | Sort-Object Repo | Select-Object $repoCols) | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $reposFile -Force
}

# ------------------------------------------------------------------------------------------------
# merged, human-friendly CSVs (rebuilt from the shards)
# ------------------------------------------------------------------------------------------------
function ConvertTo-CsvLine($vals) {
    ($vals | ForEach-Object { $s = [string]$_; '"' + $s.Replace('"', '""') + '"' }) -join ','
}
function Merge-Inventory {
    Write-Host 'Rebuilding urls-used.csv and endpoints-exposed.csv ...'
    $meta = @{}; foreach ($r in $state.Values) { $meta[$r.Repo] = $r }
    $enc = New-Object System.Text.UTF8Encoding($true)
    $defs = @(
        @{ Suffix = 'used'; File = 'urls-used.csv'
           Cols = 'Repo', 'Url', 'Kind', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count', 'RepoLastCommit', 'ScannedAt'
           Map = { param($r, $m) @($r.Repo, $r.Value, $r.Kind, $r.Host, $r.UrlPath, $r.Verb, $r.Detail, $r.File, $r.Line, $r.Count, $m.LastCommit, $m.ScannedAt) } },
        @{ Suffix = 'exposed'; File = 'endpoints-exposed.csv'
           Cols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'Operation', 'HttpVerb', 'Route', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'ImplClasses', 'Flags', 'ProjectNames', 'RepoLastCommit'
           Map = { param($r, $m) @($r.Repo, $r.Kind, $r.Role, $r.Service, $r.Contract, $r.Operation, $r.HttpVerb, $r.Route, $r.SoapAction, $r.WireNamespace, $r.SvcFile, $r.File, $r.Line, $r.ImplClasses, $r.Flags, $r.ProjectNames, $m.LastCommit) } }
    )
    foreach ($d in $defs) {
        $tmp = Join-Path $InventoryPath ($d.File + '.tmp')
        $w = New-Object System.IO.StreamWriter($tmp, $false, $enc)
        try {
            $w.WriteLine((ConvertTo-CsvLine $d.Cols))
            $rows = 0
            foreach ($f in (Get-ChildItem -LiteralPath $shardDir -Filter ('*.' + $d.Suffix + '.csv') | Sort-Object Name)) {
                foreach ($r in (Import-Csv -LiteralPath $f.FullName)) {
                    $m = $meta[$r.Repo]; if (-not $m) { $m = [pscustomobject]@{ LastCommit = ''; ScannedAt = '' } }
                    $w.WriteLine((ConvertTo-CsvLine (& $d.Map $r $m))); $rows++
                }
            }
        } finally { $w.Dispose() }
        Move-Item -LiteralPath $tmp -Destination (Join-Path $InventoryPath $d.File) -Force
        Write-Host ("  {0}: {1:N0} rows" -f $d.File, $rows)
    }
}
if ($MergeOnly) { Merge-Inventory; return }

if (-not $BaseUrl -and -not $FromFolder) { throw 'Pass -BaseUrl (org / project URL) or -FromFolder (folder with existing clones).' }

# ------------------------------------------------------------------------------------------------
# helpers: API, repo listing
# ------------------------------------------------------------------------------------------------
function Invoke-Api([string]$url, [hashtable]$headers) {
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        try { return (Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop) }
        catch {
            $code = 0; if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
            if ($code -eq 404) { return $null }
            if ($code -in 401, 203) { throw "The server rejected the credentials (HTTP $code) - check the token / PAT and its permissions." }
            if ($code -in 403, 429 -and $attempt -lt 4) { Write-Host '  API rate limit, waiting 60 s ...'; Start-Sleep -Seconds 60; continue }
            if (($code -ge 500 -or $code -eq 0) -and $attempt -lt 4) { Start-Sleep -Seconds (2 * $attempt); continue }
            throw
        }
    }
}

function Get-RemoteRepos {
    $u = [uri]$BaseUrl
    $prov = $Provider
    if ($prov -eq 'Auto') { $prov = if ($u.Host -match '(?i)^dev\.azure\.com$|\.visualstudio\.com$|/_git/|/tfs/') { 'AzureDevOps' } elseif ($u.AbsolutePath -match '(?i)/_apis|/tfs/') { 'AzureDevOps' } else { 'GitHub' } }
    $list = New-Object System.Collections.Generic.List[object]
    if ($prov -eq 'GitHub') {
        $script:Token = if ($Token) { $Token } else { $env:GITHUB_TOKEN }
        $org = ($u.AbsolutePath.Trim('/') -split '/')[0]
        if (-not $org) { throw "Could not read an org/user from '$BaseUrl'." }
        $api = if ($ApiBase) { $ApiBase.TrimEnd('/') } elseif ($u.Host -eq 'github.com') { 'https://api.github.com' } else { "$($u.Scheme)://$($u.Host)/api/v3" }
        $h = @{ Accept = 'application/vnd.github+json'; 'User-Agent' = 'endpoint-scan'; 'X-GitHub-Api-Version' = '2022-11-28' }
        if ($script:Token) { $h.Authorization = "Bearer $($script:Token)" }
        $kind = if ($null -eq (Invoke-Api "$api/orgs/$org" $h)) { 'users' } else { 'orgs' }
        $page = 1
        while ($true) {
            $items = @(Invoke-Api "$api/$kind/$org/repos?per_page=100&page=$page&type=all" $h)
            if ($items.Count -eq 0 -or $null -eq $items[0]) { break }
            foreach ($x in $items) { $list.Add([pscustomobject]@{ Name = $x.name; CloneUrl = $x.clone_url; Branch = $x.default_branch; SizeMB = [math]::Round($x.size / 1024.0, 1); Archived = [bool]$x.archived; Fork = [bool]$x.fork; Private = [bool]$x.private }) }
            if ($items.Count -lt 100) { break }; $page++
        }
        $script:ProviderUsed = 'GitHub'; $script:CloneHost = "$($u.Scheme)://$($u.Host)/"
        $script:AuthHeaderValue = if ($script:Token) { 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("x-access-token:$($script:Token)")) } else { '' }
    } else {
        $script:Token = if ($Token) { $Token } elseif ($env:AZURE_DEVOPS_PAT) { $env:AZURE_DEVOPS_PAT } else { $env:SYSTEM_ACCESSTOKEN }
        if (-not $script:Token) { throw 'Azure DevOps needs a PAT (Code: Read): pass -Token or set $env:AZURE_DEVOPS_PAT.' }
        $basic = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(":$($script:Token)"))
        $h = @{ Authorization = $basic; Accept = 'application/json'; 'User-Agent' = 'endpoint-scan' }
        $root = if ($ApiBase) { $ApiBase.TrimEnd('/') } else { $BaseUrl.TrimEnd('/') -replace '/_git/.*$', '' }
        $r = Invoke-Api "$root/_apis/git/repositories?api-version=7.1" $h
        if ($null -eq $r -or $null -eq $r.value) { throw "No repositories returned from $root/_apis/git/repositories - check the URL (org or org/project) and the PAT." }
        $names = @{}; foreach ($x in $r.value) { $names[$x.name] = 1 + [int]$names[$x.name] }
        foreach ($x in $r.value) {
            $nm = if ($names[$x.name] -gt 1 -and $x.project) { "$($x.project.name).$($x.name)" } else { $x.name }
            $br = ("$($x.defaultBranch)" -replace '^refs/heads/', '')
            $list.Add([pscustomobject]@{ Name = $nm; CloneUrl = $x.remoteUrl; Branch = $br; SizeMB = [math]::Round(([double]$x.size) / 1MB, 1); Archived = [bool]$x.isDisabled; Fork = [bool]$x.isFork; Private = $true })
        }
        $script:ProviderUsed = 'AzureDevOps'; $script:CloneHost = "$(([uri]$list[0].CloneUrl).Scheme)://$(([uri]$list[0].CloneUrl).Host)/"
        $script:AuthHeaderValue = $basic
    }
    return $list
}

# ------------------------------------------------------------------------------------------------
# clone worker: shallow + partial + sparse (deny-list of junk directories and binary extensions)
# ------------------------------------------------------------------------------------------------
$junkDirs = 'bin', 'obj', 'node_modules', 'packages', '.vs', 'dist', 'bower_components', 'TestResults', '.next', '.angular', 'coverage'
$junkExt = 'dll exe pdb zip 7z rar gz tgz tar nupkg msi iso bin dat db sqlite mdf ldf bak png jpg jpeg gif bmp ico tif tiff pdf doc docx xls xlsx ppt pptx mp3 mp4 avi mov wav woff woff2 ttf eot otf jar war class so dylib lib o snk pfx cer p12 psd ai dwg sav pkg apk ipa swf flv mkv wmv ogg webm webp heic svgz'.Split(' ')
$sparseLines = @('/*') + @($junkDirs | ForEach-Object { "!$_/" }) + @($junkExt | ForEach-Object { "!*.$_" })

$workerText = @'
param($r, $dest, $patterns)
$res = [ordered]@{ Name = $r.Name; Status = ''; Detail = '' }
function Last-Line($o) {
    $l = @($o | ForEach-Object { "$_".Trim() } | Where-Object { $_ })
    $f = @($l | Where-Object { $_ -match '^(fatal|error|remote):' })
    if ($f.Count) { return ($f[0] -replace '^(fatal|error|remote):\s*', '') }
    if ($l.Count) { return $l[-1] } else { return '' }
}
try {
    if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
    $ok = $false; $o = $null
    foreach ($filter in @('--filter=blob:none', '')) {
        $a = @('-c', 'core.longpaths=true', 'clone', '--quiet', '--no-tags', '--no-checkout', '--depth', '1')
        if ($filter) { $a += $filter }
        $a += @($r.CloneUrl, $dest)
        for ($try = 1; $try -le 3; $try++) {
            $o = & git @a 2>&1
            if ($LASTEXITCODE -eq 0) { $ok = $true; break }
            if (Test-Path -LiteralPath $dest) { Remove-Item -Recurse -Force -LiteralPath $dest -ErrorAction SilentlyContinue }
            if ("$o" -match 'not found|Authentication failed|could not read Username|Repository not found|403|does not appear') { break }
            Start-Sleep -Seconds (3 * $try)
        }
        if ($ok) { break }
    }
    if (-not $ok) { $res.Status = 'failed'; $res.Detail = Last-Line $o; return [pscustomobject]$res }
    & git -C $dest rev-parse --verify --quiet HEAD 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) { $res.Status = 'empty'; $res.Detail = 'repository has no commits'; return [pscustomobject]$res }
    & git -C $dest config core.sparseCheckout true 2>&1 | Out-Null
    $info = Join-Path $dest '.git/info'
    New-Item -ItemType Directory -Force -Path $info | Out-Null
    [System.IO.File]::WriteAllLines((Join-Path $info 'sparse-checkout'), [string[]]$patterns)
    $o = & git -C $dest checkout --quiet 2>&1
    if ($LASTEXITCODE -ne 0) { $res.Status = 'failed'; $res.Detail = 'checkout: ' + (Last-Line $o); return [pscustomobject]$res }
    $res.Status = 'cloned'
} catch { $res.Status = 'failed'; $res.Detail = $_.Exception.Message }
[pscustomobject]$res
'@

function Get-FreeGB([string]$path) {
    try { $root = [System.IO.Path]::GetPathRoot((Resolve-Path -LiteralPath $path).Path); return ((New-Object System.IO.DriveInfo($root)).AvailableFreeSpace / 1GB) } catch { return 1e6 }
}

function Remove-Tree([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    try { Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { try { $_.Attributes = 'Normal' } catch { } } } catch { }
    try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop; return } catch { }
    if ($env:OS -eq 'Windows_NT') { & cmd.exe /c rd /s /q ('"' + $path + '"') 2>&1 | Out-Null }
    if (Test-Path -LiteralPath $path) { Write-Warning "Could not fully delete $path - delete it manually." }
}

# ------------------------------------------------------------------------------------------------
# harvest one batch folder -> shards
# ------------------------------------------------------------------------------------------------
function Write-Shard($repo, [string]$suffix, $rows, [string[]]$cols) {
    $base = Join-Path $shardDir ((Safe-Name $repo) + ".$suffix.csv")
    $arr = @($rows)
    if ($arr.Count -gt 0) { $arr | Select-Object $cols | Export-Csv -LiteralPath "$base.tmp" -NoTypeInformation -Encoding UTF8 }
    else { Set-Content -LiteralPath "$base.tmp" -Value (($cols | ForEach-Object { '"' + $_ + '"' }) -join ',') -Encoding UTF8 }
    Move-Item -LiteralPath "$base.tmp" -Destination $base -Force
}

$exposedCols = 'Repo', 'Kind', 'Role', 'Service', 'Contract', 'ClrNamespace', 'Operation', 'HttpVerb', 'Route', 'RouteNormalized', 'SoapAction', 'WireNamespace', 'SvcFile', 'File', 'Line', 'Framework', 'ProjectNames', 'ImplClasses', 'Flags'
$usedCols = 'Repo', 'Kind', 'Value', 'Host', 'UrlPath', 'Verb', 'Detail', 'File', 'Line', 'Count'

function Invoke-Harvest($batchDir, $batchRepos, [int]$batchNo) {
    $tmpOut = Join-Path $WorkPath ('engine-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    $ip = @{ RootPath = $batchDir; OutputPath = $tmpOut; SkipGit = $true; OnlyRepo = @($batchRepos | ForEach-Object { $_.Name }) }
    if ($IncludeTests) { $ip.IncludeTests = $true }
    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    try { & (Join-Path $PSScriptRoot 'Get-EndpointInventory.ps1') @ip 6>$null 3>$null | Out-Null } finally { $ProgressPreference = $old }
    $inv = @(); $clu = @{}; $refs = @()
    if (Test-Path (Join-Path $tmpOut 'endpoint-inventory.csv')) { $inv = @(Import-Csv (Join-Path $tmpOut 'endpoint-inventory.csv')) }
    if (Test-Path (Join-Path $tmpOut 'endpoint-clusters.csv')) { foreach ($c in (Import-Csv (Join-Path $tmpOut 'endpoint-clusters.csv'))) { $clu[$c.ClusterId] = $c } }
    if (Test-Path (Join-Path $tmpOut 'repo-references.csv')) { $refs = @(Import-Csv (Join-Path $tmpOut 'repo-references.csv')) }
    $invBy = @{}; foreach ($r in $inv) { if (-not $invBy.ContainsKey($r.Repo)) { $invBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $invBy[$r.Repo].Add($r) }
    $refBy = @{}; foreach ($r in $refs) { if (-not $refBy.ContainsKey($r.Repo)) { $refBy[$r.Repo] = New-Object System.Collections.Generic.List[object] }; $refBy[$r.Repo].Add($r) }

    foreach ($br in $batchRepos) {
        $name = $br.Name
        $dir = Join-Path $batchDir $name
        $exposed = New-Object System.Collections.Generic.List[object]
        $proxyAgg = @{}
        if ($invBy.ContainsKey($name)) {
            foreach ($r in $invBy[$name]) {
                $c = $clu[$r.ClusterId]
                if ($r.Role -eq 'ProxyClient') {
                    $k = $r.File + '|' + $r.ContractOrController
                    if (-not $proxyAgg.ContainsKey($k)) { $proxyAgg[$k] = @{ Row = $r; Ops = (New-Object System.Collections.Generic.List[string]) } }
                    if ($r.Operation -and $r.Operation -ne '*' -and -not $proxyAgg[$k].Ops.Contains($r.Operation)) { $proxyAgg[$k].Ops.Add($r.Operation) }
                    continue
                }
                $svc = ''; $svcFile = ''
                if ($r.Kind -eq 'WCF') { $leaf = @(Split-List $c.SvcFiles | Select-Object -First 1)[0]; if ($leaf -and $r.Role -in 'Host', 'Implementation') { $svcFile = $leaf; $svc = ($leaf -split '[\\/]')[-1] } }
                else { $svc = $r.ContractOrController }
                $exposed.Add([pscustomobject]@{
                    Repo = $name; Kind = $r.Kind; Role = $r.Role; Service = $svc; Contract = $(if ($r.Kind -eq 'WCF') { $r.ContractOrController } else { '' }); ClrNamespace = $r.ClrNamespace
                    Operation = $(if ($r.Kind -eq 'WCF') { $r.Operation } else { $r.Operation }); HttpVerb = $r.HttpVerb; Route = $r.Route; RouteNormalized = $r.RouteNormalized
                    SoapAction = $r.SoapAction; WireNamespace = $r.WireNamespace; SvcFile = $svcFile; File = $r.File; Line = $r.Line; Framework = $r.Framework
                    ProjectNames = $r.ProjectNames; ImplClasses = $r.ImplClasses; Flags = $r.Flags
                })
            }
        }
        $used = New-Object System.Collections.Generic.List[object]
        foreach ($pa in $proxyAgg.Values) {
            $r = $pa.Row
            $used.Add([pscustomobject][ordered]@{ Repo = $name; Kind = 'SoapProxy'; Value = $r.ContractOrController; Host = ''; UrlPath = ''; Verb = ''
                Detail = ('wire=' + $r.WireNamespace + ';ops=' + ($pa.Ops -join ',') + ';generated=' + $r.IsGenerated); File = $r.File; Line = $r.Line; Count = 1 })
        }
        foreach ($f in (Get-RepoUsedFacts -RepoDir $dir -RepoName $name -ExcludeDir $excludeDir -IncludeTests:$IncludeTests)) { $used.Add($f) }
        $refRows = @(); if ($refBy.ContainsKey($name)) { $refRows = $refBy[$name] | ForEach-Object { [pscustomobject]@{ Repo = $name; RefType = $_.RefType; RefName = $_.RefName } } }

        Write-Shard $name 'exposed' $exposed.ToArray() $exposedCols
        Write-Shard $name 'used' $used.ToArray() $usedCols
        Write-Shard $name 'refs' $refRows @('Repo', 'RefType', 'RefName')
        $br | Add-Member -NotePropertyName ExposedRows -NotePropertyValue $exposed.Count -Force
        $br | Add-Member -NotePropertyName UsedRows -NotePropertyValue $used.Count -Force
    }
    Remove-Item -LiteralPath $tmpOut -Recurse -Force -ErrorAction SilentlyContinue
}

function Get-RepoGitInfo([string]$dir) {
    $i = @{ Url = ''; Branch = ''; LastCommit = ''; Sha = '' }
    try {
        $url = (& git -C $dir config --get remote.origin.url 2>$null)
        if ($url) { $i.Url = ($url -replace '://[^/@]+@', '://') }
        $i.Branch = (& git -C $dir rev-parse --abbrev-ref HEAD 2>$null)
        $i.LastCommit = (& git -C $dir log -1 --format=%cI 2>$null)
        $i.Sha = (& git -C $dir rev-parse HEAD 2>$null)
    } catch { }
    return $i
}

# ------------------------------------------------------------------------------------------------
# main
# ------------------------------------------------------------------------------------------------
New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null
$WorkPath = (Resolve-Path -LiteralPath $WorkPath).Path
$batchRoot = Join-Path $WorkPath 'batch'

# --- the list of repos to process
$all = New-Object System.Collections.Generic.List[object]
if ($FromFolder) {
    foreach ($d in (Find-Repos -Root $FromFolder -ExcludeDir $excludeDir -ExcludeRepo @())) { $all.Add([pscustomobject]@{ Name = (Split-Path $d -Leaf); CloneUrl = ''; Branch = ''; SizeMB = 0; Archived = $false; Fork = $false; Private = $false; Dir = $d }) }
    $script:ProviderUsed = 'Folder'
} else {
    Write-Host "Listing repositories of $BaseUrl ..."
    foreach ($r in (Get-RemoteRepos)) { $all.Add($r) }
}
$skippedA = 0; $skippedF = 0; $skippedI = 0
$wanted = New-Object System.Collections.Generic.List[object]
foreach ($r in ($all | Sort-Object Name)) {
    if (-not $IncludeArchived -and $r.Archived) { $skippedA++; continue }
    if (-not $IncludeForks -and $r.Fork) { $skippedF++; continue }
    $ok = $false; foreach ($p in $Include) { if ($r.Name -like $p) { $ok = $true; break } }
    foreach ($p in $Exclude) { if ($r.Name -like $p) { $ok = $false; break } }
    if (-not $ok) { $skippedI++; continue }
    $wanted.Add($r)
}
$pending = New-Object System.Collections.Generic.List[object]
foreach ($r in $wanted) {
    $st = $state[$r.Name]
    $done = $st -and $st.Status -in 'ok', 'empty'
    if ($done -and ($Refresh -or ($RefreshOlderThanDays -gt 0 -and $st.ScannedAt -and ([datetime]::Parse($st.ScannedAt, [Globalization.CultureInfo]::InvariantCulture) -lt (Get-Date).AddDays(-$RefreshOlderThanDays))))) { $done = $false }
    if (-not $done) { $pending.Add($r) }
}
$alreadyDone = $wanted.Count - $pending.Count
if ($Limit -gt 0 -and $pending.Count -gt $Limit) { $pending = New-Object System.Collections.Generic.List[object] (, @($pending | Select-Object -First $Limit)) }
$skipText = @(); if ($skippedA) { $skipText += "$skippedA archived/disabled" }; if ($skippedF) { $skipText += "$skippedF forks" }; if ($skippedI) { $skipText += "$skippedI by filter" }
Write-Host ("{0} repos listed, {1} in scope{2}; {3} already in the inventory, {4} to do." -f $all.Count, $wanted.Count, $(if ($skipText) { " (skipped: $($skipText -join ', '))" } else { '' }), $alreadyDone, $pending.Count)
if ($pending.Count -eq 0) { Merge-Inventory; return }

# --- auth for git (environment only; nothing is written to .git/config or the command line)
$saved = @{}
foreach ($n in 'GIT_TERMINAL_PROMPT', 'GIT_LFS_SKIP_SMUDGE', 'GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0', 'GIT_CONFIG_VALUE_0') { $saved[$n] = [Environment]::GetEnvironmentVariable($n) }
$env:GIT_TERMINAL_PROMPT = '0'; $env:GIT_LFS_SKIP_SMUDGE = '1'
if (-not $FromFolder -and $script:AuthHeaderValue) {
    $env:GIT_CONFIG_COUNT = '1'
    $env:GIT_CONFIG_KEY_0 = "http.$($script:CloneHost).extraheader"
    $env:GIT_CONFIG_VALUE_0 = "AUTHORIZATION: $($script:AuthHeaderValue)"
}

$batchNo = 0; $totalDone = $alreadyDone; $totalFailed = 0
$queue = New-Object System.Collections.Generic.Queue[object]
foreach ($r in $pending) { $queue.Enqueue($r) }
$estBatches = [math]::Ceiling($pending.Count / [double]$BatchSize)
try {
    while ($queue.Count -gt 0) {
        $batchNo++
        # ---- build the batch (count and optional size limit)
        $batch = New-Object System.Collections.Generic.List[object]; $gb = 0.0
        while ($queue.Count -gt 0 -and $batch.Count -lt $BatchSize) {
            $next = $queue.Peek()
            if ($MaxBatchGB -gt 0 -and $batch.Count -gt 0 -and ($gb + $next.SizeMB / 1024.0) -gt $MaxBatchGB) { break }
            $batch.Add($queue.Dequeue()); $gb += $next.SizeMB / 1024.0
        }
        Write-Host ("`n[batch {0}/~{1}] {2} repos" -f $batchNo, $estBatches, $batch.Count) -ForegroundColor Cyan
        $now = (Get-Date).ToString('s')
        $cloned = New-Object System.Collections.Generic.List[object]

        if ($FromFolder) {
            $batchDir = $FromFolder      # repos are scanned in place; nothing is cloned or deleted
            foreach ($r in $batch) { $cloned.Add($r) }
        } else {
            Remove-Tree $batchRoot
            New-Item -ItemType Directory -Force -Path $batchRoot | Out-Null
            $batchDir = $batchRoot
            # ---- clone in small waves so the free-space guard can stop a batch early
            $wave = [Math]::Max(1, $Parallel * 2)
            $idx = 0; $deferred = New-Object System.Collections.Generic.List[object]
            while ($idx -lt $batch.Count) {
                if ((Get-FreeGB $batchRoot) -lt $MinFreeGB) {
                    for ($j = $idx; $j -lt $batch.Count; $j++) { $deferred.Add($batch[$j]) }
                    Write-Host ("  free space below {0} GB - stopping this batch early, {1} repos wait for the next one" -f $MinFreeGB, $deferred.Count) -ForegroundColor Yellow
                    break
                }
                $chunk = @($batch[$idx..([Math]::Min($idx + $wave, $batch.Count) - 1)])
                $idx += $chunk.Count
                if ($PSVersionTable.PSVersion.Major -ge 7 -and $Parallel -gt 1) {
                    $res = @($chunk | ForEach-Object -ThrottleLimit $Parallel -Parallel {
                        $w = [scriptblock]::Create($using:workerText)
                        & $w $_ (Join-Path $using:batchRoot $_.Name) $using:sparseLines
                    })
                } else {
                    $w = [scriptblock]::Create($workerText)
                    $res = @($chunk | ForEach-Object { & $w $_ (Join-Path $batchRoot $_.Name) $sparseLines })
                }
                foreach ($x in $res) {
                    $br = $chunk | Where-Object { $_.Name -eq $x.Name } | Select-Object -First 1
                    if ($x.Status -eq 'cloned') { $cloned.Add($br) }
                    else {
                        $st = if ($x.Status -eq 'empty') { 'empty' } else { 'failed' }
                        $state[$x.Name] = [pscustomobject]@{ Repo = $x.Name; RepoUrl = $br.CloneUrl; Provider = $script:ProviderUsed; DefaultBranch = $br.Branch; LastCommit = ''; Sha = ''; ScannedAt = $now; Batch = $batchNo; Status = $st; Message = $x.Detail; ExposedRows = 0; UsedRows = 0; ApiSizeMB = $br.SizeMB }
                        if ($st -eq 'failed') { $totalFailed++; Write-Host ("  FAILED {0}: {1}" -f $x.Name, $x.Detail) -ForegroundColor Yellow }
                    }
                }
                Write-Progress -Activity "Batch $batchNo : cloning" -Status "$idx / $($batch.Count)" -PercentComplete (100 * $idx / [Math]::Max(1, $batch.Count))
            }
            Write-Progress -Activity "Batch $batchNo : cloning" -Completed
            if ($deferred.Count -gt 0) {
                if ($cloned.Count -eq 0 -and -not ($batch | Where-Object { $state.ContainsKey($_.Name) -and $state[$_.Name].Batch -eq $batchNo })) {
                    throw ("Free space on the work drive is below -MinFreeGB ({0} GB) even before the first clone. Free some space, lower -MinFreeGB, or point -WorkPath at a bigger drive." -f $MinFreeGB)
                }
                $rest = @($queue.ToArray()); $queue = New-Object 'System.Collections.Generic.Queue[object]'
                foreach ($d in $deferred) { $queue.Enqueue($d) }; foreach ($x in $rest) { $queue.Enqueue($x) }
            }
            Write-Host ("  cloned {0}/{1}; disk used by clones: {2:N1} GB" -f $cloned.Count, $batch.Count, ((Get-ChildItem -LiteralPath $batchRoot -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1GB))
        }

        # ---- harvest
        if ($cloned.Count -gt 0) {
            Write-Host '  harvesting ...'
            Invoke-Harvest $batchDir $cloned $batchNo
            foreach ($br in $cloned) {
                $dir = if ($FromFolder) { $br.Dir } else { Join-Path $batchDir $br.Name }
                $gi = Get-RepoGitInfo $dir
                $state[$br.Name] = [pscustomobject]@{ Repo = $br.Name; RepoUrl = $(if ($br.CloneUrl) { ($br.CloneUrl -replace '://[^/@]+@', '://') } else { $gi.Url }); Provider = $script:ProviderUsed; DefaultBranch = $(if ($gi.Branch) { $gi.Branch } else { $br.Branch })
                    LastCommit = $gi.LastCommit; Sha = $gi.Sha; ScannedAt = $now; Batch = $batchNo; Status = 'ok'; Message = ''; ExposedRows = $br.ExposedRows; UsedRows = $br.UsedRows; ApiSizeMB = $br.SizeMB }
            }
        }
        Save-State
        if (-not $FromFolder -and -not $KeepClones) { Remove-Tree $batchRoot; Write-Host '  clones deleted' }
        $totalDone += $cloned.Count
        Write-Host ("  inventory now covers {0}/{1} repos" -f $totalDone, $wanted.Count) -ForegroundColor Green
    }
} finally {
    foreach ($n in $saved.Keys) { [Environment]::SetEnvironmentVariable($n, $saved[$n]) }
    Save-State
    Merge-Inventory
}
$ok = @($state.Values | Where-Object Status -eq 'ok').Count
$bad = @($state.Values | Where-Object Status -eq 'failed')
Write-Host ''
Write-Host ("Inventory: {0} repos OK, {1} failed (re-run the same command to retry them)  ->  {2}" -f $ok, $bad.Count, $InventoryPath) -ForegroundColor $(if ($bad.Count) { 'Yellow' } else { 'Green' })
