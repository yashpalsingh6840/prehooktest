# EndpointScan.Facts.ps1
# Shared by Build-UrlInventory.ps1 and Find-HomeRepoUsage.ps1. Dot-sourced - do not run directly.
# Needs EndpointScan.Common.ps1 to be dot-sourced first (CsMasker, Get-RepoFiles, Read-Text, Test-IsTestPath ...).

# ---- compiled hot path ------------------------------------------------------------------------------------------
# URL classification, HTTP-verb hints and the literal scan of code files run in C#: the same rules as the PowerShell
# versions kept further below (Get-VerbHint / Get-LineAt), ~100x faster. C# 5 syntax only (Windows PowerShell 5.1 compiler).
if (-not ('FactScan' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Concurrent;

public sealed class UrlParts { public string Class; public string Host; public string Path; public string Raw; }
public sealed class FactRec { public string Repo { get; set; } public string Kind { get; set; } public string Value { get; set; } public string Host { get; set; } public string UrlPath { get; set; } public string Verb { get; set; } public string Detail { get; set; } public string File { get; set; } public int Line { get; set; } public int Count { get; set; } }

public static class FactScan
{
    const RegexOptions C = RegexOptions.Compiled;
    const RegexOptions CI = RegexOptions.Compiled | RegexOptions.IgnoreCase;
    static readonly Regex IgnoreHostRx = new Regex(@"(^|\.)(schemas\.[\w.]+|w3\.org|purl\.org|tempuri\.org|xmlsoap\.org|oasis-open\.org|openxmlformats\.org|microsoft\.com|aka\.ms|nuget\.org|shields\.io|localhost|127\.0\.0\.1|0\.0\.0\.0|example\.(com|org)|xmlns\.com|json-schema\.org|npmjs\.(com|org)|jquery\.com|googleapis\.com|gstatic\.com|cloudflare\.com|cdnjs\.[\w.]+|jsdelivr\.net|unpkg\.com|bootstrapcdn\.com|fontawesome\.com|google\.com|github\.com|githubusercontent\.com)$", CI);
    static readonly Regex StaticExtRx = new Regex(@"\.(png|jpe?g|gif|svg|css|scss|less|js|mjs|ts|tsx|map|html?|cshtml|razor|aspx|ascx|xml|xsd|xsl|xslt|json|resx|config|txt|md|pdf|dll|exe|ico|woff2?|ttf|eot|zip|csv|sql|cs|vb|csproj|sln|yml|yaml|ps1|bat|cmd|sh|log|bak)$", CI);
    static readonly Regex UrlRx = new Regex(@"^(?<scheme>(?:https?|net\.tcp|net\.pipe|net\.msmq|wss?|soap\.tcp))://(?<host>[^/:?#\s]+)(?::(?<port>\d+))?(?<path>/[^?#\s]*)?", CI);
    static readonly Regex OtherSchemeRx = new Regex(@"^[a-zA-Z][a-zA-Z0-9+.-]*://", C);
    static readonly Regex SvcRx = new Regex(@"\.svc(\b|$|[/?#])", CI);
    static readonly Regex SvcAnyRx = new Regex(@"\.svc", CI);
    static readonly Regex PlaceholderRx = new Regex(@"\{\{[^}]*\}\}|\$?\{[^}]*\}|%7B[^%]*%7D", C);
    static readonly Regex WsRx = new Regex(@"\s", C);
    static readonly Regex BadRelRx = new Regex(@"^(\.{1,2}/|@|#)", CI);
    static readonly Regex MimeRx = new Regex(@"^(application|text|image|multipart|audio|video|font)$", CI);
    static readonly Regex SegOkRx = new Regex(@"^[\w\-\.{}$~%@:]+$", C);
    static readonly Regex WordRx = new Regex(@"[a-z]{3}", CI);
    static readonly Regex WireCtxRx = new Regex(@"Namespace\s*=|xmlns|\[ServiceContract|ReplyAction|\bAction\s*=|targetNamespace|schemaLocation", CI);
    static readonly Regex DefLineRx = new Regex(@"\[[^\]]*\b(Route|RoutePrefix|Http(Get|Post|Put|Delete|Patch|Head|Options)|AcceptVerbs)\b|\.Map(Get|Post|Put|Delete|Patch|Methods|Group)\s*\(", C);
    static readonly Regex ImportRx = new Regex(@"^(import\b|export\b.*\bfrom\b|using\b|#include\b)|\brequire\s*\(", CI);
    static readonly Regex LitD = new Regex(@"(?:\$@|@\$|\$|@)?""(?<s>[^""\r\n]{4,300})""|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s""'<>)]{4,300})", C);
    static readonly Regex LitJs = new Regex(@"""(?<s>[^""\r\n]{4,300})""|'(?<s2>[^'\r\n]{4,300})'|`(?<s3>[^`]{4,300})`|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s""'`<>)]{4,300})", C);
    static readonly Regex JsCommentRx = new Regex(@"^[ \t]*(?://|/\*|\*).*$", RegexOptions.Compiled | RegexOptions.Multiline);
    static readonly Regex VerbRx = new Regex(
        @"HttpMethod\.(?<v1>Get|Post|Put|Delete|Patch)\b" +
        @"|\b(?<v2>Get|Post|Put|Delete|Patch)(?:Async|FromJsonAsync|AsJsonAsync|ByteArrayAsync|StringAsync|StreamAsync)\b" +
        @"|\[(?<v3>Get|Post|Put|Delete|Patch)\s*\(" +
        @"|Method\.(?<v4>Get|Post|Put|Delete|Patch)\b" +
        @"|\.(?<v5>Get|Post|Put|Delete|Patch)\s*<" +
        @"|new\s+HttpMethod\s*\(\s*""(?<v6>GET|POST|PUT|DELETE|PATCH)""" +
        @"|(?:[Hh]ttp|axios|[Cc]lient|[Aa]pi|[Rr]equest|[Ff]etch|ajax|\$)\w*\s*\.\s*(?<v7>get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(" +
        @"|(?:method|type)\s*[:=]\s*[""'`](?<v8>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)[""'`]" +
        @"|\.request\s*\(\s*[""'](?<v9>get|post|put|delete|patch)[""']", C);
    static readonly string[] VerbGroups = new string[] { "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9" };

    // identical strings are very common across files: parse each distinct string once (null results are cached too)
    static readonly ConcurrentDictionary<string, UrlParts> ParseCache = new ConcurrentDictionary<string, UrlParts>();
    static readonly UrlParts NoUrl = new UrlParts();
    static UrlParts ParseCached(string v)
    {
        UrlParts r;
        if (ParseCache.TryGetValue(v, out r)) return object.ReferenceEquals(r, NoUrl) ? null : r;
        r = Parse(v);
        if (ParseCache.Count > 200000) ParseCache.Clear();
        ParseCache[v] = (r == null) ? NoUrl : r;
        return r;
    }
    sealed class LineInfo { public string Text; public bool Blocked; public bool HasHint; public string Hint; }

    // true when the text contains anything that could be a URL / *.svc reference (cheap pre-filter: most files contain none)
    public static bool HasUrlLike(string text) { return text.IndexOf("://", StringComparison.Ordinal) >= 0 || text.IndexOf(".svc", StringComparison.OrdinalIgnoreCase) >= 0; }

    static bool IsNamespaceAttr(string name)
    {
        string n = name.ToLowerInvariant();
        return n == "xmlns" || n.StartsWith("xmlns:") || n == "targetnamespace" || n == "namespace" || n.EndsWith("schemalocation") || n == "xsi:nonamespaceschemalocation";
    }

    // Fast URL extraction for XML files that are NOT WCF configuration (Salesforce / SSIS / data / resources): no DOM and no per-element
    // work - it only looks around the places where a URL actually occurs. Kind = ConfigUrl, Detail = '@attribute' or '<element>'.
    public static List<FactRec> ScanXmlUrls(string text, int maxFacts, string repo, string file)
    {
        List<FactRec> list = new List<FactRec>();
        Dictionary<string, FactRec> seen = new Dictionary<string, FactRec>();
        int pos = 0;
        while (pos < text.Length && list.Count < maxFacts)
        {
            int i = text.IndexOf("://", pos, StringComparison.Ordinal);
            int j = text.IndexOf(".svc", pos, StringComparison.OrdinalIgnoreCase);
            if (i < 0 && j < 0) break;
            int at = (i < 0) ? j : ((j < 0) ? i : Math.Min(i, j));
            // value boundaries: the quote / tag delimiters around the occurrence
            int l = at - 1;
            while (l >= 0 && text[l] != '"' && text[l] != '\'' && text[l] != '<' && text[l] != '>') l--;
            int r = at;
            while (r < text.Length && text[r] != '"' && text[r] != '\'' && text[r] != '<' && text[r] != '>') r++;
            pos = r + 1;
            if (l < 0 || r >= text.Length) continue;
            char d = text[l];
            string detail = null;
            if (d == '"' || d == '\'')
            {
                if (text[r] != d) continue;
                int k = l - 1; while (k >= 0 && char.IsWhiteSpace(text[k])) k--;
                if (k < 0 || text[k] != '=') continue;                       // not an opening quote of an attribute value
                k--; while (k >= 0 && char.IsWhiteSpace(text[k])) k--;
                int e = k; while (k >= 0 && (char.IsLetterOrDigit(text[k]) || text[k] == ':' || text[k] == '.' || text[k] == '-' || text[k] == '_')) k--;
                string name = text.Substring(k + 1, e - k);
                if (name.Length == 0 || IsNamespaceAttr(name)) continue;
                detail = "@" + name;
            }
            else if (d == '>')
            {
                if (text[r] != '<') continue;
                int k = l - 1; while (k >= 0 && text[k] != '<') k--;
                if (k < 0) continue;
                int e = k + 1; while (e < text.Length && !char.IsWhiteSpace(text[e]) && text[e] != '>' && text[e] != '/') e++;
                detail = "<" + text.Substring(k + 1, e - k - 1) + ">";
            }
            else continue;
            string v = text.Substring(l + 1, r - l - 1).Trim();
            UrlParts info = ParseCached(v);
            if (info == null || info.Class == "Route") continue;
            string key = v + "|" + detail;
            FactRec f;
            if (seen.TryGetValue(key, out f)) { f.Count++; continue; }
            int line = 1;
            for (int q = 0; q < l && q < text.Length; q++) { if (text[q] == '\n') line++; }
            f = new FactRec(); f.Repo = repo; f.File = file; f.Kind = "ConfigUrl"; f.Value = v; f.Host = info.Host; f.UrlPath = info.Path; f.Verb = ""; f.Detail = detail; f.Line = line; f.Count = 1;
            seen[key] = f; list.Add(f);
        }
        return list;
    }

    public static UrlParts Parse(string v)
    {
        if (v == null) return null;
        v = v.Trim();
        if (v.Length == 0) return null;
        if (v.Length < 4 || v.Length > 300 || WsRx.IsMatch(v)) return null;
        string host = ""; string path = v;
        Match m = UrlRx.Match(v);
        if (m.Success)
        {
            host = m.Groups["host"].Value.ToLowerInvariant();
            if (IgnoreHostRx.IsMatch(host)) return null;
            path = m.Groups["path"].Value;
        }
        else if (OtherSchemeRx.IsMatch(v)) return null;
        bool isSvc = SvcRx.IsMatch(v);
        int q = path.IndexOfAny(new char[] { '?', '#' });
        if (q >= 0) path = path.Substring(0, q);
        bool trail = path.EndsWith("/", StringComparison.Ordinal);
        path = PlaceholderRx.Replace(path, "{}");
        string[] raw = path.Trim('~', '/').ToLowerInvariant().Split('/');
        List<string> segs = new List<string>();
        foreach (string r in raw) { if (r.Length > 0) segs.Add(r); }
        while (segs.Count > 0 && segs[0] == "{}") segs.RemoveAt(0);
        string norm = string.Join("/", segs.ToArray()) + ((trail && segs.Count > 0) ? "/" : "");
        UrlParts res = new UrlParts(); res.Host = host; res.Path = norm; res.Raw = v;
        if (m.Success) { res.Class = isSvc ? "Svc" : "Url"; return res; }
        if (isSvc) { res.Class = "Svc"; return res; }
        if (v.IndexOf('\\') >= 0 || BadRelRx.IsMatch(v)) return null;
        if (segs.Count < 2) return null;
        if (MimeRx.IsMatch(segs[0])) return null;
        if (StaticExtRx.IsMatch(segs[segs.Count - 1])) return null;
        int words = 0;
        foreach (string sg in segs) { if (!SegOkRx.IsMatch(sg)) return null; if (WordRx.IsMatch(sg)) words++; }
        if (words < 1) return null;
        res.Class = "Route";
        return res;
    }

    static string LineAt(string text, int idx)
    {
        if (idx < 0 || idx >= text.Length) return "";
        int s = text.LastIndexOf('\n', Math.Max(0, idx - 1));
        int e = text.IndexOf('\n', idx);
        if (e < 0) e = text.Length;
        return text.Substring(s + 1, e - s - 1).Trim();
    }

    // HTTP verbs hinted by the line of the literal, the previous line or the next line (first line that hints anything wins)
    public static string VerbHint(string text, int idx)
    {
        List<string> probe = new List<string>();
        probe.Add(LineAt(text, idx));
        int ls = text.LastIndexOf('\n', Math.Max(0, idx - 1));
        if (ls > 0) probe.Add(LineAt(text, ls - 1));
        int le = text.IndexOf('\n', idx);
        if (le >= 0 && le + 1 < text.Length) probe.Add(LineAt(text, le + 1));
        foreach (string pt in probe)
        {
            SortedSet<string> hint = new SortedSet<string>(StringComparer.Ordinal);
            foreach (Match vm in VerbRx.Matches(pt))
                foreach (string gn in VerbGroups)
                    if (vm.Groups[gn].Success) hint.Add(vm.Groups[gn].Value.ToUpperInvariant());
            if (hint.Count > 0) return string.Join("|", new List<string>(hint).ToArray());
        }
        return "";
    }

    public static string StripJsComments(string text)
    {
        return JsCommentRx.Replace(text, delegate(Match m) { return new string(' ', m.Length); });
    }

    // text = original file, clean = same text with comments blanked (same length). Returns de-duplicated URL / route / .svc literals.
    public static List<FactRec> ScanCode(string text, string clean, bool jsLike, int maxFacts, string repo, string file)
    {
        List<FactRec> list = new List<FactRec>();
        Dictionary<string, FactRec> seen = new Dictionary<string, FactRec>();
        Regex litRx = jsLike ? LitJs : LitD;
        string[] groups = new string[] { "s", "s2", "s3", "u" };
        int lastIdx = 0, lastLine = 1;
        Dictionary<int, LineInfo> lines = new Dictionary<int, LineInfo>();     // everything that depends only on the line a literal sits on
        foreach (Match lm in litRx.Matches(clean))
        {
            if (list.Count >= maxFacts) break;
            string s = "";
            foreach (string gn in groups) { if (lm.Groups[gn].Success) { s = lm.Groups[gn].Value; break; } }
            if (s.IndexOf('/') < 0 && !SvcAnyRx.IsMatch(s)) continue;
            int ls = text.LastIndexOf('\n', Math.Max(0, lm.Index - 1));
            LineInfo li;
            if (!lines.TryGetValue(ls, out li))
            {
                li = new LineInfo();
                li.Text = LineAt(text, lm.Index);
                li.Blocked = WireCtxRx.IsMatch(li.Text) || DefLineRx.IsMatch(li.Text) || ImportRx.IsMatch(li.Text);
                lines[ls] = li;
            }
            if (li.Blocked) continue;
            UrlParts info = ParseCached(s);
            if (info == null) continue;
            string kind = info.Class == "Svc" ? "ServiceUrl" : (info.Class == "Url" ? "UrlLiteral" : "RouteLiteral");
            string verb = "";
            if (info.Class != "Svc") { if (!li.HasHint) { li.Hint = VerbHint(clean, lm.Index); li.HasHint = true; } verb = li.Hint; }
            string key = kind + "|" + s + "||" + verb;
            FactRec f;
            if (seen.TryGetValue(key, out f)) { f.Count++; continue; }
            int idx = lm.Index;                              // matches arrive in increasing order: count newlines incrementally
            for (int i = lastIdx; i < idx && i < text.Length; i++) { if (text[i] == '\n') lastLine++; }
            lastIdx = idx;
            f = new FactRec(); f.Repo = repo; f.File = file; f.Kind = kind; f.Value = s; f.Host = info.Host; f.UrlPath = info.Path; f.Verb = verb; f.Detail = ""; f.Line = lastLine; f.Count = 1;
            seen[key] = f; list.Add(f);
        }
        return list;
    }
}
'@
}

#region URL helpers ---------------------------------------------------------------------------------------------
$script:IgnoreHostRx = New-Object System.Text.RegularExpressions.Regex('(?i)(^|\.)(schemas\.[\w.]+|w3\.org|purl\.org|tempuri\.org|xmlsoap\.org|oasis-open\.org|openxmlformats\.org|microsoft\.com|aka\.ms|nuget\.org|shields\.io|localhost|127\.0\.0\.1|0\.0\.0\.0|example\.(com|org)|xmlns\.com|json-schema\.org|npmjs\.(com|org)|jquery\.com|googleapis\.com|gstatic\.com|cloudflare\.com|cdnjs\.[\w.]+|jsdelivr\.net|unpkg\.com|bootstrapcdn\.com|fontawesome\.com|google\.com|github\.com|githubusercontent\.com)$')
$script:StaticExtRx = New-Object System.Text.RegularExpressions.Regex('(?i)\.(png|jpe?g|gif|svg|css|scss|less|js|mjs|ts|tsx|map|html?|cshtml|razor|aspx|ascx|xml|xsd|xsl|xslt|json|resx|config|txt|md|pdf|dll|exe|ico|woff2?|ttf|eot|zip|csv|sql|cs|vb|csproj|sln|yml|yaml|ps1|bat|cmd|sh|log|bak)$')
$script:UrlRx = New-Object System.Text.RegularExpressions.Regex('^(?<scheme>(?:https?|net\.tcp|net\.pipe|net\.msmq|wss?|soap\.tcp))://(?<host>[^/:?#\s]+)(?::(?<port>\d+))?(?<path>/[^?#\s]*)?', 'IgnoreCase')
$script:WireCtxRx = New-Object System.Text.RegularExpressions.Regex('Namespace\s*=|xmlns|\[ServiceContract|ReplyAction|\bAction\s*=|targetNamespace|schemaLocation', 'IgnoreCase')
$script:DefLineRx = New-Object System.Text.RegularExpressions.Regex('\[[^\]]*\b(Route|RoutePrefix|Http(Get|Post|Put|Delete|Patch|Head|Options)|AcceptVerbs)\b|\.Map(Get|Post|Put|Delete|Patch|Methods|Group)\s*\(')

# Classifies a string. Returns $null when it does not look like a URL / route / .svc reference, otherwise
#   @{ Class = 'Url'|'Route'|'Svc'; Host; Path (normalised: lower-case, {} for placeholders, trailing '/' kept); Raw }
function Get-UrlInfo([string]$v) {
    $r = [FactScan]::Parse($v)
    if ($null -eq $r) { return $null }
    return @{ Class = $r.Class; Host = $r.Host; Path = $r.Path; Raw = $r.Raw }
}

# Splits a stored UrlPath back into segments + trailing-slash flag
function Split-UrlPath([string]$p) {
    $trail = $p.EndsWith('/')
    [pscustomobject]@{ Segs = @($p.Trim('/') -split '/' | Where-Object { $_ -ne '' }); Trail = $trail }
}

# Does a literal (segments, trailing-slash flag) match a REST route cluster-like object { Segs; SegRx }?  -> 'Full' | 'Prefix' | $null
function Test-RouteMatch($c, $lit, [bool]$trail = $false) {
    $n = [Math]::Min($lit.Count, $c.Segs.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $p = $c.SegRx[$i]; $sg = $lit[$i]
        if ($null -eq $p) { if ($c.Segs[$i] -ne $sg) { return $null } }        # fixed word: must be equal (a runtime placeholder does not match it)
        elseif ($p -is [string]) { }                                            # pure {param}
        else { if ($sg -ne '{}' -and -not $p.IsMatch($sg)) { return $null } }  # v{version}
    }
    if ($lit.Count -eq $c.Segs.Count) { return 'Full' }
    if ($lit.Count -lt $c.Segs.Count) {
        if ($trail -and $c.Segs.Count -eq $lit.Count + 1 -and $c.SegRx[$lit.Count] -is [string]) { return 'Full' }   # "api/orders/" + id
        return 'Prefix'
    }
    return $null
}

# Builds SegRx / StaticCount / Key for a normalised route
function New-RouteShape([string]$routeNorm) {
    $segs = @($routeNorm.Trim('/') -split '/' | Where-Object { $_ -ne '' })
    $rx = @()
    foreach ($sg in $segs) {
        if ($sg -eq '{}') { $rx += '*' }
        elseif ($sg.Contains('{}')) { $rx += (New-Object System.Text.RegularExpressions.Regex(('^' + (($sg -split [regex]::Escape('{}') | ForEach-Object { [regex]::Escape($_) }) -join '.+') + '$'))) }
        else { $rx += $null }
    }
    $n = 0; foreach ($sg in $segs) { if ($sg.Contains('{')) { break }; $n++ }
    $key = ''; if ($n -ge 2) { $key = $segs[0] + '/' + $segs[1] } elseif ($n -eq 1) { $key = $segs[0] }
    $strong = @($segs | Where-Object { ($_ -replace '\{\}', '') -match '[a-z]{3}' }).Count
    [pscustomobject]@{ Segs = $segs; SegRx = $rx; StaticCount = $n; StrongCount = $strong; Key = $key }
}
#endregion

#region HTTP verb hints --------------------------------------------------------------------------------------------
$script:RxVerbHint = New-Object System.Text.RegularExpressions.Regex((@(
    'HttpMethod\.(?<v1>Get|Post|Put|Delete|Patch)\b',
    '\b(?<v2>Get|Post|Put|Delete|Patch)(?:Async|FromJsonAsync|AsJsonAsync|ByteArrayAsync|StringAsync|StreamAsync)\b',
    '\[(?<v3>Get|Post|Put|Delete|Patch)\s*\(',
    'Method\.(?<v4>Get|Post|Put|Delete|Patch)\b',
    '\.(?<v5>Get|Post|Put|Delete|Patch)\s*<',
    'new\s+HttpMethod\s*\(\s*"(?<v6>GET|POST|PUT|DELETE|PATCH)"',
    '(?:[Hh]ttp|axios|[Cc]lient|[Aa]pi|[Rr]equest|[Ff]etch|ajax|\$)\w*\s*\.\s*(?<v7>get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(',
    '(?:method|type)\s*[:=]\s*["''`](?<v8>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)["''`]',
    '\.request\s*\(\s*["''](?<v9>get|post|put|delete|patch)["'']'
) -join '|'), 'Compiled')
$script:VerbGroups = 'v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8', 'v9'

function Get-LineAt([string]$text, [int]$idx) {
    if ($idx -lt 0 -or $idx -ge $text.Length) { return '' }
    $s = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); $e = $text.IndexOf("`n", $idx)
    if ($e -lt 0) { $e = $text.Length }
    return $text.Substring($s + 1, $e - $s - 1).Trim()
}

# HTTP verbs hinted by the line of the literal, the previous line or the next line ('' when none)
function Get-VerbHint([string]$text, [int]$idx) {
    $probe = New-Object System.Collections.Generic.List[string]
    $probe.Add((Get-LineAt $text $idx))
    $ls = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); if ($ls -gt 0) { $probe.Add((Get-LineAt $text ($ls - 1))) }
    $le = $text.IndexOf("`n", $idx); if ($le -ge 0 -and $le + 1 -lt $text.Length) { $probe.Add((Get-LineAt $text ($le + 1))) }
    foreach ($pt in $probe) {
        $hint = New-Object 'System.Collections.Generic.SortedSet[string]'
        foreach ($vm in $script:RxVerbHint.Matches($pt)) { foreach ($gn in $script:VerbGroups) { if ($vm.Groups[$gn].Success) { [void]$hint.Add($vm.Groups[$gn].Value.ToUpperInvariant()) } } }
        if ($hint.Count -gt 0) { return ($hint -join '|') }
    }
    return ''
}
#endregion

#region harvest ----------------------------------------------------------------------------------------------------
$script:RxLitD  = New-Object System.Text.RegularExpressions.Regex('(?:\$@|@\$|\$|@)?"(?<s>[^"\r\n]{4,300})"|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300})', 'Compiled')
$script:RxLitJs = New-Object System.Text.RegularExpressions.Regex('"(?<s>[^"\r\n]{4,300})"|''(?<s2>[^''\r\n]{4,300})''|`(?<s3>[^`]{4,300})`|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''`<>)]{4,300})', 'Compiled')
$script:RxClientType = New-Object System.Text.RegularExpressions.Regex('(?<k>ChannelFactory|DuplexChannelFactory|DuplexClientBase|ClientBase)\s*<\s*(?<t>[\w\.]+)', 'Compiled')
$script:CodeExt  = @('.cs', '.vb', '.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx')
$script:JsLike   = @('.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx', '.ps1', '.sh')
$script:JsonCfgRx = New-Object System.Text.RegularExpressions.Regex('(?i)^(appsettings.*|.*config.*|.*settings.*|ocelot.*|environment.*|env.*|host|local\.settings|services.*|endpoints.*)\.json$')
$script:SkipFileRx = New-Object System.Text.RegularExpressions.Regex('(?i)package-lock\.json|\.min\.|\.bundle\.|\.d\.ts$|\.(g|designer)\.cs$|AssemblyInfo\.cs$|launchSettings\.json$|^(swagger|openapi)[^\\/]*\.(json|ya?ml)$|\.csproj(\.user)?$|\.(props|targets|resx|xaml|nuspec|vcxproj|sln)$')

function Add-XmlFacts($node, [string]$path, [string]$text, [string]$rel, $addFact) {
    foreach ($ch in $node.ChildNodes) {
        if ($ch.NodeType -ne 'Element') { continue }
        $name = $ch.LocalName
        $ctxName = $name
        foreach ($idAttr in 'key', 'name') { $a = $ch.GetAttribute($idAttr); if ($a) { $ctxName = "$name[$idAttr=$a]"; break } }
        $here = if ($path) { "$path/$ctxName" } else { $ctxName }
        if ($name -eq 'endpoint' -and $path -match '(^|/)client$') {
            $addr = $ch.GetAttribute('address')
            $detail = 'contract=' + $ch.GetAttribute('contract') + ';binding=' + $ch.GetAttribute('binding') + ';name=' + $ch.GetAttribute('name')
            & $addFact 'SoapClientEndpoint' $addr $detail $rel $addr
        }
        foreach ($attr in $ch.Attributes) {
            $v = $attr.Value
            if (-not $v -or $attr.Name -match '^(?i:xmlns(:.*)?|targetNamespace|namespace|.*schemaLocation)$') { continue }     # XML namespaces are not endpoints
            $info = Get-UrlInfo $v
            if ($info -and ($info.Class -ne 'Route' -or $attr.Name -match '(?i)^(address|baseaddress|url|uri|endpoint|location)$')) {
                if ($name -eq 'endpoint' -and $path -match '(^|/)client$' -and $attr.Name -eq 'address') { continue }   # already recorded as SoapClientEndpoint
                & $addFact 'ConfigUrl' $v ("$here@" + $attr.Name) $rel $v
            }
        }
        if ($ch.ChildNodes.Count -eq 1 -and $ch.FirstChild.NodeType -eq 'Text') {
            $t = "$($ch.InnerText)".Trim()
            if ($t) { $info = Get-UrlInfo $t; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $t $here $rel $t } }
        }
        Add-XmlFacts $ch $here $text $rel $addFact
    }
}

# Returns facts about everything this repo calls / is configured to call.
#   @{ Repo; Kind; Value; Host; UrlPath; Verb; Detail; File; Line; Count }
# Kinds: ConfigUrl, SoapClientEndpoint, ServiceUrl (*.svc), UrlLiteral (absolute URL in code), RouteLiteral (relative route in code), ClientType (ChannelFactory<T>/ClientBase<T>)
function Get-RepoUsedFacts {
    param([string]$RepoDir, [string]$RepoName, [string[]]$ExcludeDir, [switch]$IncludeTests, [int]$MaxPerFile = 300, [int]$MaxPerRepo = 20000, [int]$MaxFileMB = 2, [hashtable]$Stats,
        # stop scanning this repo after this many minutes (the facts found so far are kept)
        [double]$MaxMinutes = 10,
        # called every -ProgressSeconds with (filesDone, filesTotal, currentFile, factsSoFar)
        [scriptblock]$OnProgress, [int]$ProgressSeconds = 15)
    if ($Stats) { $Stats.Files = 0; $Stats.TotalFiles = 0; $Stats.MaxedOut = $false; $Stats.TimedOut = $false; $Stats.Skipped = 0 }
    $clock = [System.Diagnostics.Stopwatch]::StartNew(); $beat = [System.Diagnostics.Stopwatch]::StartNew(); $seenFiles = 0
    $out = New-Object System.Collections.Generic.List[object]
    $rootLen = $RepoDir.TrimEnd('\', '/').Length
    $allFiles = Get-RepoFiles -Dir $RepoDir -ExcludeDir $ExcludeDir
    if ($Stats) { $Stats.TotalFiles = $allFiles.Count }
    foreach ($f in $allFiles) {
        if ($out.Count -ge $MaxPerRepo) { if ($Stats) { $Stats.MaxedOut = $true }; break }
        $seenFiles++
        if ($clock.Elapsed.TotalMinutes -ge $MaxMinutes) { if ($Stats) { $Stats.TimedOut = $true }; break }       # one huge repo must not block the whole run
        if ($OnProgress -and $beat.Elapsed.TotalSeconds -ge $ProgressSeconds) { & $OnProgress $seenFiles $allFiles.Count ($f.Substring([Math]::Min($RepoDir.Length, $f.Length)).TrimStart('\', '/')) $out.Count; $beat.Restart() }
        $leaf = [System.IO.Path]::GetFileName($f)
        $ext = [System.IO.Path]::GetExtension($f).ToLowerInvariant()
        if ($script:SkipFileRx.IsMatch($leaf)) { continue }
        $isCfgXml = $ext -in '.config', '.xml', '.svcmap', '.wsdl'
        $isCfgJson = ($ext -eq '.json' -and $script:JsonCfgRx.IsMatch($leaf))
        $isCfgText = $ext -in '.yml', '.yaml', '.properties', '.env', '.ini', '.tfvars', '.http'
        $isCode = $script:CodeExt -contains $ext
        $isScript = $ext -in '.ps1', '.sh', '.bat', '.cmd'
        if (-not ($isCfgXml -or $isCfgJson -or $isCfgText -or $isCode -or $isScript)) { continue }
        $rel = ($f.Substring($rootLen).TrimStart('\', '/')) -replace '\\', '/'
        if (-not $IncludeTests -and (Test-IsTestPath $rel)) { continue }
        $text = Read-Text $f $MaxFileMB
        if (-not $text -or $text.Length -lt 8) { continue }
        if ($Stats) { $Stats.Files++ }

        $seen = @{}; $st = @{ n = 0 }      # reference types: the scriptblock below runs in a child scope and cannot update plain variables
        $addFact = {
            param($kind, $value, $detail, $file, $raw, $line = 0, $verb = '')
            if ($st.n -ge $MaxPerFile -or [string]::IsNullOrWhiteSpace($value)) { return }
            $key = "$kind|$value|$detail|$verb"      # the verb is part of the identity: GET and POST on the same URL are different calls
            if ($seen.ContainsKey($key)) { $seen[$key].Count++; return }
            $info = Get-UrlInfo $value
            if ($line -le 0) { $idx = $text.IndexOf($raw, [StringComparison]::Ordinal); $line = if ($idx -ge 0) { [CsMasker]::Line($text, $idx) } else { 1 } }
            $obj = [pscustomobject][ordered]@{
                Repo = $RepoName; Kind = $kind; Value = $value; Host = $(if ($info) { $info.Host } else { '' }); UrlPath = $(if ($info) { $info.Path } else { '' })
                Verb = $verb; Detail = $detail; File = $file; Line = $line; Count = 1
            }
            $seen[$key] = $obj; $out.Add($obj); $st.n++
        }

        try {
            if ($isCfgXml) {
                # Most XML (Salesforce / SSIS / data / resources) contains no URL at all: skip it without parsing. Parsing every element in
                # PowerShell costs ~1.6 s per 300 KB file - thousands of such files would take hours.
                $isWcfStyle = ($ext -ne '.xml') -and ($text.IndexOf('<client', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or $text.IndexOf('serviceModel', [StringComparison]::OrdinalIgnoreCase) -ge 0)
                if (-not $isWcfStyle -and -not [FactScan]::HasUrlLike($text)) { if ($Stats) { $Stats.Skipped++ } }
                elseif ($ext -eq '.xml' -or $text.Length -gt 512KB) {
                    $xf = [FactScan]::ScanXmlUrls($text, [Math]::Max(0, $MaxPerFile - $st.n), $RepoName, $rel)      # compiled regex scan, no DOM
                    $out.AddRange($xf); $st.n += $xf.Count
                } else {
                    $doc = $null
                    try { $doc = [xml]$text } catch { }
                    if ($doc -and $doc.DocumentElement) { Add-XmlFacts $doc.DocumentElement $doc.DocumentElement.LocalName $text $rel $addFact }
                    else { foreach ($m in [regex]::Matches($text, '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300}')) { if (Get-UrlInfo $m.Value) { & $addFact 'ConfigUrl' $m.Value 'text' $rel $m.Value ([CsMasker]::Line($text, $m.Index)) } } }
                }
            }
            elseif ($isCfgJson) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    $ln = $lines[$i]
                    $kvs = [regex]::Matches($ln, '"(?<k>[^"\\]{1,120})"\s*:\s*"(?<v>[^"\\]{3,300})"')
                    if ($kvs.Count -gt 0) { foreach ($kv in $kvs) { $info = Get-UrlInfo $kv.Groups['v'].Value; if ($info) { & $addFact 'ConfigUrl' $kv.Groups['v'].Value ('key=' + $kv.Groups['k'].Value) $rel $kv.Groups['v'].Value ($i + 1) } } }
                    else { $b = [regex]::Match($ln, '^\s*"(?<v>[^"\\]{3,300})"\s*,?\s*$'); if ($b.Success) { $info = Get-UrlInfo $b.Groups['v'].Value; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $b.Groups['v'].Value 'array item' $rel $b.Groups['v'].Value ($i + 1) } } }
                }
            }
            elseif (($isCfgText -or $isScript) -and -not [FactScan]::HasUrlLike($text)) { if ($Stats) { $Stats.Skipped++ } }
            elseif ($isCfgText -or $isScript) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    foreach ($m in [regex]::Matches($lines[$i], '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)\]]{4,300}')) {
                        if (Get-UrlInfo $m.Value) { & $addFact $(if ($isScript) { 'UrlLiteral' } else { 'ConfigUrl' }) $m.Value ('line text') $rel $m.Value ($i + 1) }
                    }
                }
            }
            else {   # code
                if ($ext -eq '.cs') { $clean = ([CsMasker]::Process($text))[0] }
                elseif ($ext -in '.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte') { $clean = [FactScan]::StripJsComments($text) }
                else { $clean = $text }
                $codeFacts = [FactScan]::ScanCode($text, $clean, [bool]($script:JsLike -contains $ext), [Math]::Max(0, $MaxPerFile - $st.n), $RepoName, $rel)
                $out.AddRange($codeFacts)                      # the compiled objects are used as they are (Repo, Kind, Value, Host, UrlPath, Verb, Detail, File, Line, Count)
                $st.n += $codeFacts.Count
                if ($ext -in '.cs', '.vb') {
                    foreach ($ct in $script:RxClientType.Matches($clean)) {
                        $t = Get-ShortName $ct.Groups['t'].Value
                        & $addFact 'ClientType' $t $ct.Groups['k'].Value $rel $ct.Value ([CsMasker]::Line($text, $ct.Index))
                    }
                }
            }
        } catch { }
    }
    return $out
}
#endregion
