# EndpointScan.Facts.ps1
# Shared by Build-UrlInventory.ps1 and Find-HomeRepoUsage.ps1. Dot-sourced - do not run directly.
# Needs EndpointScan.Common.ps1 to be dot-sourced first (CsMasker, Get-RepoFiles, Read-Text, Test-IsTestPath ...).

# ---- compiled hot path ------------------------------------------------------------------------------------------
# URL classification, HTTP-verb hints and the literal scan of code files run in C#: the same rules as the PowerShell
# versions kept further below (Get-VerbHint / Get-LineAt), ~100x faster. C# 5 syntax only (Windows PowerShell 5.1 compiler).
if (-not ('FactScan' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Concurrent;

public sealed class UrlParts { public string Class; public string Host; public string Path; public string Raw; }
public sealed class FactRec { public string Repo { get; set; } public string Kind { get; set; } public string Value { get; set; } public string Host { get; set; } public string UrlPath { get; set; } public string Verb { get; set; } public string Detail { get; set; } public string File { get; set; } public int Line { get; set; } public int Count { get; set; } }

public static class FactScan
{
    const RegexOptions C = RegexOptions.Compiled;
    const RegexOptions CI = RegexOptions.Compiled | RegexOptions.IgnoreCase;
    static readonly Regex IgnoreHostRx = new Regex(@"(^|\.)(schemas\.[\w.]+|w3\.org|purl\.org|tempuri\.org|xmlsoap\.org|oasis-open\.org|openxmlformats\.org|microsoft\.com|aka\.ms|nuget\.org|shields\.io|localhost|127\.0\.0\.1|0\.0\.0\.0|example\.(com|org)|xmlns\.com|json-schema\.org|npmjs\.(com|org)|jquery\.com|googleapis\.com|gstatic\.com|cloudflare\.com|cdnjs\.[\w.]+|jsdelivr\.net|unpkg\.com|bootstrapcdn\.com|fontawesome\.com|google\.com|github\.com|githubusercontent\.com)$", CI);
    static readonly Regex StaticExtRx = new Regex(@"\.(png|jpe?g|gif|svg|css|scss|less|js|mjs|ts|tsx|map|html?|cshtml|razor|aspx|ascx|xml|xsd|xsl|xslt|json|resx|config|txt|md|pdf|dll|exe|ico|woff2?|ttf|eot|zip|csv|sql|cs|vb|csproj|sln|yml|yaml|ps1|bat|cmd|sh|log|bak)$", CI);
    static readonly Regex UrlRx = new Regex(@"^(?<scheme>(?:https?|net\.tcp|net\.pipe|net\.msmq|wss?|soap\.tcp))://(?<host>[^/:?#\s]+)(?::(?<port>\d+))?(?<path>/[^?#\s]*)?", CI);
    static readonly Regex OtherSchemeRx = new Regex(@"^[a-zA-Z][a-zA-Z0-9+.-]*://", C);
    static readonly Regex SvcRx = new Regex(@"\.svc(\b|$|[/?#])", CI);
    static readonly Regex SvcAnyRx = new Regex(@"\.svc", CI);
    static readonly Regex PlaceholderRx = new Regex(@"\{\{[^}]*\}\}|\$?\{[^}]*\}|%7B[^%]*%7D", C);
    static readonly Regex WsRx = new Regex(@"\s", C);
    static readonly Regex BadRelRx = new Regex(@"^(\.{1,2}/|@|#)", CI);
    static readonly Regex MimeRx = new Regex(@"^(application|text|image|multipart|audio|video|font)$", CI);
    static readonly Regex SegOkRx = new Regex(@"^[\w\-\.{}$~%@:]+$", C);
    static readonly Regex WordRx = new Regex(@"[a-z]{3}", CI);
    static readonly Regex WireCtxRx = new Regex(@"Namespace\s*=|xmlns|\[ServiceContract|ReplyAction|\bAction\s*=|targetNamespace|schemaLocation", CI);
    static readonly Regex DefLineRx = new Regex(@"\[[^\]]*\b(Route|RoutePrefix|Http(Get|Post|Put|Delete|Patch|Head|Options)|AcceptVerbs)\b|\.Map(Get|Post|Put|Delete|Patch|Methods|Group)\s*\(", C);
    // page navigation in single-page apps (Angular router / React Router / links) is not an API call
    static readonly Regex UiRouteRx = new Regex(@"\brouterLink\b|router-link|<\s*(?:Route|Link|NavLink|Redirect|Navigate)\b|\bnavigate(?:ByUrl|To)?\s*\(|\bhistory\.(?:push|replace)\s*\(|\bredirectTo\s*:|\bhref\s*=|\bsrc\s*=|(?<![\w.])path\s*:\s*['""`]|\bto\s*=\s*[{'""`]", C);
    static readonly Regex ImportRx = new Regex(@"^(import\b|export\b.*\bfrom\b|using\b|#include\b)|\brequire\s*\(", CI);
    static readonly Regex LitD = new Regex(@"(?:\$@|@\$|\$|@)?""(?<s>[^""\r\n]{4,300})""|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s""'<>)]{4,300})", C);
    static readonly Regex LitJs = new Regex(@"""(?<s>[^""\r\n]{4,300})""|'(?<s2>[^'\r\n]{4,300})'|`(?<s3>[^`]{4,300})`|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s""'`<>)]{4,300})", C);
    static readonly Regex JsCommentRx = new Regex(@"^[ \t]*(?://|/\*|\*).*$", RegexOptions.Compiled | RegexOptions.Multiline);
    static readonly Regex VerbRx = new Regex(
        @"HttpMethod\.(?<v1>Get|Post|Put|Delete|Patch)\b" +
        @"|\b(?<v2>Get|Post|Put|Delete|Patch)(?:Async|FromJsonAsync|AsJsonAsync|ByteArrayAsync|StringAsync|StreamAsync)\b" +
        @"|\[(?<v3>Get|Post|Put|Delete|Patch)\s*\(" +
        @"|Method\.(?<v4>Get|Post|Put|Delete|Patch)\b" +
        @"|\.(?<v5>Get|Post|Put|Delete|Patch)\s*<" +
        @"|new\s+HttpMethod\s*\(\s*""(?<v6>GET|POST|PUT|DELETE|PATCH)""" +
        @"|(?:[Hh]ttp|axios|[Cc]lient|[Aa]pi|[Rr]equest|[Ff]etch|ajax|[Ss]ervice|[Rr]epository|[Rr]esource|[Ii]nstance|[Aa]gent|[Gg]ateway|[Bb]ackend|[Rr]est|[Rr]emote|\$)\w*\s*\.\s*(?<v7>get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(" +
        @"|(?:method|type)\s*[:=]\s*[""'`](?<v8>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)[""'`]" +
        @"|\.request\s*\(\s*[""'](?<v9>get|post|put|delete|patch)[""']" +
        @"|\.open\s*\(\s*[""'](?<v10>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)[""']" +
        @"|HttpRequest\s*(?:<[^>]*>)?\s*\(\s*[""'](?<v11>GET|POST|PUT|DELETE|PATCH)[""']", C);
    // ---- frontend API calls: short paths, base URLs, verbs further down -----------------------------------------------------
    static readonly Regex BaseCtxRx = new Regex(@"(?<![A-Za-z])(?:base_?url|api_?(?:url|base|root|host|prefix|endpoint|path)|base_?path|service_?url|backend_?url|server_?url|host_?url)\b", CI);
    // the literal is the direct VALUE of a base-url style setting:  baseURL: '/api'   const API_URL = process.env.X || 'http://...'
    static readonly Regex BaseAssignRx = new Regex(@"(?<![A-Za-z])(?:base_?url|api_?(?:url|base|root|host|prefix|endpoint|path)|base_?path|service_?url|backend_?url|server_?url|host_?url)\b[^'""`;()]*[:=]\s*(?:[\w.$]+\s*(?:\|\||\?\?)\s*)?$", CI);
    static readonly Regex ApiCtxRx = new Regex(@"\b(?:url|uri|endpoint)\s*:|\bquery\s*:", CI);
    static readonly Regex VerbMethodRx = new Regex(@"(?:method|type)\s*[:=]\s*[""'`](?<m>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)[""'`]", C);
    static readonly Regex NewStmtRx = new Regex(@"^(?:const|let|var|export|import|function|async|await|return|if|for|while|class|case|default)\b", C);
    static readonly Regex VerbWordRx = new Regex(@"^(?:get|post|put|delete|patch|head|options)/?$", CI);
    static readonly Regex WordLikeRx = new Regex(@"^[A-Za-z][A-Za-z0-9_\-]{2,40}/?$", C);
    static readonly string[] VerbGroups = new string[] { "v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11" };

    // identical strings are very common across files: parse each distinct string once (null results are cached too)
    static readonly ConcurrentDictionary<string, UrlParts> ParseCache = new ConcurrentDictionary<string, UrlParts>();
    static readonly UrlParts NoUrl = new UrlParts();
    static UrlParts ParseCached(string v)
    {
        UrlParts r;
        if (ParseCache.TryGetValue(v, out r)) return object.ReferenceEquals(r, NoUrl) ? null : r;
        r = Parse(v);
        if (ParseCache.Count > 200000) ParseCache.Clear();
        ParseCache[v] = (r == null) ? NoUrl : r;
        return r;
    }
    sealed class LineInfo { public string Text; public bool Blocked; public bool HasHint; public string Hint; public bool BaseCtx; public bool ApiCtx; public bool VerbOnLine; }

    static char PrevNonSpace(string t, int idx)
    {
        int i = idx - 1;
        while (i >= 0 && (t[i] == ' ' || t[i] == '\t')) i--;
        return i >= 0 ? t[i] : '\0';
    }

    // a single-segment API path such as "/orders", "orders/", `${base}/orders` (only called when the line clearly makes an HTTP call)
    static UrlParts ParseShort(string v)
    {
        string t = v.Trim();
        if (t.Length < 3 || t.Length > 100 || WsRx.IsMatch(t)) return null;
        if (t.IndexOf('\\') >= 0 || BadRelRx.IsMatch(t)) return null;
        string p = PlaceholderRx.Replace(t, "{}");
        bool trail = p.EndsWith("/", StringComparison.Ordinal);
        List<string> segs = new List<string>();
        foreach (string r in p.Trim('~', '/').ToLowerInvariant().Split('/')) { if (r.Length > 0) segs.Add(r); }
        while (segs.Count > 0 && segs[0] == "{}") segs.RemoveAt(0);
        if (segs.Count != 1) return null;
        string sg = segs[0];
        if (sg == "{}" || VerbWordRx.IsMatch(sg) || !SegOkRx.IsMatch(sg) || !WordRx.IsMatch(sg) || StaticExtRx.IsMatch(sg) || MimeRx.IsMatch(sg)) return null;
        UrlParts res = new UrlParts(); res.Class = "Route"; res.Host = ""; res.Path = sg + (trail ? "/" : ""); res.Raw = t;
        return res;
    }

    // fetch(url, {\n headers..,\n method: 'PUT' }) - the verb sits a few lines below the URL; stops at the end of the statement
    static string MethodLookahead(string text, int idx)
    {
        if (LineAt(text, idx).EndsWith(";", StringComparison.Ordinal)) return "";
        int pos = text.IndexOf('\n', idx);
        int guard = 0;
        while (pos >= 0 && pos + 1 < text.Length && guard < 6)
        {
            string ln = LineAt(text, pos + 1);
            Match m = VerbMethodRx.Match(ln);
            if (m.Success) return m.Groups["m"].Value.ToUpperInvariant();
            if (ln.EndsWith(";", StringComparison.Ordinal) || NewStmtRx.IsMatch(ln)) return "";
            pos = text.IndexOf('\n', pos + 1); guard++;
        }
        return "";
    }

    // true when the text contains anything that could be a URL / *.svc reference (cheap pre-filter: most files contain none)
    public static bool HasUrlLike(string text) { return text.IndexOf("://", StringComparison.Ordinal) >= 0 || text.IndexOf(".svc", StringComparison.OrdinalIgnoreCase) >= 0; }

    static bool IsNamespaceAttr(string name)
    {
        string n = name.ToLowerInvariant();
        return n == "xmlns" || n.StartsWith("xmlns:") || n == "targetnamespace" || n == "namespace" || n.EndsWith("schemalocation") || n == "xsi:nonamespaceschemalocation";
    }

    // Fast URL extraction for XML files that are NOT WCF configuration (Salesforce / SSIS / data / resources): no DOM and no per-element
    // work - it only looks around the places where a URL actually occurs. Kind = ConfigUrl, Detail = '@attribute' or '<element>'.
    public static List<FactRec> ScanXmlUrls(string text, int maxFacts, string repo, string file)
    {
        List<FactRec> list = new List<FactRec>();
        Dictionary<string, FactRec> seen = new Dictionary<string, FactRec>();
        int pos = 0;
        while (pos < text.Length && list.Count < maxFacts)
        {
            int i = text.IndexOf("://", pos, StringComparison.Ordinal);
            int j = text.IndexOf(".svc", pos, StringComparison.OrdinalIgnoreCase);
            if (i < 0 && j < 0) break;
            int at = (i < 0) ? j : ((j < 0) ? i : Math.Min(i, j));
            // value boundaries: the quote / tag delimiters around the occurrence
            int l = at - 1;
            while (l >= 0 && text[l] != '"' && text[l] != '\'' && text[l] != '<' && text[l] != '>') l--;
            int r = at;
            while (r < text.Length && text[r] != '"' && text[r] != '\'' && text[r] != '<' && text[r] != '>') r++;
            pos = r + 1;
            if (l < 0 || r >= text.Length) continue;
            char d = text[l];
            string detail = null;
            if (d == '"' || d == '\'')
            {
                if (text[r] != d) continue;
                int k = l - 1; while (k >= 0 && char.IsWhiteSpace(text[k])) k--;
                if (k < 0 || text[k] != '=') continue;                       // not an opening quote of an attribute value
                k--; while (k >= 0 && char.IsWhiteSpace(text[k])) k--;
                int e = k; while (k >= 0 && (char.IsLetterOrDigit(text[k]) || text[k] == ':' || text[k] == '.' || text[k] == '-' || text[k] == '_')) k--;
                string name = text.Substring(k + 1, e - k);
                if (name.Length == 0 || IsNamespaceAttr(name)) continue;
                detail = "@" + name;
            }
            else if (d == '>')
            {
                if (text[r] != '<') continue;
                int k = l - 1; while (k >= 0 && text[k] != '<') k--;
                if (k < 0) continue;
                int e = k + 1; while (e < text.Length && !char.IsWhiteSpace(text[e]) && text[e] != '>' && text[e] != '/') e++;
                detail = "<" + text.Substring(k + 1, e - k - 1) + ">";
            }
            else continue;
            string v = text.Substring(l + 1, r - l - 1).Trim();
            UrlParts info = ParseCached(v);
            if (info == null || info.Class == "Route") continue;
            string key = v + "|" + detail;
            FactRec f;
            if (seen.TryGetValue(key, out f)) { f.Count++; continue; }
            int line = 1;
            for (int q = 0; q < l && q < text.Length; q++) { if (text[q] == '\n') line++; }
            f = new FactRec(); f.Repo = repo; f.File = file; f.Kind = "ConfigUrl"; f.Value = v; f.Host = info.Host; f.UrlPath = info.Path; f.Verb = ""; f.Detail = detail; f.Line = line; f.Count = 1;
            seen[key] = f; list.Add(f);
        }
        return list;
    }

    public static UrlParts Parse(string v)
    {
        if (v == null) return null;
        v = v.Trim();
        if (v.Length == 0) return null;
        if (v.Length < 4 || v.Length > 300 || WsRx.IsMatch(v)) return null;
        string host = ""; string path = v;
        Match m = UrlRx.Match(v);
        if (m.Success)
        {
            host = m.Groups["host"].Value.ToLowerInvariant();
            if (IgnoreHostRx.IsMatch(host)) return null;
            path = m.Groups["path"].Value;
        }
        else if (OtherSchemeRx.IsMatch(v)) return null;
        bool isSvc = SvcRx.IsMatch(v);
        int q = path.IndexOfAny(new char[] { '?', '#' });
        if (q >= 0) path = path.Substring(0, q);
        bool trail = path.EndsWith("/", StringComparison.Ordinal);
        path = PlaceholderRx.Replace(path, "{}");
        string[] raw = path.Trim('~', '/').ToLowerInvariant().Split('/');
        List<string> segs = new List<string>();
        foreach (string r in raw) { if (r.Length > 0) segs.Add(r); }
        while (segs.Count > 0 && segs[0] == "{}") segs.RemoveAt(0);
        string norm = string.Join("/", segs.ToArray()) + ((trail && segs.Count > 0) ? "/" : "");
        UrlParts res = new UrlParts(); res.Host = host; res.Path = norm; res.Raw = v;
        if (m.Success) { res.Class = isSvc ? "Svc" : "Url"; return res; }
        if (isSvc) { res.Class = "Svc"; return res; }
        if (v.IndexOf('\\') >= 0 || BadRelRx.IsMatch(v)) return null;
        if (segs.Count < 2) return null;
        if (MimeRx.IsMatch(segs[0])) return null;
        if (StaticExtRx.IsMatch(segs[segs.Count - 1])) return null;
        int words = 0;
        foreach (string sg in segs) { if (!SegOkRx.IsMatch(sg)) return null; if (WordRx.IsMatch(sg)) words++; }
        if (words < 1) return null;
        res.Class = "Route";
        return res;
    }

    static string LineAt(string text, int idx)
    {
        if (idx < 0 || idx >= text.Length) return "";
        int s = text.LastIndexOf('\n', Math.Max(0, idx - 1));
        int e = text.IndexOf('\n', idx);
        if (e < 0) e = text.Length;
        return text.Substring(s + 1, e - s - 1).Trim();
    }

    // HTTP verbs hinted by the line of the literal, the previous line or the next line (first line that hints anything wins)
    public static string VerbHint(string text, int idx)
    {
        List<string> probe = new List<string>();
        probe.Add(LineAt(text, idx));
        int ls = text.LastIndexOf('\n', Math.Max(0, idx - 1));
        if (ls > 0) probe.Add(LineAt(text, ls - 1));
        int le = text.IndexOf('\n', idx);
        if (le >= 0 && le + 1 < text.Length) probe.Add(LineAt(text, le + 1));
        foreach (string pt in probe)
        {
            SortedSet<string> hint = new SortedSet<string>(StringComparer.Ordinal);
            foreach (Match vm in VerbRx.Matches(pt))
                foreach (string gn in VerbGroups)
                    if (vm.Groups[gn].Success) hint.Add(vm.Groups[gn].Value.ToUpperInvariant());
            if (hint.Count > 0) return string.Join("|", new List<string>(hint).ToArray());
        }
        return "";
    }

    public static string StripJsComments(string text)
    {
        return JsCommentRx.Replace(text, delegate(Match m) { return new string(' ', m.Length); });
    }

    // text = original file, clean = same text with comments blanked (same length). Returns de-duplicated URL / route / .svc literals.
    public static List<FactRec> ScanCode(string text, string clean, bool jsLike, int maxFacts, string repo, string file)
    {
        List<FactRec> list = new List<FactRec>();
        Dictionary<string, FactRec> seen = new Dictionary<string, FactRec>();
        Regex litRx = jsLike ? LitJs : LitD;
        string[] groups = new string[] { "s", "s2", "s3", "u" };
        int lastIdx = 0, lastLine = 1;
        Dictionary<int, LineInfo> lines = new Dictionary<int, LineInfo>();     // everything that depends only on the line a literal sits on
        foreach (Match lm in litRx.Matches(clean))
        {
            if (list.Count >= maxFacts) break;
            string s = "";
            foreach (string gn in groups) { if (lm.Groups[gn].Success) { s = lm.Groups[gn].Value; break; } }
            bool noSlash = s.IndexOf('/') < 0 && !SvcAnyRx.IsMatch(s);
            if (noSlash && !(jsLike && PrevNonSpace(clean, lm.Index) == '(' && WordLikeRx.IsMatch(s))) continue;      // 'orders' is only a candidate as the first argument of a call
            int ls = text.LastIndexOf('\n', Math.Max(0, lm.Index - 1));
            LineInfo li;
            if (!lines.TryGetValue(ls, out li))
            {
                li = new LineInfo();
                li.Text = LineAt(text, lm.Index);
                li.Blocked = WireCtxRx.IsMatch(li.Text) || DefLineRx.IsMatch(li.Text) || ImportRx.IsMatch(li.Text)
                    || (jsLike && UiRouteRx.IsMatch(li.Text) && !VerbRx.IsMatch(li.Text));      // navigation, unless the same line also makes an HTTP call
                if (jsLike) { li.BaseCtx = BaseCtxRx.IsMatch(li.Text); li.ApiCtx = ApiCtxRx.IsMatch(li.Text); li.VerbOnLine = VerbRx.IsMatch(li.Text); }
                lines[ls] = li;
            }
            if (li.Blocked) continue;
            if (noSlash && !li.VerbOnLine) continue;
            UrlParts info = noSlash ? null : ParseCached(s);
            bool isBase = false;
            if (jsLike && li.BaseCtx && !li.VerbOnLine && s.IndexOf("${", StringComparison.Ordinal) < 0)
            {
                int lineStart = ls + 1;
                isBase = BaseAssignRx.IsMatch(clean.Substring(lineStart, Math.Max(0, lm.Index - lineStart)));
            }
            if (info == null && jsLike)
            {
                // short relative API paths ("/orders", "orders") and base paths ("/api"): accepted only where the line clearly is an API call / base setting
                if (isBase) info = ParseShort(s);
                else
                {
                    if (!li.HasHint) { li.Hint = VerbHint(clean, lm.Index); if (li.Hint.Length == 0) li.Hint = MethodLookahead(clean, lm.Index); li.HasHint = true; }
                    if (li.Hint.Length > 0 || li.ApiCtx) info = ParseShort(s);
                }
            }
            if (info == null) continue;
            string kind = info.Class == "Svc" ? "ServiceUrl" : (info.Class == "Url" ? "UrlLiteral" : "RouteLiteral");
            if (isBase && info.Class != "Svc") kind = "ApiBase";
            string verb = "";
            if (info.Class != "Svc" && kind != "ApiBase") { if (!li.HasHint) { li.Hint = VerbHint(clean, lm.Index); if (jsLike && li.Hint.Length == 0) li.Hint = MethodLookahead(clean, lm.Index); li.HasHint = true; } verb = li.Hint; }
            string key = kind + "|" + s + "||" + verb;
            FactRec f;
            if (seen.TryGetValue(key, out f)) { f.Count++; continue; }
            int idx = lm.Index;                              // matches arrive in increasing order: count newlines incrementally
            for (int i = lastIdx; i < idx && i < text.Length; i++) { if (text[i] == '\n') lastLine++; }
            lastIdx = idx;
            f = new FactRec(); f.Repo = repo; f.File = file; f.Kind = kind; f.Value = s; f.Host = info.Host; f.UrlPath = info.Path; f.Verb = verb; f.Detail = ""; f.Line = lastLine; f.Count = 1;
            seen[key] = f; list.Add(f);
        }
        return list;
    }
}

// ---------------------------------------------------------------------------------------------------------------------------
// SOAP providers that are NOT a *.svc file: WSDL, ASMX, WCF mounted by ServiceRoute / ServiceHost / CoreWCF / <service> config,
// Java JAX-WS / CXF / Spring-WS / Axis / web.xml servlet mappings.  Output = FactRec of Kind "SoapProvider":
//   Value = address as written, UrlPath = normalized address (lower case, no host, {} for parameters), Detail = key=value;...
// ---------------------------------------------------------------------------------------------------------------------------
public static class SoapProviderScan
{
    const RegexOptions C = RegexOptions.Compiled;
    const RegexOptions CS = RegexOptions.Compiled | RegexOptions.Singleline;
    static readonly Regex TnsRx = new Regex(@"targetNamespace\s*=\s*[""']([^""']*)[""']", C);
    static readonly Regex WsdlBindingRx = new Regex(@"<(?:\w+:)?binding\b[^>]*>", C);
    static readonly Regex WsdlPortTypeRx = new Regex(@"<(?:\w+:)?portType\b[^>]*>(?<b>.*?)</(?:\w+:)?portType>", CS);
    static readonly Regex WsdlServiceRx = new Regex(@"<(?:\w+:)?service\b[^>]*>(?<b>.*?)</(?:\w+:)?service>", CS);
    static readonly Regex WsdlPortRx = new Regex(@"<(?:\w+:)?port\b[^>]*>(?<b>.*?)</(?:\w+:)?port>", CS);
    static readonly Regex WsdlAddrRx = new Regex(@"<(?:\w+:)?address\b[^>]*\blocation\s*=\s*[""']([^""']*)[""']", C);
    static readonly Regex WsdlOpRx = new Regex(@"<(?:\w+:)?operation\b[^>]*\bname\s*=\s*[""']([^""']+)[""']", C);
    static readonly Regex AsmxClassRx = new Regex(@"<%@\s*WebService\b[^%]*?\bClass\s*=\s*[""']([^""']+)[""']", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    static readonly Regex AsmxCodeRx = new Regex(@"\[\s*WebService\b(?:\s*\((?<a>[^)]*)\))?\s*\][\s\S]{0,400}?\bclass\s+(?<c>\w+)", C);
    static readonly Regex WebMethodRx = new Regex(@"\[\s*WebMethod\b[^\]]*\]\s*(?:public|protected|internal)?\s*[\w<>\[\],.?]+\s+(?<m>\w+)\s*\(", C);
    static readonly Regex ServiceRouteRx = new Regex(@"new\s+(?:\w+\.)*ServiceRoute\s*\(\s*""(?<p>[^""]*)""\s*,[^;]*?typeof\s*\(\s*(?<t>[\w.]+)\s*\)", CS);
    static readonly Regex MapServiceRouteRx = new Regex(@"MapServiceRoute\s*<\s*(?<t>[\w.]+)\s*>\s*\(\s*""(?<p>[^""]*)""", C);
    static readonly Regex ServiceHostRx = new Regex(@"new\s+(?:\w+\.)*ServiceHost\s*\(\s*typeof\s*\(\s*(?<t>[\w.]+)\s*\)(?:\s*,\s*new\s+(?:\w+\.)*Uri\s*\(\s*""(?<u>[^""]+)""\s*\))?", C);
    static readonly Regex AddEndpointRx = new Regex(@"AddServiceEndpoint\s*\(\s*typeof\s*\(\s*(?<c>[\w.]+)\s*\)\s*,\s*[^,]+,\s*""(?<a>[^""]*)""", C);
    static readonly Regex AddEndpointGenRx = new Regex(@"AddServiceEndpoint\s*<\s*(?<t>[\w.]+)\s*,\s*(?<c>[\w.]+)\s*>\s*\(\s*[^,]+,\s*""(?<a>[^""]*)""", C);
    static readonly Regex CfgServiceRx = new Regex(@"<service\s+[^>]*\bname\s*=\s*[""'](?<n>[^""']+)[""'][^>]*>(?<b>.*?)</service>", CS);
    static readonly Regex BaseAddrRx = new Regex(@"baseAddress\s*=\s*[""']([^""']*)[""']", C);
    static readonly Regex TagEndpointRx = new Regex(@"<endpoint\b[^>]*>", C);
    static readonly Regex JavaAnnRx = new Regex(@"@(?:javax\.jws\.|jakarta\.jws\.)?(?<k>WebServiceProvider|WebService|Endpoint)\b(?:\s*\((?<a>[^)]*)\))?", C);
    static readonly Regex JavaClassRx = new Regex(@"\b(?<k>class|interface)\s+(?<c>\w+)", C);
    static readonly Regex JavaPkgRx = new Regex(@"^\s*package\s+([\w.]+)\s*;", RegexOptions.Compiled | RegexOptions.Multiline);
    static readonly Regex JavaWebMethodRx = new Regex(@"@WebMethod\b[^\n]*\n(?:\s*@\w+(?:\([^)]*\))?\s*)*\s*(?:public\s+)?[\w<>\[\],.? ]+?\s+(?<m>\w+)\s*\(", C);
    static readonly Regex PayloadRootRx = new Regex(@"@PayloadRoot\s*\([^)]*localPart\s*=\s*""(?<m>[^""]+)""", C);
    static readonly Regex JavaPublishRx = new Regex(@"Endpoint\s*\.\s*publish\s*\(\s*""(?<u>[^""]+)""", C);
    static readonly Regex CxfTagRx = new Regex(@"<(?:\w+:)?(?:endpoint|server)\b[^>]*\baddress\s*=[^>]*>", C);
    static readonly Regex SunJaxwsRx = new Regex(@"<endpoint\b[^>]*\burl-pattern\s*=[^>]*>", C);
    static readonly Regex ServletRx = new Regex(@"<servlet>(?<b>.*?)</servlet>", CS);
    static readonly Regex ServletMapRx = new Regex(@"<servlet-mapping>(?<b>.*?)</servlet-mapping>", CS);
    static readonly Regex AxisServiceRx = new Regex(@"<service\s+[^>]*\bname\s*=\s*[""'](?<n>[^""']+)[""'][^>]*>(?<b>.*?)</service>", CS);
    static readonly Regex AxisClassRx = new Regex(@"<parameter\s+name\s*=\s*[""']ServiceClass[""'][^>]*>\s*(?<c>[\w.$]+)\s*<", C);
    static readonly Regex WsdlServletClassRx = new Regex(@"CXFServlet|AxisServlet|MessageDispatcherServlet|WSServlet|XFireServlet|SOAPServlet|ServiceServlet|JAXWSServlet", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    static string Attr(string tag, string name)
    {
        Match m = Regex.Match(tag, @"(?<![\w-])" + Regex.Escape(name) + @"\s*=\s*(?:""([^""]*)""|'([^']*)')", RegexOptions.IgnoreCase);
        if (!m.Success) return "";
        return m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value;
    }
    static string Last(string qn) { if (string.IsNullOrEmpty(qn)) return ""; int i = qn.LastIndexOfAny(new char[] { '.', ':', '$', '/' }); return i >= 0 ? qn.Substring(i + 1) : qn; }

    // address as written -> lower-case path without host / query, '{}' for parameters and wildcards
    static string NormPath(string addr)
    {
        if (string.IsNullOrWhiteSpace(addr)) return "";
        string a = addr.Trim();
        int sch = a.IndexOf("://", StringComparison.Ordinal);
        if (sch > 0) { int slash = a.IndexOf('/', sch + 3); a = slash >= 0 ? a.Substring(slash) : ""; }
        int q = a.IndexOfAny(new char[] { '?', '#' }); if (q >= 0) a = a.Substring(0, q);
        a = Regex.Replace(a, @"\{[^}]*\}|\*+", "{}");
        List<string> segs = new List<string>();
        foreach (string s in a.Trim().Trim('/', '.', '~').ToLowerInvariant().Split('/')) { if (s.Length > 0 && s != ".") segs.Add(s); }
        return string.Join("/", segs.ToArray());
    }
    static string Join(string a, string b)
    {
        string x = (a ?? "").Trim('/'), y = (b ?? "").Trim('/');
        if (x.Length == 0) return y; if (y.Length == 0) return x; return x + "/" + y;
    }

    static void Emit(List<FactRec> list, string repo, string file, int line, string src, string value, string service, string contract, string ns, string impl, string pkg, string ops)
    {
        FactRec f = new FactRec();
        f.Repo = repo; f.File = file; f.Line = line; f.Kind = "SoapProvider"; f.Verb = ""; f.Count = 1; f.Host = "";
        f.Value = string.IsNullOrEmpty(value) ? service : value;
        f.UrlPath = NormPath(value);
        f.Detail = "src=" + src + ";service=" + service + ";contract=" + contract + ";ns=" + ns + ";impl=" + impl + ";pkg=" + pkg + ";ops=" + ops;
        list.Add(f);
    }
    static int LineOf(string text, int idx) { int n = 1; for (int i = 0; i < idx && i < text.Length; i++) if (text[i] == '\n') n++; return n; }

    // does the file need the (more expensive) scan at all?
    public static bool Wants(string ext, string leaf, string text)
    {
        switch (ext)
        {
            case ".wsdl": case ".asmx": case ".wsdd": return true;
            case ".java": return text.IndexOf("WebService", StringComparison.Ordinal) >= 0 || text.IndexOf("@Endpoint", StringComparison.Ordinal) >= 0 || text.IndexOf("Endpoint.publish", StringComparison.Ordinal) >= 0;
            case ".cs": case ".vb": return text.IndexOf("ServiceRoute", StringComparison.Ordinal) >= 0 || text.IndexOf("[WebService", StringComparison.Ordinal) >= 0 || text.IndexOf("ServiceHost", StringComparison.Ordinal) >= 0 || text.IndexOf("AddServiceEndpoint", StringComparison.Ordinal) >= 0;
            case ".config": case ".xml":
                return (text.IndexOf("<service ", StringComparison.Ordinal) >= 0 && (text.IndexOf("baseAddress", StringComparison.Ordinal) >= 0 || text.IndexOf("<endpoint", StringComparison.Ordinal) >= 0 || leaf == "services.xml"))
                    || text.IndexOf("jaxws:", StringComparison.Ordinal) >= 0 || (text.IndexOf("url-pattern", StringComparison.Ordinal) >= 0 && (text.IndexOf("<endpoint", StringComparison.Ordinal) >= 0 || WsdlServletClassRx.IsMatch(text)))
                    || text.IndexOf("<wsdl:definitions", StringComparison.Ordinal) >= 0;
            default: return false;
        }
    }

    public static List<FactRec> Scan(string text, string ext, string leaf, string rel, string repo)
    {
        List<FactRec> list = new List<FactRec>();
        string lf = leaf.ToLowerInvariant();
        try
        {
            if (ext == ".wsdl" || (ext == ".xml" && text.IndexOf("<wsdl:definitions", StringComparison.Ordinal) >= 0)) ScanWsdl(text, rel, repo, list);
            else if (ext == ".asmx") { Match m = AsmxClassRx.Match(text); string cls = m.Success ? m.Groups[1].Value : ""; Emit(list, repo, rel, 1, "asmx", leaf, Last(cls), Last(cls), "", cls, "", ""); }
            else if (ext == ".wsdd") ScanAxis(text, rel, repo, list, "wsdd");
            else if (ext == ".java") ScanJava(text, rel, repo, list);
            else if (ext == ".cs" || ext == ".vb") ScanDotnet(text, rel, repo, list);
            else if (ext == ".config" || ext == ".xml")
            {
                if (text.IndexOf("<service ", StringComparison.Ordinal) >= 0 && lf == "services.xml") ScanAxis(text, rel, repo, list, "axis2");
                else if (text.IndexOf("<service ", StringComparison.Ordinal) >= 0 && (text.IndexOf("baseAddress", StringComparison.Ordinal) >= 0 || text.IndexOf("<endpoint", StringComparison.Ordinal) >= 0)) ScanWcfConfig(text, rel, repo, list);
                if (text.IndexOf("jaxws:", StringComparison.Ordinal) >= 0) ScanCxf(text, rel, repo, list);
                if (text.IndexOf("url-pattern", StringComparison.Ordinal) >= 0)
                {
                    ScanSunJaxws(text, rel, repo, list);
                    if (lf == "web.xml") ScanWebXml(text, rel, repo, list);
                }
            }
        }
        catch { }
        return list;
    }

    static void ScanWsdl(string text, string rel, string repo, List<FactRec> list)
    {
        string tns = TnsRx.Match(text).Groups[1].Value;
        Dictionary<string, string> bindType = new Dictionary<string, string>();
        foreach (Match b in WsdlBindingRx.Matches(text))
        {
            string name = Attr(b.Value, "name"), type = Attr(b.Value, "type");
            if (name.Length > 0 && type.Length > 0) bindType[name] = Last(type);
        }
        Dictionary<string, string> ptOps = new Dictionary<string, string>();
        foreach (Match p in WsdlPortTypeRx.Matches(text))
        {
            string name = Attr(p.Value.Substring(0, p.Value.IndexOf('>') + 1), "name");
            List<string> ops = new List<string>();
            foreach (Match o in WsdlOpRx.Matches(p.Groups["b"].Value)) { if (!ops.Contains(o.Groups[1].Value) && ops.Count < 40) ops.Add(o.Groups[1].Value); }
            ptOps[name] = string.Join("|", ops.ToArray());
        }
        int before = list.Count;
        foreach (Match s in WsdlServiceRx.Matches(text))
        {
            string sname = Attr(s.Value.Substring(0, s.Value.IndexOf('>') + 1), "name");
            foreach (Match pt in WsdlPortRx.Matches(s.Groups["b"].Value))
            {
                string head = pt.Value.Substring(0, pt.Value.IndexOf('>') + 1);
                string pname = Attr(head, "name"), binding = Last(Attr(head, "binding"));
                Match am = WsdlAddrRx.Match(pt.Groups["b"].Value);
                string loc = am.Success ? am.Groups[1].Value : "";
                string contract; if (!bindType.TryGetValue(binding, out contract)) contract = pname;
                string ops; if (!ptOps.TryGetValue(contract, out ops)) ops = "";
                Emit(list, repo, rel, LineOf(text, s.Index), "wsdl", loc, sname, contract + (pname.Length > 0 && pname != contract ? "|" + pname : ""), tns, "", "", ops);
            }
        }
        if (list.Count == before)      // abstract WSDL (no <service>): the port types alone still identify the contract
        {
            foreach (KeyValuePair<string, string> kv in ptOps) Emit(list, repo, rel, 1, "wsdl", "", "", kv.Key, tns, "", "", kv.Value);
        }
    }

    static void ScanDotnet(string text, string rel, string repo, List<FactRec> list)
    {
        foreach (Match m in ServiceRouteRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "serviceroute", m.Groups["p"].Value, Last(m.Groups["t"].Value), "", "", m.Groups["t"].Value, "", "");
        foreach (Match m in MapServiceRouteRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "serviceroute", m.Groups["p"].Value, Last(m.Groups["t"].Value), "", "", m.Groups["t"].Value, "", "");
        List<string> hostUris = new List<string>(); string hostType = "";
        foreach (Match m in ServiceHostRx.Matches(text))
        {
            if (hostType.Length == 0) hostType = m.Groups["t"].Value;
            if (m.Groups["u"].Success) { hostUris.Add(m.Groups["u"].Value); Emit(list, repo, rel, LineOf(text, m.Index), "servicehost", m.Groups["u"].Value, Last(m.Groups["t"].Value), "", "", m.Groups["t"].Value, "", ""); }
        }
        foreach (Match m in AddEndpointRx.Matches(text))
        {
            Emit(list, repo, rel, LineOf(text, m.Index), "servicehost", m.Groups["a"].Value, "", Last(m.Groups["c"].Value), "", "", "", "");
            string ea = m.Groups["a"].Value;
            if (hostUris.Count == 1 && ea.IndexOf("://", StringComparison.Ordinal) < 0 && ea.Length > 0)      // base address + relative endpoint address = the full address
                Emit(list, repo, rel, LineOf(text, m.Index), "servicehost", hostUris[0].TrimEnd('/') + "/" + ea.TrimStart('/'), Last(hostType), Last(m.Groups["c"].Value), "", hostType, "", "");
        }
        foreach (Match m in AddEndpointGenRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "corewcf", m.Groups["a"].Value, Last(m.Groups["t"].Value), Last(m.Groups["c"].Value), "", m.Groups["t"].Value, "", "");
        foreach (Match m in AsmxCodeRx.Matches(text))
        {
            string ns = Regex.Match(m.Groups["a"].Value, @"Namespace\s*=\s*""([^""]*)""").Groups[1].Value;
            List<string> ops = new List<string>();
            foreach (Match w in WebMethodRx.Matches(text)) { if (ops.Count < 40 && !ops.Contains(w.Groups["m"].Value)) ops.Add(w.Groups["m"].Value); }
            Emit(list, repo, rel, LineOf(text, m.Index), "asmx", "", m.Groups["c"].Value, m.Groups["c"].Value, ns, m.Groups["c"].Value, "", string.Join("|", ops.ToArray()));
        }
    }

    static void ScanWcfConfig(string text, string rel, string repo, List<FactRec> list)
    {
        foreach (Match s in CfgServiceRx.Matches(text))
        {
            string body = s.Groups["b"].Value, name = s.Groups["n"].Value;
            string basePath = "";
            Match bm = BaseAddrRx.Match(body);
            if (bm.Success) basePath = bm.Groups[1].Value;
            bool any = false;
            foreach (Match e in TagEndpointRx.Matches(body))
            {
                string contract = Attr(e.Value, "contract");
                if (contract.Length == 0 || contract.IndexOf("IMetadataExchange", StringComparison.OrdinalIgnoreCase) >= 0 || contract.IndexOf("IMetadata", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                string a = Attr(e.Value, "address");
                string full;
                if (a.IndexOf("://", StringComparison.Ordinal) > 0) full = a; else if (basePath.Length > 0) full = basePath.TrimEnd('/') + (a.Length > 0 ? "/" + a.TrimStart('/') : ""); else full = a;
                if (full.Trim().Length == 0) continue;      // address="" and no base address = the ordinary *.svc hosting, already known as a .svc service
                Emit(list, repo, rel, LineOf(text, s.Index + e.Index), "wcf-config", full, Last(name), Last(contract), "", name, "", "");
                any = true;
            }
            if (!any && basePath.Length > 0) Emit(list, repo, rel, LineOf(text, s.Index), "wcf-config", basePath, Last(name), "", "", name, "", "");
        }
    }

    static void ScanJava(string text, string rel, string repo, List<FactRec> list)
    {
        string pkg = JavaPkgRx.Match(text).Groups[1].Value;
        foreach (Match a in JavaAnnRx.Matches(text))
        {
            string args = a.Groups["a"].Value, kind = a.Groups["k"].Value;
            if (kind == "Endpoint" && text.IndexOf("springframework.ws", StringComparison.Ordinal) < 0) continue;     // @Endpoint of other frameworks is not SOAP
            Match cm = JavaClassRx.Match(text, a.Index + a.Length);
            if (!cm.Success) continue;
            string cls = cm.Groups["c"].Value;
            string svc = Attr(args, "serviceName"), port = Attr(args, "portName"), name = Attr(args, "name"), tns = Attr(args, "targetNamespace");
            string ei = Last(Attr(args, "endpointInterface"));
            List<string> ops = new List<string>();
            int end = Math.Min(text.Length, cm.Index + 60000);
            string body = text.Substring(cm.Index, end - cm.Index);
            foreach (Match w in JavaWebMethodRx.Matches(body)) { if (ops.Count < 40 && !ops.Contains(w.Groups["m"].Value)) ops.Add(w.Groups["m"].Value); }
            foreach (Match w in PayloadRootRx.Matches(body)) { if (ops.Count < 40 && !ops.Contains(w.Groups["m"].Value)) ops.Add(w.Groups["m"].Value); }
            string contract = ei.Length > 0 ? ei : (name.Length > 0 ? name : cls);
            if (port.Length > 0 && port != contract) contract = contract + "|" + port;
            Emit(list, repo, rel, LineOf(text, a.Index), kind == "Endpoint" ? "springws" : "jaxws", "", svc.Length > 0 ? svc : cls, contract, tns, (pkg.Length > 0 ? pkg + "." : "") + cls, pkg, string.Join("|", ops.ToArray()));
        }
        foreach (Match p in JavaPublishRx.Matches(text)) Emit(list, repo, rel, LineOf(text, p.Index), "jaxws", p.Groups["u"].Value, "", "", "", "", pkg, "");
    }

    static void ScanCxf(string text, string rel, string repo, List<FactRec> list)
    {
        foreach (Match t in CxfTagRx.Matches(text))
        {
            if (t.Value.IndexOf("jaxws:", StringComparison.Ordinal) < 0) continue;
            string impl = Attr(t.Value, "implementor"); if (impl.Length == 0) impl = Attr(t.Value, "serviceBean"); if (impl.Length == 0) impl = Attr(t.Value, "serviceClass");
            string svc = Attr(t.Value, "serviceName"); string port = Attr(t.Value, "endpointName");
            Emit(list, repo, rel, LineOf(text, t.Index), "cxf", Attr(t.Value, "address"), svc.Length > 0 ? Last(svc) : Last(impl), port.Length > 0 ? Last(port) : "", "", impl.TrimStart('#'), "", "");
        }
    }

    static void ScanSunJaxws(string text, string rel, string repo, List<FactRec> list)
    {
        foreach (Match t in SunJaxwsRx.Matches(text))
        {
            string impl = Attr(t.Value, "implementation"); string name = Attr(t.Value, "name");
            Emit(list, repo, rel, LineOf(text, t.Index), "jaxws", Attr(t.Value, "url-pattern"), name.Length > 0 ? name : Last(impl), Last(Attr(t.Value, "port")), "", impl, "", "");
        }
    }

    static void ScanWebXml(string text, string rel, string repo, List<FactRec> list)
    {
        Dictionary<string, string> servlets = new Dictionary<string, string>();
        foreach (Match s in ServletRx.Matches(text))
        {
            string name = Regex.Match(s.Groups["b"].Value, @"<servlet-name>\s*([^<\s]+)\s*<").Groups[1].Value;
            string cls = Regex.Match(s.Groups["b"].Value, @"<servlet-class>\s*([^<\s]+)\s*<").Groups[1].Value;
            if (name.Length > 0 && WsdlServletClassRx.IsMatch(cls)) servlets[name] = cls;
        }
        foreach (Match m in ServletMapRx.Matches(text))
        {
            string name = Regex.Match(m.Groups["b"].Value, @"<servlet-name>\s*([^<\s]+)\s*<").Groups[1].Value;
            string cls; if (!servlets.TryGetValue(name, out cls)) continue;
            foreach (Match u in Regex.Matches(m.Groups["b"].Value, @"<url-pattern>\s*([^<\s]+)\s*<"))
                Emit(list, repo, rel, LineOf(text, m.Index), "webxml", u.Groups[1].Value, name, "", "", cls, "", "");
        }
    }

    static void ScanAxis(string text, string rel, string repo, List<FactRec> list, string src)
    {
        foreach (Match s in AxisServiceRx.Matches(text))
        {
            string name = s.Groups["n"].Value;
            string cls = AxisClassRx.Match(s.Groups["b"].Value).Groups["c"].Value;
            Emit(list, repo, rel, LineOf(text, s.Index), src, "/services/" + name, name, "", "", cls, "", "");
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------------
// Where a service is MOUNTED / reachable, as declared by the provider's own repo (not by its routes):
//   path base:  app.UsePathBase("/markitapi"), PathBase / basePath / contextPath / routePrefix settings, ASPNETCORE_PATHBASE in a Dockerfile,
//               Kubernetes / OpenShift / Helm ingress paths ("path: /ZT30/AccountEnquiryBypass")
//   host name:  host / hostname entries of ingress / route / values files   (an OpenShift route name is usually the app name)
// Output = FactRec of Kind "DeployHint":  Value = path or host,  UrlPath = normalized path,  Host = host,  Detail = kind=pathbase|host;src=...
// ---------------------------------------------------------------------------------------------------------------------------
public static class DeployHintScan
{
    const RegexOptions CI = RegexOptions.Compiled | RegexOptions.IgnoreCase;
    const RegexOptions CM = RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline;
    static readonly Regex UsePathBaseRx = new Regex(@"UsePathBase\s*\(\s*(?:new\s+(?:\w+\.)*PathString\s*\(\s*)?""(?<p>/[^""]*)""", CI);
    static readonly Regex KeyPathRx = new Regex(@"(?<![A-Za-z0-9])(?:aspnetcore_pathbase|path_?base|base_?path|context_?path|context-path|route_?prefix|api_?prefix|url_?prefix|virtual_?path)[""']?\s*[:=]\s*[""']?(?<p>/[A-Za-z0-9_\-./{}]*)", CI);
    static readonly Regex IngressCtxRx = new Regex(@"kind\s*:\s*(?:Ingress|Route|VirtualService|HTTPRoute)\b|^\s*ingress\s*:|^\s*route\s*:|ingressClassName|ingress\.kubernetes\.io|nginx\.ingress", CM);
    static readonly Regex PathLineRx = new Regex(@"^\s*-?\s*path\s*:\s*[""']?(?<p>/[A-Za-z0-9_\-./{}*()?]*)", CM);
    static readonly Regex PathItemRx = new Regex(@"^\s*-\s*[""']?(?<p>/[A-Za-z0-9_\-./]+)[""']?\s*$", CM);
    static readonly Regex PrefixRx = new Regex(@"(?:prefix|uri)\s*:\s*[""']?(?<p>/[A-Za-z0-9_\-./]+)", CI);
    static readonly Regex HostLineRx = new Regex(@"^\s*-?\s*[""']?(?:host|hostname|hosts?)[""']?\s*:\s*[""']?(?<h>[a-z0-9][a-z0-9\-]*(?:\.[a-z0-9\-]+){2,})", CM);
    static readonly Regex HostItemRx = new Regex(@"^\s*-\s*[""']?(?<h>[a-z0-9][a-z0-9\-]*(?:\.[a-z0-9\-]+){2,})[""']?\s*$", CM);
    static readonly Regex HostJsonRx = new Regex(@"""(?:host|hostname)""\s*:\s*""(?<h>[a-z0-9][a-z0-9\-]*(?:\.[a-z0-9\-]+){2,})""", CI);

    static string NormPath(string p)
    {
        if (string.IsNullOrWhiteSpace(p)) return "";
        string a = p.Trim();
        a = Regex.Replace(a, @"\(\.\*\)|\(/\|\$\)|\(\.\+\)|\$$|\*+$|\?$", "");             // ingress regex / wildcard tails
        a = Regex.Replace(a, @"\{[^}]*\}", "{}");
        List<string> segs = new List<string>();
        foreach (string s in a.Trim('/', ' ').ToLowerInvariant().Split('/')) { if (s.Length > 0) segs.Add(s); }
        return string.Join("/", segs.ToArray());
    }
    static int LineOf(string text, int idx) { int n = 1; for (int i = 0; i < idx && i < text.Length; i++) if (text[i] == '\n') n++; return n; }
    static void Emit(List<FactRec> list, string repo, string file, int line, string kind, string src, string value)
    {
        FactRec f = new FactRec();
        f.Repo = repo; f.File = file; f.Line = line; f.Kind = "DeployHint"; f.Verb = ""; f.Count = 1;
        f.Value = value; f.Detail = "kind=" + kind + ";src=" + src;
        if (kind == "pathbase") { f.UrlPath = NormPath(value); f.Host = ""; if (f.UrlPath.Length == 0) return; }
        else { f.UrlPath = ""; f.Host = value.ToLowerInvariant(); }
        list.Add(f);
    }

    public static bool Wants(string ext, string leaf, string text)
    {
        switch (ext)
        {
            case ".cs": return text.IndexOf("UsePathBase", StringComparison.Ordinal) >= 0;
            case ".yml": case ".yaml": case ".properties": case ".env": case ".json": case ".tpl": case ".conf":
                return text.IndexOf("ath", StringComparison.Ordinal) >= 0 || text.IndexOf("ost", StringComparison.Ordinal) >= 0 || text.IndexOf("refix", StringComparison.Ordinal) >= 0;
            case "": return leaf.StartsWith("dockerfile", StringComparison.OrdinalIgnoreCase) && text.IndexOf("PATHBASE", StringComparison.OrdinalIgnoreCase) >= 0;
            default: return false;
        }
    }

    public static List<FactRec> Scan(string text, string ext, string leaf, string rel, string repo)
    {
        List<FactRec> list = new List<FactRec>();
        try
        {
            if (ext == ".cs") { foreach (Match m in UsePathBaseRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "pathbase", "usepathbase", m.Groups["p"].Value); return list; }
            bool yaml = ext == ".yml" || ext == ".yaml" || ext == ".tpl";
            foreach (Match m in KeyPathRx.Matches(text)) { if (m.Groups["p"].Value.Length > 1) Emit(list, repo, rel, LineOf(text, m.Index), "pathbase", "setting", m.Groups["p"].Value); }
            if (yaml || ext == ".conf")
            {
                bool ingress = IngressCtxRx.IsMatch(text);
                if (ingress)
                {
                    foreach (Match m in PathLineRx.Matches(text)) { string p = m.Groups["p"].Value; if (p.Length > 1) Emit(list, repo, rel, LineOf(text, m.Index), "pathbase", "ingress", p); }
                    foreach (Match m in PathItemRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "pathbase", "ingress", m.Groups["p"].Value);
                    foreach (Match m in PrefixRx.Matches(text)) { string p = m.Groups["p"].Value; if (p.Length > 1) Emit(list, repo, rel, LineOf(text, m.Index), "pathbase", "ingress", p); }
                }
                foreach (Match m in HostLineRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "host", ingress ? "ingress" : "yaml", m.Groups["h"].Value);
                if (ingress) foreach (Match m in HostItemRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "host", "ingress", m.Groups["h"].Value);
            }
            else if (ext == ".json") { foreach (Match m in HostJsonRx.Matches(text)) Emit(list, repo, rel, LineOf(text, m.Index), "host", "json", m.Groups["h"].Value); }
            else if (ext == ".properties" || ext == ".env")
            {
                foreach (Match m in Regex.Matches(text, @"^\s*[\w.\-]*(?:host|hostname)\s*[=:]\s*(?<h>[a-z0-9][a-z0-9\-]*(?:\.[a-z0-9\-]+){2,})\s*$", RegexOptions.IgnoreCase | RegexOptions.Multiline))
                    Emit(list, repo, rel, LineOf(text, m.Index), "host", "properties", m.Groups["h"].Value);
            }
        }
        catch { }
        return list;
    }
}
'@
}

#region URL helpers ---------------------------------------------------------------------------------------------
$script:IgnoreHostRx = New-Object System.Text.RegularExpressions.Regex('(?i)(^|\.)(schemas\.[\w.]+|w3\.org|purl\.org|tempuri\.org|xmlsoap\.org|oasis-open\.org|openxmlformats\.org|microsoft\.com|aka\.ms|nuget\.org|shields\.io|localhost|127\.0\.0\.1|0\.0\.0\.0|example\.(com|org)|xmlns\.com|json-schema\.org|npmjs\.(com|org)|jquery\.com|googleapis\.com|gstatic\.com|cloudflare\.com|cdnjs\.[\w.]+|jsdelivr\.net|unpkg\.com|bootstrapcdn\.com|fontawesome\.com|google\.com|github\.com|githubusercontent\.com)$')
$script:StaticExtRx = New-Object System.Text.RegularExpressions.Regex('(?i)\.(png|jpe?g|gif|svg|css|scss|less|js|mjs|ts|tsx|map|html?|cshtml|razor|aspx|ascx|xml|xsd|xsl|xslt|json|resx|config|txt|md|pdf|dll|exe|ico|woff2?|ttf|eot|zip|csv|sql|cs|vb|csproj|sln|yml|yaml|ps1|bat|cmd|sh|log|bak)$')
$script:UrlRx = New-Object System.Text.RegularExpressions.Regex('^(?<scheme>(?:https?|net\.tcp|net\.pipe|net\.msmq|wss?|soap\.tcp))://(?<host>[^/:?#\s]+)(?::(?<port>\d+))?(?<path>/[^?#\s]*)?', 'IgnoreCase')
$script:WireCtxRx = New-Object System.Text.RegularExpressions.Regex('Namespace\s*=|xmlns|\[ServiceContract|ReplyAction|\bAction\s*=|targetNamespace|schemaLocation', 'IgnoreCase')
$script:DefLineRx = New-Object System.Text.RegularExpressions.Regex('\[[^\]]*\b(Route|RoutePrefix|Http(Get|Post|Put|Delete|Patch|Head|Options)|AcceptVerbs)\b|\.Map(Get|Post|Put|Delete|Patch|Methods|Group)\s*\(')

# Classifies a string. Returns $null when it does not look like a URL / route / .svc reference, otherwise
#   @{ Class = 'Url'|'Route'|'Svc'; Host; Path (normalised: lower-case, {} for placeholders, trailing '/' kept); Raw }
function Get-UrlInfo([string]$v) {
    $r = [FactScan]::Parse($v)
    if ($null -eq $r) { return $null }
    return @{ Class = $r.Class; Host = $r.Host; Path = $r.Path; Raw = $r.Raw }
}

# Splits a stored UrlPath back into segments + trailing-slash flag
function Split-UrlPath([string]$p) {
    $trail = $p.EndsWith('/')
    [pscustomobject]@{ Segs = @($p.Trim('/') -split '/' | Where-Object { $_ -ne '' }); Trail = $trail }
}

# Does a literal (segments, trailing-slash flag) match a REST route cluster-like object { Segs; SegRx }?  -> 'Full' | 'Prefix' | $null
function Test-RouteMatch($c, $lit, [bool]$trail = $false) {
    $n = [Math]::Min($lit.Count, $c.Segs.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $p = $c.SegRx[$i]; $sg = $lit[$i]
        if ($null -eq $p) { if ($c.Segs[$i] -ne $sg) { return $null } }        # fixed word: must be equal (a runtime placeholder does not match it)
        elseif ($p -is [string]) { }                                            # pure {param}
        else { if ($sg -ne '{}' -and -not $p.IsMatch($sg)) { return $null } }  # v{version}
    }
    if ($lit.Count -eq $c.Segs.Count) { return 'Full' }
    if ($lit.Count -lt $c.Segs.Count) {
        if ($trail -and $c.Segs.Count -eq $lit.Count + 1 -and $c.SegRx[$lit.Count] -is [string]) { return 'Full' }   # "api/orders/" + id
        return 'Prefix'
    }
    return $null
}

# Builds SegRx / StaticCount / Key for a normalised route
function New-RouteShape([string]$routeNorm) {
    $segs = @($routeNorm.Trim('/') -split '/' | Where-Object { $_ -ne '' })
    $rx = @()
    foreach ($sg in $segs) {
        if ($sg -eq '{}') { $rx += '*' }
        elseif ($sg.Contains('{}')) { $rx += (New-Object System.Text.RegularExpressions.Regex(('^' + (($sg -split [regex]::Escape('{}') | ForEach-Object { [regex]::Escape($_) }) -join '.+') + '$'))) }
        else { $rx += $null }
    }
    $n = 0; foreach ($sg in $segs) { if ($sg.Contains('{')) { break }; $n++ }
    $key = ''; if ($n -ge 2) { $key = $segs[0] + '/' + $segs[1] } elseif ($n -eq 1) { $key = $segs[0] }
    $strong = @($segs | Where-Object { ($_ -replace '\{\}', '') -match '[a-z]{3}' }).Count
    [pscustomobject]@{ Segs = $segs; SegRx = $rx; StaticCount = $n; StrongCount = $strong; Key = $key }
}
#endregion

#region HTTP verb hints --------------------------------------------------------------------------------------------
$script:RxVerbHint = New-Object System.Text.RegularExpressions.Regex((@(
    'HttpMethod\.(?<v1>Get|Post|Put|Delete|Patch)\b',
    '\b(?<v2>Get|Post|Put|Delete|Patch)(?:Async|FromJsonAsync|AsJsonAsync|ByteArrayAsync|StringAsync|StreamAsync)\b',
    '\[(?<v3>Get|Post|Put|Delete|Patch)\s*\(',
    'Method\.(?<v4>Get|Post|Put|Delete|Patch)\b',
    '\.(?<v5>Get|Post|Put|Delete|Patch)\s*<',
    'new\s+HttpMethod\s*\(\s*"(?<v6>GET|POST|PUT|DELETE|PATCH)"',
    '(?:[Hh]ttp|axios|[Cc]lient|[Aa]pi|[Rr]equest|[Ff]etch|ajax|\$)\w*\s*\.\s*(?<v7>get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(',
    '(?:method|type)\s*[:=]\s*["''`](?<v8>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)["''`]',
    '\.request\s*\(\s*["''](?<v9>get|post|put|delete|patch)["'']'
) -join '|'), 'Compiled')
$script:VerbGroups = 'v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8', 'v9'

function Get-LineAt([string]$text, [int]$idx) {
    if ($idx -lt 0 -or $idx -ge $text.Length) { return '' }
    $s = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); $e = $text.IndexOf("`n", $idx)
    if ($e -lt 0) { $e = $text.Length }
    return $text.Substring($s + 1, $e - $s - 1).Trim()
}

# HTTP verbs hinted by the line of the literal, the previous line or the next line ('' when none)
function Get-VerbHint([string]$text, [int]$idx) {
    $probe = New-Object System.Collections.Generic.List[string]
    $probe.Add((Get-LineAt $text $idx))
    $ls = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); if ($ls -gt 0) { $probe.Add((Get-LineAt $text ($ls - 1))) }
    $le = $text.IndexOf("`n", $idx); if ($le -ge 0 -and $le + 1 -lt $text.Length) { $probe.Add((Get-LineAt $text ($le + 1))) }
    foreach ($pt in $probe) {
        $hint = New-Object 'System.Collections.Generic.SortedSet[string]'
        foreach ($vm in $script:RxVerbHint.Matches($pt)) { foreach ($gn in $script:VerbGroups) { if ($vm.Groups[$gn].Success) { [void]$hint.Add($vm.Groups[$gn].Value.ToUpperInvariant()) } } }
        if ($hint.Count -gt 0) { return ($hint -join '|') }
    }
    return ''
}
#endregion

#region harvest ----------------------------------------------------------------------------------------------------
$script:RxLitD  = New-Object System.Text.RegularExpressions.Regex('(?:\$@|@\$|\$|@)?"(?<s>[^"\r\n]{4,300})"|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300})', 'Compiled')
$script:RxLitJs = New-Object System.Text.RegularExpressions.Regex('"(?<s>[^"\r\n]{4,300})"|''(?<s2>[^''\r\n]{4,300})''|`(?<s3>[^`]{4,300})`|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''`<>)]{4,300})', 'Compiled')
$script:RxClientType = New-Object System.Text.RegularExpressions.Regex('(?<k>ChannelFactory|DuplexChannelFactory|DuplexClientBase|ClientBase)\s*<\s*(?<t>[\w\.]+)', 'Compiled')
$script:CodeExt  = @('.cs', '.vb', '.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.mts', '.cts', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx')
$script:JsLike   = @('.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.mts', '.cts', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx', '.ps1', '.sh')
$script:JsonCfgRx = New-Object System.Text.RegularExpressions.Regex('(?i)^(appsettings.*|.*config.*|.*settings.*|ocelot.*|environment.*|env.*|host|local\.settings|services.*|endpoints.*|proxy.*)\.json$')
$script:SkipFileRx = New-Object System.Text.RegularExpressions.Regex('(?i)package-lock\.json|\.min\.|\.bundle\.|\.chunk\.[cm]?js$|\.[0-9a-f]{7,}\.(chunk\.)?[cm]?js$|(^|[.-])(vendors?|polyfills|runtime|bundle)[.-][\w.-]*\.[cm]?js$|\.d\.ts$|\.(g|designer)\.cs$|AssemblyInfo\.cs$|launchSettings\.json$|^(swagger|openapi)[^\\/]*\.(json|ya?ml)$|\.csproj(\.user)?$|\.(props|targets|resx|xaml|nuspec|vcxproj|sln)$')

function Add-XmlFacts($node, [string]$path, [string]$text, [string]$rel, $addFact) {
    foreach ($ch in $node.ChildNodes) {
        if ($ch.NodeType -ne 'Element') { continue }
        $name = $ch.LocalName
        $ctxName = $name
        foreach ($idAttr in 'key', 'name') { $a = $ch.GetAttribute($idAttr); if ($a) { $ctxName = "$name[$idAttr=$a]"; break } }
        $here = if ($path) { "$path/$ctxName" } else { $ctxName }
        if ($name -eq 'endpoint' -and $path -match '(^|/)client$') {
            $addr = $ch.GetAttribute('address')
            $detail = 'contract=' + $ch.GetAttribute('contract') + ';binding=' + $ch.GetAttribute('binding') + ';name=' + $ch.GetAttribute('name')
            & $addFact 'SoapClientEndpoint' $addr $detail $rel $addr
        }
        foreach ($attr in $ch.Attributes) {
            $v = $attr.Value
            if (-not $v -or $attr.Name -match '^(?i:xmlns(:.*)?|targetNamespace|namespace|.*schemaLocation)$') { continue }     # XML namespaces are not endpoints
            $info = Get-UrlInfo $v
            if ($info -and ($info.Class -ne 'Route' -or $attr.Name -match '(?i)^(address|baseaddress|url|uri|endpoint|location)$')) {
                if ($name -eq 'endpoint' -and $path -match '(^|/)client$' -and $attr.Name -eq 'address') { continue }   # already recorded as SoapClientEndpoint
                & $addFact 'ConfigUrl' $v ("$here@" + $attr.Name) $rel $v
            }
        }
        if ($ch.ChildNodes.Count -eq 1 -and $ch.FirstChild.NodeType -eq 'Text') {
            $t = "$($ch.InnerText)".Trim()
            if ($t) { $info = Get-UrlInfo $t; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $t $here $rel $t } }
        }
        Add-XmlFacts $ch $here $text $rel $addFact
    }
}

# A 'SoapProvider' fact becomes a row of the repo's EXPOSED results (Kind 'SOAP'): what this repo serves although it is not a *.svc file.
#   Role 'Provider' = code / configuration that serves it; Role 'Wsdl' = a WSDL describing it (the provider's own copy - or a consumer's copy of it)
function ConvertTo-SoapExposedRow($f) {
    $kv = @{}
    foreach ($p in ("$($f.Detail)" -split ';')) { $i = $p.IndexOf('='); if ($i -gt 0) { $kv[$p.Substring(0, $i)] = $p.Substring($i + 1) } }
    $src = $kv['src']
    $hasAddr = [bool]$f.UrlPath
    return [pscustomobject]@{
        Repo = $f.Repo; Kind = 'SOAP'; Role = $(if ($src -eq 'wsdl') { 'Wsdl' } else { 'Provider' }); Service = $kv['service']; Contract = $kv['contract']; ClrNamespace = $kv['pkg']
        Operation = $kv['ops']; HttpVerb = ''; Route = $(if ($hasAddr) { $f.Value } else { '' }); RouteNormalized = $f.UrlPath; SoapAction = ''; WireNamespace = $kv['ns']; SvcFile = ''
        File = $f.File; Line = $f.Line; Framework = $src; ProjectNames = ''; ImplClasses = $kv['impl']; Flags = 'NonSvc'
    }
}

# A 'DeployHint' fact becomes a row of the repo's EXPOSED results (Kind 'DEPLOY'): the path base / host name this repo declares for itself.
function ConvertTo-DeployExposedRow($f) {
    $kv = @{}
    foreach ($p in ("$($f.Detail)" -split ';')) { $i = $p.IndexOf('='); if ($i -gt 0) { $kv[$p.Substring(0, $i)] = $p.Substring($i + 1) } }
    $isHost = ($kv['kind'] -eq 'host')
    return [pscustomobject]@{
        Repo = $f.Repo; Kind = 'DEPLOY'; Role = 'Provider'; Service = $kv['kind']; Contract = ''; ClrNamespace = ''
        Operation = ''; HttpVerb = ''; Route = $f.Value; RouteNormalized = $(if ($isHost) { $f.Host } else { $f.UrlPath }); SoapAction = ''; WireNamespace = ''; SvcFile = ''
        File = $f.File; Line = $f.Line; Framework = $kv['src']; ProjectNames = ''; ImplClasses = ''; Flags = 'DeployHint'
    }
}

# Returns facts about everything this repo calls / is configured to call.
#   @{ Repo; Kind; Value; Host; UrlPath; Verb; Detail; File; Line; Count }
# Kinds: ConfigUrl, SoapClientEndpoint, ServiceUrl (*.svc), UrlLiteral (absolute URL in code), RouteLiteral (relative route in code), ClientType (ChannelFactory<T>/ClientBase<T>)
function Get-RepoUsedFacts {
    param([string]$RepoDir, [string]$RepoName, [string[]]$ExcludeDir, [switch]$IncludeTests, [int]$MaxPerFile = 300, [int]$MaxPerRepo = 20000, [int]$MaxFileMB = 2, [hashtable]$Stats,
        # stop scanning this repo after this many minutes (the facts found so far are kept)
        [double]$MaxMinutes = 10,
        # called every -ProgressSeconds with (filesDone, filesTotal, currentFile, factsSoFar)
        [scriptblock]$OnProgress, [int]$ProgressSeconds = 15)
    if ($Stats) { $Stats.Files = 0; $Stats.TotalFiles = 0; $Stats.MaxedOut = $false; $Stats.TimedOut = $false; $Stats.Skipped = 0 }
    $clock = [System.Diagnostics.Stopwatch]::StartNew(); $beat = [System.Diagnostics.Stopwatch]::StartNew(); $seenFiles = 0
    $out = New-Object System.Collections.Generic.List[object]
    $rootLen = $RepoDir.TrimEnd('\', '/').Length
    $allFiles = Get-RepoFiles -Dir $RepoDir -ExcludeDir $ExcludeDir
    if ($Stats) { $Stats.TotalFiles = $allFiles.Count }
    foreach ($f in $allFiles) {
        if ($out.Count -ge $MaxPerRepo) { if ($Stats) { $Stats.MaxedOut = $true }; break }
        $seenFiles++
        if ($clock.Elapsed.TotalMinutes -ge $MaxMinutes) { if ($Stats) { $Stats.TimedOut = $true }; break }       # one huge repo must not block the whole run
        if ($OnProgress -and $beat.Elapsed.TotalSeconds -ge $ProgressSeconds) { & $OnProgress $seenFiles $allFiles.Count ($f.Substring([Math]::Min($RepoDir.Length, $f.Length)).TrimStart('\', '/')) $out.Count; $beat.Restart() }
        $leaf = [System.IO.Path]::GetFileName($f)
        $ext = [System.IO.Path]::GetExtension($f).ToLowerInvariant()
        if ($script:SkipFileRx.IsMatch($leaf)) { continue }
        $isCfgXml = $ext -in '.config', '.xml', '.svcmap', '.wsdl'
        $isCfgJson = ($ext -eq '.json' -and $script:JsonCfgRx.IsMatch($leaf))
        $isCfgText = ($ext -in '.yml', '.yaml', '.properties', '.env', '.ini', '.tfvars', '.http') -or ($leaf -match '^\.env(\..+)?$')       # .env, .env.production, .env.local ...
        $isCode = $script:CodeExt -contains $ext
        $isScript = $ext -in '.ps1', '.sh', '.bat', '.cmd'
        $isProvOnly = $ext -in '.java', '.asmx', '.wsdd'          # only searched for SOAP provider declarations (@WebService, <%@ WebService %>, ...), never for URL literals
        $isDocker = ($ext -eq '' -and $leaf -match '(?i)^dockerfile')
        if (-not ($isCfgXml -or $isCfgJson -or $isCfgText -or $isCode -or $isScript -or $isProvOnly -or $isDocker)) { continue }
        $rel = ($f.Substring($rootLen).TrimStart('\', '/')) -replace '\\', '/'
        if (-not $IncludeTests -and (Test-IsTestPath $rel)) { continue }
        $text = Read-Text $f $MaxFileMB
        if (-not $text -or $text.Length -lt 8) { continue }
        if ($text.Length -gt 60KB -and $ext -in '.js', '.mjs', '.cjs') {      # minified / bundled JavaScript (a few enormous lines) is build output, not source
            $lineCount = $text.Length - $text.Replace("`n", '').Length + 1
            if (($text.Length / $lineCount) -gt 400) { if ($Stats) { $Stats.Skipped++ }; continue }
        }
        if ($Stats) { $Stats.Files++ }
        # SOAP services that are not a *.svc file (WSDL, ASMX, ServiceRoute / ServiceHost / CoreWCF / <service> config, Java JAX-WS / CXF / Spring-WS / Axis / web.xml)
        if ($ext -in '.wsdl', '.asmx', '.wsdd', '.java', '.cs', '.vb', '.config', '.xml') {
            try { if ([SoapProviderScan]::Wants($ext, $leaf.ToLowerInvariant(), $text)) { $pf = [SoapProviderScan]::Scan($text, $ext, $leaf, $rel, $RepoName); if ($pf.Count -gt 0) { $out.AddRange($pf) } } } catch { }
        }
        # where the service is mounted / reachable according to its own repo: UsePathBase, PathBase settings, ingress paths, host names of ingress / route files
        if ($ext -in '.cs', '.yml', '.yaml', '.properties', '.env', '.json', '.tpl', '.conf', '') {
            try { if ([DeployHintScan]::Wants($ext, $leaf, $text)) { $dh = [DeployHintScan]::Scan($text, $ext, $leaf, $rel, $RepoName); if ($dh.Count -gt 0) { $out.AddRange($dh) } } } catch { }
        }
        if ($isProvOnly -or $isDocker) { continue }

        $seen = @{}; $st = @{ n = 0 }      # reference types: the scriptblock below runs in a child scope and cannot update plain variables
        $addFact = {
            param($kind, $value, $detail, $file, $raw, $line = 0, $verb = '')
            if ($st.n -ge $MaxPerFile -or [string]::IsNullOrWhiteSpace($value)) { return }
            $key = "$kind|$value|$detail|$verb"      # the verb is part of the identity: GET and POST on the same URL are different calls
            if ($seen.ContainsKey($key)) { $seen[$key].Count++; return }
            $info = Get-UrlInfo $value
            if ($line -le 0) { $idx = $text.IndexOf($raw, [StringComparison]::Ordinal); $line = if ($idx -ge 0) { [CsMasker]::Line($text, $idx) } else { 1 } }
            $obj = [pscustomobject][ordered]@{
                Repo = $RepoName; Kind = $kind; Value = $value; Host = $(if ($info) { $info.Host } else { '' }); UrlPath = $(if ($info) { $info.Path } else { '' })
                Verb = $verb; Detail = $detail; File = $file; Line = $line; Count = 1
            }
            $seen[$key] = $obj; $out.Add($obj); $st.n++
        }

        try {
            if ($isCfgXml) {
                # Most XML (Salesforce / SSIS / data / resources) contains no URL at all: skip it without parsing. Parsing every element in
                # PowerShell costs ~1.6 s per 300 KB file - thousands of such files would take hours.
                $isWcfStyle = ($ext -ne '.xml') -and ($text.IndexOf('<client', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or $text.IndexOf('serviceModel', [StringComparison]::OrdinalIgnoreCase) -ge 0)
                if (-not $isWcfStyle -and -not [FactScan]::HasUrlLike($text)) { if ($Stats) { $Stats.Skipped++ } }
                elseif ($ext -eq '.xml' -or $text.Length -gt 512KB) {
                    $xf = [FactScan]::ScanXmlUrls($text, [Math]::Max(0, $MaxPerFile - $st.n), $RepoName, $rel)      # compiled regex scan, no DOM
                    $out.AddRange($xf); $st.n += $xf.Count
                } else {
                    $doc = $null
                    try { $doc = [xml]$text } catch { }
                    if ($doc -and $doc.DocumentElement) { Add-XmlFacts $doc.DocumentElement $doc.DocumentElement.LocalName $text $rel $addFact }
                    else { foreach ($m in [regex]::Matches($text, '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300}')) { if (Get-UrlInfo $m.Value) { & $addFact 'ConfigUrl' $m.Value 'text' $rel $m.Value ([CsMasker]::Line($text, $m.Index)) } } }
                }
            }
            elseif ($isCfgJson) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    $ln = $lines[$i]
                    $kvs = [regex]::Matches($ln, '"(?<k>[^"\\]{1,120})"\s*:\s*"(?<v>[^"\\]{3,300})"')
                    if ($kvs.Count -gt 0) { foreach ($kv in $kvs) { $info = Get-UrlInfo $kv.Groups['v'].Value; if ($info) { & $addFact 'ConfigUrl' $kv.Groups['v'].Value ('key=' + $kv.Groups['k'].Value) $rel $kv.Groups['v'].Value ($i + 1) } } }
                    else { $b = [regex]::Match($ln, '^\s*"(?<v>[^"\\]{3,300})"\s*,?\s*$'); if ($b.Success) { $info = Get-UrlInfo $b.Groups['v'].Value; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $b.Groups['v'].Value 'array item' $rel $b.Groups['v'].Value ($i + 1) } } }
                }
            }
            elseif (($isCfgText -or $isScript) -and -not [FactScan]::HasUrlLike($text)) { if ($Stats) { $Stats.Skipped++ } }
            elseif ($isCfgText -or $isScript) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    foreach ($m in [regex]::Matches($lines[$i], '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)\]]{4,300}')) {
                        if (Get-UrlInfo $m.Value) { & $addFact $(if ($isScript) { 'UrlLiteral' } else { 'ConfigUrl' }) $m.Value ('line text') $rel $m.Value ($i + 1) }
                    }
                }
            }
            else {   # code
                if ($ext -eq '.cs') { $clean = ([CsMasker]::Process($text))[0] }
                elseif ($ext -in '.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.mts', '.cts', '.vue', '.svelte') { $clean = [FactScan]::StripJsComments($text) }
                else { $clean = $text }
                $codeFacts = [FactScan]::ScanCode($text, $clean, [bool]($script:JsLike -contains $ext), [Math]::Max(0, $MaxPerFile - $st.n), $RepoName, $rel)
                $out.AddRange($codeFacts)                      # the compiled objects are used as they are (Repo, Kind, Value, Host, UrlPath, Verb, Detail, File, Line, Count)
                $st.n += $codeFacts.Count
                if ($ext -in '.cs', '.vb') {
                    foreach ($ct in $script:RxClientType.Matches($clean)) {
                        $t = Get-ShortName $ct.Groups['t'].Value
                        & $addFact 'ClientType' $t $ct.Groups['k'].Value $rel $ct.Value ([CsMasker]::Line($text, $ct.Index))
                    }
                }
            }
        } catch { }
    }
    return $out
}
#endregion
