# EndpointScan.Facts.ps1
# Shared by Build-UrlInventory.ps1 and Find-HomeRepoUsage.ps1. Dot-sourced - do not run directly.
# Needs EndpointScan.Common.ps1 to be dot-sourced first (CsMasker, Get-RepoFiles, Read-Text, Test-IsTestPath ...).

#region URL helpers ---------------------------------------------------------------------------------------------
$script:IgnoreHostRx = New-Object System.Text.RegularExpressions.Regex('(?i)(^|\.)(schemas\.[\w.]+|w3\.org|purl\.org|tempuri\.org|xmlsoap\.org|oasis-open\.org|openxmlformats\.org|microsoft\.com|aka\.ms|nuget\.org|shields\.io|localhost|127\.0\.0\.1|0\.0\.0\.0|example\.(com|org)|xmlns\.com|json-schema\.org|npmjs\.(com|org)|jquery\.com|googleapis\.com|gstatic\.com|cloudflare\.com|cdnjs\.[\w.]+|jsdelivr\.net|unpkg\.com|bootstrapcdn\.com|fontawesome\.com|google\.com|github\.com|githubusercontent\.com)$')
$script:StaticExtRx = New-Object System.Text.RegularExpressions.Regex('(?i)\.(png|jpe?g|gif|svg|css|scss|less|js|mjs|ts|tsx|map|html?|cshtml|razor|aspx|ascx|xml|xsd|xsl|xslt|json|resx|config|txt|md|pdf|dll|exe|ico|woff2?|ttf|eot|zip|csv|sql|cs|vb|csproj|sln|yml|yaml|ps1|bat|cmd|sh|log|bak)$')
$script:UrlRx = New-Object System.Text.RegularExpressions.Regex('^(?<scheme>(?:https?|net\.tcp|net\.pipe|net\.msmq|wss?|soap\.tcp))://(?<host>[^/:?#\s]+)(?::(?<port>\d+))?(?<path>/[^?#\s]*)?', 'IgnoreCase')
$script:WireCtxRx = New-Object System.Text.RegularExpressions.Regex('Namespace\s*=|xmlns|\[ServiceContract|ReplyAction|\bAction\s*=|targetNamespace|schemaLocation', 'IgnoreCase')
$script:DefLineRx = New-Object System.Text.RegularExpressions.Regex('\[[^\]]*\b(Route|RoutePrefix|Http(Get|Post|Put|Delete|Patch|Head|Options)|AcceptVerbs)\b|\.Map(Get|Post|Put|Delete|Patch|Methods|Group)\s*\(')

# Classifies a string. Returns $null when it does not look like a URL / route / .svc reference, otherwise
#   @{ Class = 'Url'|'Route'|'Svc'; Host; Path (normalised: lower-case, {} for placeholders, trailing '/' kept); Raw }
function Get-UrlInfo([string]$v) {
    if ([string]::IsNullOrWhiteSpace($v)) { return $null }
    $v = $v.Trim()
    if ($v.Length -lt 4 -or $v.Length -gt 300 -or $v -match '\s') { return $null }
    $hostName = ''; $path = $v
    $m = $script:UrlRx.Match($v)
    if ($m.Success) {
        $hostName = $m.Groups['host'].Value.ToLowerInvariant()
        if ($script:IgnoreHostRx.IsMatch($hostName)) { return $null }
        $path = $m.Groups['path'].Value
    } elseif ($v -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') { return $null }          # other schemes (file:, ftp:, ...)
    $isSvc = $v -match '(?i)\.svc(\b|$|[/?#])'
    $path = ($path -split '[?#]')[0]
    $trail = $path.EndsWith('/')
    $path = [regex]::Replace($path, '\{\{[^}]*\}\}|\$?\{[^}]*\}|%7B[^%]*%7D', '{}')
    $segs = @($path.Trim('~', '/').ToLowerInvariant() -split '/' | Where-Object { $_ -ne '' })
    while ($segs.Count -gt 0 -and $segs[0] -eq '{}') { if ($segs.Count -gt 1) { $segs = $segs[1..($segs.Count - 1)] } else { $segs = @() } }
    $norm = ($segs -join '/') + $(if ($trail -and $segs.Count -gt 0) { '/' } else { '' })
    if ($m.Success) {
        if ($isSvc) { return @{ Class = 'Svc'; Host = $hostName; Path = $norm; Raw = $v } }
        return @{ Class = 'Url'; Host = $hostName; Path = $norm; Raw = $v }
    }
    if ($isSvc) { return @{ Class = 'Svc'; Host = ''; Path = $norm; Raw = $v } }
    # relative route-like: >= 2 segments, plain characters, not a file name, not a MIME type, at least one real word
    if ($v -match '\\' -or $v -match '^(\.{1,2}/|@|#)') { return $null }          # windows paths, ./relative module imports, @scoped/npm, anchors
    if ($segs.Count -lt 2) { return $null }
    if ($segs[0] -match '^(application|text|image|multipart|audio|video|font)$') { return $null }
    if ($script:StaticExtRx.IsMatch($segs[-1])) { return $null }
    $words = 0
    foreach ($sg in $segs) { if ($sg -notmatch '^[\w\-\.{}$~%@:]+$') { return $null }; if ($sg -match '[a-z]{3}') { $words++ } }
    if ($words -lt 1) { return $null }
    return @{ Class = 'Route'; Host = ''; Path = $norm; Raw = $v }
}

# Splits a stored UrlPath back into segments + trailing-slash flag
function Split-UrlPath([string]$p) {
    $trail = $p.EndsWith('/')
    [pscustomobject]@{ Segs = @($p.Trim('/') -split '/' | Where-Object { $_ -ne '' }); Trail = $trail }
}

# Does a literal (segments, trailing-slash flag) match a REST route cluster-like object { Segs; SegRx }?  -> 'Full' | 'Prefix' | $null
function Test-RouteMatch($c, $lit, [bool]$trail = $false) {
    $n = [Math]::Min($lit.Count, $c.Segs.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $p = $c.SegRx[$i]; $sg = $lit[$i]
        if ($null -eq $p) { if ($c.Segs[$i] -ne $sg) { return $null } }        # fixed word: must be equal (a runtime placeholder does not match it)
        elseif ($p -is [string]) { }                                            # pure {param}
        else { if ($sg -ne '{}' -and -not $p.IsMatch($sg)) { return $null } }  # v{version}
    }
    if ($lit.Count -eq $c.Segs.Count) { return 'Full' }
    if ($lit.Count -lt $c.Segs.Count) {
        if ($trail -and $c.Segs.Count -eq $lit.Count + 1 -and $c.SegRx[$lit.Count] -is [string]) { return 'Full' }   # "api/orders/" + id
        return 'Prefix'
    }
    return $null
}

# Builds SegRx / StaticCount / Key for a normalised route
function New-RouteShape([string]$routeNorm) {
    $segs = @($routeNorm.Trim('/') -split '/' | Where-Object { $_ -ne '' })
    $rx = @()
    foreach ($sg in $segs) {
        if ($sg -eq '{}') { $rx += '*' }
        elseif ($sg.Contains('{}')) { $rx += (New-Object System.Text.RegularExpressions.Regex(('^' + (($sg -split [regex]::Escape('{}') | ForEach-Object { [regex]::Escape($_) }) -join '.+') + '$'))) }
        else { $rx += $null }
    }
    $n = 0; foreach ($sg in $segs) { if ($sg.Contains('{')) { break }; $n++ }
    $key = ''; if ($n -ge 2) { $key = $segs[0] + '/' + $segs[1] } elseif ($n -eq 1) { $key = $segs[0] }
    $strong = @($segs | Where-Object { ($_ -replace '\{\}', '') -match '[a-z]{3}' }).Count
    [pscustomobject]@{ Segs = $segs; SegRx = $rx; StaticCount = $n; StrongCount = $strong; Key = $key }
}
#endregion

#region HTTP verb hints --------------------------------------------------------------------------------------------
$script:RxVerbHint = New-Object System.Text.RegularExpressions.Regex((@(
    'HttpMethod\.(?<v1>Get|Post|Put|Delete|Patch)\b',
    '\b(?<v2>Get|Post|Put|Delete|Patch)(?:Async|FromJsonAsync|AsJsonAsync|ByteArrayAsync|StringAsync|StreamAsync)\b',
    '\[(?<v3>Get|Post|Put|Delete|Patch)\s*\(',
    'Method\.(?<v4>Get|Post|Put|Delete|Patch)\b',
    '\.(?<v5>Get|Post|Put|Delete|Patch)\s*<',
    'new\s+HttpMethod\s*\(\s*"(?<v6>GET|POST|PUT|DELETE|PATCH)"',
    '(?:[Hh]ttp|axios|[Cc]lient|[Aa]pi|[Rr]equest|[Ff]etch|ajax|\$)\w*\s*\.\s*(?<v7>get|post|put|delete|patch)\s*(?:<[^>]*>)?\s*\(',
    '(?:method|type)\s*[:=]\s*["''`](?<v8>GET|POST|PUT|DELETE|PATCH|get|post|put|delete|patch)["''`]',
    '\.request\s*\(\s*["''](?<v9>get|post|put|delete|patch)["'']'
) -join '|'), 'Compiled')
$script:VerbGroups = 'v1', 'v2', 'v3', 'v4', 'v5', 'v6', 'v7', 'v8', 'v9'

function Get-LineAt([string]$text, [int]$idx) {
    if ($idx -lt 0 -or $idx -ge $text.Length) { return '' }
    $s = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); $e = $text.IndexOf("`n", $idx)
    if ($e -lt 0) { $e = $text.Length }
    return $text.Substring($s + 1, $e - $s - 1).Trim()
}

# HTTP verbs hinted by the line of the literal, the previous line or the next line ('' when none)
function Get-VerbHint([string]$text, [int]$idx) {
    $probe = New-Object System.Collections.Generic.List[string]
    $probe.Add((Get-LineAt $text $idx))
    $ls = $text.LastIndexOf("`n", [Math]::Max(0, $idx - 1)); if ($ls -gt 0) { $probe.Add((Get-LineAt $text ($ls - 1))) }
    $le = $text.IndexOf("`n", $idx); if ($le -ge 0 -and $le + 1 -lt $text.Length) { $probe.Add((Get-LineAt $text ($le + 1))) }
    foreach ($pt in $probe) {
        $hint = New-Object 'System.Collections.Generic.SortedSet[string]'
        foreach ($vm in $script:RxVerbHint.Matches($pt)) { foreach ($gn in $script:VerbGroups) { if ($vm.Groups[$gn].Success) { [void]$hint.Add($vm.Groups[$gn].Value.ToUpperInvariant()) } } }
        if ($hint.Count -gt 0) { return ($hint -join '|') }
    }
    return ''
}
#endregion

#region harvest ----------------------------------------------------------------------------------------------------
$script:RxLitD  = New-Object System.Text.RegularExpressions.Regex('(?:\$@|@\$|\$|@)?"(?<s>[^"\r\n]{4,300})"|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300})', 'Compiled')
$script:RxLitJs = New-Object System.Text.RegularExpressions.Regex('"(?<s>[^"\r\n]{4,300})"|''(?<s2>[^''\r\n]{4,300})''|`(?<s3>[^`]{4,300})`|(?<u>(?:https?|net\.tcp|net\.pipe)://[^\s"''`<>)]{4,300})', 'Compiled')
$script:RxClientType = New-Object System.Text.RegularExpressions.Regex('(?<k>ChannelFactory|DuplexChannelFactory|DuplexClientBase|ClientBase)\s*<\s*(?<t>[\w\.]+)', 'Compiled')
$script:CodeExt  = @('.cs', '.vb', '.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx')
$script:JsLike   = @('.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte', '.html', '.htm', '.cshtml', '.razor', '.aspx', '.ascx', '.ps1', '.sh')
$script:JsonCfgRx = New-Object System.Text.RegularExpressions.Regex('(?i)^(appsettings.*|.*config.*|.*settings.*|ocelot.*|environment.*|env.*|host|local\.settings|services.*|endpoints.*)\.json$')
$script:SkipFileRx = New-Object System.Text.RegularExpressions.Regex('(?i)package-lock\.json|\.min\.|\.bundle\.|\.d\.ts$|\.(g|designer)\.cs$|AssemblyInfo\.cs$|launchSettings\.json$|^(swagger|openapi)[^\\/]*\.(json|ya?ml)$|\.csproj(\.user)?$|\.(props|targets|resx|xaml|nuspec|vcxproj|sln)$')

function Add-XmlFacts($node, [string]$path, [string]$text, [string]$rel, $addFact) {
    foreach ($ch in $node.ChildNodes) {
        if ($ch.NodeType -ne 'Element') { continue }
        $name = $ch.LocalName
        $ctxName = $name
        foreach ($idAttr in 'key', 'name') { $a = $ch.GetAttribute($idAttr); if ($a) { $ctxName = "$name[$idAttr=$a]"; break } }
        $here = if ($path) { "$path/$ctxName" } else { $ctxName }
        if ($name -eq 'endpoint' -and $path -match '(^|/)client$') {
            $addr = $ch.GetAttribute('address')
            $detail = 'contract=' + $ch.GetAttribute('contract') + ';binding=' + $ch.GetAttribute('binding') + ';name=' + $ch.GetAttribute('name')
            & $addFact 'SoapClientEndpoint' $addr $detail $rel $addr
        }
        foreach ($attr in $ch.Attributes) {
            $v = $attr.Value
            if (-not $v) { continue }
            $info = Get-UrlInfo $v
            if ($info -and ($info.Class -ne 'Route' -or $attr.Name -match '(?i)^(address|baseaddress|url|uri|endpoint|location)$')) {
                if ($name -eq 'endpoint' -and $path -match '(^|/)client$' -and $attr.Name -eq 'address') { continue }   # already recorded as SoapClientEndpoint
                & $addFact 'ConfigUrl' $v ("$here@" + $attr.Name) $rel $v
            }
        }
        if ($ch.ChildNodes.Count -eq 1 -and $ch.FirstChild.NodeType -eq 'Text') {
            $t = "$($ch.InnerText)".Trim()
            if ($t) { $info = Get-UrlInfo $t; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $t $here $rel $t } }
        }
        Add-XmlFacts $ch $here $text $rel $addFact
    }
}

# Returns facts about everything this repo calls / is configured to call.
#   @{ Repo; Kind; Value; Host; UrlPath; Verb; Detail; File; Line; Count }
# Kinds: ConfigUrl, SoapClientEndpoint, ServiceUrl (*.svc), UrlLiteral (absolute URL in code), RouteLiteral (relative route in code), ClientType (ChannelFactory<T>/ClientBase<T>)
function Get-RepoUsedFacts {
    param([string]$RepoDir, [string]$RepoName, [string[]]$ExcludeDir, [switch]$IncludeTests, [int]$MaxPerFile = 300, [int]$MaxPerRepo = 20000, [int]$MaxFileMB = 2)
    $out = New-Object System.Collections.Generic.List[object]
    $rootLen = $RepoDir.TrimEnd('\', '/').Length
    foreach ($f in (Get-RepoFiles -Dir $RepoDir -ExcludeDir $ExcludeDir)) {
        if ($out.Count -ge $MaxPerRepo) { break }
        $leaf = [System.IO.Path]::GetFileName($f)
        $ext = [System.IO.Path]::GetExtension($f).ToLowerInvariant()
        if ($script:SkipFileRx.IsMatch($leaf)) { continue }
        $isCfgXml = $ext -in '.config', '.xml', '.svcmap', '.wsdl'
        $isCfgJson = ($ext -eq '.json' -and $script:JsonCfgRx.IsMatch($leaf))
        $isCfgText = $ext -in '.yml', '.yaml', '.properties', '.env', '.ini', '.tfvars', '.http'
        $isCode = $script:CodeExt -contains $ext
        $isScript = $ext -in '.ps1', '.sh', '.bat', '.cmd'
        if (-not ($isCfgXml -or $isCfgJson -or $isCfgText -or $isCode -or $isScript)) { continue }
        $rel = ($f.Substring($rootLen).TrimStart('\', '/')) -replace '\\', '/'
        if (-not $IncludeTests -and (Test-IsTestPath $rel)) { continue }
        $text = Read-Text $f $MaxFileMB
        if (-not $text -or $text.Length -lt 8) { continue }

        $seen = @{}; $st = @{ n = 0 }      # reference types: the scriptblock below runs in a child scope and cannot update plain variables
        $addFact = {
            param($kind, $value, $detail, $file, $raw, $line = 0, $verb = '')
            if ($st.n -ge $MaxPerFile -or [string]::IsNullOrWhiteSpace($value)) { return }
            $key = "$kind|$value|$detail|$verb"      # the verb is part of the identity: GET and POST on the same URL are different calls
            if ($seen.ContainsKey($key)) { $seen[$key].Count++; return }
            $info = Get-UrlInfo $value
            if ($line -le 0) { $idx = $text.IndexOf($raw, [StringComparison]::Ordinal); $line = if ($idx -ge 0) { [CsMasker]::Line($text, $idx) } else { 1 } }
            $obj = [pscustomobject][ordered]@{
                Repo = $RepoName; Kind = $kind; Value = $value; Host = $(if ($info) { $info.Host } else { '' }); UrlPath = $(if ($info) { $info.Path } else { '' })
                Verb = $verb; Detail = $detail; File = $file; Line = $line; Count = 1
            }
            $seen[$key] = $obj; $out.Add($obj); $st.n++
        }

        try {
            if ($isCfgXml) {
                $doc = $null
                try { $doc = [xml]$text } catch { }
                if ($doc -and $doc.DocumentElement) { Add-XmlFacts $doc.DocumentElement $doc.DocumentElement.LocalName $text $rel $addFact }
                else { foreach ($m in [regex]::Matches($text, '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)]{4,300}')) { if (Get-UrlInfo $m.Value) { & $addFact 'ConfigUrl' $m.Value 'text' $rel $m.Value ([CsMasker]::Line($text, $m.Index)) } } }
            }
            elseif ($isCfgJson) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    $ln = $lines[$i]
                    $kvs = [regex]::Matches($ln, '"(?<k>[^"\\]{1,120})"\s*:\s*"(?<v>[^"\\]{3,300})"')
                    if ($kvs.Count -gt 0) { foreach ($kv in $kvs) { $info = Get-UrlInfo $kv.Groups['v'].Value; if ($info) { & $addFact 'ConfigUrl' $kv.Groups['v'].Value ('key=' + $kv.Groups['k'].Value) $rel $kv.Groups['v'].Value ($i + 1) } } }
                    else { $b = [regex]::Match($ln, '^\s*"(?<v>[^"\\]{3,300})"\s*,?\s*$'); if ($b.Success) { $info = Get-UrlInfo $b.Groups['v'].Value; if ($info -and $info.Class -ne 'Route') { & $addFact 'ConfigUrl' $b.Groups['v'].Value 'array item' $rel $b.Groups['v'].Value ($i + 1) } } }
                }
            }
            elseif ($isCfgText -or $isScript) {
                $lines = $text -split "`n"
                for ($i = 0; $i -lt $lines.Count; $i++) {
                    foreach ($m in [regex]::Matches($lines[$i], '(?:https?|net\.tcp|net\.pipe)://[^\s"''<>)\]]{4,300}')) {
                        if (Get-UrlInfo $m.Value) { & $addFact $(if ($isScript) { 'UrlLiteral' } else { 'ConfigUrl' }) $m.Value ('line text') $rel $m.Value ($i + 1) }
                    }
                }
            }
            else {   # code
                if ($ext -eq '.cs') { $clean = ([CsMasker]::Process($text))[0] }
                elseif ($ext -in '.js', '.jsx', '.mjs', '.ts', '.tsx', '.vue', '.svelte') { $clean = [regex]::Replace($text, '(?m)^[ \t]*(?://|/\*|\*).*$', [System.Text.RegularExpressions.MatchEvaluator]{ param($m) ' ' * $m.Length }) }
                else { $clean = $text }
                $litRx = if ($script:JsLike -contains $ext) { $script:RxLitJs } else { $script:RxLitD }
                foreach ($lm in $litRx.Matches($clean)) {
                    $s = ''; foreach ($gn in 's', 's2', 's3', 'u') { if ($lm.Groups[$gn].Success) { $s = $lm.Groups[$gn].Value; break } }
                    if ($s.IndexOf('/') -lt 0 -and $s -notmatch '(?i)\.svc') { continue }
                    $info = Get-UrlInfo $s
                    if (-not $info) { continue }
                    $lineTxt = Get-LineAt $text $lm.Index
                    if ($script:WireCtxRx.IsMatch($lineTxt) -or $script:DefLineRx.IsMatch($lineTxt)) { continue }     # SOAP namespaces / own controller attributes
                    if ($lineTxt -match '^(import\b|export\b.*\bfrom\b|using\b|#include\b)|\brequire\s*\(') { continue }   # module imports
                    $kind = switch ($info.Class) { 'Svc' { 'ServiceUrl' } 'Url' { 'UrlLiteral' } default { 'RouteLiteral' } }
                    $verb = if ($info.Class -ne 'Svc') { Get-VerbHint $clean $lm.Index } else { '' }
                    & $addFact $kind $s '' $rel $s ([CsMasker]::Line($text, $lm.Index)) $verb
                }
                if ($ext -in '.cs', '.vb') {
                    foreach ($ct in $script:RxClientType.Matches($clean)) {
                        $t = Get-ShortName $ct.Groups['t'].Value
                        & $addFact 'ClientType' $t $ct.Groups['k'].Value $rel $ct.Value ([CsMasker]::Line($text, $ct.Index))
                    }
                }
            }
        } catch { }
    }
    return $out
}
#endregion
