<#
.SYNOPSIS
    Which repos use the endpoints that ONE home repo exposes?  Answered from the inventory built by Build-UrlInventory.ps1 -
    no cloning of the other repos needed.

.DESCRIPTION
    1. Lists every SOAP service (contract, operations, .svc, wire namespace) and REST endpoint (verb + route) the home repo
       exposes                                                              -> home-endpoints.csv
    2. Matches those endpoints against what every other repo in the inventory calls
       (config URLs, WCF <client> endpoints, generated proxies, ChannelFactory<T>, *.svc references, route/URL literals in
       code and frontend files)                                             -> service-usage.csv + service-summary.csv
       (same report format as Find-ServiceUsage.ps1)

    Home repo: -HomeRepo <name as in repos.csv>   (read from the inventory), or
               -HomeRepoPath <local folder>       (the repo is scanned live - use it when the repo changed since the inventory run
                                                   or is not in the inventory yet; all OTHER repos still come from the inventory)

    Matching is at SERVICE level for SOAP (the inventory does not record which operations are called) and at ENDPOINT level
    for REST (verb + route). Use the consumer list to clone only those few repos for a deep check with Find-ServiceUsage.ps1.

.EXAMPLE
    .\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepo Orders.Api
.EXAMPLE
    .\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepoPath C:\Proj\Orders.Api -Service OrderController.cs,OrderService.svc -HostMapPath .\hosts.csv
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$InventoryPath,
    [string]$HomeRepo,
    [string]$HomeRepoPath,
    # Optional: only these services (controller / .svc / interface names or file names). Default: everything the home repo exposes.
    [string[]]$Service = @(),
    [string]$OutputPath = (Get-Location).Path,
    # Optional CSV (Repo,Host): host names of the home repo's deployment; confirm matches and separate identical routes in different services
    [string]$HostMapPath,
    [switch]$IncludeLow,
    [switch]$ExcludeHome,
    [switch]$Detail,
    [string]$WorkPath = (Join-Path ([System.IO.Path]::GetTempPath()) 'home-usage-work')
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'EndpointScan.Common.ps1')
. (Join-Path $PSScriptRoot 'EndpointScan.Facts.ps1')
function Split-List($s) { if ([string]::IsNullOrWhiteSpace($s)) { return @() }; return @($s -split ';' | Where-Object { $_ }) }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }
function Get-Key([string]$s) { (((($s.Trim() -split '[\\/]')[-1]) -replace '(?i)\.svc\.cs$', '' -replace '(?i)\.(svc|cs)$', '')).ToLowerInvariant() }
function NormNs([string]$ns) { if (-not $ns) { return '' }; return $ns.Trim().TrimEnd('/').ToLowerInvariant() }

if (-not (Test-Path -LiteralPath $InventoryPath)) { throw "InventoryPath not found: $InventoryPath" }
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$shardDir = Join-Path $InventoryPath 'shards'
$reposFile = Join-Path $InventoryPath 'repos.csv'
if (-not (Test-Path $reposFile)) { throw "repos.csv not found in $InventoryPath - run Build-UrlInventory.ps1 first." }
$repoRows = @(Import-Csv $reposFile)
if (-not $HomeRepo -and -not $HomeRepoPath) { throw 'Pass -HomeRepo (name in the inventory) or -HomeRepoPath (local folder of the home repo).' }
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null
$OutputPath = (Resolve-Path -LiteralPath $OutputPath).Path
if (Test-Path $WorkPath) { Remove-Item -Recurse -Force $WorkPath -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Force -Path $WorkPath | Out-Null

# ------------------------------------------------------------------------------------------------
# 1. the home repo: from the inventory, or scanned live
# ------------------------------------------------------------------------------------------------
$liveShardDir = $null
if ($HomeRepoPath) {
    if (-not (Test-Path -LiteralPath $HomeRepoPath -PathType Container)) { throw "HomeRepoPath not found: $HomeRepoPath" }
    $homeFull = (Resolve-Path -LiteralPath $HomeRepoPath).Path.TrimEnd('\', '/')
    $HomeRepo = Split-Path $homeFull -Leaf
    Write-Host "Scanning the home repo '$HomeRepo' live ..."
    $liveInv = Join-Path $WorkPath 'live-inventory'
    $p = @{ FromFolder = (Split-Path $homeFull -Parent); InventoryPath = $liveInv; WorkPath = (Join-Path $WorkPath 'live-work'); Include = @($HomeRepo); BatchSize = 1; Refresh = $true; IncludeForks = $true; IncludeArchived = $true }
    $old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
    try { & (Join-Path $PSScriptRoot 'Build-UrlInventory.ps1') @p 6>$null 3>$null | Out-Null } finally { $ProgressPreference = $old }
    $liveShardDir = Join-Path $liveInv 'shards'
    if (-not (Test-Path (Join-Path $liveShardDir ((Safe-Name $HomeRepo) + '.exposed.csv')))) { throw "'$homeFull' could not be scanned as a repo (is it a git repo / does it contain a .git folder?)." }
} else {
    if (-not ($repoRows | Where-Object { $_.Repo -eq $HomeRepo })) {
        $near = @($repoRows | Where-Object { $_.Repo -like "*$HomeRepo*" } | Select-Object -First 8 -ExpandProperty Repo)
        throw ("Home repo '$HomeRepo' is not in the inventory." + $(if ($near.Count) { " Did you mean: $($near -join ', ')?" } else { '' }))
    }
}
function Get-ShardPath([string]$repo, [string]$suffix) {
    if ($liveShardDir -and $repo -eq $HomeRepo) { return (Join-Path $liveShardDir ((Safe-Name $repo) + ".$suffix.csv")) }
    return (Join-Path $shardDir ((Safe-Name $repo) + ".$suffix.csv"))
}
function Import-Shard([string]$repo, [string]$suffix) {
    $f = Get-ShardPath $repo $suffix
    if (Test-Path -LiteralPath $f) { return @(Import-Csv -LiteralPath $f) } else { return @() }
}

$homeExposed = Import-Shard $HomeRepo 'exposed'
$homeRefs = @(Import-Shard $HomeRepo 'refs')
if ($homeExposed.Count -eq 0) { throw "The home repo '$HomeRepo' exposes no SOAP services or REST endpoints (nothing found in its code)." }

# ------------------------------------------------------------------------------------------------
# 2. what do ALL repos declare?  (needed to resolve contracts split over repos and to detect name collisions)
# ------------------------------------------------------------------------------------------------
Write-Host ("Reading the inventory ({0} repos) ..." -f $repoRows.Count)
$decl = @{}          # interface (lower) -> list of @{Repo; Wire; Role; Ops; ProjNames}
$restExposedBy = @{} # "VERB|routeNorm" -> set of repos exposing it
$allExposedRepos = @($repoRows | Where-Object { $_.Status -eq 'ok' } | Select-Object -ExpandProperty Repo)
if ($HomeRepo -notin $allExposedRepos) { $allExposedRepos += $HomeRepo }
$exposedByRepo = @{}
foreach ($r in $allExposedRepos) {
    $rows = if ($r -eq $HomeRepo) { $homeExposed } else { Import-Shard $r 'exposed' }
    $exposedByRepo[$r] = $rows
    foreach ($x in $rows) {
        if ($x.Kind -eq 'WCF' -and $x.Contract) {
            $k = $x.Contract.ToLowerInvariant()
            if (-not $decl.ContainsKey($k)) { $decl[$k] = New-Object System.Collections.Generic.List[object] }
            $decl[$k].Add([pscustomobject]@{ Repo = $r; Wire = (NormNs $x.WireNamespace); Role = $x.Role; Op = $x.Operation; ProjNames = $x.ProjectNames; SvcFile = $x.SvcFile })
        } elseif ($x.Kind -eq 'REST') {
            $k = $x.HttpVerb + '|' + $x.RouteNormalized
            if (-not $restExposedBy.ContainsKey($k)) { $restExposedBy[$k] = New-Object 'System.Collections.Generic.HashSet[string]' }
            [void]$restExposedBy[$k].Add($r)
        }
    }
}

# ------------------------------------------------------------------------------------------------
# 3. the home repo's endpoints
# ------------------------------------------------------------------------------------------------
$roleRank = @{ Host = 3; Implementation = 2; ContractOnly = 1; Library = 1 }
$homeProj = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
$soap = New-Object System.Collections.Generic.List[object]
$rest = New-Object System.Collections.Generic.List[object]

foreach ($g in ($homeExposed | Where-Object { $_.Kind -eq 'WCF' } | Group-Object Contract)) {
    $rows = $g.Group
    $ops = @($rows | ForEach-Object { $_.Operation } | Where-Object { $_ -and $_ -ne '*' } | Select-Object -Unique)
    $wire = @($rows | ForEach-Object { $_.WireNamespace } | Where-Object { $_ } | Select-Object -First 1)[0]
    $role = ($rows | Sort-Object { - $roleRank[$_.Role] } | Select-Object -First 1).Role
    $svcFile = @($rows | ForEach-Object { $_.SvcFile } | Where-Object { $_ } | Select-Object -First 1)[0]
    $proj = @($rows | ForEach-Object { Split-List $_.ProjectNames } | Select-Object -Unique)
    $note = ''
    if ($ops.Count -eq 0 -or -not $wire -or $wire -eq 'http://tempuri.org/') {
        # contract declared in another repo (NuGet / shared library): take operations + wire namespace from there (declared contract, else a consumer's proxy)
        $cands = @()
        if ($decl.ContainsKey($g.Name.ToLowerInvariant())) { $cands = @($decl[$g.Name.ToLowerInvariant()] | Where-Object { $_.Repo -ne $HomeRepo -and $_.Op -and $_.Op -ne '*' }) }
        if ($cands.Count -gt 0) {
            $refNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase); foreach ($r in $homeRefs) { [void]$refNames.Add($r.RefName) }
            $byRef = @($cands | Where-Object { @(Split-List $_.ProjNames | Where-Object { $refNames.Contains($_) }).Count -gt 0 })
            $pick = if ($byRef.Count -gt 0) { $byRef } else { $cands }
            $wires = @($pick | ForEach-Object { $_.Wire } | Select-Object -Unique)
            if ($byRef.Count -gt 0 -or $wires.Count -eq 1) {
                $firstWire = $wires[0]
                $pick = @($pick | Where-Object { $_.Wire -eq $firstWire })
                if ($ops.Count -eq 0) { $ops = @($pick | ForEach-Object { $_.Op } | Select-Object -Unique) }
                if (-not $wire) { $wire = ($pick[0]).Wire }
                foreach ($pn in (Split-List ($pick | ForEach-Object { $_.ProjNames } | Select-Object -First 1))) { $proj += $pn }
                $note = "contract declared in: $((@($pick | ForEach-Object { $_.Repo } | Select-Object -Unique)) -join ', ')"
            } else { $note = 'contract name exists with different wire namespaces in other repos - not resolved' }
        }
    }
    foreach ($pn in $proj) { [void]$homeProj.Add($pn) }
    $soap.Add([pscustomobject]@{
        Id = 'SOAP-' + (Get-ShortHash ("$HomeRepo|$($g.Name)|$svcFile")); Contract = $g.Name; Service = $(if ($svcFile) { ($svcFile -split '[\\/]')[-1] } else { $g.Name })
        SvcFile = $svcFile; SvcLeaf = $(if ($svcFile) { (($svcFile -split '[\\/]')[-1]).ToLowerInvariant() } else { '' }); Wire = (NormNs $wire); WireRaw = $wire
        Ops = $ops; Role = $role; ProjNames = @($proj | Select-Object -Unique); File = $rows[0].File; Line = $rows[0].Line
        ImplClasses = (@($rows | ForEach-Object { Split-List $_.ImplClasses } | Select-Object -Unique) -join ';'); Flags = (@($rows | ForEach-Object { $_.Flags } | Where-Object { $_ } | Select-Object -First 1)[0]); Note = $note
    })
}
foreach ($g in ($homeExposed | Where-Object { $_.Kind -eq 'REST' } | Group-Object { $_.HttpVerb + '|' + $_.RouteNormalized })) {
    $r0 = $g.Group[0]
    $shape = New-RouteShape $r0.RouteNormalized
    $flags = @($g.Group | ForEach-Object { $_.Flags } | Where-Object { $_ } | Select-Object -Unique)
    $others = @(); if ($restExposedBy.ContainsKey($g.Name)) { $others = @($restExposedBy[$g.Name] | Where-Object { $_ -ne $HomeRepo }) }
    $rest.Add([pscustomobject]@{
        Id = 'REST-' + (Get-ShortHash ("$HomeRepo|$($g.Name)")); Verb = $r0.HttpVerb; Route = $r0.Route; RouteNorm = $r0.RouteNormalized; Controller = $r0.Service; Method = $r0.Operation
        Segs = $shape.Segs; SegRx = $shape.SegRx; StaticCount = $shape.StaticCount; StrongCount = $shape.StrongCount; Key = $shape.Key; File = $r0.File; Line = $r0.Line; Role = $r0.Role
        Flags = ($flags -join ';'); OtherRepos = $others; Framework = $r0.Framework
    })
}

# optional filter by -Service
$tokens = @($Service | ForEach-Object { foreach ($t in ($_ -split '[,;\r\n]')) { $t = $t.Trim().Trim('"', "'"); if ($t) { $t } } } | Select-Object -Unique)
$inputRes = New-Object System.Collections.Generic.List[object]
if ($tokens.Count -gt 0) {
    $tk = @($tokens | ForEach-Object { [pscustomobject]@{ Raw = $_; Key = (Get-Key $_); Kind = $(if ($_ -match '(?i)\.svc$') { 'svc' } elseif ($_ -match '(?i)\.cs$') { 'file' } else { 'any' }); Matched = (New-Object System.Collections.Generic.List[string]) } })
    $keepSoap = New-Object System.Collections.Generic.List[object]; $keepRest = New-Object System.Collections.Generic.List[object]
    foreach ($s in $soap) {
        $hit = $false
        $files = @($homeExposed | Where-Object { $_.Kind -eq 'WCF' -and $_.Contract -eq $s.Contract } | ForEach-Object { Get-Key $_.File } | Select-Object -Unique)
        foreach ($t in $tk) {
            $m = switch ($t.Kind) { 'svc' { $s.SvcLeaf -and ((Get-Key $s.SvcLeaf) -eq $t.Key) } 'file' { $files -contains $t.Key } default { ($s.Contract.ToLowerInvariant() -eq $t.Key) -or ((Get-Key $s.Service) -eq $t.Key) -or ($files -contains $t.Key) } }
            if ($m) { $t.Matched.Add($s.Id); $hit = $true }
        }
        if ($hit) { $keepSoap.Add($s) }
    }
    foreach ($c in $rest) {
        $hit = $false; $fk = Get-Key $c.File
        foreach ($t in $tk) {
            $m = switch ($t.Kind) { 'svc' { $false } 'file' { $fk -eq $t.Key } default { ($c.Controller.ToLowerInvariant() -eq $t.Key) -or ($c.Controller.ToLowerInvariant() -eq ($t.Key + 'controller')) -or ($fk -eq $t.Key) } }
            if ($m) { $t.Matched.Add($c.Id); $hit = $true }
        }
        if ($hit) { $keepRest.Add($c) }
    }
    $soap = $keepSoap; $rest = $keepRest
    foreach ($t in $tk) { $inputRes.Add([pscustomobject]@{ Input = $t.Raw; MatchedClusters = (($t.Matched | Select-Object -Unique) -join ';') }) }
}
if ($soap.Count -eq 0 -and $rest.Count -eq 0) { throw "None of the given -Service names matches an endpoint exposed by '$HomeRepo'." }

# --- home-endpoints.csv : the list the user asked for
$hostRows = New-Object System.Collections.Generic.List[object]
foreach ($s in $soap) {
    if ($s.Ops.Count -eq 0) { $hostRows.Add([pscustomobject][ordered]@{ Repo = $HomeRepo; Type = 'SOAP'; Service = $s.Service; Contract = $s.Contract; Verb = ''; RouteOrOperation = '(operations unknown)'; SoapAction = ''; WireNamespace = $s.WireRaw; Role = $s.Role; SvcFile = $s.SvcFile; File = $s.File; Line = $s.Line; Note = $s.Note }) }
    foreach ($op in $s.Ops) {
        $sa = @($homeExposed | Where-Object { $_.Kind -eq 'WCF' -and $_.Contract -eq $s.Contract -and $_.Operation -eq $op -and $_.SoapAction } | Select-Object -First 1)[0]
        $hostRows.Add([pscustomobject][ordered]@{ Repo = $HomeRepo; Type = 'SOAP'; Service = $s.Service; Contract = $s.Contract; Verb = ''; RouteOrOperation = $op; SoapAction = $(if ($sa) { $sa.SoapAction } else { '' }); WireNamespace = $s.WireRaw; Role = $s.Role; SvcFile = $s.SvcFile; File = $s.File; Line = $s.Line; Note = $s.Note })
    }
}
foreach ($c in $rest) { $hostRows.Add([pscustomobject][ordered]@{ Repo = $HomeRepo; Type = 'REST'; Service = $c.Controller; Contract = ''; Verb = $c.Verb; RouteOrOperation = $c.Route; SoapAction = ''; WireNamespace = ''; Role = $c.Role; SvcFile = ''; File = $c.File; Line = $c.Line; Note = $(if ($c.Flags) { $c.Flags } else { '' }) }) }
$hostRows.ToArray() | Sort-Object Type, Service, RouteOrOperation | Export-Csv -LiteralPath (Join-Path $OutputPath 'home-endpoints.csv') -NoTypeInformation -Encoding UTF8
Write-Host ("Home repo {0} exposes {1} SOAP service(s) with {2} operation(s) and {3} REST endpoint(s)." -f $HomeRepo, $soap.Count, (($soap | ForEach-Object { $_.Ops.Count } | Measure-Object -Sum).Sum), $rest.Count)

# ------------------------------------------------------------------------------------------------
# 4. host names of the home deployment
# ------------------------------------------------------------------------------------------------
$homeHosts = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
if ($HostMapPath) {
    foreach ($r in (Import-Csv $HostMapPath)) {
        if ($r.Repo -ne $HomeRepo) { continue }
        foreach ($h in ($r.Host -split ';')) { $h = $h.Trim() -replace '^[a-z]+://', '' -replace '[/:].*$', ''; if ($h) { [void]$homeHosts.Add($h.ToLowerInvariant()) } }
    }
}

# ------------------------------------------------------------------------------------------------
# 5. load what every repo calls, index it, and match
# ------------------------------------------------------------------------------------------------
$ev = New-Object System.Collections.Generic.List[object]
$hostSeen = @{}
$refsByRepo = @{}
$restIdx = @{}
foreach ($c in $rest) { if ($c.Key) { if (-not $restIdx.ContainsKey($c.Key)) { $restIdx[$c.Key] = New-Object System.Collections.Generic.List[object] }; $restIdx[$c.Key].Add($c) } }
$soapBySvc = @{}; foreach ($s in $soap) { if ($s.SvcLeaf) { $soapBySvc[$s.SvcLeaf] = $s } }
$soapByName = @{}; foreach ($s in $soap) { $k = $s.Contract.ToLowerInvariant(); if (-not $soapByName.ContainsKey($k)) { $soapByName[$k] = New-Object System.Collections.Generic.List[object] }; $soapByName[$k].Add($s) }

# repos that declare a service's contract (copies / shared libs) are not consumers just because they use the type
$copyRepos = @{}
foreach ($s in $soap) {
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    if ($decl.ContainsKey($s.Contract.ToLowerInvariant())) { foreach ($d in $decl[$s.Contract.ToLowerInvariant()]) { if ($d.Repo -ne $HomeRepo -and (-not $s.Wire -or $d.Wire -eq $s.Wire)) { [void]$set.Add($d.Repo) } } }
    $copyRepos[$s.Id] = $set
}
function Get-Detail([string]$detail, [string]$key) { $m = [regex]::Match($detail, "(?:^|;)$key=([^;]*)"); if ($m.Success) { return $m.Groups[1].Value } else { return '' } }
function Add-Ev($cl, [string]$repo, $f, [string]$type, [string]$conf, [string]$res, [string]$cands) {
    $isHome = ($repo -eq $HomeRepo)
    if ($isHome -and $ExcludeHome) { return }
    $ev.Add([pscustomobject][ordered]@{
        ClusterId = $cl.Id; Kind = $(if ($cl.Id -like 'SOAP-*') { 'WCF' } else { 'REST' }); Endpoint = ''; Owner = $HomeRepo; ConsumerRepo = $repo; File = $f.File; Line = $f.Line
        EvidenceType = $type; Operation = ''; Confidence = $conf; Resolution = $res; Candidates = $cands; TargetHostRepo = ''; Matched = $f.Value; Snippet = ("{0}{1}" -f $f.Value, $(if ($f.Detail) { "  [$($f.Detail)]" } else { '' })); IsSelf = $isHome
    })
}

$scanRepos = @($repoRows | Where-Object { $_.Status -eq 'ok' } | Select-Object -ExpandProperty Repo)
if ($HomeRepo -notin $scanRepos) { $scanRepos += $HomeRepo }
$n = 0
foreach ($repo in $scanRepos) {
    $n++
    if ($n % 200 -eq 0) { Write-Host ("  ... {0}/{1} repos" -f $n, $scanRepos.Count) }
    if ($repo -eq $HomeRepo -and $ExcludeHome) { continue }
    $isHome = ($repo -eq $HomeRepo)
    $facts = if ($isHome -and $liveShardDir) { @(Import-Shard $repo 'used') } else { @(Import-Shard $repo 'used') }
    $refs = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($r in (Import-Shard $repo 'refs')) { [void]$refs.Add($r.RefName) }
    $refsByRepo[$repo] = $refs
    if ($facts.Count -eq 0 -and $refs.Count -eq 0) { continue }

    # proxies / wire identities this repo declares for each contract name
    $proxies = @($facts | Where-Object { $_.Kind -eq 'SoapProxy' })
    foreach ($f in $facts) { if ($f.Host) { if (-not $hostSeen.ContainsKey($repo)) { $hostSeen[$repo] = New-Object 'System.Collections.Generic.HashSet[string]' }; [void]$hostSeen[$repo].Add($f.Host) } }

    # ---- SOAP
    foreach ($s in $soap) {
        $copy = $copyRepos[$s.Id].Contains($repo)
        $clientSideOnly = $isHome -or $copy
        $myProxy = @($proxies | Where-Object { $_.Value -ieq $s.Contract -and ((NormNs (Get-Detail $_.Detail 'wire')) -eq $s.Wire -or -not $s.Wire) })
        $refHit = @($s.ProjNames | Where-Object { $refs.Contains($_) })
        $nameCands = @(); if ($decl.ContainsKey($s.Contract.ToLowerInvariant())) { $nameCands = @($decl[$s.Contract.ToLowerInvariant()] | ForEach-Object { $_.Wire } | Select-Object -Unique) }
        foreach ($f in $facts) {
            switch ($f.Kind) {
                'SoapProxy' {
                    if ($f.Value -ine $s.Contract) { break }
                    $w = NormNs (Get-Detail $f.Detail 'wire')
                    if ($s.Wire -and $w -and $w -eq $s.Wire) { Add-Ev $s $repo $f 'GeneratedProxy' 'High' 'WireIdentity' '' }
                    elseif (-not $s.Wire -or -not $w) { Add-Ev $s $repo $f 'GeneratedProxy' $(if ($refHit.Count) { 'High' } else { 'Low' }) 'NameOnly' '' }
                }
                'SoapClientEndpoint' {
                    $addrLeaf = if ($f.UrlPath) { ($f.UrlPath.TrimEnd('/') -split '/')[-1] } else { '' }
                    $cShort = Get-ShortName (Get-Detail $f.Detail 'contract')
                    $addrMatch = $s.SvcLeaf -and ($addrLeaf -eq $s.SvcLeaf)
                    $contractMatch = ($cShort -ieq $s.Contract) -and ($myProxy.Count -gt 0 -or $refHit.Count -gt 0 -or $nameCands.Count -le 1)
                    if (-not ($addrMatch -or $contractMatch)) { break }
                    $conf = if ($addrMatch -and $contractMatch) { 'High' } elseif ($addrMatch) { 'Medium' } else { if ($myProxy.Count -gt 0 -or $refHit.Count -gt 0) { 'High' } else { 'Low' } }
                    $how = if ($addrMatch -and $contractMatch) { 'Contract+Address' } elseif ($addrMatch) { 'AddressOnly' } else { 'ContractOnly' }
                    if ($addrMatch -and $f.Host -and $homeHosts.Count -gt 0) { if ($homeHosts.Contains($f.Host)) { $conf = 'High'; $how += '+HostMatch' } else { $conf = 'Low'; $how += '+HostMismatch' } }
                    Add-Ev $s $repo $f 'ConfigClientEndpoint' $conf $how ''
                }
                'ClientType' {
                    if ($clientSideOnly -or $f.Value -ine $s.Contract) { break }
                    if ($myProxy.Count -gt 0) { Add-Ev $s $repo $f 'CodeReference' 'High' 'Local' '' }
                    elseif ($refHit.Count -gt 0) { Add-Ev $s $repo $f 'CodeReference' 'High' 'ProjectRef' '' }
                    elseif ($nameCands.Count -le 1) { Add-Ev $s $repo $f 'CodeReference' 'Low' 'NameOnly' '' }
                    else { Add-Ev $s $repo $f 'CodeReference' 'Low' 'Ambiguous' 'several contracts share this interface name' }
                }
                default {
                    if ($clientSideOnly -or -not $s.SvcLeaf) { break }
                    $isSvcRef = ($f.Kind -in 'ServiceUrl', 'UrlLiteral', 'ConfigUrl') -and $f.UrlPath -and (($f.UrlPath.TrimEnd('/') -split '/')[-1] -eq $s.SvcLeaf)
                    if (-not $isSvcRef) { break }
                    $conf = 'Medium'; $how = 'SvcName'
                    if ($f.Host -and $homeHosts.Count -gt 0) { if ($homeHosts.Contains($f.Host)) { $conf = 'High'; $how = 'SvcName+HostMatch' } else { $conf = 'Low'; $how = 'SvcName+HostMismatch' } }
                    Add-Ev $s $repo $f 'ServiceUrlReference' $conf $how ''
                }
            }
        }
        if (-not $clientSideOnly -and $refHit.Count -gt 0 -and $s.ProjNames.Count -gt 0) {
            Add-Ev $s $repo ([pscustomobject]@{ File = ''; Line = 0; Value = ('References ' + ($refHit -join ',')); Detail = '' }) 'LibraryReference' 'Low' 'ProjectRef' ''
        }
    }

    # ---- REST
    if ($restIdx.Count -gt 0) {
        $done = @{}
        foreach ($f in $facts) {
            if ($f.Kind -notin 'RouteLiteral', 'UrlLiteral', 'ConfigUrl' -or -not $f.UrlPath) { continue }
            if ($f.UrlPath -match '\.svc$') { continue }
            $sp = Split-UrlPath $f.UrlPath
            if ($sp.Segs.Count -eq 0) { continue }
            $keys = @(); if ($sp.Segs.Count -ge 2) { $keys += ($sp.Segs[0] + '/' + $sp.Segs[1]) }; $keys += $sp.Segs[0]
            $found = New-Object System.Collections.Generic.List[object]
            foreach ($k in $keys) { if ($restIdx.ContainsKey($k)) { foreach ($c in $restIdx[$k]) { $lvl = Test-RouteMatch $c $sp.Segs $sp.Trail; if ($lvl) { $found.Add(@{ C = $c; Lvl = $lvl }) } } } }
            if ($found.Count -eq 0) { continue }
            $hint = @(); if ($f.Verb) { $hint = @($f.Verb -split '\|') }
            $keep = New-Object System.Collections.Generic.List[object]
            foreach ($fm in $found) { if ($hint.Count -gt 0 -and $fm.C.Verb -ne 'ANY' -and $hint -notcontains $fm.C.Verb) { continue }; $keep.Add($fm) }
            $hasFull = $false; foreach ($fm in $keep) { if ($fm.Lvl -eq 'Full') { $hasFull = $true } }
            foreach ($fm in $keep) {
                $c = $fm.C; $lvl = $fm.Lvl
                if ($hasFull -and $lvl -ne 'Full') { continue }
                $dk = $c.Id + '|' + $f.UrlPath; if ($done.ContainsKey($dk)) { continue }; $done[$dk] = $true
                $conf = if ($lvl -eq 'Full') { 'Medium' } else { 'Low' }
                if ($c.StrongCount -lt 2) { $conf = 'Low' }
                $how = $lvl + $(if ($hint.Count -gt 0) { '+VerbHint' } else { '' })
                if ($f.Host -and $homeHosts.Count -gt 0) { if ($homeHosts.Contains($f.Host)) { $conf = $(if ($lvl -eq 'Full') { 'High' } else { 'Medium' }); $how += '+HostMatch' } else { $conf = 'Low'; $how += '+HostMismatch' } }
                Add-Ev $c $repo $f 'RouteLiteral' $conf $how ''
            }
        }
    }
}
# host-in-repo boost: a repo that mentions the home host AND matches the route is a much stronger candidate
if ($homeHosts.Count -gt 0) {
    foreach ($e in $ev) {
        if ($e.Confidence -eq 'High' -or $e.Resolution -match 'HostMismatch' -or $e.EvidenceType -notin 'RouteLiteral', 'ServiceUrlReference') { continue }
        if (-not $hostSeen.ContainsKey($e.ConsumerRepo)) { continue }
        if (@($homeHosts | Where-Object { $hostSeen[$e.ConsumerRepo].Contains($_) }).Count -gt 0) { $e.Confidence = $(if ($e.Resolution -like 'Prefix*') { 'Medium' } else { 'High' }); $e.Resolution += '+HostInRepo' }
    }
}

# ------------------------------------------------------------------------------------------------
# 6. write engine-format files and let Find-ServiceUsage build the report
# ------------------------------------------------------------------------------------------------
$cache = Join-Path $WorkPath 'report'; $null = New-Item -ItemType Directory -Force -Path (Join-Path $cache 'inventory'), (Join-Path $cache 'usage')
$clusterRows = New-Object System.Collections.Generic.List[object]
foreach ($s in $soap) {
    $flags = New-Object System.Collections.Generic.List[string]
    $copies = @($copyRepos[$s.Id])
    $otherHosts = @(); if ($decl.ContainsKey($s.Contract.ToLowerInvariant())) { $otherHosts = @($decl[$s.Contract.ToLowerInvariant()] | Where-Object { $_.Repo -ne $HomeRepo -and $_.Role -in 'Host', 'Implementation' -and (-not $s.Wire -or $_.Wire -eq $s.Wire) } | ForEach-Object { $_.Repo } | Select-Object -Unique) }
    if ($otherHosts.Count -gt 0) { $flags.Add('MultiHost') }
    if ($copies.Count -gt 0) { $flags.Add('DefinedInMultipleRepos') }
    $wiresOfName = @(); if ($decl.ContainsKey($s.Contract.ToLowerInvariant())) { $wiresOfName = @($decl[$s.Contract.ToLowerInvariant()] | ForEach-Object { $_.Wire } | Select-Object -Unique) }
    if ($wiresOfName.Count -gt 1) { $flags.Add('NameCollision') }
    if ($s.Flags -match 'ContractNotInScannedRepos' -and -not $s.Note -and $s.Ops.Count -eq 0) { $flags.Add('ContractNotInScannedRepos') }     # the harvest flag is group-local: only repeat it if the inventory really has no declaration of the contract
    $clusterRows.Add([pscustomobject][ordered]@{
        ClusterId = $s.Id; Kind = 'WCF'; Name = $s.Contract; Owner = $HomeRepo; OwnerConfidence = ''; HostRepos = (@($HomeRepo) + $otherHosts) -join ';'; ImplRepos = ''
        DefinitionRepos = (@($HomeRepo) + $copies) -join ';'; ProxyRepos = ''; OperationCount = $s.Ops.Count; Operations = ($s.Ops -join ';'); InterfaceNames = $s.Contract; ClientClasses = ''
        ClrNamespaces = ''; WireNamespace = $s.WireRaw; SvcFiles = $s.SvcFile; DefinitionProjectNames = ($s.ProjNames -join ';'); HttpVerb = ''; Route = ''; RouteNormalized = ''; Flags = ($flags -join ';')
    })
}
foreach ($c in $rest) {
    $flags = @(Split-List $c.Flags); if ($c.OtherRepos.Count -gt 0) { $flags += 'DuplicateRoute' }
    $clusterRows.Add([pscustomobject][ordered]@{
        ClusterId = $c.Id; Kind = 'REST'; Name = ($c.Verb + ' /' + $c.RouteNorm); Owner = $HomeRepo; OwnerConfidence = ''; HostRepos = (@($HomeRepo) + @($c.OtherRepos)) -join ';'; ImplRepos = ''
        DefinitionRepos = (@($HomeRepo) + @($c.OtherRepos)) -join ';'; ProxyRepos = ''; OperationCount = 1; Operations = ($c.Controller + '.' + $c.Method); InterfaceNames = ''; ClientClasses = ''
        ClrNamespaces = ''; WireNamespace = ''; SvcFiles = ''; DefinitionProjectNames = ''; HttpVerb = $c.Verb; Route = $c.Route; RouteNormalized = $c.RouteNorm; Flags = ($flags -join ';')
    })
}
$clusterRows.ToArray() | Export-Csv -LiteralPath (Join-Path $cache 'inventory\endpoint-clusters.csv') -NoTypeInformation -Encoding UTF8
$clusterRows.ToArray() | Select-Object ClusterId | Export-Csv -LiteralPath (Join-Path $cache 'discovered-endpoints.csv') -NoTypeInformation -Encoding UTF8
if ($inputRes.Count -gt 0) { $inputRes.ToArray() | Export-Csv -LiteralPath (Join-Path $cache 'input-resolution.csv') -NoTypeInformation -Encoding UTF8 }
$evArr = $ev.ToArray()
$evArr | Export-Csv -LiteralPath (Join-Path $cache 'usage\usage-detail.csv') -NoTypeInformation -Encoding UTF8
$rank = @{ High = 3; Medium = 2; Low = 1 }
$clusterById = @{}; foreach ($c in $clusterRows) { $clusterById[$c.ClusterId] = $c }
$summary = New-Object System.Collections.Generic.List[object]
foreach ($g in ($evArr | Group-Object ClusterId, ConsumerRepo)) {
    $rows = $g.Group
    $best = ($rows | Sort-Object { - $rank[$_.Confidence] } | Select-Object -First 1)
    $summary.Add([pscustomobject][ordered]@{
        ClusterId = $best.ClusterId; Kind = $best.Kind; Endpoint = $clusterById[$best.ClusterId].Name; Owner = $HomeRepo; ConsumerRepo = $best.ConsumerRepo; InHomeRepo = $best.IsSelf
        BestConfidence = $best.Confidence; EvidenceCount = $rows.Count; EvidenceTypes = (($rows | Select-Object -ExpandProperty EvidenceType -Unique) -join ';')
        Resolutions = (($rows | Select-Object -ExpandProperty Resolution -Unique) -join ';'); OperationsUsed = ''; TargetHostRepos = ''
        AmbiguousWith = (($rows | Where-Object Candidates | Select-Object -ExpandProperty Candidates -Unique) -join ' | '); BestFile = $best.File; BestLine = $best.Line; BestSnippet = $best.Snippet
    })
}
$summary.ToArray() | Export-Csv -LiteralPath (Join-Path $cache 'usage\consumer-summary.csv') -NoTypeInformation -Encoding UTF8

$rp = @{ ReportFromCache = $cache; OutputPath = $OutputPath; HomeLabel = $HomeRepo; ContractLevel = $true }
if ($IncludeLow) { $rp.IncludeLow = $true }
if ($Detail) { $rp.Detail = $true }
$old = $ProgressPreference; $ProgressPreference = 'SilentlyContinue'
try { & (Join-Path $PSScriptRoot 'Find-ServiceUsage.ps1') @rp } finally { $ProgressPreference = $old }
Write-Host ("  wrote {0}" -f (Join-Path $OutputPath 'home-endpoints.csv'))
Remove-Item -Recurse -Force $WorkPath -ErrorAction SilentlyContinue
