<#
.SYNOPSIS
    Which repos integrate with this S3 bucket, which of them are .NET Framework / .NET 7 / 8 / 10 projects, and which change most often?

.DESCRIPTION
    1. CANDIDATES - from the inventory built by Build-UrlInventory.ps1 (nothing is cloned or rescanned): every repo whose saved URL facts mention the
       bucket. Give the bucket as a URL or a name, any mix:
           https://acme-docs.s3.amazonaws.com/uploads/        (virtual-hosted)        s3://acme-docs/uploads/
           https://s3.us-east-1.amazonaws.com/acme-docs/...   (path-style)            arn:aws:s3:::acme-docs
           https://acme-docs.s3.ca-central-1.amazonaws.com    (regional)              acme-docs   (bare bucket name)
       A URL that is not AWS (MinIO, CloudFront / custom domain) is matched by host + path.
    2. FRAMEWORK - for every candidate the repo's file tree and project files are read through the Git server API (GitHub / GitHub Enterprise or
       Azure DevOps; no clone). The project that CONTAINS the S3 reference is looked at (nearest *.csproj above the file; -RepoWide = every project),
       and classified from <TargetFramework(s)> / <TargetFrameworkVersion> / Directory.Build.props / web.config / app.config:
           NetFramework (4.x)   Net5 Net6 Net7 Net8 Net9 Net10   Core (netcoreapp)   Standard (netstandard)
       -TargetFramework chooses what you want (default: NetFramework, Net7, Net8, Net10). Repos that are not .NET or have another framework are
       listed as excluded, with the reason.
    3. RANK - the qualifying repos are ranked by how often they change: commits on the default branch in the last -ActivityDays (default 180),
       also counted for just the files that hold the S3 reference. -Top N keeps the N best.
    4. OUTPUT - a table on screen and, in -OutputPath: s3-repos.csv (every candidate with its status), s3-evidence.csv (file / line / URL per
       repo), repos-to-clone.txt (names), clone-list.txt (clone URLs), clone-selected.ps1 (git clone commands). -Clone clones the selected repos.

    What the inventory can find: S3 references written as https:// URLs (the usual appsettings / config / code form). Bare `BucketName` settings,
    s3:// URIs and AWS SDK usage are not URLs and are not in an inventory harvested by an older scanner; -CodeSearch adds the server's code search
    (GitHub) for those, and the AWSSDK.S3 package reference seen in the project files is shown in the S3Sdk column.

.EXAMPLE
    .\Find-S3Repos.ps1 -InventoryPath D:\url-inventory -S3 https://acme-docs.s3.amazonaws.com -Top 5
.EXAMPLE
    .\Find-S3Repos.ps1 -InventoryPath D:\url-inventory -S3 acme-docs,acme-reports -TargetFramework Any -ActivityDays 90 -Top 10 -OutputPath C:\work\s3
.EXAMPLE
    $env:GITHUB_TOKEN = '<token with repo / contents read>'
    .\Find-S3Repos.ps1 -InventoryPath D:\url-inventory -S3 s3://acme-docs/exports -Top 5 -Clone -CloneTo D:\work\s3-repos
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$InventoryPath,
    # the bucket(s): URL, s3:// URI, ARN or bucket name
    [Alias('S3Url', 'Url', 'Bucket')][string[]]$S3 = @(),
    [string]$S3File,
    # how many repos you want in the end (0 = every qualifying repo)
    [int]$Top = 0,
    # Activity = commits on the default branch in the window; S3Activity = commits touching the files that hold the S3 reference; LastCommit; Evidence = number of S3 references
    [ValidateSet('Activity', 'S3Activity', 'LastCommit', 'Evidence')][string]$RankBy = 'Activity',
    [int]$ActivityDays = 180,
    # NetFramework | Net5 | Net6 | Net7 | Net8 | Net9 | Net10 | Core | Standard | Any
    [string[]]$TargetFramework = @('NetFramework', 'Net7', 'Net8', 'Net10'),
    # judge every project of the repo, not only the project that holds the S3 reference
    [switch]$RepoWide,
    # skip the Git server completely: list the repos that reference the bucket (no framework, no ranking by activity)
    [switch]$NoFramework,
    [ValidateSet('Auto', 'GitHub', 'AzureDevOps')][string]$Provider = 'Auto',
    # needed only for repos whose RepoUrl is not in repos.csv yet:  https://host/org   or   https://dev.azure.com/org/project
    [string]$BaseUrl,
    # API root, e.g. https://ghe.example.com/api/v3  (default: derived from the repo URL)
    [string]$ApiBase,
    [string]$Token,
    [int]$MaxCandidates = 300,
    [int]$MaxProjectFiles = 25,
    # also ask the server's code search (GitHub) for the bucket name: finds s3:// URIs, ARNs and BucketName settings that are not in the inventory
    [switch]$CodeSearch,
    [string]$OutputPath = (Get-Location).Path,
    [switch]$Clone,
    [string]$CloneTo
)

$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }
function Log([string]$m, [string]$color = '') { if ($color) { Write-Host $m -ForegroundColor $color } else { Write-Host $m } }
function Safe-Name([string]$n) { return ($n -replace '[\\/:*?"<>|]', '_') }

# ------------------------------------------------------------------------------------------------------------------ inputs
$inputs = New-Object System.Collections.Generic.List[string]
foreach ($x in $S3) { foreach ($p in ($x -split '[,;\r\n]')) { if ($p.Trim()) { $inputs.Add($p.Trim()) } } }
if ($S3File) {
    if (-not (Test-Path -LiteralPath $S3File)) { throw "S3File not found: $S3File" }
    foreach ($l in (Get-Content -LiteralPath $S3File)) { $t = $l.Trim(); if ($t -and $t -notmatch '^#') { $inputs.Add($t) } }
}
if ($inputs.Count -eq 0) { throw 'Nothing to look for: pass -S3 (bucket URL / s3:// URI / ARN / bucket name) and/or -S3File.' }
if (-not (Test-Path -LiteralPath $InventoryPath)) { throw "InventoryPath not found: $InventoryPath" }
$InventoryPath = (Resolve-Path -LiteralPath $InventoryPath).Path
$shardDir = Join-Path $InventoryPath 'shards'; $reposFile = Join-Path $InventoryPath 'repos.csv'
if (-not (Test-Path $reposFile) -or -not (Test-Path $shardDir)) { throw "$InventoryPath is not an inventory folder (repos.csv / shards missing) - run Build-UrlInventory.ps1 first." }
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null; $OutputPath = (Resolve-Path -LiteralPath $OutputPath).Path

# wanted frameworks
$wantKeys = New-Object System.Collections.Generic.HashSet[string] ([System.StringComparer]::OrdinalIgnoreCase)
foreach ($t in $TargetFramework) { foreach ($p in ($t -split '[,;\s]+')) { if ($p) { [void]$wantKeys.Add(($p -replace '[^A-Za-z0-9]', '')) } } }
$anyFramework = $wantKeys.Contains('Any')
$validKeys = 'NetFramework', 'Net5', 'Net6', 'Net7', 'Net8', 'Net9', 'Net10', 'Core', 'Standard', 'Any'
foreach ($k in $wantKeys) { if ($validKeys -notcontains $k) { throw "Unknown -TargetFramework '$k'. Use: $($validKeys -join ', ')" } }

# ---- the bucket(s): name + optional key prefix, or host + path for a non-AWS endpoint
function Read-S3Input([string]$raw) {
    $t = $raw.Trim(); $bucket = ''; $prefix = ''; $hostName = ''; $path = ''
    if ($t -match '^(?i)s3a?://([^/\s]+)(?:/(.*))?$') { $bucket = $Matches[1]; $prefix = $Matches[2] }
    elseif ($t -match '^(?i)arn:aws[\w-]*:s3:::([^/\s]+)(?:/(.*))?$') { $bucket = $Matches[1]; $prefix = $Matches[2] }
    elseif ($t -match '^(?i)https?://([^/?#\s]+)(/[^?#]*)?') {
        $hostName = ($Matches[1] -replace ':\d+$', '').ToLowerInvariant(); $path = "$($Matches[2])".Trim('/')
        if ($hostName -match '(?i)\.amazonaws\.com(\.cn)?$') {
            if ($hostName -match '^(?<b>.+?)\.s3[.-]') { $bucket = $Matches['b']; $prefix = $path }        # virtual-hosted / regional / website / dualstack
            elseif ($hostName -match '^s3[.-]') { $segs = @($path -split '/', 2); $bucket = $segs[0]; $prefix = $(if ($segs.Count -gt 1) { $segs[1] } else { '' }) }   # path-style
        }
    }
    elseif ($t -match '^[a-z0-9][a-z0-9.\-]{2,62}$') { $bucket = $t }
    else { throw "Cannot read '$raw' as an S3 bucket (use a bucket URL, s3:// URI, ARN or bucket name)." }
    $bucket = "$bucket".ToLowerInvariant()
    return [pscustomobject]@{ Raw = $raw; Bucket = $bucket; Prefix = ("$prefix").Trim('/').ToLowerInvariant(); Host = $(if ($bucket) { '' } else { $hostName }); Path = $path.ToLowerInvariant() }
}
$targets = @($inputs | ForEach-Object { Read-S3Input $_ })
foreach ($t in $targets) { Log ("Looking for: {0}" -f $(if ($t.Bucket) { "bucket '$($t.Bucket)'" + $(if ($t.Prefix) { " (prefix '$($t.Prefix)')" } else { '' }) } else { "$($t.Host)/$($t.Path) (not an AWS address: matched by host and path)" })) }

# ------------------------------------------------------------------------------------------------------------------ 1. candidates from the inventory
$repoInfo = @{}; $okRepos = New-Object System.Collections.Generic.List[string]
foreach ($r in (Import-Csv $reposFile)) { if (-not $r.Repo) { continue }; $repoInfo[$r.Repo] = $r; if ($r.Status -eq 'ok') { $okRepos.Add($r.Repo) } }
$notHarvested = $repoInfo.Count - $okRepos.Count

$tokens = @(); foreach ($t in $targets) { if ($t.Bucket) { $tokens += [regex]::Escape($t.Bucket) } else { $tokens += [regex]::Escape($t.Host) } }
$scanRx = New-Object System.Text.RegularExpressions.Regex(('(?i)' + ($tokens -join '|')))

function Test-FactMatch($u, $t) {
    # returns 'bucket+prefix' | 'bucket' | $null
    $h = "$($u.Host)".ToLowerInvariant(); $url = if ($u.Value) { "$($u.Value)" } else { "$($u.Url)" }      # shard files call the column Value, the merged urls-used.csv calls it Url
    if (-not $h -and $url -match '^(?i)[a-z0-9+.-]+://([^/:?#]+)') { $h = $Matches[1].ToLowerInvariant() }
    $p = ''; if ($url -match '^(?i)[a-z0-9+.-]+://[^/?#]+(/[^?#]*)?') { $p = "$($Matches[1])".Trim('/').ToLowerInvariant() }
    if ($t.Bucket) {
        $b = $t.Bucket
        $key = $null
        if ($h -match '(?i)\.amazonaws\.com(\.cn)?$') {
            if ($h.StartsWith($b + '.s3.') -or $h.StartsWith($b + '.s3-')) { $key = $p }
            elseif ($h -match '^s3[.-]') { $segs = @($p -split '/', 2); if ($segs[0] -eq $b) { $key = $(if ($segs.Count -gt 1) { $segs[1] } else { '' }) } }
        }
        elseif ($u.Kind -eq 'S3Bucket' -and $h -eq $b) { $key = $p }
        elseif ($h -eq $b) { $key = $p }                  # a bucket named like its domain, served as http(s)://<bucket>/...
        if ($null -eq $key) { return $null }
        if ($t.Prefix -and $key.StartsWith($t.Prefix)) { return 'bucket+prefix' }
        return 'bucket'
    }
    if ($h -eq $t.Host -and ($t.Path -eq '' -or $p.StartsWith($t.Path))) { return $(if ($t.Path) { 'bucket+prefix' } else { 'bucket' }) }
    return $null
}

$evidence = New-Object System.Collections.Generic.List[object]
Log "Searching the saved URL facts of $($okRepos.Count) harvested repos ..."
foreach ($repo in $okRepos) {
    $f = Join-Path $shardDir ((Safe-Name $repo) + '.used.csv'); if (-not (Test-Path -LiteralPath $f)) { continue }
    $text = [System.IO.File]::ReadAllText($f)
    if (-not $scanRx.IsMatch($text)) { continue }
    $lines = $text -split "`r?`n"
    $hdr = ($lines[0] -replace '[\uFEFF"]', '') -split ','
    $hit = @($lines | Select-Object -Skip 1 | Where-Object { $_ -and $scanRx.IsMatch($_) })
    foreach ($u in ($hit | ConvertFrom-Csv -Header $hdr)) {
        foreach ($t in $targets) {
            $lvl = Test-FactMatch $u $t
            if ($lvl) { $evidence.Add([pscustomobject]@{ Repo = $repo; File = $u.File; Line = $u.Line; Url = $(if ($u.Value) { $u.Value } else { $u.Url }); Kind = $u.Kind; MatchLevel = $lvl; Query = $t.Raw; Source = 'inventory' }) }
        }
    }
}

# ---- optional: the server's code search for the bucket name (s3:// URIs, ARNs, BucketName settings are not URLs)
$script:Token = if ($Token) { $Token } elseif ($env:GITHUB_TOKEN) { $env:GITHUB_TOKEN } elseif ($env:AZURE_DEVOPS_PAT) { $env:AZURE_DEVOPS_PAT } else { $env:SYSTEM_ACCESSTOKEN }

if (-not $script:Token -and -not $NoFramework) { Log 'WARNING: no token found ($env:GITHUB_TOKEN / $env:AZURE_DEVOPS_PAT / -Token). Private repos cannot be read and GitHub allows only 60 anonymous requests per hour.' 'Yellow' }

function Get-RepoCtx($row) {
    # owner / name / API root / headers for one repo (GitHub or Azure DevOps), from its RepoUrl
    $url = "$($row.RepoUrl)"
    $prov = "$($row.Provider)"
    if (-not $url -and $BaseUrl) {
        $b = $BaseUrl.TrimEnd('/')
        $url = if ($b -match '(?i)dev\.azure\.com|visualstudio\.com|/tfs/') { "$b/_git/$($row.Repo)" } else { "$b/$($row.Repo)" }
        if (-not $prov) { $prov = if ($b -match '(?i)dev\.azure\.com|visualstudio\.com|/tfs/') { 'AzureDevOps' } else { 'GitHub' } }
    }
    if (-not $url) { return $null }
    $url = $url -replace '://[^/@]+@', '://'
    if ($Provider -ne 'Auto') { $prov = $Provider }
    if (-not $prov) { $prov = if ($url -match '/_git/') { 'AzureDevOps' } else { 'GitHub' } }
    $u = [uri]$url
    $branch = "$($row.DefaultBranch)"
    if ($prov -eq 'GitHub') {
        $segs = @($u.AbsolutePath.Trim('/') -replace '\.git$', '' -split '/')
        if ($segs.Count -lt 2) { return $null }
        $api = if ($ApiBase) { $ApiBase.TrimEnd('/') } elseif ($u.Host -eq 'github.com') { 'https://api.github.com' } else { "$($u.Scheme)://$($u.Host)/api/v3" }
        $h = @{ Accept = 'application/vnd.github+json'; 'User-Agent' = 'endpoint-scan'; 'X-GitHub-Api-Version' = '2022-11-28' }
        if ($script:Token) { $h.Authorization = "Bearer $($script:Token)" }
        return [pscustomobject]@{ Provider = 'GitHub'; Api = $api; Owner = $segs[0]; Name = $segs[1]; Branch = $branch; Headers = $h; CloneUrl = $url; Root = '' }
    }
    $root = if ($ApiBase) { $ApiBase.TrimEnd('/') } else { ($url -replace '/_git/.*$', '') }
    $nm = [uri]::UnescapeDataString((($url -split '/_git/')[-1]).Trim('/'))
    $h = @{ Accept = 'application/json'; 'User-Agent' = 'endpoint-scan' }
    if ($script:Token) { $h.Authorization = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(":$($script:Token)")) }
    return [pscustomobject]@{ Provider = 'AzureDevOps'; Api = $root; Owner = ''; Name = $nm; Branch = $branch; Headers = $h; CloneUrl = $url; Root = $root }
}

# ------------------------------------------------------------------------------------------------------------------ API helpers
function Invoke-Web([string]$url, [hashtable]$headers, [string]$method = 'Get', $body = $null) {
    for ($attempt = 1; $attempt -le 4; $attempt++) {
        try {
            $p = @{ Uri = $url; Headers = $headers; Method = $method; TimeoutSec = 120; ErrorAction = 'Stop'; UseBasicParsing = $true }
            if ($null -ne $body) { $p.Body = $body; $p.ContentType = 'application/json' }
            return (Invoke-WebRequest @p)
        } catch {
            $code = 0; $resp = $_.Exception.Response
            if ($resp) { $code = [int]$resp.StatusCode }
            if ($code -eq 404 -or $code -eq 409 -or $code -eq 422) { return $null }
            if ($code -in 401, 203) { throw "The server rejected the credentials (HTTP $code) - set `$env:GITHUB_TOKEN / `$env:AZURE_DEVOPS_PAT or pass -Token (it needs read access to the repos' code)." }
            if (($code -eq 403 -or $code -eq 429) -and $attempt -lt 4) {
                $wait = 60
                $ra = $null; $reset = $null
                try { $ra = ($resp.Headers.GetValues('Retry-After') | Select-Object -First 1) } catch { }                 # PowerShell 7 (HttpResponseMessage) and 5.1 (WebHeaderCollection)
                if (-not $ra) { try { $ra = $resp.Headers['Retry-After'] } catch { } }
                try { $reset = ($resp.Headers.GetValues('X-RateLimit-Reset') | Select-Object -First 1) } catch { }
                if (-not $reset) { try { $reset = $resp.Headers['X-RateLimit-Reset'] } catch { } }
                if ($ra) { $wait = [Math]::Max(1, [Math]::Min(300, [int]("$ra" -replace '\D', ''))) }
                elseif ($reset) { $until = [DateTimeOffset]::FromUnixTimeSeconds([long]("$reset" -replace '\D', '')); $wait = [Math]::Max(1, [Math]::Min(300, [int]($until - [DateTimeOffset]::UtcNow).TotalSeconds + 2)) }
                Log "  API rate limit, waiting $wait s ..." 'Yellow'; Start-Sleep -Seconds $wait; continue
            }
            if (($code -ge 500 -or $code -eq 0) -and $attempt -lt 4) { Start-Sleep -Seconds (2 * $attempt); continue }
            throw
        }
    }
}
function ConvertTo-Text($web) {
    if ($null -eq $web) { return $null }
    $c = $web.Content
    if ($c -is [byte[]]) { $c = [Text.Encoding]::UTF8.GetString($c) }
    return ("$c" -replace '^\uFEFF', '')
}
function Get-Json($web) {
    $t = ConvertTo-Text $web; if ([string]::IsNullOrWhiteSpace($t)) { return $null }
    try { return ($t | ConvertFrom-Json) }
    catch {
        # Windows PowerShell 5.1 stops at 2 MB (maxJsonLength): parse the same text with a serializer that has no such limit
        $first = $_
        try { Add-Type -AssemblyName System.Web.Extensions -ErrorAction Stop; $js = New-Object System.Web.Script.Serialization.JavaScriptSerializer; $js.MaxJsonLength = [int]::MaxValue; $js.RecursionLimit = 200; return $js.DeserializeObject($t) }
        catch { throw $first }
    }
}

function Get-RepoFiles($ctx) {
    # all file paths of the default branch ( @{ Paths; Truncated } )
    $paths = New-Object System.Collections.Generic.List[string]; $trunc = $false
    if ($ctx.Provider -eq 'GitHub') {
        $br = [uri]::EscapeDataString($ctx.Branch)
        $r = Get-Json (Invoke-Web "$($ctx.Api)/repos/$($ctx.Owner)/$($ctx.Name)/git/trees/${br}?recursive=1" $ctx.Headers)
        if ($null -eq $r) { return $null }
        foreach ($e in $r.tree) { if ($e.type -eq 'blob') { $paths.Add([string]$e.path) } }
        $trunc = [bool]$r.truncated
    } else {
        $q = "recursionLevel=Full&api-version=7.1"; if ($ctx.Branch) { $q += "&versionDescriptor.version=$([uri]::EscapeDataString($ctx.Branch))&versionDescriptor.versionType=branch" }
        $r = Get-Json (Invoke-Web "$($ctx.Root)/_apis/git/repositories/$([uri]::EscapeDataString($ctx.Name))/items?$q" $ctx.Headers)
        if ($null -eq $r) { return $null }
        foreach ($e in $r.value) { if (-not $e.isFolder) { $paths.Add(([string]$e.path).TrimStart('/')) } }
    }
    return @{ Paths = $paths; Truncated = $trunc }
}
function Get-RepoFileText($ctx, [string]$path) {
    if ($ctx.Provider -eq 'GitHub') {
        $enc = (($path -split '/') | ForEach-Object { [uri]::EscapeDataString($_) }) -join '/'
        $h = @{} + $ctx.Headers; $h.Accept = 'application/vnd.github.raw'
        return (ConvertTo-Text (Invoke-Web "$($ctx.Api)/repos/$($ctx.Owner)/$($ctx.Name)/contents/${enc}?ref=$([uri]::EscapeDataString($ctx.Branch))" $h))
    }
    $h = @{} + $ctx.Headers; $h.Accept = 'text/plain'
    $q = "path=$([uri]::EscapeDataString('/' + $path))&" + '$format=text' + "&api-version=7.1"; if ($ctx.Branch) { $q += "&versionDescriptor.version=$([uri]::EscapeDataString($ctx.Branch))&versionDescriptor.versionType=branch" }
    return (ConvertTo-Text (Invoke-Web "$($ctx.Root)/_apis/git/repositories/$([uri]::EscapeDataString($ctx.Name))/items?$q" $h))
}
function Get-CommitStats($ctx, [datetime]$since, [string]$path = '') {
    # commits since a date (and the newest commit): @{ Count; Last }
    $iso = $since.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
    if ($ctx.Provider -eq 'GitHub') {
        $b = "$($ctx.Api)/repos/$($ctx.Owner)/$($ctx.Name)/commits?sha=$([uri]::EscapeDataString($ctx.Branch))&per_page=1"
        if ($path) { $b += "&path=$([uri]::EscapeDataString($path))" }
        $w = Invoke-Web ($b + "&since=$iso") $ctx.Headers
        $count = 0
        if ($w) {
            $link = ''; try { $link = ($w.Headers['Link'] -join ',') } catch { }
            if ($link -match '[?&]page=(\d+)[^>]*>;\s*rel="last"') { $count = [int]$Matches[1] }
            else { $j = Get-Json $w; $count = @($j).Count; if ($count -eq 1 -and $null -eq @($j)[0]) { $count = 0 } }
        }
        $last = ''
        $w2 = Invoke-Web $b $ctx.Headers
        if ($w2) { $j2 = @(Get-Json $w2); if ($j2.Count -gt 0 -and $j2[0]) { $last = "$($j2[0].commit.committer.date)" } }
        return @{ Count = $count; Last = $last }
    }
    $b = "$($ctx.Root)/_apis/git/repositories/$([uri]::EscapeDataString($ctx.Name))/commits?api-version=7.1&searchCriteria.`$top=1000"
    if ($ctx.Branch) { $b += "&searchCriteria.itemVersion.version=$([uri]::EscapeDataString($ctx.Branch))&searchCriteria.itemVersion.versionType=branch" }
    if ($path) { $b += "&searchCriteria.itemPath=$([uri]::EscapeDataString('/' + $path))" }
    $j = Get-Json (Invoke-Web ($b + "&searchCriteria.fromDate=$iso") $ctx.Headers)
    $count = 0; if ($j) { $count = [int]$j.count }
    $j2 = Get-Json (Invoke-Web ($b + '&searchCriteria.$top=1') $ctx.Headers)
    $last = ''; if ($j2 -and $j2.value -and @($j2.value).Count -gt 0) { $last = "$(@($j2.value)[0].committer.date)" }
    return @{ Count = $count; Last = $last }
}

# ---- code search (GitHub only, opt-in)
if ($CodeSearch) {
    $firstRow = $null; foreach ($rn in $okRepos) { if ($repoInfo[$rn].RepoUrl) { $firstRow = $repoInfo[$rn]; break } }
    $c0 = $null; if ($firstRow) { $c0 = Get-RepoCtx $firstRow }
    if ($c0 -and $c0.Provider -eq 'GitHub') {
        Log 'Asking the server code search for the bucket name(s) ...'
        $buckets = @($targets | Where-Object { $_.Bucket } | ForEach-Object { $_.Bucket } | Select-Object -Unique)
        foreach ($bn in $buckets) {
            try {
                $w = Invoke-Web "$($c0.Api)/search/code?q=$([uri]::EscapeDataString('"' + $bn + '"'))+org:$($c0.Owner)&per_page=100" $c0.Headers
                $j = Get-Json $w
                if ($j -and $j.items) {
                    foreach ($it in $j.items) {
                        $rn = [string]$it.repository.name
                        $evidence.Add([pscustomobject]@{ Repo = $rn; File = [string]$it.path; Line = 0; Url = "$bn (code search)"; Kind = 'CodeSearch'; MatchLevel = 'bucket'; Query = $bn; Source = 'code-search' })
                        if (-not $repoInfo.ContainsKey($rn)) { $repoInfo[$rn] = [pscustomobject]@{ Repo = $rn; RepoUrl = [string]$it.repository.html_url; Provider = 'GitHub'; DefaultBranch = ''; LastCommit = ''; Status = 'not-in-inventory' } }
                    }
                    Log ("  code search for '{0}': {1} file(s)" -f $bn, @($j.items).Count)
                } else { Log "  code search for '$bn': no results (or code search is not available on this server)" 'Yellow' }
            } catch { Log "  code search failed: $($_.Exception.Message)" 'Yellow' }
            Start-Sleep -Seconds 2
        }
    } else { Log '-CodeSearch is only available for GitHub / GitHub Enterprise.' 'Yellow' }
}

# group the evidence per repo
$byRepo = @{}
foreach ($e in $evidence) { if (-not $byRepo.ContainsKey($e.Repo)) { $byRepo[$e.Repo] = New-Object System.Collections.Generic.List[object] }; $byRepo[$e.Repo].Add($e) }
Log ("{0} repo(s) reference the bucket in the inventory{1}." -f $byRepo.Count, $(if ($notHarvested -gt 0) { " ($notHarvested repo(s) are not harvested - they cannot be found)" } else { '' })) 'Cyan'
if ($byRepo.Count -eq 0) {
    Log 'Nothing found. The inventory only has S3 references written as https:// URLs; try the other spelling of the bucket (name, s3:// URI) with -CodeSearch, or check the bucket name.' 'Yellow'
    return
}

# ------------------------------------------------------------------------------------------------------------------ framework classification
function Get-FrameworkInfo([string]$tok) {
    $t = $tok.Trim().ToLowerInvariant() -replace '-(windows|android|ios|maccatalyst|macos|tizen|browser|linux)[\w.]*$', ''
    if ($t -match '^net(\d{2,3})$') {
        $d = $Matches[1]; $v = if ($d.Length -eq 2) { "$($d[0]).$($d[1])" } else { "$($d[0]).$($d[1]).$($d[2])" }
        return @{ Family = 'NetFramework'; Key = 'NetFramework'; Label = ".NET Framework $v"; Token = $tok }
    }
    if ($t -match '^net(\d+)\.(\d+)$') { $mj = [int]$Matches[1]; if ($mj -ge 5) { return @{ Family = 'Net'; Key = "Net$mj"; Label = ".NET $mj"; Token = $tok } } }
    if ($t -match '^netcoreapp(\d+\.\d+)$') { return @{ Family = 'Core'; Key = 'Core'; Label = ".NET Core $($Matches[1])"; Token = $tok } }
    if ($t -match '^netstandard(\d+\.\d+)$') { return @{ Family = 'Standard'; Key = 'Standard'; Label = ".NET Standard $($Matches[1])"; Token = $tok } }
    return @{ Family = 'Other'; Key = 'Other'; Label = $tok; Token = $tok }
}
function Read-Project([string]$text) {
    $fw = New-Object System.Collections.Generic.List[object]
    $m = [regex]::Match($text, '<TargetFrameworks?>\s*([^<]+?)\s*</TargetFrameworks?>', 'IgnoreCase')
    if ($m.Success) { foreach ($tk in ($m.Groups[1].Value -split '[;\s]+')) { if ($tk -and $tk -notmatch '^\$\(') { $fw.Add((Get-FrameworkInfo $tk)) } } }
    $v = [regex]::Match($text, '<TargetFrameworkVersion>\s*v?([\d.]+)\s*</TargetFrameworkVersion>', 'IgnoreCase')
    if ($v.Success -and $fw.Count -eq 0) { $fw.Add((Get-FrameworkInfo ('net' + ($v.Groups[1].Value -replace '\.', '')))) }
    $sdk = ($text -match 'Sdk\s*=\s*"Microsoft\.NET\.Sdk') -or ($text -match '<Project\s+Sdk=')
    return @{ Frameworks = $fw; Sdk = $sdk; S3Sdk = ($text -match '(?i)AWSSDK\.S3|Amazon\.S3|AWSSDK\.Extensions\.NETCore\.Setup') ; HasTfmProperty = ($text -match '\$\(TargetFramework') }
}
function Get-NearestProjects($paths, [string]$file) {
    # the project(s) above a file: the nearest folder (walking up) that holds a *.csproj / *.vbproj / *.fsproj
    $projs = @($paths | Where-Object { $_ -match '(?i)\.(cs|vb|fs)proj$' })
    $dir = ($file -replace '\\', '/'); $dir = if ($dir.Contains('/')) { $dir.Substring(0, $dir.LastIndexOf('/')) } else { '' }
    while ($true) {
        $here = @($projs | Where-Object { $d = if ($_.Contains('/')) { $_.Substring(0, $_.LastIndexOf('/')) } else { '' }; $d -eq $dir })
        if ($here.Count -gt 0) { return $here }
        if (-not $dir) { return @() }
        $dir = if ($dir.Contains('/')) { $dir.Substring(0, $dir.LastIndexOf('/')) } else { '' }
    }
}

$cutoff = (Get-Date).AddDays(-$ActivityDays)
$rows = New-Object System.Collections.Generic.List[object]
$names = @($byRepo.Keys | Sort-Object { - $byRepo[$_].Count }, { $_ })
if ($names.Count -gt $MaxCandidates) { Log "Only the first $MaxCandidates repos (by number of S3 references) are analysed; raise -MaxCandidates for more." 'Yellow'; $names = @($names | Select-Object -First $MaxCandidates) }

$i = 0
foreach ($name in $names) {
    $i++
    $ev = $byRepo[$name].ToArray(); $info = $repoInfo[$name]
    $row = [ordered]@{
        Rank = ''; Selected = 'no'; Repo = $name; Status = ''; Framework = ''; Family = ''; AllFrameworks = ''; S3Project = ''; S3Sdk = ''
        Evidence = $ev.Count; EvidenceFiles = ((@($ev | ForEach-Object { $_.File } | Select-Object -Unique | Select-Object -First 5)) -join '; '); MatchLevel = $(if (@($ev | Where-Object { $_.MatchLevel -eq 'bucket+prefix' }).Count -gt 0) { 'bucket+prefix' } else { 'bucket' })
        CommitsInWindow = ''; S3FileCommits = ''; LastCommit = ''; Branch = "$($info.DefaultBranch)"; RepoUrl = "$($info.RepoUrl)"
    }
    if ($NoFramework) { $row.Status = 'not analysed (-NoFramework)'; $row.LastCommit = "$($info.LastCommit)"; $rows.Add([pscustomobject]$row); continue }
    $ctx = Get-RepoCtx $info
    if (-not $ctx) { $row.Status = 'cannot reach: RepoUrl is not in repos.csv (run Build-UrlInventory.ps1 once to fill it, or pass -BaseUrl)'; $rows.Add([pscustomobject]$row); Log ("[{0,3}/{1}] {2}: {3}" -f $i, $names.Count, $name, $row.Status) 'Yellow'; continue }
    try {
        if (-not $ctx.Branch) { # branch unknown: ask the repo
            if ($ctx.Provider -eq 'GitHub') { $rj = Get-Json (Invoke-Web "$($ctx.Api)/repos/$($ctx.Owner)/$($ctx.Name)" $ctx.Headers); if ($rj) { $ctx.Branch = [string]$rj.default_branch } }
            else { $rj = Get-Json (Invoke-Web "$($ctx.Root)/_apis/git/repositories/$([uri]::EscapeDataString($ctx.Name))?api-version=7.1" $ctx.Headers); if ($rj) { $ctx.Branch = ("$($rj.defaultBranch)" -replace '^refs/heads/', '') } }
            $row.Branch = $ctx.Branch
        }
        $tree = Get-RepoFiles $ctx
        if ($null -eq $tree) { $row.Status = 'cannot read the repo (not found / no access / empty)'; $rows.Add([pscustomobject]$row); Log ("[{0,3}/{1}] {2}: {3}" -f $i, $names.Count, $name, $row.Status) 'Yellow'; continue }
        $paths = $tree.Paths
        $projAll = @($paths | Where-Object { $_ -match '(?i)\.(cs|vb|fs)proj$' })
        # which projects to judge: the ones holding the S3 reference (nearest project above the file) - or all of them
        $relevant = New-Object System.Collections.Generic.List[string]; $scope = 'project'
        if (-not $RepoWide) {
            foreach ($f in @($ev | ForEach-Object { $_.File } | Select-Object -Unique)) { foreach ($p in (Get-NearestProjects $paths ($f -replace '\\', '/'))) { if (-not $relevant.Contains($p)) { $relevant.Add($p) } } }
        }
        if ($RepoWide -or $relevant.Count -eq 0) { $scope = 'repo'; foreach ($p in ($projAll | Select-Object -First $MaxProjectFiles)) { if (-not $relevant.Contains($p)) { $relevant.Add($p) } } }
        $judged = New-Object System.Collections.Generic.List[object]; $allFw = New-Object System.Collections.Generic.HashSet[string]; $s3sdk = $false
        $propsCache = @{}
        foreach ($p in ($relevant | Select-Object -First $MaxProjectFiles)) {
            $txt = Get-RepoFileText $ctx $p; if (-not $txt) { continue }
            $pi = Read-Project $txt
            if ($pi.S3Sdk) { $s3sdk = $true }
            if ($pi.Frameworks.Count -eq 0) {      # SDK-style project without its own TargetFramework: Directory.Build.props (nearest above)
                $dir = if ($p.Contains('/')) { $p.Substring(0, $p.LastIndexOf('/')) } else { '' }
                while ($true) {
                    $cand = if ($dir) { "$dir/Directory.Build.props" } else { 'Directory.Build.props' }
                    if ($paths -contains $cand) {
                        if (-not $propsCache.ContainsKey($cand)) { $propsCache[$cand] = Read-Project (Get-RepoFileText $ctx $cand) }
                        if ($propsCache[$cand].Frameworks.Count -gt 0) { $pi.Frameworks = $propsCache[$cand].Frameworks; break }
                    }
                    if (-not $dir) { break }
                    $dir = if ($dir.Contains('/')) { $dir.Substring(0, $dir.LastIndexOf('/')) } else { '' }
                }
            }
            $judged.Add(@{ Path = $p; Info = $pi })
            foreach ($fw in $pi.Frameworks) { [void]$allFw.Add($fw.Label) }
        }
        # repos without project files: classic web sites / config-only .NET Framework apps, or not .NET at all
        $notDotNet = ''
        if ($judged.Count -eq 0) {
            foreach ($cfg in @($paths | Where-Object { $_ -match '(?i)(^|/)(web|app)\.config$' } | Select-Object -First 3)) {
                $txt = Get-RepoFileText $ctx $cfg; if (-not $txt) { continue }
                $m = [regex]::Match($txt, '(?i)(?:targetFramework\s*=\s*"|Version=v)(4\.\d(?:\.\d)?)'); if ($m.Success) { $fi = Get-FrameworkInfo ('net' + ($m.Groups[1].Value -replace '\.', '')); $judged.Add(@{ Path = $cfg; Info = @{ Frameworks = @($fi); S3Sdk = $false } }); [void]$allFw.Add($fi.Label + ' (config)') }
            }
            if ($judged.Count -eq 0) {
                $notDotNet = if ($paths -contains 'package.json' -or @($paths | Where-Object { $_ -match '(^|/)package\.json$' }).Count -gt 0) { 'Node / JavaScript' } elseif (@($paths | Where-Object { $_ -match '(^|/)(pom\.xml|build\.gradle)$' }).Count -gt 0) { 'Java' } elseif (@($paths | Where-Object { $_ -match '(^|/)(requirements\.txt|pyproject\.toml|setup\.py)$' }).Count -gt 0) { 'Python' } elseif (@($paths | Where-Object { $_ -match '(^|/)go\.mod$' }).Count -gt 0) { 'Go' } else { '' }
            }
        }
        $keys = New-Object System.Collections.Generic.HashSet[string]; $labels = New-Object System.Collections.Generic.List[string]
        foreach ($j in $judged) { foreach ($fw in $j.Info.Frameworks) { [void]$keys.Add($fw.Key); if (-not $labels.Contains($fw.Label)) { $labels.Add($fw.Label) } } }
        $row.Framework = if ($labels.Count -gt 0) { $labels -join '; ' } elseif ($notDotNet) { "not .NET ($notDotNet)" } else { 'unknown' }
        $row.Family = if ($keys.Count -gt 0) { (@($keys) | Sort-Object) -join '+' } elseif ($notDotNet) { 'NotDotNet' } else { 'Unknown' }
        $row.AllFrameworks = if ($allFw.Count -gt 0) { (@($allFw) | Sort-Object) -join '; ' } else { '' }
        $row.S3Project = if ($judged.Count -gt 0) { (@($judged | Select-Object -First 3 | ForEach-Object { $_.Path }) -join '; ') + $(if ($scope -eq 'repo') { ' (all projects: the S3 file has no project above it)' } else { '' }) } else { '' }
        $row.S3Sdk = if ($s3sdk) { 'yes' } else { 'no' }
        $match = $false
        if ($anyFramework -and $keys.Count -gt 0) { $match = $true } else { foreach ($k in $keys) { if ($wantKeys.Contains($k)) { $match = $true } } }
        if ($tree.Truncated) { $row.Status = 'truncated tree: ' }
        if (-not $match) {
            $row.Status = $row.Status + $(if ($notDotNet) { "excluded: not a .NET repo ($notDotNet)" } elseif ($keys.Count -eq 0) { 'excluded: no .NET project found' } else { "excluded: $($row.Framework)" })
            Log ("[{0,3}/{1}] {2}: {3}" -f $i, $names.Count, $name, $row.Status) 'DarkGray'
        } else {
            $st = Get-CommitStats $ctx $cutoff
            $row.CommitsInWindow = $st.Count; $row.LastCommit = $st.Last
            $s3c = 0
            foreach ($f in @($ev | ForEach-Object { $_.File } | Select-Object -Unique | Select-Object -First 3)) { if ($f) { $s3c += (Get-CommitStats $ctx $cutoff ($f -replace '\\', '/')).Count } }
            $row.S3FileCommits = $s3c
            $row.Status = $row.Status + 'qualifies'
            Log ("[{0,3}/{1}] {2}: {3}  | {4} commit(s) in {5} days, {6} on the S3 files, last {7}" -f $i, $names.Count, $name, $row.Framework, $st.Count, $ActivityDays, $s3c, $st.Last) 'Green'
        }
    } catch {
        if ($_.Exception.Message -like '*rejected the credentials*') { throw }      # a token problem is the same for every repo: stop now
        $row.Status = "error: $($_.Exception.Message)"; Log ("[{0,3}/{1}] {2}: {3}" -f $i, $names.Count, $name, $row.Status) 'Red' }
    $rows.Add([pscustomobject]$row)
}

# ------------------------------------------------------------------------------------------------------------------ rank and select
$qual = @($rows | Where-Object { $_.Status -like '*qualifies' -or ($NoFramework -and $true) })
$sortKey = switch ($RankBy) {
    'Activity'   { { [int]$_.CommitsInWindow } }
    'S3Activity' { { [int]$_.S3FileCommits } }
    'LastCommit' { { "$($_.LastCommit)" } }
    'Evidence'   { { [int]$_.Evidence } }
}
$qual = @($qual | Sort-Object @{ e = $sortKey; Descending = $true }, @{ e = { [int]$_.CommitsInWindow }; Descending = $true }, @{ e = { [int]$_.Evidence }; Descending = $true }, @{ e = { $_.Repo } })
$take = if ($Top -gt 0) { [Math]::Min($Top, $qual.Count) } else { $qual.Count }
for ($k = 0; $k -lt $qual.Count; $k++) { $qual[$k].Rank = $k + 1; if ($k -lt $take) { $qual[$k].Selected = 'yes' } }
$selected = @($qual | Where-Object { $_.Selected -eq 'yes' })

$cols = 'Rank', 'Selected', 'Repo', 'Status', 'Framework', 'Family', 'AllFrameworks', 'S3Project', 'S3Sdk', 'Evidence', 'EvidenceFiles', 'MatchLevel', 'CommitsInWindow', 'S3FileCommits', 'LastCommit', 'Branch', 'RepoUrl'
$ordered = @($rows | Sort-Object @{ e = { if ($_.Rank -ne '') { [int]$_.Rank } else { 99999 } } }, @{ e = { $_.Repo } })
$ordered | Select-Object $cols | Export-Csv -LiteralPath (Join-Path $OutputPath 's3-repos.csv') -NoTypeInformation -Encoding UTF8
@($evidence | Sort-Object Repo, File, Line) | Select-Object Repo, File, Line, Url, Kind, MatchLevel, Query, Source | Export-Csv -LiteralPath (Join-Path $OutputPath 's3-evidence.csv') -NoTypeInformation -Encoding UTF8
Set-Content -LiteralPath (Join-Path $OutputPath 'repos-to-clone.txt') -Value @($selected | ForEach-Object { $_.Repo }) -Encoding UTF8
Set-Content -LiteralPath (Join-Path $OutputPath 'clone-list.txt') -Value @($selected | ForEach-Object { $_.RepoUrl } | Where-Object { $_ }) -Encoding UTF8
$cloneLines = @('# git clone commands for the selected repos (generated by Find-S3Repos.ps1)') + @($selected | Where-Object { $_.RepoUrl } | ForEach-Object { "git clone `"$($_.RepoUrl)`" `"$((Safe-Name $_.Repo))`"" })
Set-Content -LiteralPath (Join-Path $OutputPath 'clone-selected.ps1') -Value $cloneLines -Encoding UTF8

# ---- screen
Log ''
$excluded = @($rows | Where-Object { $_.Status -like '*excluded*' -or $_.Status -like 'cannot*' -or $_.Status -like 'error*' })
if ($NoFramework) { Log ("{0} repo(s) reference the bucket (framework and activity not checked: -NoFramework):" -f $rows.Count) 'Cyan' }
else { Log ("{0} repo(s) qualify ({1}); showing the {2} {3}:" -f $qual.Count, $(if ($anyFramework) { 'any .NET framework' } else { (@($wantKeys) -join ', ') }), $selected.Count, $(if ($RankBy -eq 'Activity') { "most frequently changed in the last $ActivityDays days" } else { "best by $RankBy" })) 'Cyan' }
$show = if ($NoFramework) { @($rows | Sort-Object { - [int]$_.Evidence }) } else { $selected }
foreach ($r in $show) {
    Log ("  {0,2}. {1,-38} {2,-26} {3,4} commits  ({4} on S3 files)  last {5}  S3 SDK: {6}" -f $(if ($r.Rank) { $r.Rank } else { '-' }), $r.Repo, $r.Framework, $r.CommitsInWindow, $r.S3FileCommits, $(if ($r.LastCommit) { ([string]$r.LastCommit).Substring(0, [Math]::Min(10, ([string]$r.LastCommit).Length)) } else { '-' }), $r.S3Sdk) 'Green'
    Log ("      S3 reference: {0}" -f $r.EvidenceFiles) 'DarkGray'
}
if ($excluded.Count -gt 0 -and -not $NoFramework) {
    Log ''; Log ("{0} candidate repo(s) not selected because of the framework / access:" -f $excluded.Count) 'DarkGray'
    foreach ($g in ($excluded | Group-Object { ($_.Status -replace '^truncated tree: ', '') } | Sort-Object Count -Descending | Select-Object -First 8)) { Log ("   {0,3} x {1}   e.g. {2}" -f $g.Count, $g.Name, ((@($g.Group | Select-Object -First 3 | ForEach-Object { $_.Repo })) -join ', ')) 'DarkGray' }
    Log '   (widen with -TargetFramework Any, or check s3-repos.csv for every repo and its reason)' 'DarkGray'
}
Log ''
Log "Wrote: $(Join-Path $OutputPath 's3-repos.csv'), s3-evidence.csv, repos-to-clone.txt, clone-list.txt, clone-selected.ps1"

if ($Clone -and $selected.Count -gt 0) {
    if (-not $CloneTo) { $CloneTo = Join-Path $OutputPath 's3-repos' }
    New-Item -ItemType Directory -Force -Path $CloneTo | Out-Null
    foreach ($r in $selected) {
        $dest = Join-Path $CloneTo (Safe-Name $r.Repo)
        if (Test-Path -LiteralPath $dest) { Log "  skip $($r.Repo): $dest already exists" 'Yellow'; continue }
        if (-not $r.RepoUrl) { Log "  skip $($r.Repo): no clone URL" 'Yellow'; continue }
        Log "  cloning $($r.Repo) -> $dest"
        & git clone $r.RepoUrl $dest 2>&1 | ForEach-Object { "    $_" }
    }
}
