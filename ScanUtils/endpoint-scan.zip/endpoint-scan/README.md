# Service usage toolkit

Two ways of working: a small estate (clone everything, search) or a huge one (build an inventory in batches, then query it). Keep all files in one folder; needs Windows PowerShell 5.1 or PowerShell 7+ and git.

## Thousands of repos / limited disk: build an inventory once, query it many times

Cloning everything is impossible (e.g. 3,400 repos on a small VDI) and re-cloning for every question would be slower still. So: harvest every repo ONCE, in batches, into a small inventory, then answer questions from it.

```powershell
# 1. Build the inventory (resumable; run it again to continue / retry failures; -Refresh to re-harvest)
$env:GITHUB_TOKEN = '<token>'          # or $env:AZURE_DEVOPS_PAT for Azure DevOps (PAT with Code: Read)
.\Build-UrlInventory.ps1 -BaseUrl https://github.com/contoso -InventoryPath D:\url-inventory -WorkPath D:\work -BatchSize 500 -MinFreeGB 10
.\Build-UrlInventory.ps1 -BaseUrl https://dev.azure.com/contoso/MyProject -InventoryPath D:\url-inventory -WorkPath D:\work     # Azure DevOps project
.\Build-UrlInventory.ps1 -FromFolder C:\Proj -InventoryPath D:\url-inventory -BatchSize 100                                   # repos you already have on disk

# 2. Which repos use what ONE repo exposes? (no cloning; ~2 min for 3,400 repos)
.\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepo Orders.Api -HostMapPath .\hosts.csv
.\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepoPath C:\Proj\Orders.Api -Service OrderController.cs,OrderService.svc
```

**Interrupted or timed out?** Just run the same command again. Every repo that already has an entry in `repos.csv` is skipped (not cloned again); progress is saved every `-CheckpointSize` repos (default 25), so at most that many are redone, and repos whose results were saved but never recorded in `repos.csv` are re-adopted automatically.
Failed repos are not retried unless you add `-RetryFailed`. Every git operation has a time limit (`-CloneTimeoutMinutes`, default 15) and a transfer slower than 1 KB/s for 2 minutes is aborted, so one stuck repo cannot freeze the run. If your session or job has a time limit, use `-MaxRunMinutes 50` (for example): the script stops cleanly after the current group and the next run continues. `urls-used.csv` / `endpoints-exposed.csv` are rebuilt when everything is done, or any time with `-MergeOnly`; `Find-HomeRepoUsage.ps1` reads the saved per-repo files directly, so it works on a partial inventory too.

**What the batch loop does:** take the next N repos -> clone them shallow, single-branch and *sparse + partial* (only source/config files; binaries, images, `node_modules`, `bin/obj`, packages are never downloaded - about 25x smaller in my test) -> harvest -> save -> delete the clones. `-MinFreeGB` stops a batch early when the drive gets low; `-MaxBatchGB` caps a batch by the size the server reports.

**Inventory folder**

| File | Content |
|---|---|
| `urls-used.csv` | what each repo calls: `Repo, Url, Kind, Host, UrlPath, Verb, Detail, File, Line, Count, RepoLastCommit, ScannedAt` - kinds: `ConfigUrl` (XML + JSON config), `SoapClientEndpoint` (WCF `<client>`), `SoapProxy` (generated proxy), `ServiceUrl` (*.svc), `UrlLiteral` / `RouteLiteral` (code, frontend, scripts), `ClientType` (`ChannelFactory<T>` / `ClientBase<T>`) |
| `endpoints-exposed.csv` | what each repo exposes: SOAP contract / operation / `.svc` / wire namespace, REST verb + route + controller |
| `repos.csv` | one row per repo: url, branch, last commit, scan time, status (`ok`/`failed`/`empty`), row counts |
| `shards\` | the per-repo source files everything is built from (re-running a repo replaces its shard - no duplicates) |

`Find-HomeRepoUsage.ps1` writes `home-endpoints.csv` (every SOAP/REST endpoint the home repo exposes) plus the usual `service-usage.csv` / `service-summary.csv`.
SOAP is matched per **service** (the inventory does not record which operations are called); REST per **endpoint** (verb + route). Best workflow: let the inventory narrow 3,400 repos to the handful of consumers,
then clone just those (`Clone-GitHubRepos.ps1 -Include ...`) and run `Find-ServiceUsage.ps1` for operation-level detail.

Notes: needs git 2.25+ (the partial clone falls back automatically to a plain shallow clone if the server does not support it); parallel cloning needs PowerShell 7; the inventory is a snapshot - re-run (`-RefreshOlderThanDays 30`) to keep it current.

## Small estates: clone everything

### 1. Clone everything

```powershell
$env:GITHUB_TOKEN = '<token>'        # only needed for private repos / to avoid API limits
.\Clone-GitHubRepos.ps1 -BaseUrl https://github.com/contoso -TargetPath C:\Proj
```

Lists all repos of the org/user through the API and clones them (parallel on PowerShell 7). Shallow, single-branch (latest code only),
archived repos and forks skipped, existing clones left alone. Prints one summary line plus any failures.

| Option | Meaning |
|---|---|
| `-Update` | refresh existing clones (repos with local changes are never touched) |
| `-IncludeArchived` / `-IncludeForks` | include them |
| `-Include` / `-Exclude` | wildcards on repo names |
| `-Depth 0` | full history |
| `-ListOnly` | just list what would be cloned |

Token: fine-grained = Contents *Read-only* on the repos (public repos need no permissions); classic = `repo`. The token is passed to git through the environment only; it is never written to `.git/config`.
GitHub Enterprise Server works (`-BaseUrl https://git.contoso.com/platform`).

### 2. Find the usage

```powershell
# services of ONE repo (the usual case): name the repo once, list the services
.\Find-ServiceUsage.ps1 -HomeRepoPath C:\Proj\Orders.Api -Service OrderController.cs,EmployeeController.cs,OrderService.svc

# ... or leave -Service out: every SOAP service and controller in that repo is searched
.\Find-ServiceUsage.ps1 -HomeRepoPath C:\Proj\Orders.Api

# services from any repos (names must then be unambiguous; or write Name@Repo)
.\Find-ServiceUsage.ps1 -RootPath C:\Proj -Service OrderService.svc,InventoryService.svc,EmployeeController.cs,OrderController.cs
.\Find-ServiceUsage.ps1 -RootPath C:\Proj -ServiceList .\services.txt -OutputPath C:\reports -HostMapPath .\hosts.csv
```

`-HomeRepoPath` = full path of the repo that hosts the services. It must be one of the cloned repos (inside `-RootPath`, which defaults to its parent folder);
a sub-folder of a repo means that repo. All names in `-Service` are taken from it, same-named services in other repos are ignored, and the search covers the home repo
itself (its own frontend) and every other repo.

Input: names, file names or full paths (comma separated and/or a list file, one per line). `X.svc` / `X.cs` match files of that type,
a bare name also matches interface / class / controller names.

**Output: exactly two files** in `-OutputPath` (default: current folder):

| File | Content |
|---|---|
| `service-usage.csv` | one row per service x consuming repo: HostedBy, Confidence, EndpointsUsed (SOAP operations / REST verb+route), Evidence, Example (file:line) |
| `service-summary.csv` | one row per service: HostedBy, Contract, Endpoints, Consumers, ConsumerRepos, EndpointsNotSeenUsed, Notes; plus a row for every input that matched nothing |

Only **High/Medium** confidence consumers are listed. Weak candidates are hidden and counted in Notes (`-IncludeLow` shows them).
`-Detail` adds `service-usage-evidence.csv` (file, line, code snippet per consumer).

Working files live in a cache outside your repo folder and outside the output folder (`%LOCALAPPDATA%\endpoint-scan`).
It is reused between runs and refreshed automatically when any repo's HEAD changed. `-Rescan` forces a refresh, `-NoCache` deletes it afterwards.

`hosts.csv` (optional, recommended): tells the tool which host name belongs to which hosting repo. It confirms REST/SOAP matches and separates
identical routes/interface names in *different* services.

```
Repo,Host
Orders.Api,orders.contoso.com
Orders.Service,orders.contoso.com;orders-internal.contoso.local
```

### Home repo, duplicates and usage inside the home repo

* Routes / operations are read from the code of the home repo - nothing has to be supplied by hand. With **`-HomeRepoPath`** the metadata comes only from that repo.
* Without `-HomeRepoPath`, the hosting repo is discovered automatically. If the same name exists in several repos (e.g. `OrderController.cs` in two repos) each is reported as its own
  service with its own `HostedBy`, and a note says so. Pick one with **`Name@Repo`** (`OrderController.cs@Orders.Api`), a full path, or `-InRepo <repo folder name>`.
* Usage **inside the home repo** is reported too (it is labelled `Orders.Api (home)`), because a frontend living next to the API is a real consumer. `-ExcludeHome` leaves it out.
  The controller's own attribute/route lines, tests, `swagger.json`/`openapi.*`, `launchSettings.json`, markdown docs and build output (`dist`, `node_modules`, `*.min.js`) are never counted.
  For SOAP, inside the home repo only client-side use counts (own generated proxy, `<client>` endpoint config); the implementation, host config and wiring are not consumers.
* Frontend code is scanned: `.js .jsx .ts .tsx .vue .svelte .html .cshtml .razor .aspx` - Angular `http.get<T>(\`/api/x/${id}\`)`, axios/fetch/jQuery, NSwag clients, `"/api/x/" + id`.
  The HTTP verb is taken from the surrounding lines (`axios.delete`, `method: 'POST'`, `type: 'DELETE'`, `HttpMethod.Put`, `PostAsJsonAsync`, Refit attributes ...).

## What is discovered for a REST controller

Give a controller (`EmployeeController`, `EmployeeController.cs`, or leave `-Service` out for the whole repo) and every endpoint (verb + full route) of it is listed, then searched for.
Found: `[HttpGet/Post/Put/Delete/Patch/Head/Options]` with or without a template (`[HttpGet("{id:int}")]`, `[HttpGet(template: "x")]`), several stacked verb attributes on one method
(each becomes its own endpoint), `[Route]` on the method, `[AcceptVerbs]`, class-level `[Route("api/[controller]")]` / `[RoutePrefix]`, API versioning (`api/v{version:apiVersion}/...` matches `/api/v1/...`),
routes from constants (`[Route(Routes.Employees)]`), routes inherited from a base controller, controllers split over several files (`partial`), Web API 2 convention actions (`GetAll` -> `GET api/employee`) and Minimal APIs (`MapGet/MapPost/MapGroup`).
Ignored on purpose: `[NonAction]`, non-public methods, public methods with no HTTP attribute in an ASP.NET Core controller (they are not endpoints).
Not resolved (flagged `UnresolvedRoute` / `ConventionRoute` in the Notes column): constants defined in another repo, computed/interpolated routes, actions inherited from a base controller, MVC conventional routing without attributes.

How callers are recognised: a URL/route string in code, frontend files or config whose segments match the route (`{id}` matches anything; a caller's runtime placeholder never matches a fixed word of another route),
the HTTP verb read from the surrounding code (`http.put`, `PutAsJsonAsync`, `method: 'DELETE'`, ...), `"api/v1/employee/" + id` counts as the full `{id}` route. Callers that match only a prefix, or whose route has fewer than two fixed words, are Low confidence and hidden unless `-IncludeLow`.

## How matching works (short)

* SOAP: contracts are identified by SOAP namespace + operation set (not by C# name); the host is the repo with the `.svc` / `<service>` / `ServiceHost` / implementing class.
  Consumers: generated proxies, `<client><endpoint>` config, `ChannelFactory<T>` / client classes (attributed to the right contract via local declaration or package reference), `.svc` URLs, operation calls.
* REST: controller actions (attribute routes, `[controller]` tokens, Web API 2 conventions, Minimal APIs) -> routes; consumers are URL string literals matched segment-wise,
  with the HTTP verb read from the surrounding code and host names checked when `hosts.csv` is given.

## Known limits - read before trusting "no consumers"

* Static analysis only: callers outside the scanned repos, URLs assembled from config/DB at runtime, and third parties are invisible. Confirm "No consumer found" with gateway/IIS logs.
* Regex-based parsing (comments/strings masked), not Roslyn. Routes are read from the code: literal `[Route]`/`[HttpGet]` templates, constants (`[Route(Routes.Employees)]`, concatenations) and `[Route]` inherited from a base controller are resolved when the constant / base class is in the same repo. Not resolved (flagged in Notes): constants from other repos or packages, interpolated/computed routes, actions inherited from a base controller, pure convention routing.
* Only the checked-out (default) branch of each repo is scanned.
* If a service's interface lives in a package whose source isn't among the repos, it is still found via its `.svc` / implementing class; its operation list is complete only if a consumer's generated proxy reveals it.

## Other scripts (the engine; normally not needed)

| Script | Purpose |
|---|---|
| `Build-UrlInventory.ps1` / `Find-HomeRepoUsage.ps1` / `EndpointScan.Facts.ps1` | the chunked inventory builder, its query tool and shared library (see above) |
| `Get-EndpointInventory.ps1` | scan all repos -> de-duplicated list of SOAP contracts / REST routes |
| `Find-EndpointUsage.ps1` | consumers for the inventory (detailed evidence CSVs) |
| `Find-ServiceConsumers.ps1` | one-shot engine used by `Find-ServiceUsage.ps1`; writes the full set of detailed CSVs |
| `Find-ServiceConsumers.GitHub.ps1` | same without cloning: GitHub code search + sparse download (limits: default branch, files < 384 KB, 1000 results/query, 10 searches/min) |
