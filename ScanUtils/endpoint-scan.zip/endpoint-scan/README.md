# Service usage toolkit

Two ways of working: a small estate (clone everything, search) or a huge one (build an inventory in batches, then query it). Keep all files in one folder; needs Windows PowerShell 5.1 or PowerShell 7+ and git.

## Thousands of repos / limited disk: build an inventory once, query it many times

Cloning everything is impossible (e.g. 3,400 repos on a small VDI) and re-cloning for every question would be slower still. So: harvest every repo ONCE, in batches, into a small inventory, then answer questions from it.

```powershell
# 1. Build the inventory (resumable; run it again to continue / retry failures; -Refresh to re-harvest)
$env:GITHUB_TOKEN = '<token>'          # or $env:AZURE_DEVOPS_PAT for Azure DevOps (PAT with Code: Read)
.\Build-UrlInventory.ps1 -BaseUrl https://github.com/contoso -InventoryPath D:\url-inventory -WorkPath D:\work -BatchSize 500 -MinFreeGB 10
.\Build-UrlInventory.ps1 -BaseUrl https://dev.azure.com/contoso/MyProject -InventoryPath D:\url-inventory -WorkPath D:\work     # Azure DevOps project
.\Build-UrlInventory.ps1 -FromFolder C:\Proj -InventoryPath D:\url-inventory -BatchSize 100                                   # repos you already have on disk

# 2. Which repos use what ONE repo exposes? (no cloning; ~2 min for 3,400 repos)
.\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepo Orders.Api -HostMapPath .\hosts.csv
.\Find-HomeRepoUsage.ps1 -InventoryPath D:\url-inventory -HomeRepoPath C:\Proj\Orders.Api -Service OrderController.cs,OrderService.svc
```

**Interrupted or timed out?** Just run the same command again. Every repo that already has an entry in `repos.csv` is skipped (not cloned again); progress is saved every `-CheckpointSize` repos (default 25), so at most that many are redone, and repos whose results were saved but never recorded in `repos.csv` are re-adopted automatically.
Failed repos are not retried unless you add `-RetryFailed`. Every git operation has a time limit (`-CloneTimeoutMinutes`, default 15) and a transfer slower than 1 KB/s for 2 minutes is aborted, so one stuck repo cannot freeze the run. If your session or job has a time limit, use `-MaxRunMinutes 50` (for example): the script stops cleanly after the current group and the next run continues. `urls-used.csv` / `endpoints-exposed.csv` are rebuilt when everything is done, or any time with `-MergeOnly`; `Find-HomeRepoUsage.ps1` reads the saved per-repo files directly, so it works on a partial inventory too.

**Looks stuck?** Each group of `-CheckpointSize` repos (default 25) is cloned before the next line is printed, so a slow server can mean a few minutes of quiet; the script now prints `cloning N repos ...` / `harvesting N repos ...` and shows a progress bar with the repo being cloned. To check it is alive: the folder `<WorkPath>\batch` should be growing (one sub-folder per repo being cloned) and `Get-Process git*` should list running git processes. A single stuck clone is aborted automatically after `-CloneTimeoutMinutes` (default 15, one retry) and recorded as failed; credential-manager pop-ups cannot block it (`credential.helper` is disabled for these clones and `GCM_INTERACTIVE=never`). Ctrl+C is safe: run the same command again. The reason a repo failed is in the `Message` column of `repos.csv`.

**What you see while it runs.** For every group of `-CheckpointSize` repos (default 25): a line per repo as soon as it is cloned (`[ 7/25] cloned  name  (8.4 s)` or `FAILED  name: reason`), then the harvest in three logged stages -
`harvest 1/3` (SOAP contracts, REST controllers, hosting and references), `harvest 2/3` (URLs used: one line per repo with its file count, URL facts and seconds, repos processed several at a time) and `harvest 3/3` (saving) - each with its duration,
a `saved:` line with the overall count and the estimated time left, and a `... still cloning / still collecting URLs / still scanning <repo>` heartbeat every 30 s (`-HeartbeatSeconds`) whenever something takes long. Per-repo engine detail goes to `build-inventory.log`.
**Speed.** URL collection (the slow part of the harvest) runs in compiled code and uses `-Parallel` repos at a time on PowerShell 7: on a test set of 4,600 files in 10 repos a group's harvest went from 108 s to 12 s with identical saved results. Very large repos are capped at 20,000 facts (`capped` is shown). The final rebuild of `urls-used.csv` takes a few minutes at your scale (or run it later with `-MergeOnly`).
**What counts as done.** A repo is skipped when it has a row in `repos.csv` (`ok`, `empty`, or `failed` unless `-RetryFailed`). Both directions are reconciled at the start of every run: results saved but no row -> the row is re-created; a row marked `ok` but its saved results missing -> the repo is harvested again (status `missing` until then).

**Log, lock and what `repos.csv` contains.** Every run appends to `build-inventory.log` in the inventory folder (parameters, one line per repo with the outcome, failures with the reason, skipped repos, warnings, errors, final summary; the token is never written). `repos.csv` has one row per repo of the server:
`ok` (harvested), `empty` (no commits), `failed` (reason in `Message`), or `skipped` (archived/disabled or a fork - a note only; these are processed if you add `-IncludeArchived` / `-IncludeForks`). A repo URL can be blank only for rows marked "recovered from saved files" (re-adopted after an interrupted run); the next run fills it in from the server's list.
Only one run can use an inventory folder at a time (`.build.lock`; a run that finds another one active refuses to start, a dead run's lock is ignored). If `repos.csv` is open in Excel the run does not stop: it warns, keeps going, and the next run adopts the saved results - but please open a *copy* of the file instead.

**Big repos and multithreading.** Cloning (`-Parallel`, default 4) and URL collection (`-HarvestParallel`, default = number of cores, max 6) run in a worker pool of several threads; this works on Windows PowerShell 5.1 as well as PowerShell 7. Files that cannot contain a URL are skipped without being parsed (XML such as Salesforce / SSIS metadata used to cost ~1.6 s per 300 KB file; now ~5 ms), and no single repo can block the run: `-MaxRepoMinutes` (default 10) stops reading one repo, keeps what it found and notes it in the log and in the `Message` column of `repos.csv`. While waiting, the heartbeat names the repos being worked on and the file each one is at (`Running: t260-sfdc-wmc-flosum (4.2 min: 8,200 of 41,000 files, 1,203 facts, now: force-app/.../x.xml)`). If a repo is flagged as stopped early, raise `-MaxRepoMinutes` and re-harvest just that repo with `-Refresh -Include <name>`.
**Deleting clones is instant:** a finished group's clones are renamed into `<WorkPath>\trash` and deleted by a separate process while the next group is already cloning (deleting a repo with 100,000+ files can take minutes on Windows); the run waits for these deletions only at its very end or when the disk is full.

**Angular / React / Vue / frontend projects.** They are scanned like any other repo: `.ts .tsx .js .jsx .mjs .cjs .vue .svelte .html .cshtml .razor` plus `environment*.json`, `.env`, `.env.production` (any `.env.*`) and `proxy*.json`.
* **What is recorded:** API calls with their HTTP verb - Angular `HttpClient` / wrapper services (`this.api.get('orders')`), `axios` (also an `axios.create({ baseURL })` instance: `http.get('/orders')`), `fetch` (the verb may be a few lines below: `method: 'PUT'`), `XMLHttpRequest.open('GET', ...)`, jQuery, Vue `request({ url, method })`, RTK Query (`query: () => '/orders'`), NSwag / OpenAPI generated clients, template literals (`` `${env.apiUrl}/orders/${id}` ``) and concatenation (`'/orders/' + id`). Short paths such as `/orders` are only recorded where the line clearly is an API call.
* **Base URLs** (`baseURL: '/api/v1'`, `apiUrl: 'https://host/gateway/api/v1'`, `.env` values) are recorded as `ApiBase`. `Find-HomeRepoUsage.ps1` combines each short call with the repo's base paths (`/orders` + `/api/v1` = `api/v1/orders`), also after removing a gateway / virtual-directory prefix (`/orders-api/api/v1/orders`), and as a last resort matches the end of a route (Low confidence).
* **Never read:** `node_modules`, `dist`, `.angular`, `.next`, `coverage`, minified / hashed build output (`main.4f3a2b1c.chunk.js`, very long lines), `*.d.ts`.
* **Deliberately not recorded** (not API calls): page navigation (Angular route tables `path: '...'`, `routerLink`, `navigate()`, `href`, React Router `<Route path>` / `<Link to>`, `history.push`) unless the same line makes an HTTP call, and test / mock files (`*.spec.*`, `*.test.*`, `__mocks__`, `cypress`, `stories`, `fixtures`).
* **Known limits:** a URL held in a variable far from the call (`this.http.get(this.base)`, `axios.get(ENDPOINTS.ORDERS)` with the string in another file) has no verb of its own - it is matched through the endpoint-constants file at Medium/Low depending on whether it looks like an API URL (`/api/...`, `/v1/...`, host). Base URLs that are only set at runtime (config fetched from the server) are not known. A frontend that goes through a BFF / proxy with different paths cannot be matched.
* **Frontend repos harvested by an older version of the scanner** have missing short-path calls. Do not rescan everything: `.\Build-UrlInventory.ps1 <same parameters> -RefreshFrontend` re-harvests only the repos that (a) were scanned before the update (recorded in `frontend-scanner.marker` in the inventory folder) and (b) show frontend code in their saved results; it does nothing a second time. A frontend repo whose saved results contain no frontend file at all is not detected - redo those with `-Refresh -Include 'name1','name2'`. Measured on a realistic test set (React with axios instance + RTK Query + fetch, Angular with wrapper service, Vue): 0 of 14 real calls found by the previous version, 9 of 14 with only the new `Find-HomeRepoUsage.ps1`, 14 of 14 after `-RefreshFrontend`; 0 false consumers.

**Upgrading the scripts while an inventory is in progress (nothing is reset).** Copy the new scripts over the old ones and run the same command: every repo that has an entry in `repos.csv` is skipped and its saved results are not touched (verified: 30 of 30 result files byte-for-byte unchanged, only the new repos were scanned). The file formats are unchanged, so old and new results live side by side in one inventory and `Find-HomeRepoUsage.ps1` reads both.
What an older harvest may contain that a newer one does not: (1) page-navigation paths and unit-test URLs from Angular / React repos - the query now ignores these when it reads the data (test / spec / mock files, `:param` route patterns, and frontend literals without an HTTP verb are Low confidence = hidden unless `-IncludeLow`), so no re-scan is needed; (2) older versions kept only the first HTTP verb when the same URL was called with several verbs in one file - a few `POST`/`PUT` callers may be missing for those repos; (3) `.env.production`-style files were not read. If these matter for specific repos, re-harvest only those: `.\Build-UrlInventory.ps1 ... -Refresh -Include 'repoA','repoB'` (repos with frontend code: `Import-Csv urls-used.csv | Where-Object { $_.File -match '\.(ts|tsx|js|jsx|vue)$' } | Select-Object -ExpandProperty Repo -Unique`).

**Stopping and restarting.** It is always safe to stop (Ctrl+C, closing the window, a timeout, even `kill -9`) and run the same command again.
* **Clones are reused, not downloaded again.** Clones left in `<WorkPath>\batch` by the interrupted run are *checked* (`git status` must be clean, HEAD valid, same remote, no `index.lock`) and reused: `[ 3/25] reused  name  (complete clone from the interrupted run ...)`. A clone that was cut off (after the clone, in the middle of the checkout, holding a lock) fails that check and is replaced; folders that are not needed are deleted. This also works for clones left by older versions of the script. **Copy the new scripts before you rerun** - an old script deletes them.
* **Nothing is lost or corrupted.** Every CSV is written to a temporary file and renamed into place, so a file is always either the old or the new complete version (a kill during a write leaves a `*.tmp` that the next run deletes). The three result files of a repo are renamed back to back and the set only counts as complete when all three exist. A damaged line in `repos.csv` is ignored and the repo is re-adopted from its saved results. Tested with 9 `kill -9` at random moments: no corrupt file, and the final result was identical to an uninterrupted run.
* The best moment to stop is right after a `saved:` line; at any other moment at most the current group of `-CheckpointSize` repos is redone (its clones are reused, so only the harvest).
* **Very large repos** (`-LargeRepoMB`, default 2048 MB as reported by the server) are cloned last, each on its own with `-LargeCloneTimeoutMinutes` (default 90 min), so a 4 GB repo never holds up a group of 25. If its clone is already on disk it is not deferred - it is reused right away. A clone that hits the limit is recorded as `failed` (reason in `Message`); retry it with `-RetryFailed -Include <name> -CloneTimeoutMinutes 180`.
* Which version am I running? The current one prints `Log file: ...` at the start and `reused` / `cloned` lines for every repo; an older one only prints `harvesting N repos ...`.
* Note: `Flags` in `endpoint-exposed` rows (e.g. `DefinedInMultipleRepos`) only reflect the repos that were in the same group during the harvest; `Find-HomeRepoUsage.ps1` recomputes duplicates across the whole inventory.

**What the batch loop does:** take the next N repos -> clone them shallow, single-branch and *sparse + partial* (only source/config files; binaries, images, `node_modules`, `bin/obj`, packages are never downloaded - about 25x smaller in my test) -> harvest -> save -> delete the clones. `-MinFreeGB` stops a batch early when the drive gets low; `-MaxBatchGB` caps a batch by the size the server reports.

**Inventory folder**

| File | Content |
|---|---|
| `urls-used.csv` | what each repo calls: `Repo, Url, Kind, Host, UrlPath, Verb, Detail, File, Line, Count, RepoLastCommit, ScannedAt` - kinds: `ConfigUrl` (XML + JSON config), `SoapClientEndpoint` (WCF `<client>`), `SoapProxy` (generated proxy), `ServiceUrl` (*.svc), `UrlLiteral` / `RouteLiteral` (code, frontend, scripts), `ClientType` (`ChannelFactory<T>` / `ClientBase<T>`) |
| `endpoints-exposed.csv` | what each repo exposes: SOAP contract / operation / `.svc` / wire namespace, REST verb + route + controller |
| `repos.csv` | one row per repo: url, branch, last commit, scan time, status (`ok`/`failed`/`empty`), row counts |
| `shards\` | the per-repo source files everything is built from (re-running a repo replaces its shard - no duplicates) |

`Find-HomeRepoUsage.ps1` writes `home-endpoints.csv` (every SOAP/REST endpoint the home repo exposes) plus the usual `service-usage.csv` / `service-summary.csv`.
SOAP is matched per **service** (the inventory does not record which operations are called); REST per **endpoint** (verb + route). Best workflow: let the inventory narrow 3,400 repos to the handful of consumers,
then clone just those (`Clone-GitHubRepos.ps1 -Include ...`) and run `Find-ServiceUsage.ps1` for operation-level detail.

Notes: needs git 2.25+ (the partial clone falls back automatically to a plain shallow clone if the server does not support it); parallel cloning needs PowerShell 7; the inventory is a snapshot - re-run (`-RefreshOlderThanDays 30`) to keep it current.

## Which repo hosts this service / endpoint?  (reverse lookup)

```powershell
.\Find-EndpointHome.ps1 -InventoryPath D:\url-inventory -Query Order.svc,'GET /api/v1/orders/5','https://api.contoso.com/orders-api/api/v1/orders'
.\Find-EndpointHome.ps1 -InventoryPath D:\url-inventory -QueryFile .\to-find.txt -HostMapPath .\hosts.csv
```

Give a WCF service (`OrderService.svc`, `OrderService`, `IOrderService`, a URL ending in `.svc`), a REST URL / route (`GET /api/v1/orders/5`, `/api/v1/orders/{id}`, a full URL) or a controller name (`OrdersController` -> all its endpoints); any mix, comma separated or one per line in a file. **Nothing is cloned or rescanned:** the answer comes from the inventory you already built - from the per-repo files `shards\*.exposed.csv` (what each repo exposes; the same data as `endpoints-exposed.csv`), *not* from `repos.csv`, which only lists the repos (it is used to show each repo's URL / last commit and to tell how much of the estate was harvested).
Output: `endpoint-home.csv` (Query, Kind, HomeRepo, Confidence, Role, Service, Contract, Endpoint, MatchedBy, File, Line, RepoUrl, LastCommit, Notes) plus a short summary on screen.
* **SOAP:** the repo that hosts the `.svc` file is High; a class / interface of that name is Medium; a repo that only declares the contract (shared library, copy) is shown as `ContractOnly`. Same-named but different services (different wire namespace) are listed separately and flagged. If no repo in the inventory hosts a `.svc` but others call it, you get the callers and the host names they use as leads.
* **REST:** the URL is matched segment by segment against every route of every controller / Minimal API (`{id}` matches any value; GET/POST... is honoured when given, otherwise every verb of the route is listed). A leading gateway / virtual-directory prefix that is not part of the controller route (`/orders-api/api/v1/orders`) is removed automatically (one confidence level lower). `-HostMapPath` (`Repo,Host`) confirms the repo when the URL's host belongs to it.
* **SOAP endpoints that do NOT end in `.svc`** (`https://host/rsax`, `.../services/PartyAcctRel-AcctList/TWY/OCC`, `:8432/webservice/Projects_X_WebInputProxy`): pass the URL as it is, or paste the WCF client line(s) from the config file - `-Query '<endpoint address="https://host/rsax" binding="basicHttpBinding" contract="FiBRS.Root.rootSoap" name="..."/>'`, or a whole `<client>` block in a `-QueryFile` (lines may wrap); the address AND the contract are used. Without `.svc` the filename says nothing, so the lookup uses what the harvest found in each repo's code, config and WSDL: the address a service is mounted at, and the contract / port type / service name. It matches by address (equal, base path, or the end of the path behind a gateway prefix), by the contract name the clients use (a WSDL port type such as `rootSoap` / `PartyAcctRelPortType` / `RTFTService_PortType` is also a name in the provider's WSDL or `@WebService`), and by host (`-HostMapPath`). The screen also shows which repos **call** the address and with which contract (`called by 2 repo(s): ...`). Use `-Soap` to stop a URL from also being tried as a REST route (automatic when a repo's WCF client config calls it).
  What the harvest recognises as a SOAP provider besides `.svc`: **WSDL** files (service / port / port type / address / operations); **ASMX** (`.asmx` + `[WebService]`); **.NET WCF** mounted with `ServiceRoute` / `MapServiceRoute`, `ServiceHost` + `AddServiceEndpoint`, CoreWCF `AddServiceEndpoint<T,C>`, or `<service><host><baseAddresses>` in config; **Java** `@WebService` / `@WebServiceProvider`, Spring-WS `@Endpoint` + `@PayloadRoot`, CXF `<jaxws:endpoint address=...>`, `sun-jaxws.xml`, `web.xml` mappings of CXF / Axis / Spring-WS servlets, Axis `services.xml` / `*.wsdd`. They are stored with the repo's exposed results (`Kind = SOAP`, role `Provider` = code or config serves it, `Wsdl` = a WSDL describes it); the other tools ignore them.
  How to read the answer: **High** = the code / config that serves the address (or address + contract agree); **Medium** = a WSDL (or only the name) matches - a WSDL in a repo is either the provider's own definition (typical for middleware / TIBCO / IBM projects) or a copy kept by a consumer, so repos that also call the address are pushed down; **leads** = if nothing declares the service, the repos that mention the address / host in configuration are listed (a deployment config of the host often names it).
  **This needs the improved scanner.** Repos harvested by an older version have no provider records: `.\Build-UrlInventory.ps1 <same parameters> -RefreshProviders` (older name: `-RefreshSoap`, still accepted) re-harvests only the older repos that are likely to host a service (a WCF or REST service, or a WSDL / ASMX / web.xml / pom.xml / helm / route / ingress file in their saved results); `-RefreshProvidersAll` re-harvests every older repo (needed for Java repos: their saved results cannot tell which have `@WebService` classes). Repos harvested since the update and everything else are left alone; a second run does nothing (`provider-scanner.marker` in the inventory folder). Not recognised: SOAP services built with other stacks that declare nothing in a file the harvest reads (TIBCO BW / IBM message flows without a WSDL in the repo, vendor products, node-soap / Python servers) - for those the leads (repos mentioning the host) are the starting point.
* **REST base URLs of outgoing calls** (`https://host/markitapi/v1`, `https://gis.host:7991/api/gis/CSDataRead/AcctClientInq/v1`, `https://apigw/ZT30/AccountEnquiryBypass/v2/`, `https://myapi-uat-n600.mtls.apps.ocp.host/v1/feature`): put one URL per line in a `-QueryFile` (a base without the operation part is fine) and run it like the others. The result is one row per hosting repo; a base URL shows how many endpoints sit under it (`2 endpoint(s) under this base: GET /v1/quotes/{symbol}; ...`). The evidence is added up as points, so signals that are individually weak can agree:
  - **the route**: a complete route match, or the URL being the base of the repo's routes (a gateway / virtual-directory prefix in front is tried);
  - **where the provider repo says it is mounted** (new in the harvest): `app.UsePathBase("/markitapi")`, `PathBase` / `basePath` / `contextPath` / `routePrefix` settings, `ASPNETCORE_PATHBASE`, Kubernetes / OpenShift / Helm ingress paths (`path: /ZT30/AccountEnquiryBypass`), and the host names of ingress / route / values files. A prefix that appears only there (not in any `[Route]`) is joined to the routes: `/markitapi` + `v1/quotes/{symbol}`;
  - **names**: the repo name or the controller name equals a word in the URL (host labels count: `featuretoggleapi-uat-n600...` -> repo `FeatureToggleApi`; environment words such as uat / qa / n600 / saifg / mtls are ignored);
  - `-HostMapPath` (`Repo,Host`) when you have one.
  The repos that already contain the URL in their own code / settings are listed as **callers** (`called by 3 repo(s): ...`), not as possible hosts; a repo that only mentions the host in a deployment-looking file (values / route / ingress / swagger / gateway) is shown as a lead when nothing declares the service. A shared gateway host (declared by more than 3 repos) is not treated as evidence for any one of them. Limits: a service whose routes are built at runtime, a gateway-only mapping that is not in the repo, and a base URL generic enough to match many repos (`/api/v1`) with no name or path-base evidence stay Low (hidden unless `-IncludeLow`).
* Not found? It suggests near names (`did you mean: OrderService.svc ...`). A repo that was not harvested yet (`failed`, `skipped`, not listed) cannot be found - the screen shows how many repos are missing from the inventory. Low-confidence matches are hidden unless `-IncludeLow`.

## Which repos integrate with an S3 bucket - and which are .NET Framework / .NET 7 / 8 / 10, most active first?

```powershell
$env:GITHUB_TOKEN = '<token that can read the repos>'          # or $env:AZURE_DEVOPS_PAT (Code: Read)
.\Find-S3Repos.ps1 -InventoryPath D:\url-inventory -S3 https://acme-docs.s3.amazonaws.com -Top 5 -OutputPath C:\work\s3
```

1. **Candidates** come from the inventory you already have (nothing is cloned or rescanned): the repos whose saved URL facts mention the bucket. Give the bucket as a URL, an `s3://` URI, an ARN or a bare name (several, comma separated or in `-S3File`); virtual-hosted (`bucket.s3.amazonaws.com`), path-style (`s3.region.amazonaws.com/bucket`) and regional / website endpoints are all understood. A key prefix (`s3://bucket/uploads/`) is reported as `MatchLevel = bucket+prefix`. A non-AWS address (MinIO, CloudFront / custom domain) is matched by host + path.
2. **Framework** - for every candidate the script reads the repo's file tree and project files **through the Git server API (no clone)**: GitHub / GitHub Enterprise (`/git/trees`, `/contents`) or Azure DevOps (`_apis/git/.../items`). The API root is derived from `RepoUrl` in `repos.csv` (override with `-ApiBase https://ghe.example.com/api/v3`; `-BaseUrl https://host/org` fills repos whose RepoUrl is empty). The project that **contains the S3 reference** is judged (nearest `*.csproj` / `*.vbproj` / `*.fsproj` above the file; `-RepoWide` = every project): `<TargetFramework(s)>` (multi-target `net48;net8.0` counts as both), `<TargetFrameworkVersion>v4.8</TargetFrameworkVersion>`, a framework set in `Directory.Build.props`, or - for sites without a project file - `web.config` / `app.config`. Result per repo: `.NET Framework 4.8`, `.NET 8`, `.NET Core 3.1`, `.NET Standard 2.0`, `not .NET (Node / Java / Python / Go)` ... `-TargetFramework` picks what you want: `NetFramework` (any 4.x), `Net5` ... `Net10`, `Core`, `Standard`, `Any`; **default `NetFramework, Net7, Net8, Net10`**. The `S3Sdk` column says whether a project references `AWSSDK.S3` (a second confirmation that the repo really talks to S3).
3. **Most frequently changed** - only the qualifying repos are measured: commits on the default branch in the last `-ActivityDays` (default 180) and, separately, commits that touch the files holding the S3 reference. `-RankBy Activity` (default) | `S3Activity` | `LastCommit` | `Evidence`; **`-Top N` keeps the N best** (0 = all).
4. **Output** in `-OutputPath`: `s3-repos.csv` (every candidate: rank, selected, framework, why excluded, commits, last commit, repo URL), `s3-evidence.csv` (repo / file / line / URL), `repos-to-clone.txt`, `clone-list.txt`, `clone-selected.ps1`; `-Clone -CloneTo D:\work\s3-repos` clones the selected repos.

* **What the inventory covers:** S3 references written as `https://` URLs (the usual form in appsettings / config / code). Bare `BucketName` settings, `s3://` URIs, ARNs and SDK-only usage are not URLs and are not in an inventory harvested by an older scanner: add **`-CodeSearch`** (GitHub / GitHub Enterprise code search for the bucket name; opt-in, rate limited) to find them without a rescan.
* **Token:** read access to the repos' contents (GitHub: `Contents: Read` / classic `repo`; Azure DevOps: `Code: Read`). Without a token private repos cannot be read and GitHub allows 60 anonymous calls per hour. A rejected token stops the run at once; a 403 / 429 rate limit is waited out using the server's own `Retry-After` / reset time.
* **Calls:** per candidate about 3 + (number of judged projects) calls, plus 4 commit queries for repos that pass the framework filter; `-MaxCandidates` (default 300) caps the number of repos analysed. `-NoFramework` skips the server altogether (just the list of repos).
* **Limits:** the framework is read from the default branch's project files (not from build output or CI settings); a huge repo whose file listing the server truncates is flagged `truncated tree`; "frequent changes" is a signal, not a measure of importance - look at `S3FileCommits` for how often the S3 code itself changes.

## Small estates: clone everything

### 1. Clone everything

```powershell
$env:GITHUB_TOKEN = '<token>'        # only needed for private repos / to avoid API limits
.\Clone-GitHubRepos.ps1 -BaseUrl https://github.com/contoso -TargetPath C:\Proj
```

Lists all repos of the org/user through the API and clones them (parallel on PowerShell 7). Shallow, single-branch (latest code only),
archived repos and forks skipped, existing clones left alone. Prints one summary line plus any failures.

| Option | Meaning |
|---|---|
| `-Update` | refresh existing clones (repos with local changes are never touched) |
| `-IncludeArchived` / `-IncludeForks` | include them |
| `-Include` / `-Exclude` | wildcards on repo names |
| `-Depth 0` | full history |
| `-ListOnly` | just list what would be cloned |

Token: fine-grained = Contents *Read-only* on the repos (public repos need no permissions); classic = `repo`. The token is passed to git through the environment only; it is never written to `.git/config`.
GitHub Enterprise Server works (`-BaseUrl https://git.contoso.com/platform`).

### 2. Find the usage

```powershell
# services of ONE repo (the usual case): name the repo once, list the services
.\Find-ServiceUsage.ps1 -HomeRepoPath C:\Proj\Orders.Api -Service OrderController.cs,EmployeeController.cs,OrderService.svc

# ... or leave -Service out: every SOAP service and controller in that repo is searched
.\Find-ServiceUsage.ps1 -HomeRepoPath C:\Proj\Orders.Api

# services from any repos (names must then be unambiguous; or write Name@Repo)
.\Find-ServiceUsage.ps1 -RootPath C:\Proj -Service OrderService.svc,InventoryService.svc,EmployeeController.cs,OrderController.cs
.\Find-ServiceUsage.ps1 -RootPath C:\Proj -ServiceList .\services.txt -OutputPath C:\reports -HostMapPath .\hosts.csv
```

`-HomeRepoPath` = full path of the repo that hosts the services. It must be one of the cloned repos (inside `-RootPath`, which defaults to its parent folder);
a sub-folder of a repo means that repo. All names in `-Service` are taken from it, same-named services in other repos are ignored, and the search covers the home repo
itself (its own frontend) and every other repo.

Input: names, file names or full paths (comma separated and/or a list file, one per line). `X.svc` / `X.cs` match files of that type,
a bare name also matches interface / class / controller names.

**Output: exactly two files** in `-OutputPath` (default: current folder):

| File | Content |
|---|---|
| `service-usage.csv` | one row per service x consuming repo: HostedBy, Confidence, EndpointsUsed (SOAP operations / REST verb+route), Evidence, Example (file:line) |
| `service-summary.csv` | one row per service: HostedBy, Contract, Endpoints, Consumers, ConsumerRepos, EndpointsNotSeenUsed, Notes; plus a row for every input that matched nothing |

Only **High/Medium** confidence consumers are listed. Weak candidates are hidden and counted in Notes (`-IncludeLow` shows them).
`-Detail` adds `service-usage-evidence.csv` (file, line, code snippet per consumer).

Working files live in a cache outside your repo folder and outside the output folder (`%LOCALAPPDATA%\endpoint-scan`).
It is reused between runs and refreshed automatically when any repo's HEAD changed. `-Rescan` forces a refresh, `-NoCache` deletes it afterwards.

`hosts.csv` (optional, recommended): tells the tool which host name belongs to which hosting repo. It confirms REST/SOAP matches and separates
identical routes/interface names in *different* services.

```
Repo,Host
Orders.Api,orders.contoso.com
Orders.Service,orders.contoso.com;orders-internal.contoso.local
```

### Home repo, duplicates and usage inside the home repo

* Routes / operations are read from the code of the home repo - nothing has to be supplied by hand. With **`-HomeRepoPath`** the metadata comes only from that repo.
* Without `-HomeRepoPath`, the hosting repo is discovered automatically. If the same name exists in several repos (e.g. `OrderController.cs` in two repos) each is reported as its own
  service with its own `HostedBy`, and a note says so. Pick one with **`Name@Repo`** (`OrderController.cs@Orders.Api`), a full path, or `-InRepo <repo folder name>`.
* Usage **inside the home repo** is reported too (it is labelled `Orders.Api (home)`), because a frontend living next to the API is a real consumer. `-ExcludeHome` leaves it out.
  The controller's own attribute/route lines, tests, `swagger.json`/`openapi.*`, `launchSettings.json`, markdown docs and build output (`dist`, `node_modules`, `*.min.js`) are never counted.
  For SOAP, inside the home repo only client-side use counts (own generated proxy, `<client>` endpoint config); the implementation, host config and wiring are not consumers.
* Frontend code is scanned: `.js .jsx .ts .tsx .vue .svelte .html .cshtml .razor .aspx` - Angular `http.get<T>(\`/api/x/${id}\`)`, axios/fetch/jQuery, NSwag clients, `"/api/x/" + id`.
  The HTTP verb is taken from the surrounding lines (`axios.delete`, `method: 'POST'`, `type: 'DELETE'`, `HttpMethod.Put`, `PostAsJsonAsync`, Refit attributes ...).

## What is discovered for a REST controller

Give a controller (`EmployeeController`, `EmployeeController.cs`, or leave `-Service` out for the whole repo) and every endpoint (verb + full route) of it is listed, then searched for.
Found: `[HttpGet/Post/Put/Delete/Patch/Head/Options]` with or without a template (`[HttpGet("{id:int}")]`, `[HttpGet(template: "x")]`), several stacked verb attributes on one method
(each becomes its own endpoint), `[Route]` on the method, `[AcceptVerbs]`, class-level `[Route("api/[controller]")]` / `[RoutePrefix]`, API versioning (`api/v{version:apiVersion}/...` matches `/api/v1/...`),
routes from constants (`[Route(Routes.Employees)]`), routes inherited from a base controller, controllers split over several files (`partial`), Web API 2 convention actions (`GetAll` -> `GET api/employee`) and Minimal APIs (`MapGet/MapPost/MapGroup`).
Ignored on purpose: `[NonAction]`, non-public methods, public methods with no HTTP attribute in an ASP.NET Core controller (they are not endpoints).
Not resolved (flagged `UnresolvedRoute` / `ConventionRoute` in the Notes column): constants defined in another repo, computed/interpolated routes, actions inherited from a base controller, MVC conventional routing without attributes.

How callers are recognised: a URL/route string in code, frontend files or config whose segments match the route (`{id}` matches anything; a caller's runtime placeholder never matches a fixed word of another route),
the HTTP verb read from the surrounding code (`http.put`, `PutAsJsonAsync`, `method: 'DELETE'`, ...), `"api/v1/employee/" + id` counts as the full `{id}` route. Callers that match only a prefix, or whose route has fewer than two fixed words, are Low confidence and hidden unless `-IncludeLow`.

## How matching works (short)

* SOAP: contracts are identified by SOAP namespace + operation set (not by C# name); the host is the repo with the `.svc` / `<service>` / `ServiceHost` / implementing class.
  Consumers: generated proxies, `<client><endpoint>` config, `ChannelFactory<T>` / client classes (attributed to the right contract via local declaration or package reference), `.svc` URLs, operation calls.
* REST: controller actions (attribute routes, `[controller]` tokens, Web API 2 conventions, Minimal APIs) -> routes; consumers are URL string literals matched segment-wise,
  with the HTTP verb read from the surrounding code and host names checked when `hosts.csv` is given.

## Known limits - read before trusting "no consumers"

* Static analysis only: callers outside the scanned repos, URLs assembled from config/DB at runtime, and third parties are invisible. Confirm "No consumer found" with gateway/IIS logs.
* Regex-based parsing (comments/strings masked), not Roslyn. Routes are read from the code: literal `[Route]`/`[HttpGet]` templates, constants (`[Route(Routes.Employees)]`, concatenations) and `[Route]` inherited from a base controller are resolved when the constant / base class is in the same repo. Not resolved (flagged in Notes): constants from other repos or packages, interpolated/computed routes, actions inherited from a base controller, pure convention routing.
* Only the checked-out (default) branch of each repo is scanned.
* If a service's interface lives in a package whose source isn't among the repos, it is still found via its `.svc` / implementing class; its operation list is complete only if a consumer's generated proxy reveals it.

## Other scripts (the engine; normally not needed)

| Script | Purpose |
|---|---|
| `Build-UrlInventory.ps1` / `Find-HomeRepoUsage.ps1` / `Find-EndpointHome.ps1` / `EndpointScan.Facts.ps1` | the chunked inventory builder, its query tool and shared library (see above) |
| `Get-EndpointInventory.ps1` | scan all repos -> de-duplicated list of SOAP contracts / REST routes |
| `Find-EndpointUsage.ps1` | consumers for the inventory (detailed evidence CSVs) |
| `Find-ServiceConsumers.ps1` | one-shot engine used by `Find-ServiceUsage.ps1`; writes the full set of detailed CSVs |
| `Find-ServiceConsumers.GitHub.ps1` | same without cloning: GitHub code search + sparse download (limits: default branch, files < 384 KB, 1000 results/query, 10 searches/min) |
